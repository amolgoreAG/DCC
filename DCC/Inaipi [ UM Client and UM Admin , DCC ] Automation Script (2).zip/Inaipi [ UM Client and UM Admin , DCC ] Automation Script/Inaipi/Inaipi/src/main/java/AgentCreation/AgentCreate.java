package AgentCreation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;

import UtilsLayerPackage.ExcelReader;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AgentCreate {

	private static WebDriver driver; 
	
	public static void main(String[] args) throws InterruptedException {
//		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(option);
//		WebDriverManager.edgedriver().setup();
//		EdgeOptions option = new EdgeOptions();
//		option.addArguments("--remote-allow-origins=*");
//		option.addArguments("--ignore-certificate-errors");
//		driver = new EdgeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\DCC_EXCEL\\AgentCreation.xlsx");
		String url = excel.getDataFromExcelSheet(0, 6, 0);
		driver.get(url);
		String username = excel.getDataFromExcelSheet(0, 2, 0);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys(username);
		
		String password = excel.getDataFromExcelSheet(0, 3, 0);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(password);

		driver.findElement(By.xpath("//span[text()='LOGIN']")).click();
		
		driver.findElement(By.xpath("//span[text()='User Creation']")).click();
		int row = excel.countRow(1);
		System.out.println(row);
		int column = excel.countCell(1);
		System.out.println(column);
		for(int i = 1032 ; i <= 1516 ; i++) {
		Thread.sleep(2000);
		WebElement fname = driver.findElement(By.xpath("//input[@id='firstName']"));
		new Actions(driver).click(fname).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		fname.sendKeys(excel.getDataFromExcelSheet(2, i, 0));
		Thread.sleep(200);
		WebElement lastname = driver.findElement(By.xpath("//input[@id='lastName']"));
		new Actions(driver).click(lastname).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		lastname.sendKeys(excel.getDataFromExcelSheet(2, i, 1));
		Thread.sleep(200);
		WebElement email = driver.findElement(By.xpath("//input[@id='email']"));
		new Actions(driver).click(email).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		email.sendKeys(excel.getDataFromExcelSheet(2, i, 2));
		Thread.sleep(200);
		WebElement contactNumber = driver.findElement(By.xpath("//input[@id='contactNumber']"));
		new Actions(driver).click(contactNumber).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		contactNumber.sendKeys(excel.getDataFromExcelSheet(2, i, 3));
		Thread.sleep(200);
		WebElement passwords = driver.findElement(By.xpath("//input[@id='password']"));
		new Actions(driver).click(passwords).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		passwords.sendKeys(excel.getDataFromExcelSheet(2, i, 4));
		Thread.sleep(200);
		WebElement confirmpasswords = driver.findElement(By.xpath("//input[@id='confirmPassword']"));
		new Actions(driver).click(confirmpasswords).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		confirmpasswords.sendKeys(excel.getDataFromExcelSheet(2, i, 5));
		Thread.sleep(200);
		WebElement clientRole = driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[7]/div[1]/div[2]/div"));
		new Actions(driver).click(clientRole).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		clientRole.click();
		Thread.sleep(1200);
		String clientName = excel.getDataFromExcelSheet(2, i, 6);
		driver.findElement(By.xpath("//span[text()='"+clientName+"']")).click();
		
		Thread.sleep(500);
		WebElement clientGroup = driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[8]/div[1]/div[2]/div"));
		new Actions(driver).click(clientGroup).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		clientGroup.click();
		Thread.sleep(1200);
		String clientGroupname = excel.getDataFromExcelSheet(2, i, 7);
		driver.findElement(By.xpath("//span[text()='"+clientGroupname+"']")).click();
		Thread.sleep(500);
		WebElement channel = driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[10]/div[1]/div[2]/div"));
		new Actions(driver).click(channel).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		channel.click();
		Thread.sleep(1200);
		String channelName = excel.getDataFromExcelSheet(2, i, 8);
		driver.findElement(By.xpath("//span[text()='"+channelName+"']")).click();
		Thread.sleep(500);
		WebElement subChannel = driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[11]/div[1]/div[2]/div"));
		new Actions(driver).click(subChannel).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		subChannel.click();
		Thread.sleep(1200);
		String subChannelName = excel.getDataFromExcelSheet(2, i, 9);
		driver.findElement(By.xpath("(//span[text()='"+subChannelName+"'])[2]")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[12]/div/div[1]/span[2]/button")).click();
		Thread.sleep(500);
		WebElement addskill = driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[12]/div/div[2]/div/div[1]/div/div"));
		new Actions(driver).click(addskill).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		addskill.click();
		Thread.sleep(1000);
		String addskillName = excel.getDataFromExcelSheet(2, i, 10);
		driver.findElement(By.xpath("//span[text()='"+addskillName+"']")).click();
		Thread.sleep(500);
		WebElement addskillProf = driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[12]/div/div[2]/div/div[2]/div/div"));
		new Actions(driver).click(addskillProf).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		addskillProf.click();
		Thread.sleep(500);
		String addskillProfName = excel.getDataFromExcelSheet(2, 10, 11);
		driver.findElement(By.xpath("//span[text()='"+addskillProfName+"']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[13]/div/div[1]/span[2]/button")).click();
		Thread.sleep(500);
		WebElement addLanguage = driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[13]/div/div[2]/div/div[1]/div/div"));
		new Actions(driver).click(addLanguage).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		addLanguage.click();
		Thread.sleep(1200);
		String addLanguageName = excel.getDataFromExcelSheet(2, i, 12);
		driver.findElement(By.xpath("//span[text()='"+addLanguageName+"']")).click();
		Thread.sleep(500);
		WebElement addLanguageProf = driver.findElement(By.xpath("//div[@class='text-left square-text']/div[1]/div[13]/div/div[2]/div/div[2]/div/div"));
		new Actions(driver).click(addLanguageProf).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		addLanguageProf.click();
		Thread.sleep(500);
		String addLanguageProfName = excel.getDataFromExcelSheet(2, 10, 13);
		driver.findElement(By.xpath("//span[text()='"+addLanguageProfName+" ']")).click();
		Thread.sleep(500);
//		driver.findElement(By.xpath("//span[text()='Clear']")).click();
//		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='Create User']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//li[@id='3']")).click();
		Thread.sleep(500);
		driver.findElement(By.xpath("//span[text()='User Creation']")).click();
		Thread.sleep(500);
		}
	}

}
