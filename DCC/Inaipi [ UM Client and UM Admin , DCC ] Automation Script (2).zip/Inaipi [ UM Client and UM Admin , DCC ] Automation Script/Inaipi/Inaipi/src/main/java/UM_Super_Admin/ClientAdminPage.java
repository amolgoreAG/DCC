package UM_Super_Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class ClientAdminPage extends BaseClass {

	@FindBy(xpath = "//span[text()='Client Admin']")
	WebElement clientAdmin;
	
	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select m')]")
	WebElement selectClient;
	
	@FindBy(xpath = "//span[text()='View']")
	WebElement view;
	
	@FindBy(xpath = "//span[text()='Add Admin']")
	WebElement addAdmin;
	
	@FindBy(xpath = "//input[@id='firstName']")
	WebElement firstName;
	
	@FindBy(xpath = "//input[@id='lastName']")
	WebElement lastName;
	
	@FindBy(xpath = "//input[@id='email']")
	WebElement email;
	
	@FindBy(xpath = "//input[@id='contactNumber']")
	WebElement contactNumber;
	
	@FindBy(xpath = "//input[@id='password']")
	WebElement adminPassword;
	
	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[5]/div/div[2]/div/div/div//*[@class='MuiSvgIcon-root']")
	WebElement adminPasswordShow;
	
	@FindBy(xpath = "//input[@id='confirmPassword']")
	WebElement adminConfirmPassword;
	
	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[6]/div/div[2]/div/div/div//*[@class='MuiSvgIcon-root']")
	WebElement adminConfirmPasswordShow;
	
	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement adminCancel;
	
	@FindBy(xpath = "//span[text()='ADD ADMIN']")
	WebElement adminAddAdmin;
	
	@FindBy(xpath = "//span[text()='EDIT ADMIN']")
	WebElement updateAddAdmin;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]//tbody/tr[1]/td[4]//*[@title='Edit Client']")
	WebElement editAdmin;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]//tbody/tr[1]/td[4]//label/span[1]")
	WebElement adminStatus;
	
	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiIconButton-root float-r']/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement close;

	public ClientAdminPage() {
		PageFactory.initElements(driver, this);
	}
	public boolean displayStatusOfclientAdmin1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clientAdmin, "clientAdmin");
		return clientAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfclientAdmin1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clientAdmin, "clientAdmin");
		return clientAdmin.isEnabled();
	}
	
	public void clickOnclientAdmin1() throws InterruptedException {
		clientAdmin.click();
	}
	public boolean displayStatusOfselectClient1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectClient, "selectClient");
		return selectClient.isDisplayed();
	}
	
	public boolean enableStatusOfselectClient1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectClient, "selectClient");
		return selectClient.isEnabled();
	}
	
	public void clickOnselectClient1andSelectAdminFromDP(String ClientName) throws InterruptedException {
		selectClient.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='"+ClientName+"']")).click();
	}
	public boolean displayStatusOfview1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(view, "view");
		return view.isDisplayed();
	}
	
	public boolean enableStatusOfview1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(view, "view");
		return view.isEnabled();
	}
	
	public void clickOnview1() throws InterruptedException {
		view.click();
	}
	public boolean displayStatusOfaddAdmin1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(addAdmin, "addAdmin");
		return addAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfaddAdmin1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(addAdmin, "addAdmin");
		return addAdmin.isEnabled();
	}
	
	public void clickOnaddAdmin1() throws InterruptedException {
		addAdmin.click();
	}
	public boolean displayStatusOffirstName1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(firstName, "firstName");
		return firstName.isDisplayed();
	}
	
	public boolean enableStatusOffirstName1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(firstName, "firstName");
		return firstName.isEnabled();
	}
	
	public void enterDataInfirstName1(String FirstName) throws InterruptedException {
		firstName.sendKeys(FirstName);
	}
	public boolean displayStatusOflastName1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(lastName, "lastName");
		return lastName.isDisplayed();
	}
	
	public boolean enableStatusOflastName1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(lastName, "lastName");
		return lastName.isEnabled();
	}
	
	public void enterDataInlastName1(String LastName) throws InterruptedException {
		lastName.sendKeys(LastName);
	}
	public boolean displayStatusOfemail1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(email, "email");
		return email.isDisplayed();
	}
	
	public boolean enableStatusOfemail1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(email, "email");
		return email.isEnabled();
	}
	
	public void enterDataInemail1(String Email) throws InterruptedException {
		email.sendKeys(Email);
	}
	public boolean displayStatusOfcontactNumber1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(contactNumber, "contactNumber");
		return contactNumber.isDisplayed();
	}
	
	public boolean enableStatusOfcontactNumber1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(contactNumber, "contactNumber");
		return contactNumber.isEnabled();
	}
	
	public void enterDataIncontactNumber1(String ContactNumber) throws InterruptedException {
		contactNumber.sendKeys(ContactNumber);
	}
	public boolean displayStatusOfadminPassword1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminPassword, "adminPassword");
		return adminPassword.isDisplayed();
	}
	
	public boolean enableStatusOfadminPassword1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminPassword, "adminPassword");
		return adminPassword.isEnabled();
	}
	
	public void enterDataInadminPassword1(String AdminPassword) throws InterruptedException {
		adminPassword.sendKeys(AdminPassword);
	}
	public boolean displayStatusOfadminPasswordShow1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminPasswordShow, "adminPasswordShow");
		return adminPasswordShow.isDisplayed();
	}
	
	public boolean enableStatusOfadminPasswordShow1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminPasswordShow, "adminPasswordShow");
		return adminPasswordShow.isEnabled();
	}
	
	public void clickOnadminPasswordShow1() throws InterruptedException {
		try {
			adminPasswordShow.click();
		} catch (Exception e) {
			new Actions(driver).click(adminPasswordShow).build().perform();
		}
	}
	public boolean displayStatusOfadminConfirmPassword1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminConfirmPassword, "adminConfirmPassword");
		return adminConfirmPassword.isDisplayed();
	}
	
	public boolean enableStatusOfadminConfirmPassword1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminConfirmPassword, "adminConfirmPassword");
		return adminConfirmPassword.isEnabled();
	}
	
	public void enterDataInadminConfirmPassword1(String AdminConfirmPassword) throws InterruptedException {
		adminConfirmPassword.sendKeys(AdminConfirmPassword);
	}
	public boolean displayStatusOfadminConfirmPasswordShow1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminConfirmPasswordShow, "adminConfirmPasswordShow");
		return adminConfirmPasswordShow.isDisplayed();
	}
	
	public boolean enableStatusOfadminConfirmPasswordShow1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminConfirmPasswordShow, "adminConfirmPasswordShow");
		return adminConfirmPasswordShow.isEnabled();
	}
	
	public void clickOnadminConfirmPasswordShow1() throws InterruptedException {
		try {
			adminConfirmPasswordShow.click();
		} catch (Exception e) {
			new Actions(driver).click(adminConfirmPasswordShow).build().perform();

		}
	}
	public boolean displayStatusOfclose2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfclose2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnclose2() throws InterruptedException {
		try {
			close.click();
		} catch (Exception e) {
			new Actions(driver).click(close).build().perform();

		}
	}
	public boolean displayStatusOfadminCancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminCancel, "adminCancel");
		return adminCancel.isDisplayed();
	}
	
	public boolean enableStatusOfadminCancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminCancel, "adminCancel");
		return adminCancel.isEnabled();
	}
	
	public void clickOnadminCancel() throws InterruptedException {
		try {
			adminCancel.click();
		} catch (Exception e) {
			new Actions(driver).click(adminCancel).build().perform();

		}
	}
	public boolean displayStatusOfadminAddAdmin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminAddAdmin, "adminAddAdmin");
		return adminAddAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfadminAddAdmin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminAddAdmin, "adminAddAdmin");
		return adminAddAdmin.isEnabled();
	}
	
	public void clickOnadminAddAdmin() throws InterruptedException {
		try {
			adminAddAdmin.click();
		} catch (Exception e) {
			new Actions(driver).click(adminAddAdmin).build().perform();

		}
	}
	public boolean displayStatusOfeditAdmin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(editAdmin, "editAdmin");
		return editAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfeditAdmin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(editAdmin, "editAdmin");
		return editAdmin.isEnabled();
	}
	
	public void clickOneditAdmin() throws InterruptedException {
		try {
			new Actions(driver).click(editAdmin).build().perform();
		} catch (Exception e) {
			editAdmin.click();
		}
	}
	public boolean displayStatusOfedit_firstName1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(firstName, "firstName");
		return firstName.isDisplayed();
	}
	
	public boolean enableStatusOfedit_firstName1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(firstName, "firstName");
		return firstName.isEnabled();
	}
	
	public void enterDataInedit_firstName1() throws InterruptedException {
		firstName.click();
		String FirstName = firstName.getAttribute("value");
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		firstName.sendKeys(FirstName);
	}
	public boolean displayStatusOfedit_lastName1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(lastName, "lastName");
		return lastName.isDisplayed();
	}
	
	public boolean enableStatusOfedit_lastName1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(lastName, "lastName");
		return lastName.isEnabled();
	}
	
	public void enterDataInedit_lastName1() throws InterruptedException {
		lastName.click();
		String LastName = lastName.getAttribute("value");
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		lastName.sendKeys(LastName);
	}
	public boolean displayStatusOfedit_email1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(email, "email");
		return email.isDisplayed();
	}
	
	public boolean enableStatusOfedit_email1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(email, "email");
		return email.isEnabled();
	}
	
	public void enterDataInedit_email1() throws InterruptedException {
		email.click();
		String Email = email.getAttribute("value");
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		email.sendKeys(Email);
	}
	public boolean displayStatusOfedit_contactNumber1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(contactNumber, "contactNumber");
		return contactNumber.isDisplayed();
	}
	
	public boolean enableStatusOfedit_contactNumber1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(contactNumber, "contactNumber");
		return contactNumber.isEnabled();
	}
	
	public void enterDataInedit_contactNumber1(String ContactNumber) throws InterruptedException {
		contactNumber.click();
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		contactNumber.sendKeys(ContactNumber);
	}
	public boolean displayStatusOfedit_close2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfedit_close2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnedit_close2() throws InterruptedException {
		try {
			close.click();
		} catch (Exception e) {
			new Actions(driver).click(close).build().perform();

		}
	}
	public boolean displayStatusOfedit_adminCancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminCancel, "adminCancel");
		return adminCancel.isDisplayed();
	}
	
	public boolean enableStatusOfedit_adminCancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminCancel, "adminCancel");
		return adminCancel.isEnabled();
	}
	
	public void clickOnedit_adminCancel() throws InterruptedException {
		try {
			adminCancel.click();
		} catch (Exception e) {
			new Actions(driver).click(adminCancel).build().perform();

		}
	}
	public boolean displayStatusOfedit_updateAddAdmin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(updateAddAdmin, "updateAddAdmin");
		return updateAddAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfedit_updateAddAdmin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(updateAddAdmin, "updateAddAdmin");
		return updateAddAdmin.isEnabled();
	}
	
	public void clickOnedit_updateAddAdmin() throws InterruptedException {
		try {
			updateAddAdmin.click();
		} catch (Exception e) {
			new Actions(driver).click(updateAddAdmin).build().perform();

		}
	}
	public boolean displayStatusOfadminAddAdminStatus() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminStatus, "adminStatus");
		return adminStatus.isDisplayed();
	}
	
	public boolean enableStatusOfadminAddAdminStatus() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminStatus, "adminStatus");
		return adminStatus.isEnabled();
	}
	
	public void clickOnadminAddAdminStatus() throws InterruptedException {
		try {
			adminStatus.click();
		} catch (Exception e) {
			new Actions(driver).click(adminStatus).build().perform();

		}
		Thread.sleep(3000);
		try {
			adminStatus.click();
		} catch (Exception e) {
			new Actions(driver).click(adminStatus).build().perform();

		}
	}
}
