package UtilsLayerPackage;

import java.util.Random;

public class RandomIntData {

	public static int randomInt() {
		Random random = new Random();
		return random.nextInt(9999);
	}

}
