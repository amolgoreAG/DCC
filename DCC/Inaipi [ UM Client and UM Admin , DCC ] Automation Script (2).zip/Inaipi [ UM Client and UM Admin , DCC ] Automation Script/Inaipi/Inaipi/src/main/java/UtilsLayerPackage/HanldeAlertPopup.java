package UtilsLayerPackage;

import BaseLayerPackage.BaseClass;

public class HanldeAlertPopup extends BaseClass {

	public static void click_On_Ok_Button() {
		driver.switchTo().alert().accept();
	}

	public static void click_On_Cancel_Button() {
		driver.switchTo().alert().dismiss();
	}

	public static void send_Data_in_Alert_Popup(String text) {
		driver.switchTo().alert().sendKeys(text);
	}

	public static void getText_From_Alert_Popup() {
		driver.switchTo().alert().getText();
	}
}
