package AgentCreation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import UtilsLayerPackage.ExcelReader;

public class checkAgentDisconnectOrNot {

	private static WebDriver driver ; 
	private static WebDriverWait wait ; 
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(option);
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		driver.get("https://dcc.aws.inaipi.ae/?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
		
		for(int j=14 ; j<=130 ; j++) {
			Thread.sleep(2000);
			driver.navigate().to("https://dcc.inaipi.ae/?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");	
		Thread.sleep(3000);
		WebElement username = driver.findElement(By.xpath("(//input[@id='exampleFormControlInput1'])[1]"));
		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\AgentCreation.xlsx");
		int row = excel.countRow(1);
		System.out.println(row);
		int column = excel.countCell(1);
		System.out.println(column);
		
		username.sendKeys(excel.getDataFromExcelSheet(1, j, 2));
//		Thread.sleep(1500);
		WebElement password = driver.findElement(By.xpath("(//input[@id='exampleFormControlInput1'])[2]"));
		wait.until(ExpectedConditions.visibilityOfAllElements(password));
		password.sendKeys("Welcome@123");
//		Thread.sleep(1500);
		WebElement login = driver.findElement(By.xpath("//button[@id='connectSocket']"));
		wait.until(ExpectedConditions.visibilityOfAllElements(login));
		login.click();
		Thread.sleep(2000);
		String url = driver.getCurrentUrl();
		System.out.println(url);
		if(url.equalsIgnoreCase("https://dcc.inaipi.ae/dashboard")) {
		WebElement chat = driver.findElement(By.xpath("//a[@id='chat_chat_agent']/button//*[@stroke='currentColor']"));
		chat.click();
				try{
//				Thread.sleep(1500);
				WebElement acceptCall1 = driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i"));
				wait.until(ExpectedConditions.visibilityOfAllElements(acceptCall1));
				Thread.sleep(4000);
				if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
					driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
					Thread.sleep(1500);
				}else {
					System.out.println("No Call :  1");
				}
				Thread.sleep(1500);
				if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
					driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
					Thread.sleep(1500);
				}else {
					System.out.println("No Call :  2");
				}
				Thread.sleep(1500);
				if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
					driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
					Thread.sleep(1500);
				}else {
					System.out.println("No Call :  3");
				}
				Thread.sleep(1500);
				if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
					driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
					Thread.sleep(1500);
				}else {
					System.out.println("No Call :  4");
				}
				Thread.sleep(1500);
				if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
					driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
					Thread.sleep(1500);
				}else {
					System.out.println("No Call :  5");
				}} catch (Exception e) {
					System.err.println("There is no any call");
				}
//				Thread.sleep(1500);
				WebElement startchat1 = driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]"));
				wait.until(ExpectedConditions.visibilityOfAllElements(startchat1));
				Thread.sleep(4000);
				try {
				if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
					Thread.sleep(1500);
					driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
					Thread.sleep(1500);
					WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
					new Actions(driver).click(endchat).build().perform();
					Thread.sleep(1500);
					WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
					Thread.sleep(1500);
					new Select(reason).selectByVisibleText("Disconnected");
					Thread.sleep(1500);
					WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(comment));
					comment.sendKeys("No Comment");
					Thread.sleep(1500);
					WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(submit));
					submit.click();
					Thread.sleep(1500);
				}else {
					System.out.println("No chat :  1");
				}
				Thread.sleep(1500);
				if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
					Thread.sleep(2500);
					driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
					Thread.sleep(1500);
					WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
					new Actions(driver).click(endchat).build().perform();
					Thread.sleep(1500);
					WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
					Thread.sleep(1500);
					new Select(reason).selectByVisibleText("Disconnected");
					Thread.sleep(1500);
					WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(comment));
					comment.sendKeys("No Comment");
					Thread.sleep(1500);
					WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(submit));
					submit.click();
					Thread.sleep(1500);
				}else {
					System.out.println("No chat :  2");
				}
				Thread.sleep(1500);
				if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
					Thread.sleep(2500);
					driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
					Thread.sleep(1500);
					WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
					new Actions(driver).click(endchat).build().perform();
					Thread.sleep(1500);
					WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
					Thread.sleep(1500);
					new Select(reason).selectByVisibleText("Disconnected");
					Thread.sleep(1500);
					WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(comment));
					comment.sendKeys("No Comment");
					Thread.sleep(1500);
					WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(submit));
					submit.click();
					Thread.sleep(1500);
				}else {
					System.out.println("No chat :  3");
				}
				Thread.sleep(1500);
				if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
					Thread.sleep(2500);
					driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
					Thread.sleep(1500);
					WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
					new Actions(driver).click(endchat).build().perform();
					Thread.sleep(1500);
					WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
					Thread.sleep(1500);
					new Select(reason).selectByVisibleText("Disconnected");
					Thread.sleep(1500);
					WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(comment));
					comment.sendKeys("No Comment");
					Thread.sleep(1500);
					WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(submit));
					submit.click();
					Thread.sleep(1500);
				}else {
					System.out.println("No chat :  4");
				}
				Thread.sleep(1500);
				if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
					Thread.sleep(2500);
					driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
					Thread.sleep(1500);
					WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
					new Actions(driver).click(endchat).build().perform();
					Thread.sleep(1500);
					WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
					Thread.sleep(1500);
					new Select(reason).selectByVisibleText("Disconnected");
					Thread.sleep(1500);
					WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(comment));
					comment.sendKeys("No Comment");
					Thread.sleep(1500);
					WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
					wait.until(ExpectedConditions.visibilityOfAllElements(submit));
					submit.click();
					Thread.sleep(1500);
				}else {
					System.out.println("No chat :  5");
				}

			} catch (Exception e) {
				System.err.println("There is no any chat");
			}
			

		driver.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--connected ']")).click();
		Thread.sleep(1500);
		driver.findElement(By.xpath("//div[@class='sign-out']")).click();
		Thread.sleep(1500); 
		}
		else {
			Thread.sleep(1500);
			WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
			wait.until(ExpectedConditions.visibilityOfAllElements(logout));
			logout.click();
			Thread.sleep(1500);
			WebElement username1 = driver.findElement(By.xpath("(//input[@id='exampleFormControlInput1'])[1]"));
			wait.until(ExpectedConditions.visibilityOfAllElements(username1));
			System.out.println("after logout : " + excel.getDataFromExcelSheet(1, j, 2));
			username1.sendKeys(excel.getDataFromExcelSheet(1, j, 2));
//			Thread.sleep(1500);
			WebElement password1 = driver.findElement(By.xpath("(//input[@id='exampleFormControlInput1'])[2]"));
			wait.until(ExpectedConditions.visibilityOfAllElements(password1));
			password1.sendKeys("Welcome@123");
//			Thread.sleep(1500);
			WebElement login1 = driver.findElement(By.xpath("//button[@id='connectSocket']"));
			wait.until(ExpectedConditions.visibilityOfAllElements(login1));
			login1.click();
//			Thread.sleep(2000);
			WebElement chat = driver.findElement(By.xpath("//a[@id='chat_chat_agent']/button//*[@stroke='currentColor']"));
			wait.until(ExpectedConditions.visibilityOfAllElements(chat));
			chat.click();
//			Thread.sleep(1500);
					try{
//					Thread.sleep(1500);
					WebElement acceptCall1 = driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i"));
					wait.until(ExpectedConditions.visibilityOfAllElements(acceptCall1));
					Thread.sleep(4000);
					if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
						driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
						Thread.sleep(1500);
					}else {
						System.out.println("No Call :  1");
					}
					Thread.sleep(1500);
					if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
						driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
						Thread.sleep(1500);
					}else {
						System.out.println("No Call :  2");
					}
					Thread.sleep(1500);
					if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
						driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
						Thread.sleep(1500);
					}else {
						System.out.println("No Call :  3");
					}
					Thread.sleep(1500);
					if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
						driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
						Thread.sleep(1500);
					}else {
						System.out.println("No Call :  4");
					}
					Thread.sleep(1500);
					if(driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).isDisplayed()) {
						driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i")).click();
						Thread.sleep(1500);
					}else {
						System.out.println("No Call :  5");
					}} catch (Exception e){
						System.err.println("There is no call");
					}
					Thread.sleep(1500);
					WebElement startchat1 = driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]"));
					wait.until(ExpectedConditions.visibilityOfAllElements(startchat1));
					Thread.sleep(4000);
					try {
					if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
						Thread.sleep(2500);
						driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
						Thread.sleep(1500);
						WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
						new Actions(driver).click(endchat).build().perform();
						Thread.sleep(1500);
						WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
						Thread.sleep(1500);
						new Select(reason).selectByVisibleText("Disconnected");
						Thread.sleep(1500);
						WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(comment));
						comment.sendKeys("No Comment");
						Thread.sleep(1500);
						WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(submit));
						submit.click();
						Thread.sleep(1500);
					}else {
						System.out.println("No chat :  1");
					}
					Thread.sleep(1500);
					if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
						Thread.sleep(2500);
						driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
						Thread.sleep(1500);
						WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
						new Actions(driver).click(endchat).build().perform();
						Thread.sleep(1500);
						WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
						Thread.sleep(1500);
						new Select(reason).selectByVisibleText("Disconnected");
						Thread.sleep(1500);
						WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(comment));
						comment.sendKeys("No Comment");
						Thread.sleep(1500);
						WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(submit));
						submit.click();
						Thread.sleep(1500);
					}else {
						System.out.println("No chat :  2");
					}
					Thread.sleep(1500);
					if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
						Thread.sleep(2500);
						driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
						Thread.sleep(1500);
						WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
						new Actions(driver).click(endchat).build().perform();
						Thread.sleep(1500);
						WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
						Thread.sleep(1500);
						new Select(reason).selectByVisibleText("Disconnected");
						Thread.sleep(1500);
						WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(comment));
						comment.sendKeys("No Comment");
						Thread.sleep(1500);
						WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(submit));
						submit.click();
						Thread.sleep(1500);
					}else {
						System.out.println("No chat :  3");
					}
					Thread.sleep(1500);
					if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
						Thread.sleep(2500);
						driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
						Thread.sleep(1500);
						WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
						new Actions(driver).click(endchat).build().perform();
						Thread.sleep(1500);
						WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
						Thread.sleep(1500);
						new Select(reason).selectByVisibleText("Disconnected");
						Thread.sleep(1500);
						WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(comment));
						comment.sendKeys("No Comment");
						Thread.sleep(1500);
						WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(submit));
						submit.click();
						Thread.sleep(1500);
					}else {
						System.out.println("No chat :  4");
					}
					Thread.sleep(1500);
					if(driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).isDisplayed()) {
						Thread.sleep(2500);
						driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div[1]")).click();
						Thread.sleep(1500);
						WebElement endchat = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@stroke='currentColor']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(endchat));
						new Actions(driver).click(endchat).build().perform();
						Thread.sleep(1500);
						WebElement reason = driver.findElement(By.xpath("//select[@class='form-select']"));
						Thread.sleep(1500);
						new Select(reason).selectByVisibleText("Disconnected");
						Thread.sleep(1500);
						WebElement comment = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(comment));
						comment.sendKeys("No Comment");
						Thread.sleep(1500);
						WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
						wait.until(ExpectedConditions.visibilityOfAllElements(submit));
						submit.click();
						Thread.sleep(1500);
					}else {
						System.out.println("No chat :  5 ");
					}
//					
				} catch (Exception e){
					System.err.println("There is no chat");
				}

			driver.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--connected ']")).click();
			Thread.sleep(1500);
			driver.findElement(By.xpath("//div[@class='sign-out']")).click();
			Thread.sleep(4000);
			}
		}
	}
	}

