package UtilsLayerPackage;

import org.openqa.selenium.WebElement;

import BaseLayerPackage.BaseClass;

public class HandleFrame extends BaseClass {

	public static void handle_By_idOrName(String nameOrId) {
		driver.switchTo().frame(nameOrId);
	}

	public static void handle_By_Index(int index) {
		driver.switchTo().frame(index);
	}

	public static void handle_By_WebElement(WebElement wb) {
		driver.switchTo().frame(wb);
	}

	public static void switch_To_Parnt() {
		driver.switchTo().parentFrame();
	}

	public static void switch_To_MainFrame() {
		driver.switchTo().defaultContent();
	}
}
