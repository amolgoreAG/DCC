package UtilsLayerPackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import BaseLayerPackage.BaseClass;

public class ExcelReader extends BaseClass{

	public XSSFWorkbook workbook;

	public ExcelReader(String filePath) {
		File f = new File(filePath);
		try {
			FileInputStream fis = new FileInputStream(f);
			workbook = new XSSFWorkbook(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getDataFromExcelSheet(int sheetIndex, int rowIndex, int cellIndex) {
		try {
			return workbook.getSheetAt(sheetIndex).getRow(rowIndex).getCell(cellIndex).getStringCellValue();
		} catch (Exception e) {
			double d = workbook.getSheetAt(sheetIndex).getRow(rowIndex).getCell(cellIndex).getNumericCellValue();
			return Long.toString((long) d);
		}
	}

	public int countRow(int sheetIndex) {
		return workbook.getSheetAt(sheetIndex).getLastRowNum()+1;
	}

	public int countCell(int sheetIndex) {
		return workbook.getSheetAt(sheetIndex).getRow(0).getLastCellNum();
	}

}
