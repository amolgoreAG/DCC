package UtilsLayerPackage;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import BaseLayerPackage.BaseClass;

public class enableStatus extends BaseClass {
	
public static void EnabledStatus(WebElement webElement ,String Test1) throws InterruptedException {
	if (webElement.isEnabled()) {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(webElement);
		Thread.sleep(500);
		((JavascriptExecutor) driver).executeScript("alert('Enable Status Of "+Test1+" is True')");
		Thread.sleep(500);
		UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
		Thread.sleep(500);
	} else {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(webElement);
		Thread.sleep(500);
		((JavascriptExecutor) driver).executeScript("alert('Enable Status Of "+Test1+" is False')");
		Thread.sleep(500);
		UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
		Thread.sleep(500);
	}
}
}
