package UtilsLayerPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class Supplier_Type extends BaseClass {

	@FindBy(xpath = "//input[@id='txtUserName']")
	WebElement username;

	@FindBy(xpath = "//input[@id='txtPassword']")
	WebElement password;

	@FindBy(xpath = "//input[@id='btnLogIn']")
	WebElement loginbtn;

	@FindBy(xpath = "//input[@name='ctl02']")
	WebElement royalParkAccountModule;

	@FindBy(xpath = "//td[@id='ctl00_Menu1n1']//a[text()='Suppliers']")
	WebElement supplier;

	@FindBy(xpath = "//tr[@id='ctl00_Menu1n17']//a[text()='Supplier Type']")
	WebElement type;

	@FindBy(xpath = "//input[@id='ctl00_Main_btnAddNew']")
	WebElement addNew;

	@FindBy(xpath = "//input[@id='ctl00_Main_txtCode']")
	WebElement code;

	@FindBy(xpath = "//input[@id='ctl00_Main_txtName']")
	WebElement name;

	@FindBy(xpath = "//input[@id='ctl00_Main_txtPrefix']")
	WebElement prefix;

	@FindBy(xpath = "//input[@id='ctl00_Main_btnSave']")
	WebElement save;

	@FindBy(xpath = "//input[@id='ctl00_Main_btnFilter']")
	WebElement searchByDate;

	@FindBy(xpath = "//input[@id='ctl00_Main_ImgBtnFrmDt']")
	WebElement fromDate;

	@FindBy(xpath = "//input[@id='ctl00_Main_ImgBtnToDt']")
	WebElement toDate;

	@FindBy(xpath = "//input[@id='ctl00_Main_btnPrint']")
	WebElement report;

	public Supplier_Type() {
		PageFactory.initElements(driver, this);
	}

	public boolean displayStatusOfusername() throws InterruptedException {
		Thread.sleep(2000);
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(username);
		return username.isDisplayed();
	}

	public boolean enableStatusOfusername() {
		return username.isEnabled();
	}

	public void enterDataInusername(String Username) {
		username.sendKeys(Username);
	}

	public boolean displayStatusOfpassword() throws InterruptedException {
		Thread.sleep(2000);
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(password);
		return password.isDisplayed();
	}

	public boolean enableStatusOfpassword() {
		return password.isEnabled();
	}

	public void enterDataInpassword(String Password) {
		password.sendKeys(Password);
	}

	public boolean displayStatusOfloginbtn() throws InterruptedException {
		Thread.sleep(2000);
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(loginbtn);
		return loginbtn.isDisplayed();
	}

	public boolean enableStatusOfloginbtn() {
		return loginbtn.isEnabled();
	}

	public void clickOnloginbtn() {
		loginbtn.click();
	}

	public boolean displayStatusOfroyalParkAccountModule() {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(royalParkAccountModule);
		return royalParkAccountModule.isDisplayed();
	}

	public boolean enableStatusOfroyalParkAccountModule() {
		return royalParkAccountModule.isEnabled();
	}

	public void clickOnroyalParkAccountModule() {
		royalParkAccountModule.click();
	}

	public boolean displayStatusOfsupplier() throws InterruptedException {
		UtilsLayerPackage.HandleWindows.switchToWindows_By_Use_Of_Iterator(1);
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(supplier);
		Thread.sleep(2000);
		return supplier.isDisplayed();
	}

	public boolean enableStatusOfsupplier() {
		return supplier.isEnabled();
	}

	public void clickOnsupplier() {
		new Actions(driver).moveToElement(supplier).build().perform();
	}

	public boolean displayStatusOftype() throws InterruptedException {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(type);
		Thread.sleep(2000);
		return type.isDisplayed();
	}

	public boolean enableStatusOftype() {
		return type.isEnabled();
	}

	public void clickOntype() {
		new Actions(driver).moveToElement(type).click().build().perform();
	}

	public boolean displayStatusOfaddNew() throws InterruptedException {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addNew);
		Thread.sleep(2000);
		return addNew.isDisplayed();
	}

	public boolean enableStatusOfaddNew() {
		return addNew.isEnabled();
	}

	public void clickOnaddNew() {
		addNew.click();
	}

	public boolean displayStatusOfcode() throws InterruptedException {
		UtilsLayerPackage.HandleWindows.switchToWindows_By_Use_Of_Iterator(2);
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(code);
		Thread.sleep(2000);
		return code.isDisplayed();
	}

	public boolean enableStatusOfcode() {
		return code.isEnabled();
	}

	public void sendDataIncode(String Code) {
		code.sendKeys(Code);
	}

	public boolean displayStatusOfname() throws InterruptedException {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(name);
		Thread.sleep(2000);
		return name.isDisplayed();
	}

	public boolean enableStatusOfname() {
		return name.isEnabled();
	}

	public void sendDataInname(String Name) {
		name.sendKeys(Name);
	}

	public boolean displayStatusOfprefix() throws InterruptedException {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(prefix);
		Thread.sleep(2000);
		return prefix.isDisplayed();
	}

	public boolean enableStatusOfprefix() {
		return prefix.isEnabled();
	}

	public void sendDataInprefix(String Prefix) {
		prefix.sendKeys(Prefix);
	}

	public boolean displayStatusOfsave() throws InterruptedException {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(save);
		Thread.sleep(2000);
		return save.isDisplayed();
	}

	public boolean enableStatusOfsave() {
		return save.isEnabled();
	}

	public void clickOnsave() {
		save.click();
	}

	public boolean displayStatusOfsearchByDate() throws InterruptedException {
		UtilsLayerPackage.HandleWindows.switchToWindows_By_Use_Of_Iterator(1);
		Thread.sleep(2000);
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(searchByDate);
		Thread.sleep(5000);
		return searchByDate.isDisplayed();
	}

	public boolean enableStatusOfsearchByDate() {
		return searchByDate.isEnabled();
	}

	public void clickOnsearchByDate() {
		searchByDate.click();
	}

	public boolean displayStatusOffromDate() throws InterruptedException {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(fromDate);
		Thread.sleep(3000);
		return fromDate.isDisplayed();
	}

	public boolean enableStatusOffromDate() {
		return fromDate.isEnabled();
	}

	public void clickOnfromDate() {
		fromDate.click();
	}

	public void selectDateFromfromDate(String TODAY) {
		driver.findElement(By.xpath("//div[@id='ctl00_Main_dpFromDate_days']//div[text()='"+TODAY+"']"))
				.click();
	}

	public boolean displayStatusOftoDate() throws InterruptedException {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(toDate);
		Thread.sleep(8000);
		return toDate.isDisplayed();
	}

	public boolean enableStatusOftoDate() {
		return toDate.isEnabled();
	}

	public void clickOntoDate() {
		toDate.click();
	}

	public void selectDateFromtoDate(String TODAY) {
		driver.findElement(By.xpath("//div[@id='ctl00_Main_dpToDate_body']//div[text()='"+TODAY+"']"))
				.click();
	}

	public void clickOnsearchByDate1() {
		searchByDate.click();
	}

	public boolean displayStatusOfreport() throws InterruptedException {
		UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(report);
		Thread.sleep(3000);
		return report.isDisplayed();
	}

	public boolean enableStatusOfreport() {
		return report.isEnabled();
	}

	public void clickOnreport() {
		report.click();
	}

}
