package UtilsLayerPackage;

public class GetDataFromDCCExcel {

	public static String excel(int SheetIndex , int row , int column) {
		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\DCC.xlsx");
		return excel.getDataFromExcelSheet(SheetIndex, row, column);
	}
}
