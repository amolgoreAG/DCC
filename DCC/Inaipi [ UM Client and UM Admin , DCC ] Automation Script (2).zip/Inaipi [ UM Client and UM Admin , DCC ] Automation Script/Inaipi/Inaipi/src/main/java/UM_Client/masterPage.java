package UM_Client;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class masterPage extends BaseClass {

	// Master

	@FindBy(xpath = "//li[@id='1']")
	WebElement master;

	// role

	@FindBy(xpath = "//li[text()='Role']")
	WebElement role;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement createRole;

	@FindBy(xpath = "//input[@id='roleName']")
	WebElement roleName;

	@FindBy(xpath = "//textarea[@id='description']")
	WebElement roleDiscription;

	@FindBy(xpath = "//div[@class='MuiDialogTitle-root']//span[1]")
	WebElement close;

	@FindBy(xpath = "//span[text()='SUBMIT']")
	WebElement submit;

	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement cancel;

	@FindBy(xpath = "//table[@class='MuiTable-root']//tbody/tr[1]/td[4]//*[@class='MuiSvgIcon-root m-r-20 text-a MuiSvgIcon-fontSizeSmall']")
	WebElement edit;

	@FindBy(xpath = "//input[@id='roleName']")
	WebElement edit_roleName;

	@FindBy(xpath = "//textarea[@id='description']")
	WebElement edit_roleDiscription;

	@FindBy(xpath = "//div[@class='MuiDialogTitle-root']//span[1]")
	WebElement edit_close;

	@FindBy(xpath = "//span[text()='UPDATE ROLE']")
	WebElement updateRole;

	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement edit_cancel;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[1]/td[4]//center/span")
	WebElement status;

	// Group

	@FindBy(xpath = "//li[text()='Group']")
	WebElement group;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement createGroup;

	@FindBy(xpath = "//input[@id='groupName']")
	WebElement groupName;

	@FindBy(xpath = "//textarea[@id='description']")
	WebElement groupNameDiscription;

	@FindBy(xpath = "//span[text()='UPDATE GROUP']")
	WebElement updateGroup;

	// Channel

	@FindBy(xpath = "//li[text()='Channel']")
	WebElement channel;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[2]/td[5]//center/span")
	WebElement channelStatus1;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[2]/td[1]//button")
	WebElement downArrow;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[1]/td[4]//center/span")
	WebElement channelSub1;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[2]/td[4]//center/span")
	WebElement channelSub2;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[3]/td[4]//center/span")
	WebElement channelSub3;

	@FindBy(xpath = "//li[text()='Status']")
	WebElement Status;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement create_Status;

	@FindBy(xpath = "//input[@id='statusName']")
	WebElement Status_Name;

	@FindBy(xpath = "//textarea[@id='statusDesc']")
	WebElement Status_Discription;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[5]/center//*[@title='Edit Role']")
	WebElement edit_status;

	@FindBy(xpath = "//span[text()='UPDATE STATUS']")
	WebElement updateStatus;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[1]/td[5]//center/span")
	WebElement Status_Status;

	// skill

	@FindBy(xpath = "//li[text()='Skillset']")
	WebElement skillSet;

	@FindBy(xpath = "//span[text()='Create Skill']")
	WebElement createSkill;

	@FindBy(xpath = "//input[@id='skillName']")
	WebElement skillName;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center//*[@title='Edit Role']")
	WebElement editSkill;

	@FindBy(xpath = "//span[text()='UPDATE SKILL']")
	WebElement updateSkill;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center/span")
	WebElement skill_Status;

	// skill Proficiency

	@FindBy(xpath = "//li[text()='Skill Proficiency']")
	WebElement skillProfeciancy;

	@FindBy(xpath = "//span[text()='Add Proficiency']")
	WebElement createProfeciancy;

	@FindBy(xpath = "//input[@id='proficiencyDesc']")
	WebElement skillProfeciancyName;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center//*[@title='Edit Role']")
	WebElement editProfeciancy;

	@FindBy(xpath = "//span[text()='UPDATE PROFICIENCY']")
	WebElement updateProfeciancy;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]//span[@class='MuiSwitch-root MuiSwitch-sizeSmall']")
	WebElement profeciancy_Status;

	// language

	@FindBy(xpath = "//li[text()='Language']")
	WebElement language;

	@FindBy(xpath = "//span[text()='Create Language']")
	WebElement createLanguage;

	@FindBy(xpath = "//input[@id='languageDesc']")
	WebElement languageName;

	@FindBy(xpath = "//input[@id='languageCode']")
	WebElement languageCode;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[5]/center//*[@title='Edit Role']")
	WebElement editLanguage;

	@FindBy(xpath = "//span[text()='UPDATE LANGUAGE']")
	WebElement updateLanguage;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[5]/center/span")
	WebElement Language_Status;

	// language Proficiency

	@FindBy(xpath = "//li[text()='Language Proficiency']")
	WebElement language_Proficiency;

	@FindBy(xpath = "//span[text()='Add Proficiency']")
	WebElement createProficiency;

	@FindBy(xpath = "//input[@id='proficiencyDesc']")
	WebElement languageProficiencyName;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center//*[@class='MuiSvgIcon-root m-r-20 text-a MuiSvgIcon-fontSizeSmall']")
	WebElement editlanguageProficiency;

	@FindBy(xpath = "//span[text()='UPDATE PROFICIENCY']")
	WebElement updatelanguageProficiency;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center/span")
	WebElement languageProficiencyStatus;

	// Routing Algorithm

	@FindBy(xpath = "//li[text()='Routing Algorithm']")
	WebElement routingAlgorithm;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center/span")
	WebElement routingAlgorithmStatus;

	// Module Master

	@FindBy(xpath = "//li[text()='Module Master']")
	WebElement moduleMaster;

	@FindBy(xpath = "//div[@class='react-dropdown-select m-t-5 css-wmw4vi-ReactDropdownSelect e1gzf2xs0']")
	WebElement selectAppName;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement view;
	
	public masterPage() {
		PageFactory.initElements(driver, this);
	}

	public boolean displayStatusOfmaster() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", master);
		Thread.sleep(1000);
		if (master.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(master);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of master is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(master);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of master is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return master.isDisplayed();
	}

	public boolean enableStatusOfmaster() throws InterruptedException {
		if (master.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(master);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of master is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(master);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of master is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return master.isEnabled();
	}

	public void clickOnmaster() {
		try {
			master.click();
		} catch (Exception e) {
		new Actions(driver).click(master).build().perform();
		}
	}

	public boolean displayStatusOfrole() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", role);
		Thread.sleep(1000);
		if (role.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(role);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of role is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(role);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of role is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return role.isDisplayed();
	}

	public boolean enableStatusOfrole() throws InterruptedException {
		if (role.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(role);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of role is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(role);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of role is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return role.isEnabled();
	}

	public void clickOnrole() {
		role.click();
	}

	public boolean displayStatusOfcreateRole() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", createRole);
		Thread.sleep(1000);
		if (createRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createRole.isDisplayed();
	}

	public boolean enableStatusOfcreateRole() throws InterruptedException {
		if (createRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createRole.isEnabled();
	}

	public void clickOncreateRole() {
		createRole.click();
	}

	public boolean displayStatusOfroleName() throws InterruptedException {
		if (roleName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleName.isDisplayed();
	}

	public boolean enableStatusOfroleName() throws InterruptedException {
		if (roleName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleName.isEnabled();
	}

	public void enterDataInroleName(String RoleName) {
		roleName.sendKeys(RoleName);
	}

	public boolean displayStatusOfroleDiscription() throws InterruptedException {
		if (roleDiscription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleDiscription.isDisplayed();
	}

	public boolean enableStatusOfroleDiscription() throws InterruptedException {
		if (roleDiscription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleDiscription.isEnabled();
	}

	public void enterDataInroleDiscription(String RoleDiscription) {
		roleDiscription.sendKeys(RoleDiscription);
	}

	public boolean displayStatusOfclose() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfclose() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfcancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancel() {
		cancel.click();
	}

	public boolean displayStatusOfsubmit() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmit() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmit() {
		submit.click();
	}

	public boolean displayStatusOfedit() throws InterruptedException {
		if (edit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit.isDisplayed();
	}

	public boolean enableStatusOfedit() throws InterruptedException {
		if (edit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit.isEnabled();
	}

	public void clickOnedit() {
		edit.click();
	}

	public boolean displayStatusOfedit_roleName() throws InterruptedException {
		if (edit_roleName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_roleName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_roleName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleName.isDisplayed();
	}

	public boolean enableStatusOfedit_roleName() throws InterruptedException {
		if (edit_roleName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_roleName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_roleName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleName.isEnabled();
	}

	public void clearTheRoleName() {
		new Actions(driver).click(edit_roleName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(edit_roleName, Keys.DELETE).build().perform();
	}

	public void enterDataInedit_roleName(String edit_RoleName) throws InterruptedException {
		edit_roleName.sendKeys(edit_RoleName);
	}

	public boolean displayStatusOfedit_roleDiscription() throws InterruptedException {
		if (edit_roleDiscription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_roleDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_roleDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleDiscription.isDisplayed();
	}

	public boolean enableStatusOfroleedit_Discription() throws InterruptedException {
		if (edit_roleDiscription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_roleDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_roleDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleDiscription.isEnabled();
	}

	public void enterDataInedit_roleDiscription(String edit_RoleDiscription) throws InterruptedException {
		edit_roleDiscription.clear();
		Thread.sleep(1200);
		edit_roleDiscription.sendKeys(edit_RoleDiscription);
	}

	public boolean displayStatusOfedit_close() throws InterruptedException {
		if (edit_close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_close.isDisplayed();
	}

	public boolean enableStatusOfedit_close() throws InterruptedException {
		if (edit_close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_close.isEnabled();
	}

	public boolean displayStatusOfedit_cancel() throws InterruptedException {
		if (edit_cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancel() throws InterruptedException {
		if (edit_cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_cancel.isEnabled();
	}

	public void clickOnedit_cancel() {
		edit_cancel.click();
	}

	public boolean displayStatusOfupdateRole() throws InterruptedException {
		if (updateRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateRole.isDisplayed();
	}

	public boolean enableStatusOfupdateRole() throws InterruptedException {
		if (updateRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateRole.isEnabled();
	}

	public void clickOnupdateRole() {
		updateRole.click();
	}

	public boolean displayStatusOfstatus() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", status);
		Thread.sleep(1000);
		if (status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return status.isDisplayed();
	}

	public boolean enableStatusOfstatus() throws InterruptedException {
		if (status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return status.isEnabled();
	}

	public void clickOnstatus() throws InterruptedException {
		status.click();
		Thread.sleep(3000);
		status.click();
	}

	public boolean displayStatusOfgroup() throws InterruptedException {
		if (group.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(group);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of group is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(group);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of group is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return group.isDisplayed();
	}

	public boolean enableStatusOfgroup() throws InterruptedException {
		if (group.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(group);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of group is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(group);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of group is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return group.isEnabled();
	}

	public void clickOngroup() throws InterruptedException {
		group.click();

	}

	public boolean displayStatusOfcreateGroup() throws InterruptedException {
		if (createGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createGroup.isDisplayed();
	}

	public boolean enableStatusOfcreateGroup() throws InterruptedException {
		if (createGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createGroup.isEnabled();
	}

	public void clickOncreateGroup() throws InterruptedException {
		createGroup.click();

	}

	public boolean displayStatusOfgroupName() throws InterruptedException {
		if (groupName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupName.isDisplayed();
	}

	public boolean enableStatusOfgroupName() throws InterruptedException {
		if (groupName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupName.isEnabled();
	}

	public void enterDataIngroupName(String GroupName) {
		groupName.sendKeys(GroupName);
	}

	public boolean displayStatusOfgroupNameDiscription() throws InterruptedException {
		if (groupNameDiscription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupNameDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupNameDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupNameDiscription.isDisplayed();
	}

	public boolean enableStatusOfgroupNameDiscription() throws InterruptedException {
		if (groupNameDiscription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupNameDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupNameDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupNameDiscription.isEnabled();
	}

	public void enterDataIngroupNameDiscription(String GroupNameDiscription) {
		groupNameDiscription.sendKeys(GroupNameDiscription);
	}

	public boolean displayStatusOfclosegroup() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfclosegroup() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfcancelgroup() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancelgroup() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancelDiscription() {
		cancel.click();
	}

	public boolean displayStatusOfsubmitgroup() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmitgroup() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmitDiscription() {
		submit.click();
	}

	public boolean displayStatusOfeditgroup() throws InterruptedException {
		if (edit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit.isDisplayed();
	}

	public boolean enableStatusOfeditgroup() throws InterruptedException {
		if (edit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit.isEnabled();
	}

	public void clickOneditDiscription() {
		edit.click();
	}

	public boolean displayStatusOfedit_groupName() throws InterruptedException {
		if (groupName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupName.isDisplayed();
	}

	public boolean enableStatusOfedit_groupName() throws InterruptedException {
		if (groupName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupName.isEnabled();
	}

	public void clearThegroupName() {
		new Actions(driver).click(groupName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(groupName, Keys.DELETE).build().perform();
	}

	public void enterDataInedit_groupNameDiscription(String edit_GroupName) throws InterruptedException {
		groupName.sendKeys(edit_GroupName);
	}

	public boolean displayStatusOfedit_groupNamegroup() throws InterruptedException {
		if (groupNameDiscription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupNameDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupNameDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupNameDiscription.isDisplayed();
	}

	public boolean enableStatusOfroleedit_groupNamegroup() throws InterruptedException {
		if (groupNameDiscription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupNameDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupNameDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleDiscription.isEnabled();
	}

	public void enterDataInedit_groupNamegroup(String edit_GroupNameDiscription) throws InterruptedException {
		groupNameDiscription.clear();
		Thread.sleep(1200);
		groupNameDiscription.sendKeys(edit_GroupNameDiscription);
	}

	public boolean displayStatusOfedit_closegroup() throws InterruptedException {
		if (edit_close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_close.isDisplayed();
	}

	public boolean enableStatusOfedit_closegroup() throws InterruptedException {
		if (edit_close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_close.isEnabled();
	}

	public boolean displayStatusOfedit_cancelgroup() throws InterruptedException {
		if (edit_cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancelgroup() throws InterruptedException {
		if (edit_cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_cancel.isEnabled();
	}

	public void clickOnedit_cancelgroup() {
		edit_cancel.click();
	}

	public boolean displayStatusOfupdateGroup() throws InterruptedException {
		if (updateGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateGroup.isDisplayed();
	}

	public boolean enableStatusOfupdateGroup() throws InterruptedException {
		if (updateGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateGroup.isEnabled();
	}

	public void clickOnupdateGroup() {
		updateGroup.click();
	}

	public boolean displayStatusOfstatusgroup() throws InterruptedException {
		if (status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return status.isDisplayed();
	}

	public boolean enableStatusOfstatusgroup() throws InterruptedException {
		if (status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return status.isEnabled();
	}

	public void clickOnstatusgroup() throws InterruptedException {
		status.click();
		Thread.sleep(3000);
		status.click();
	}

	public boolean displayStatusOfchannel() throws InterruptedException {
		if (channel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channel.isDisplayed();
	}

	public boolean enableStatusOfchannel() throws InterruptedException {
		if (channel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channel.isEnabled();
	}

	public void clickOnchannel() throws InterruptedException {
		channel.click();
	}

	public boolean displayStatusOfchannelStatus1() throws InterruptedException {
		if (channelStatus1.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelStatus1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelStatus1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelStatus1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelStatus1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelStatus1.isDisplayed();
	}

	public boolean enableStatusOfchannelStatus1() throws InterruptedException {
		if (channelStatus1.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelStatus1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelStatus1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelStatus1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelStatus1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelStatus1.isEnabled();
	}

	public void clickOnchannelStatus1() throws InterruptedException {
		channelStatus1.click();
		Thread.sleep(501);
		channelStatus1.click();

	}

	public boolean displayStatusOfdownArrow() throws InterruptedException {
		if (downArrow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return downArrow.isDisplayed();
	}

	public boolean enableStatusOfdownArrow() throws InterruptedException {
		if (downArrow.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of downArrow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of downArrow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return downArrow.isEnabled();
	}

	public void clickOnchanneldownArrow() throws InterruptedException {
		downArrow.click();
	}

	public boolean displayStatusOfchannelSub1() throws InterruptedException {
		if (channelSub1.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub1.isDisplayed();
	}

	public boolean enableStatusOfchannelSub1() throws InterruptedException {
		if (channelSub1.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub1.isEnabled();
	}

	public void clickOnchannelSub1() throws InterruptedException {
		channelSub1.click();
		Thread.sleep(501);
		channelSub1.click();
	}

	public boolean displayStatusOfchannelSub2() throws InterruptedException {
		if (channelSub2.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub2);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub2 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub2);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub2 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub2.isDisplayed();
	}

	public boolean enableStatusOfchannelSub2() throws InterruptedException {
		if (channelSub2.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub2);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub2 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub2);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub2 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub2.isEnabled();
	}

	public void clickOnchannelSub2() throws InterruptedException {
		channelSub2.click();
		Thread.sleep(501);
		channelSub2.click();
	}

	public boolean displayStatusOfchannelSub3() throws InterruptedException {
		if (channelSub3.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub3);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub3 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub3);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub3 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub3.isDisplayed();
	}

	public boolean enableStatusOfchannelSub3() throws InterruptedException {
		if (channelSub3.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub3);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub3 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub3);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub3 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub3.isEnabled();
	}

	public void clickOnchannelSub3() throws InterruptedException {
		channelSub3.click();
		Thread.sleep(501);
		channelSub3.click();
	}

	public boolean displayStatusOfdownArrow2() throws InterruptedException {
		if (downArrow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return downArrow.isDisplayed();
	}

	public boolean enableStatusOfdownArrow2() throws InterruptedException {
		if (downArrow.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of downArrow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of downArrow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return downArrow.isEnabled();
	}

	public void clickOndownArrow2() throws InterruptedException {
		downArrow.click();
	}

	public boolean displayStatusOfStatus() throws InterruptedException {
		if (Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status.isDisplayed();
	}

	public boolean enableStatusOfStatus() throws InterruptedException {
		if (Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status.isEnabled();
	}

	public void clickOnStatus() throws InterruptedException {
		Status.click();
	}

	public boolean displayStatusOfcreate_Status() throws InterruptedException {
		if (create_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(create_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of create_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(create_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of create_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return create_Status.isDisplayed();
	}

	public boolean enableStatusOfcreate_Status() throws InterruptedException {
		if (create_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(create_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of create_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(create_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of create_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return create_Status.isEnabled();
	}

	public void clickOncreate_Status() throws InterruptedException {
		create_Status.click();
	}

	public boolean displayStatusOfStatus_Name() throws InterruptedException {
		if (Status_Name.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Name is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Name is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Name.isDisplayed();
	}

	public boolean enableStatusOfStatus_Name() throws InterruptedException {
		if (Status_Name.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Name is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Name is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Name.isEnabled();
	}

	public void eneterDataInStatus_Name(String Status_name) throws InterruptedException {
		Status_Name.sendKeys(Status_name);
	}

	public boolean displayStatusOfStatus_Discription() throws InterruptedException {
		if (Status_Discription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Discription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display create_Status of Status_Discription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Discription.isDisplayed();
	}

	public boolean enableStatusOfStatus_Discription() throws InterruptedException {
		if (Status_Discription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Discription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Discription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Discription.isEnabled();
	}

	public void eneterDataInStatus_Discription(String Status_discription) throws InterruptedException {
		Status_Discription.sendKeys(Status_discription);
	}

	public boolean displayStatusOfStatus_close() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfStatus_close() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfStatus_cancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfStatus_cancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnStatus_cancel() {
		cancel.click();
	}

	public boolean displayStatusOfStatus_submit() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfStatus_submit() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnStatus_submit() {
		submit.click();
	}

	public boolean displayStatusOfedit_status() throws InterruptedException {
		if (edit_status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_status.isDisplayed();
	}

	public boolean enableStatusOfedit_status() throws InterruptedException {
		if (edit_status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_status.isEnabled();
	}

	public void clickOnedit_status() {
		edit_status.click();
	}

	public boolean displayStatusOfedit_Status_Name() throws InterruptedException {
		if (Status_Name.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Name is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Name is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Name.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_Name() throws InterruptedException {
		if (Status_Name.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Name is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Name is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Name.isEnabled();
	}

	public void eneterDataInedit_Status_Name(String Status_name) throws InterruptedException {
		new Actions(driver).click(Status_Name).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(Status_Name, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		Status_Name.sendKeys(Status_name);
	}

	public boolean displayStatusOfedit_Status_Discription() throws InterruptedException {
		if (Status_Discription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Discription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display create_Status of Status_Discription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Discription.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_Discription() throws InterruptedException {
		if (Status_Discription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Discription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Discription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Discription.isEnabled();
	}

	public void eneterDataInedit_Status_Discription(String edit_Status_discription) throws InterruptedException {
		new Actions(driver).click(Status_Discription).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(Status_Discription, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		Status_Discription.sendKeys(edit_Status_discription);
	}

	public boolean displayStatusOfedit_Status_close() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_close() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfedit_Status_cancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_cancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_Status_cancel() {
		cancel.click();
	}

	public boolean displayStatusOfedit_Status_updateStatus() throws InterruptedException {
		if (updateStatus.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateStatus.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_updateStatus() throws InterruptedException {
		if (updateStatus.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateStatus.isEnabled();
	}

	public void clickOnedit_Status_updateStatus() {
		updateStatus.click();
	}

	public boolean displayStatusOfStatus_Status() throws InterruptedException {
		if (Status_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Status_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Status_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Status.isDisplayed();
	}

	public boolean enableStatusOfStatus_Status() throws InterruptedException {
		if (Status_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Status_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Status_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Status.isEnabled();
	}

	public void clickOnStatus_Status() throws InterruptedException {
		Status_Status.click();
		Thread.sleep(501);
		Status_Status.click();
	}

	public boolean displayStatusOfskillSet() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillSet);
		Thread.sleep(1000);
		if (skillSet.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillSet);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillSet is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillSet);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillSet is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillSet.isDisplayed();
	}

	public boolean enableStatusOfskillSet() throws InterruptedException {
		if (skillSet.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillSet);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillSet is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillSet);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillSet is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillSet.isEnabled();
	}

	public void clickOnskillSet() {
		skillSet.click();
	}

	public boolean displayStatusOfcreateSkill() throws InterruptedException {
		if (createSkill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createSkill.isDisplayed();
	}

	public boolean enableStatusOfcreateSkill() throws InterruptedException {
		if (createSkill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createSkill.isEnabled();
	}

	public void clickOncreateSkill() {
		createSkill.click();
	}

	public boolean displayStatusOfskillName() throws InterruptedException {
		if (skillName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillName.isDisplayed();
	}

	public boolean enableStatusOfskillName() throws InterruptedException {
		if (skillName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillName.isEnabled();
	}

	public void enterDataInskillName(String SkillName) {
		skillName.sendKeys(SkillName);
	}

	public boolean displayStatusOfskill_close() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfskill_close() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfskill_cancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfskill_cancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnskill_cancel() {
		cancel.click();
	}

	public boolean displayStatusOfSkillsubmit() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfSkillsubmit() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnskillsubmit() {
		submit.click();
	}

	public boolean displayStatusOfeditSkill() throws InterruptedException {
		if (editSkill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editSkill.isDisplayed();
	}

	public boolean enableStatusOfeditSkill() throws InterruptedException {
		if (editSkill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editSkill.isEnabled();
	}

	public void clickOneditSkill() {
		editSkill.click();
	}

	public boolean displayStatusOfedit_skillName() throws InterruptedException {
		if (skillName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillName.isDisplayed();
	}

	public boolean enableStatusOfedit_skillName() throws InterruptedException {
		if (skillName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillName.isEnabled();
	}

	public void enterDataInedit_skillName(String SkillName) throws InterruptedException {
		new Actions(driver).click(skillName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(skillName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		skillName.sendKeys(SkillName);
	}

	public boolean displayStatusOfedit_skill_close() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_skill_close() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfedit_skill_cancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_skill_cancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_skill_cancel() {
		cancel.click();
	}

	public boolean displayStatusOfupdateSkill() throws InterruptedException {
		if (updateSkill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateSkill.isDisplayed();
	}

	public boolean enableStatusOfupdateSkill() throws InterruptedException {
		if (updateSkill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateSkill.isEnabled();
	}

	public void clickOnupdateSkill() {
		updateSkill.click();
	}

	public boolean displayStatusOfskill_Status() throws InterruptedException {
		if (skill_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skill_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skill_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skill_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skill_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skill_Status.isDisplayed();
	}

	public boolean enableStatusOfskill_Status() throws InterruptedException {
		if (skill_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skill_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skill_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skill_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skill_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skill_Status.isEnabled();
	}

	public void clickOnskill_Status() throws InterruptedException {
		skill_Status.click();
		Thread.sleep(501);
		skill_Status.click();
	}

	public boolean displayStatusOfskillProfeciancy() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillProfeciancy);
		Thread.sleep(1000);
		if (skillProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfskillProfeciancy() throws InterruptedException {
		if (skillProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancy.isEnabled();
	}

	public void clickOnskillProfeciancy() throws InterruptedException {
		skillProfeciancy.click();
	}

	public boolean displayStatusOfcreateProfeciancy() throws InterruptedException {
		if (createProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfcreateProfeciancy() throws InterruptedException {
		if (createProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createProfeciancy.isEnabled();
	}

	public void clickOncreateProfeciancy() throws InterruptedException {
		createProfeciancy.click();
	}

	public boolean displayStatusOfskillProfeciancyName() throws InterruptedException {
		if (skillProfeciancyName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancyName.isDisplayed();
	}

	public boolean enableStatusOfskillProfeciancyName() throws InterruptedException {
		if (skillProfeciancyName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancyName.isEnabled();
	}

	public void entertDataInskillProfeciancyName(String SkillProfeciancyName) throws InterruptedException {
		skillProfeciancyName.sendKeys(SkillProfeciancyName);
	}

	public boolean displayStatusOfcloseProfeciancy() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfcloseProfeciancy() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOncloseProfeciancy() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfsubmitProfeciancy() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmitProfeciancy() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmitProfeciancy() throws InterruptedException {
		submit.click();
	}

	public boolean displayStatusOfcancelProfeciancy() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancelProfeciancy() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancelProfeciancy() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfeditProfeciancy() throws InterruptedException {
		if (editProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfeditProfeciancy() throws InterruptedException {
		if (editProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editProfeciancy.isEnabled();
	}

	public void clickOneditProfeciancy() throws InterruptedException {
		editProfeciancy.click();
	}

	public boolean displayStatusOfedit_skillProfeciancyName() throws InterruptedException {
		if (skillProfeciancyName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancyName.isDisplayed();
	}

	public boolean enableStatusOfedit_skillProfeciancyName() throws InterruptedException {
		if (skillProfeciancyName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancyName.isEnabled();
	}

	public void entertDataInedit_skillProfeciancyName(String SkillProfeciancyName) throws InterruptedException {
		new Actions(driver).click(skillProfeciancyName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(skillProfeciancyName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		skillProfeciancyName.sendKeys(SkillProfeciancyName);
	}

	public boolean displayStatusOfedit_closeProfeciancy() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_closeProfeciancy() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOnedit_closeProfeciancy() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfedit_updateProfeciancy() throws InterruptedException {
		if (updateProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfedit_updateProfeciancy() throws InterruptedException {
		if (updateProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateProfeciancy.isEnabled();
	}

	public void clickOnedit_updateProfeciancy() throws InterruptedException {
		updateProfeciancy.click();
	}

	public boolean displayStatusOfedit_cancelProfeciancy() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancelProfeciancy() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_cancelProfeciancy() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfprofeciancy_Status() throws InterruptedException {
		if (profeciancy_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(profeciancy_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of profeciancy_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(profeciancy_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of profeciancy_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return profeciancy_Status.isDisplayed();
	}

	public boolean enableStatusOfprofeciancy_Status() throws InterruptedException {
		if (profeciancy_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(profeciancy_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of profeciancy_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(profeciancy_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of profeciancy_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return profeciancy_Status.isEnabled();
	}

	public void clickOnprofeciancy_Status() throws InterruptedException {
		profeciancy_Status.click();
		Thread.sleep(501);
		profeciancy_Status.click();
	}

	public boolean displayStatusOflanguage() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", language);
		Thread.sleep(1000);
		if (language.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(language);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of language is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(language);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of language is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return language.isDisplayed();
	}

	public boolean enableStatusOflanguage() throws InterruptedException {
		if (language.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(language);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of language is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(language);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of language is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return language.isEnabled();
	}

	public void clickOnlanguage() throws InterruptedException {
		language.click();
	}

	public boolean displayStatusOfcreateLanguage() throws InterruptedException {
		if (createLanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createLanguage.isDisplayed();
	}

	public boolean enableStatusOfcreateLanguage() throws InterruptedException {
		if (createLanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createLanguage.isEnabled();
	}

	public void clickOncreateLanguage() throws InterruptedException {
		createLanguage.click();
	}

	public boolean displayStatusOflanguageName() throws InterruptedException {
		if (languageName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageName.isDisplayed();
	}

	public boolean enableStatusOflanguageName() throws InterruptedException {
		if (languageName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageName.isEnabled();
	}

	public void enterDataInlanguageName(String LanguageName) throws InterruptedException {
		languageName.sendKeys(LanguageName);
	}

	public boolean displayStatusOflanguageCode() throws InterruptedException {
		if (languageCode.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageCode is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageCode is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageCode.isDisplayed();
	}

	public boolean enableStatusOflanguageCode() throws InterruptedException {
		if (languageCode.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageCode is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageCode is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageCode.isEnabled();
	}

	public void enterDataInlanguageCode(String LanguageName) throws InterruptedException {
		languageCode.sendKeys(LanguageName);
	}

	public boolean displayStatusOfcloseLanguage() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfcloseLanguage() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOncloseLanguage() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfsubmitLanguage() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmitLanguage() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmitLanguage() throws InterruptedException {
		submit.click();
	}

	public boolean displayStatusOfcancelLanguage() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancelLanguage() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancelLanguage() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfedit_Language() throws InterruptedException {
		if (editLanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editLanguage.isDisplayed();
	}

	public boolean enableStatusOfedit_Language() throws InterruptedException {
		if (editLanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editLanguage.isEnabled();
	}

	public void clickOnedit_Language() throws InterruptedException {
		editLanguage.click();
	}

	public boolean displayStatusOfedit_languageName() throws InterruptedException {
		if (languageName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageName.isDisplayed();
	}

	public boolean enableStatusOfedit_languageName() throws InterruptedException {
		if (languageName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageName.isEnabled();
	}

	public void enterDataInedit_languageName(String LanguageName) throws InterruptedException {
		new Actions(driver).click(languageName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(languageName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		languageName.sendKeys(LanguageName);
	}

	public boolean displayStatusOfedit_languageCode() throws InterruptedException {
		if (languageCode.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageCode is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageCode is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageCode.isDisplayed();
	}

	public boolean enableStatusOfedit_languageCode() throws InterruptedException {
		if (languageCode.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageCode is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageCode is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageCode.isEnabled();
	}

	public void enterDataInedit_languageCode(String LanguageCode) throws InterruptedException {
		new Actions(driver).click(languageCode).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(languageCode, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		languageCode.sendKeys(LanguageCode);
	}

	public boolean displayStatusOfedit_closeLanguage() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_closeLanguage() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOnedit_closeLanguage() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfedit_updateLanguage() throws InterruptedException {
		if (updateLanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateLanguage.isDisplayed();
	}

	public boolean enableStatusOfedit_updateLanguage() throws InterruptedException {
		if (updateLanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateLanguage.isEnabled();
	}

	public void clickOnedit_updateLanguage() throws InterruptedException {
		updateLanguage.click();
	}

	public boolean displayStatusOfedit_cancelLanguage() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancelLanguage() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_cancelLanguage() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfedit_Language_Status() throws InterruptedException {
		if (Language_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Language_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Language_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Language_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Language_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Language_Status.isDisplayed();
	}

	public boolean enableStatusOfedit_Language_Status() throws InterruptedException {
		if (Language_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Language_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Language_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Language_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Language_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Language_Status.isEnabled();
	}

	public void clickOnedit_Language_Status() throws InterruptedException {
		Language_Status.click();
		Thread.sleep(501);
		Language_Status.click();
	}

	public boolean displayStatusOflanguage_Proficiency() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", language_Proficiency);
		Thread.sleep(1000);
		if (language_Proficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(language_Proficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of language_Proficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(language_Proficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of language_Proficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return language_Proficiency.isDisplayed();
	}

	public boolean enableStatusOflanguage_Proficiency() throws InterruptedException {
		if (language_Proficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(language_Proficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of language_Proficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(language_Proficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of language_Proficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return language_Proficiency.isEnabled();
	}

	public void clickOnlanguage_Proficiency() throws InterruptedException {
		language_Proficiency.click();
	}

	public boolean displayStatusOfcreateProficiency() throws InterruptedException {
		if (createProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createProficiency.isDisplayed();
	}

	public boolean enableStatusOfcreateProficiency() throws InterruptedException {
		if (createProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createProficiency.isEnabled();
	}

	public void clickOncreateProficiency() throws InterruptedException {
		createProficiency.click();
	}

	public boolean displayStatusOflanguageProficiencyName() throws InterruptedException {
		if (languageProficiencyName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyName.isDisplayed();
	}

	public boolean enableStatusOflanguageProficiencyName() throws InterruptedException {
		if (languageProficiencyName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyName.isEnabled();
	}

	public void enterDataInlanguageProficiencyName(String LanguageProficiencyName) throws InterruptedException {
		languageProficiencyName.sendKeys(LanguageProficiencyName);
	}

	public boolean displayStatusOfcloseLanguageProficiency() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfcloseLanguageProficiency() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOncloseLanguageProficiency() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfsubmitLanguageProficiency() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmitLanguageProficiency() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmitLanguageProficiency() throws InterruptedException {
		submit.click();
	}

	public boolean displayStatusOfcancelLanguageProficiency() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancelLanguageProficiency() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancelLanguageProficiency() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfedit_LanguageProficiency() throws InterruptedException {
		if (editlanguageProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editlanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editlanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editlanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editlanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editlanguageProficiency.isDisplayed();
	}

	public boolean enableStatusOfedit_LanguageProficiency() throws InterruptedException {
		if (editlanguageProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editlanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editlanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editlanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editlanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editlanguageProficiency.isEnabled();
	}

	public void clickOnedit_LanguageProficiency() throws InterruptedException {
		editlanguageProficiency.click();
	}

	public boolean displayStatusOfedit_languageProficiencyName() throws InterruptedException {
		if (languageProficiencyName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyName.isDisplayed();
	}

	public boolean enableStatusOfedit_languageProficiencyName() throws InterruptedException {
		if (languageProficiencyName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyName.isEnabled();
	}

	public void enterDataInedit_languageProficiencyName(String LanguageName) throws InterruptedException {
		new Actions(driver).click(languageProficiencyName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(languageProficiencyName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		languageProficiencyName.sendKeys(LanguageName);
	}

	public boolean displayStatusOfedit_closeLanguageProficiency() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_closeLanguageProficiency() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOnedit_closeLanguageProficiency() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfedit_updateLanguageProficiency() throws InterruptedException {
		if (updatelanguageProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updatelanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updatelanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updatelanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of updatelanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updatelanguageProficiency.isDisplayed();
	}

	public boolean enableStatusOfedit_updateLanguageProficiency() throws InterruptedException {
		if (updatelanguageProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updatelanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updatelanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updatelanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updatelanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updatelanguageProficiency.isEnabled();
	}

	public void clickOnedit_updateLanguageProficiency() throws InterruptedException {
		updatelanguageProficiency.click();
	}

	public boolean displayStatusOfedit_cancelLanguageProficiency() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancelLanguageProficiency() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_cancelLanguageProficiency() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfedit_languageProficiencyStatus() throws InterruptedException {
		if (languageProficiencyStatus.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of languageProficiencyStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyStatus.isDisplayed();
	}

	public boolean enableStatusOfedit_languageProficiencyStatus() throws InterruptedException {
		if (languageProficiencyStatus.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyStatus.isEnabled();
	}

	public void clickOnedit_languageProficiencyStatus() throws InterruptedException {
		languageProficiencyStatus.click();
		Thread.sleep(501);
		languageProficiencyStatus.click();
	}

	public boolean displayStatusOfedit_routingAlgorithm() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", routingAlgorithm);
		Thread.sleep(1000);
		if (routingAlgorithm.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithm);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithm is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithm);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithm is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithm.isDisplayed();
	}

	public boolean enableStatusOfedit_routingAlgorithm() throws InterruptedException {
		if (routingAlgorithm.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithm);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithm is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithm);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithm is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithm.isEnabled();
	}

	public void clickOnedit_routingAlgorithm() throws InterruptedException {
		routingAlgorithm.click();
	}

	public boolean displayStatusOfedit_routingAlgorithmStatus() throws InterruptedException {
		if (routingAlgorithmStatus.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmStatus.isDisplayed();
	}

	public boolean enableStatusOfedit_routingAlgorithmStatus() throws InterruptedException {
		if (routingAlgorithmStatus.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmStatus.isEnabled();
	}

	public void clickOnedit_routingAlgorithmStatus() throws InterruptedException {
		routingAlgorithmStatus.click();
		Thread.sleep(501);
		routingAlgorithmStatus.click();
		Thread.sleep(2000);
		master.click();
	}

	public boolean displayStatusOfmoduleMaster() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", moduleMaster);
		Thread.sleep(1000);
		if (moduleMaster.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(moduleMaster);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of moduleMaster is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(moduleMaster);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of moduleMaster is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return moduleMaster.isDisplayed();
	}

	public boolean enableStatusOfmoduleMaster() throws InterruptedException {
		if (moduleMaster.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(moduleMaster);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of moduleMaster is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(moduleMaster);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of moduleMaster is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return moduleMaster.isEnabled();
	}

	public void clickOnmoduleMaster() throws InterruptedException {
		moduleMaster.click();
	}

	public boolean displayStatusOfselectAppName() throws InterruptedException {
		if (selectAppName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectAppName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectAppName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectAppName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectAppName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectAppName.isDisplayed();
	}

	public boolean enableStatusOfselectAppName() throws InterruptedException {
		if (selectAppName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectAppName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectAppName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectAppName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectAppName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectAppName.isEnabled();
	}

	public void clickOnselectAppName() throws InterruptedException {
		selectAppName.click();
	}

	public void selectTheDpValueFromSelectAppName(String appNAme) {

		driver.findElement(By.xpath("//span[text()='" + appNAme + "']")).click();
	}
}
