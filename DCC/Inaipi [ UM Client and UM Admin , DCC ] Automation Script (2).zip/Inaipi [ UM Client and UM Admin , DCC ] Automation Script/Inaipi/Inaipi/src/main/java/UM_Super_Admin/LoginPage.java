package UM_Super_Admin;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class LoginPage extends BaseClass{

	@FindBy(xpath = "//input[@id='email']")
	WebElement username;

	@FindBy(xpath = "//input[@id='password']")
	WebElement password;

	@FindBy(xpath = "//div[@class='MuiInputAdornment-root MuiInputAdornment-positionEnd MuiInputAdornment-marginDense']")
	WebElement eye;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement login;
	
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	

	public boolean displayStatusOfusername1() throws InterruptedException {
//		UtilsLayerPackage.displayStatus.DisplayStatus(username, "username");
		return username.isDisplayed();
	}

	public boolean enableStatusOfusername() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(username, "username");
		return username.isEnabled();
	}

	public void enterDataInusername(String Username) {
		username.sendKeys(Username);
	}

	public boolean displayStatusOfpassword() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(password, "password");
		return password.isDisplayed();
	}

	public boolean enableStatusOfpassword() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(password, "password");
		return password.isEnabled();
	}

	public void enterDataInpassword(String Password) {
		password.sendKeys(Password);
//		log.info("Enter Password : " + Password );
	}
	public boolean displayStatusOfeye() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(eye, "eye");
		return eye.isDisplayed();
	}
	
	public boolean enableStatusOfeye() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(eye, "eye");
		return eye.isEnabled();
	}
	
	public void clickOneye() {
		eye.click();
//		log.info("Click on eye btn");
	}
	public boolean displayStatusOflogin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(login, "login");
		return login.isDisplayed();
	}
	
	public boolean enableStatusOflogin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(login, "login");
		return login.isEnabled();
	}
	
	public void clickOnlogin() {
		login.click();
//		log.info("Click on login");
	}

}
