package UtilsLayerPackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import BaseLayerPackage.BaseClass;

public class HandleWindows extends BaseClass {

	public static String handle_Two_Window(String parent, Set<String> allWindow) {
		for (String abc : allWindow) {
			if (!abc.equals(parent)) {
				driver.switchTo().window(abc);
				return driver.getWindowHandle();
			}
		}
		return null;
	}

	public static String handle_Three_Window(String parent, Set<String> allWindow, Set<String> child1) {
		for (String abc : allWindow) {
			if (!abc.equals(parent) && !abc.equals(child1)) {
				driver.switchTo().window(abc);
				return driver.getWindowHandle();
			}
		}
		return null;
	}

	public static void handle_Window_By_ArrayList(Set<String> allWindow, int index) {
		ArrayList<String> arr = new ArrayList<String>(allWindow);
		driver.switchTo().window(arr.get(index));
	}

	public static void switchToWindows_By_Use_Of_Iterator(int index) {
		String windowId = null;
		Set<String> windowIds = driver.getWindowHandles();
		Iterator<String> iter = windowIds.iterator();

		for (int i = 0; i <= index; i++) {
			windowId = iter.next();
		}
		driver.switchTo().window(windowId);
	}
}
