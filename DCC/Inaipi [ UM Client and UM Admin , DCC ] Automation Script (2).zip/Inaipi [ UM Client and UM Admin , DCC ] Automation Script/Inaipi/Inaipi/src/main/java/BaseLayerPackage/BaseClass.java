package BaseLayerPackage;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import UtilsLayerPackage.ExcelReader;


public class BaseClass {

	public static WebDriver driver;
	public static WebDriver driver2;
	public static WebDriver driver3;
	public static ExcelReader excel;

	public static void StartingUMClient() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
//		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\DCC.xlsx");
		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\DCC_EXCEL\\DCC.xlsx");
		String UMClient = excel.getDataFromExcelSheet(0, 2, 1);
		driver.get(UMClient);
	}
	public static void StartingUM_SuperAdmin() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(option);
		option.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
//		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\DCC.xlsx");
		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\DCC_EXCEL\\DCC.xlsx");
		String UMSuperAdmin = excel.getDataFromExcelSheet(0, 9, 1);
		driver.get(UMSuperAdmin);
	}
	public static void chatInterFace() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("use-fake-ui-for-media-stream");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\DCC.xlsx");
		String chatInterfaceURL = excel.getDataFromExcelSheet(0, 16, 1);
		driver.get("https://dcc.inaipi.ae/?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
	}
	public static void PowerBIReport() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("use-fake-ui-for-media-stream");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
//		excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\DCC.xlsx");
		excel = new ExcelReader("C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\DCC_EXCEL\\DCC.xlsx");
		String chatInterfaceURL = excel.getDataFromExcelSheet(0, 16, 1);
		driver.get("https://dcc.inaipi.ae/?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
	}
	public static void CBIReport() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("use-fake-ui-for-media-stream");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
//		excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\DCC.xlsx");
//		excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\CBI_Account_creator.xlsx");
//		String chatInterfaceURL = excel.getDataFromExcelSheet(0, 16, 1);
		driver.get("https://cms.inaipiapp.com/helpdesk_cbi");
	}
	
}
