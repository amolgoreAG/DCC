package UM_Super_Admin;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class masterPage extends BaseClass{

	@FindBy(xpath = "//li[@id='1']")
	WebElement master;
	
	@FindBy(xpath = "//li[text()='Channels']")
	WebElement channel;
	
	@FindBy(xpath = "//span[text()='Create Channel']")
	WebElement createChannel;
	
	@FindBy(xpath = "//input[@id='channelName']")
	WebElement channelName;
	
	@FindBy(xpath = "//textarea[@id='channelDesc']")
	WebElement channelDiscription;
	
	@FindBy(xpath = "//span[text()='SUBMIT']")
	WebElement submit;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]//tbody/tr[1]/td[5]/center//*[starts-with(@class,'MuiSvgIcon-root m-r-20 text-a')]")
	WebElement editChannel;
	
	@FindBy(xpath = "//span[text()='UPDATE CHANNEL']")
	WebElement updateChannel;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div/table/tbody/tr[1]/td[1]/center/button/span//*[@class='MuiSvgIcon-root']")
	WebElement downArrow;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div/table/tbody/tr[1]/td[5]//*[@title='Create SubChannel']")
	WebElement addSubChannel;
	
	@FindBy(xpath = "//tr[@class='MuiTableRow-root subTable']/td[2]/div/div/div/div/table/tbody/tr[1]/td[4]/center//*[@title='Edit Channel']")
	WebElement editSubChannel;
	
	@FindBy(xpath = "//li[text()='Routers']")
	WebElement router;
	
	@FindBy(xpath = "//span[text()='Create Router']")
	WebElement createRouter;
	
	@FindBy(xpath = "//input[@id='name']")
	WebElement routerName;
	
	@FindBy(xpath = "//textarea[@id='desc']")
	WebElement routerDiscription;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div//tbody/tr[1]/td[5]/center//*[@title='Edit Router']")
	WebElement editRouter;
	
	@FindBy(xpath = "//span[text()='UPDATE ROUTER']")
	WebElement updateRouter;
	
	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement cancel;
	
	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiIconButton-root float-r']/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement close;

	public masterPage() {
		PageFactory.initElements(driver, this);
	}
	public boolean displayStatusOfmaster() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(master, "master");
		return master.isDisplayed();
	}
	
	public boolean enableStatusOfmaster() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(master, "master");
		return master.isEnabled();
	}
	
	public void clickOnmaster() throws InterruptedException {
		master.click();
	}
	public boolean displayStatusOfchannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channel, "channel");
		return channel.isDisplayed();
	}
	
	public boolean enableStatusOfchannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channel, "channel");
		return channel.isEnabled();
	}
	
	public void clickOnchannel() throws InterruptedException {
		channel.click();
	}
	public boolean displayStatusOfcreateChannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(createChannel, "createChannel");
		return createChannel.isDisplayed();
	}
	
	public boolean enableStatusOfcreateChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(createChannel, "createChannel");
		return createChannel.isEnabled();
	}
	
	public void clickOncreateChannel() throws InterruptedException {
		createChannel.click();
	}
	public boolean displayStatusOfchannelName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelName, "channelName");
		return channelName.isDisplayed();
	}
	
	public boolean enableStatusOfchannelName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelName, "channelName");
		return channelName.isEnabled();
	}
	
	public void enterDataInchannelName(String ChannelName) throws InterruptedException {
		channelName.sendKeys(ChannelName);
	}
	public boolean displayStatusOfchannelDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfchannelDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isEnabled();
	}
	
	public void enterDataInchannelDiscription(String ChannelDiscription) throws InterruptedException {
		channelDiscription.sendKeys(ChannelDiscription);
	}
	public boolean displayStatusOfcloseCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfcloseCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOncloseCreateChnnel() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfcancelCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfcancelCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOncancelCreateChnnel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfsubmitCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(submit, "submit");
		return submit.isDisplayed();
	}
	
	public boolean enableStatusOfsubmitCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(submit, "submit");
		return submit.isEnabled();
	}
	
	public void clickOnsubmitCreateChnnel() throws InterruptedException {
		submit.click();
	}
	public boolean displayStatusOfeditChannelCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(editChannel, "editChannel");
		return editChannel.isDisplayed();
	}
	
	public boolean enableStatusOfeditChannelCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(editChannel, "editChannel");
		return editChannel.isEnabled();
	}
	
	public void clickOneditChannelCreateChnnel() throws InterruptedException {
		editChannel.click();
	}
	public boolean displayStatusOfeditMain_channelName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelName, "channelName");
		return channelName.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_channelName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelName, "channelName");
		return channelName.isEnabled();
	}
	
	public void enterDataIneditMain_channelName(String ChannelName) throws InterruptedException {
		channelName.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		channelName.sendKeys(ChannelName);
	}
	public boolean displayStatusOfeditMain_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isEnabled();
	}
	
	public void enterDataIneditMain_channelDiscription(String ChannelDiscription) throws InterruptedException {
		channelDiscription.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		channelDiscription.sendKeys(ChannelDiscription);
	}
	public boolean displayStatusOfeditMain_close() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_close() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOneditMain_close() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfeditMain_cancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_cancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOneditMain_cancel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfeditMain_updateChannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(updateChannel, "updateChannel");
		return updateChannel.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_updateChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(updateChannel, "updateChannel");
		return updateChannel.isEnabled();
	}
	
	public void clickOneditMain_updateChannel() throws InterruptedException {
		updateChannel.click();
	}
	public boolean displayStatusOfedit_downArrow() throws InterruptedException {
		if (downArrow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("alert('Display Status Of downArrow is True')");
			Thread.sleep(1000);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(500);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is False')");
			Thread.sleep(1000);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(500);
		}
		return downArrow.isDisplayed();
	}
	
	public boolean enableStatusOfedit_downArrow() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(downArrow, "downArrow");
		return downArrow.isEnabled();
	}
	
	public void clickOnedit_downArrow() throws InterruptedException {
		downArrow.click();
	}
	public boolean displayStatusOfedit_addSubChannel() throws InterruptedException {
		if (addSubChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSubChannel);
			Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("alert('Display Status Of addSubChannel is True')");
			Thread.sleep(1000);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(500);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSubChannel);
			Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSubChannel is False')");
			Thread.sleep(1000);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(500);
		}
		return addSubChannel.isDisplayed();
	}
	
	public boolean enableStatusOfedit_addSubChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(addSubChannel, "addSubChannel");
		return addSubChannel.isEnabled();
	}
	
	public void clickOnedit_addSubChannel() throws InterruptedException {
		try {
			addSubChannel.click();
		} catch (Exception e) {
			new Actions(driver).click(addSubChannel).build().perform();
		}
	}
	public boolean displayStatusOfaddsub_channelName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelName, "channelName");
		return channelName.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_channelName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelName, "channelName");
		return channelName.isEnabled();
	}
	
	public void enterDataInaddsub_channelName(String ChannelName) throws InterruptedException {
		channelName.sendKeys(ChannelName);
	}
	public boolean displayStatusOfaddsub_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isEnabled();
	}
	
	public void enterDataInaddsub_channelDiscription(String ChannelDiscription) throws InterruptedException {
		channelDiscription.sendKeys(ChannelDiscription);
	}
	public boolean displayStatusOfaddsub_close() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_close() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnaddsub_close() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfaddsub_cancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_cancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOnaddsub_cancel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfaddsub_submit() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(submit, "submit");
		return submit.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_submit() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(submit, "submit");
		return submit.isEnabled();
	}
	
	public void clickOnaddsub_submit() throws InterruptedException {
		submit.click();
	}
	public boolean displayStatusOfeditsub_editSubChannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(editSubChannel, "editSubChannel");
		return editSubChannel.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_editSubChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(editSubChannel, "editSubChannel");
		return editSubChannel.isEnabled();
	}
	
	public void clickOneditsub_editSubChannel() throws InterruptedException {
		editSubChannel.click();
	}
	public boolean displayStatusOfeditsub_channelName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelName, "channelName");
		return channelName.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_channelName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelName, "channelName");
		return channelName.isEnabled();
	}
	
	public void enterDataIneditsub_channelName(String ChannelName) throws InterruptedException {
		channelName.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		channelName.sendKeys(ChannelName);
	}
	public boolean displayStatusOfeditsub_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isEnabled();
	}
	
	public void enterDataIneditsub_channelDiscription(String ChannelDiscription) throws InterruptedException {
		channelDiscription.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		channelDiscription.sendKeys(ChannelDiscription);
	}
	public boolean displayStatusOfeditsub_close() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_close() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOneditsub_close() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfeditsub_cancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_cancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOneditsub_cancel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfeditsub_updateChannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(updateChannel, "updateChannel");
		return updateChannel.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_updateChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(updateChannel, "updateChannel");
		return updateChannel.isEnabled();
	}
	
	public void clickOneditsub_updateChannel() throws InterruptedException {
		updateChannel.click();
	}
	public boolean displayStatusOfrouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(router, "router");
		return router.isDisplayed();
	}
	
	public boolean enableStatusOfrouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(router, "router");
		return router.isEnabled();
	}
	
	public void clickOnrouter() throws InterruptedException {
		router.click();
	}
	public boolean displayStatusOfcreateRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(createRouter, "createRouter");
		return createRouter.isDisplayed();
	}
	
	public boolean enableStatusOfcreateRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(createRouter, "createRouter");
		return createRouter.isEnabled();
	}
	
	public void clickOncreateRouter() throws InterruptedException {
		createRouter.click();
	}
	public boolean displayStatusOfrouterName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routerName, "routerName");
		return routerName.isDisplayed();
	}
	
	public boolean enableStatusOfrouterName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routerName, "routerName");
		return routerName.isEnabled();
	}
	
	public void enterDataInrouterName(String RouterName) throws InterruptedException {
		routerName.sendKeys(RouterName);
	}
	public boolean displayStatusOfrouterDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routerDiscription, "routerDiscription");
		return routerDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfrouterDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routerDiscription, "routerDiscription");
		return routerDiscription.isEnabled();
	}
	
	public void enterDataInrouterDiscription(String RouterDiscription) throws InterruptedException {
		routerDiscription.sendKeys(RouterDiscription);
	}
	public boolean displayStatusOfclose1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfclose1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnclose1() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfcancel1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfcancel1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOncancel1() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfsubmit1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(submit, "submit");
		return submit.isDisplayed();
	}
	
	public boolean enableStatusOfsubmit1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(submit, "submit");
		return submit.isEnabled();
	}
	
	public void clickOnsubmit1() throws InterruptedException {
		submit.click();
	}
	public boolean displayStatusOfeditRouter1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(editRouter, "editRouter");
		return editRouter.isDisplayed();
	}
	
	public boolean enableStatusOfeditRouter1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(editRouter, "editRouter");
		return editRouter.isEnabled();
	}
	
	public void clickOneditRouter1() throws InterruptedException {
		editRouter.click();
	}
	public boolean displayStatusOfupdate_routerName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routerName, "routerName");
		return routerName.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_routerName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routerName, "routerName");
		return routerName.isEnabled();
	}
	
	public void enterDataInupdate_routerName(String RouterName) throws InterruptedException {
		routerName.sendKeys(RouterName);
	}
	public boolean displayStatusOfupdate_routerDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routerDiscription, "routerDiscription");
		return routerDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_routerDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routerDiscription, "routerDiscription");
		return routerDiscription.isEnabled();
	}
	
	public void enterDataInupdate_routerDiscription(String RouterDiscription) throws InterruptedException {
		routerDiscription.sendKeys(RouterDiscription);
	}
	public boolean displayStatusOfupdate_close1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_close1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnupdate_close1() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfupdate_cancel1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_cancel1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOnupdate_cancel1() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfupdate_updateRouter1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(updateRouter, "updateRouter");
		return updateRouter.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_updateRouter1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(updateRouter, "updateRouter");
		return updateRouter.isEnabled();
	}
	
	public void clickOnupdate_updateRouter1() throws InterruptedException {
		updateRouter.click();
		Thread.sleep(2000);
		master.click();
	}
}
