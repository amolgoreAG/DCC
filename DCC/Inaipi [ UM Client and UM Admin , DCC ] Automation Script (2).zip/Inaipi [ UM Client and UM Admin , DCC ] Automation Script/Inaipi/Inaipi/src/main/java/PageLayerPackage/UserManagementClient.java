package PageLayerPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Sleeper;

import BaseLayerPackage.BaseClass;
import io.reactivex.rxjava3.functions.Action;

public class UserManagementClient extends BaseClass {

	// login page

	@FindBy(xpath = "//input[@id='email']")
	WebElement username;

	@FindBy(xpath = "//input[@id='password']")
	WebElement password;

	@FindBy(xpath = "//div[@class='MuiInputAdornment-root MuiInputAdornment-positionEnd MuiInputAdornment-marginDense']")
	WebElement eye;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement login;

	// Master

	@FindBy(xpath = "//li[@id='1']")
	WebElement master;

	// role

	@FindBy(xpath = "//li[text()='Role']")
	WebElement role;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement createRole;

	@FindBy(xpath = "//input[@id='roleName']")
	WebElement roleName;

	@FindBy(xpath = "//textarea[@id='description']")
	WebElement roleDiscription;

	@FindBy(xpath = "//div[@class='MuiDialogTitle-root']//span[1]")
	WebElement close;

	@FindBy(xpath = "//span[text()='SUBMIT']")
	WebElement submit;

	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement cancel;

	@FindBy(xpath = "//table[@class='MuiTable-root']//tbody/tr[1]/td[4]//*[@class='MuiSvgIcon-root m-r-20 text-a MuiSvgIcon-fontSizeSmall']")
	WebElement edit;

	@FindBy(xpath = "//input[@id='roleName']")
	WebElement edit_roleName;

	@FindBy(xpath = "//textarea[@id='description']")
	WebElement edit_roleDiscription;

	@FindBy(xpath = "//div[@class='MuiDialogTitle-root']//span[1]")
	WebElement edit_close;

	@FindBy(xpath = "//span[text()='UPDATE ROLE']")
	WebElement updateRole;

	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement edit_cancel;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[1]/td[4]//center/span")
	WebElement status;

	// Group

	@FindBy(xpath = "//li[text()='Group']")
	WebElement group;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement createGroup;

	@FindBy(xpath = "//input[@id='groupName']")
	WebElement groupName;

	@FindBy(xpath = "//textarea[@id='description']")
	WebElement groupNameDiscription;

	@FindBy(xpath = "//span[text()='UPDATE GROUP']")
	WebElement updateGroup;

	// Channel

	@FindBy(xpath = "//li[text()='Channel']")
	WebElement channel;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[2]/td[5]//center/span")
	WebElement channelStatus1;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[2]/td[1]//button")
	WebElement downArrow;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[1]/td[4]//center/span")
	WebElement channelSub1;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[2]/td[4]//center/span")
	WebElement channelSub2;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[3]/td[4]//center/span")
	WebElement channelSub3;

	@FindBy(xpath = "//li[text()='Status']")
	WebElement Status;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement create_Status;

	@FindBy(xpath = "//input[@id='statusName']")
	WebElement Status_Name;

	@FindBy(xpath = "//textarea[@id='statusDesc']")
	WebElement Status_Discription;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[5]/center//*[@title='Edit Role']")
	WebElement edit_status;

	@FindBy(xpath = "//span[text()='UPDATE STATUS']")
	WebElement updateStatus;

	@FindBy(xpath = "//div[@class='MuiTableContainer-root']/table//tbody/tr[1]/td[5]//center/span")
	WebElement Status_Status;

	// skill

	@FindBy(xpath = "//li[text()='Skillset']")
	WebElement skillSet;

	@FindBy(xpath = "//span[text()='Create Skill']")
	WebElement createSkill;

	@FindBy(xpath = "//input[@id='skillName']")
	WebElement skillName;

	@FindBy(xpath = "(//td[@class='MuiTableCell-root MuiTableCell-body'])[4]//*[@title='Edit skillset']")
	WebElement editSkill;

	@FindBy(xpath = "//span[text()='UPDATE SKILL']")
	WebElement updateSkill;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center/span")
	WebElement skill_Status;

	// skill Proficiency

	@FindBy(xpath = "//li[text()='Skill Proficiency']")
	WebElement skillProfeciancy;

	@FindBy(xpath = "//span[text()='Add Proficiency']")
	WebElement createProfeciancy;

	@FindBy(xpath = "//input[@id='proficiencyDesc']")
	WebElement skillProfeciancyName;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center//*[@title='Edit Role']")
	WebElement editProfeciancy;

	@FindBy(xpath = "//span[text()='UPDATE PROFICIENCY']")
	WebElement updateProfeciancy;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]//span[@class='MuiSwitch-root MuiSwitch-sizeSmall']")
	WebElement profeciancy_Status;

	// language

	@FindBy(xpath = "//li[text()='Language']")
	WebElement language;

	@FindBy(xpath = "//span[text()='Create Language']")
	WebElement createLanguage;

	@FindBy(xpath = "//input[@id='languageDesc']")
	WebElement languageName;

	@FindBy(xpath = "//input[@id='languageCode']")
	WebElement languageCode;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[5]/center//*[@title='Edit Role']")
	WebElement editLanguage;

	@FindBy(xpath = "//span[text()='UPDATE LANGUAGE']")
	WebElement updateLanguage;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[5]/center/span")
	WebElement Language_Status;

	// language Proficiency

	@FindBy(xpath = "//li[text()='Language Proficiency']")
	WebElement language_Proficiency;

	@FindBy(xpath = "//span[text()='Add Proficiency']")
	WebElement createProficiency;

	@FindBy(xpath = "//input[@id='proficiencyDesc']")
	WebElement languageProficiencyName;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center//*[@class='MuiSvgIcon-root m-r-20 text-a MuiSvgIcon-fontSizeSmall']")
	WebElement editlanguageProficiency;

	@FindBy(xpath = "//span[text()='UPDATE PROFICIENCY']")
	WebElement updatelanguageProficiency;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center/span")
	WebElement languageProficiencyStatus;

	// Routing Algorithm

	@FindBy(xpath = "//li[text()='Routing Algorithm']")
	WebElement routingAlgorithm;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']//table//tbody/tr[1]/td[4]/center/span")
	WebElement routingAlgorithmStatus;

	// Module Master

	@FindBy(xpath = "//li[text()='Module Master']")
	WebElement moduleMaster;

	@FindBy(xpath = "//div[@class='react-dropdown-select m-t-5 css-wmw4vi-ReactDropdownSelect e1gzf2xs0']")
	WebElement selectAppName;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement view;

	// create client

	@FindBy(xpath = "//span[text()='User Creation']")
	WebElement createClient;

	@FindBy(xpath = "//input[@id='firstName']")
	WebElement firstName;

	@FindBy(xpath = "//input[@id='lastName']")
	WebElement lastName;

	@FindBy(xpath = "//input[@id='email']")
	WebElement email;

	@FindBy(xpath = "//input[@id='contactNumber']")
	WebElement contactNumber;

	@FindBy(xpath = "//input[@id='password']")
	WebElement clientPassword;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[5]/div/div[2]/div/div/div//*[@class='MuiSvgIcon-root']")
	WebElement clientPasswordShow;

	@FindBy(xpath = "//input[@id='confirmPassword']")
	WebElement clientConfirmPassword;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[6]/div/div[2]/div/div/div//*[@class='MuiSvgIcon-root']")
	WebElement clientConfirmPasswordShow;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[7]/div[1]/div[2]/div")
	WebElement clientRole;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[8]/div[1]/div[2]/div")
	WebElement clientGroup;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[10]/div[1]/div[2]/div")
	WebElement clientChannel;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[11]/div[1]/div[2]/div")
	WebElement clientSubChannel;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[12]/div/div[1]/span[2]/button")
	WebElement addSkillAndProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[12]/div/div[2]/div/div[1]/div/div")
	WebElement addSkill;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[12]/div/div[2]/div/div[2]/div/div")
	WebElement addSkillProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[12]/div/div[2]/div/div[3]//*[@class='MuiSvgIcon-root groupRemoveIcon']")
	WebElement removeSkillAndProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[13]/div/div[1]/span[2]/button")
	WebElement addLanguageAndProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[13]/div/div[2]/div/div[1]/div/div")
	WebElement addLanguage;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[13]/div/div[2]/div/div[2]/div/div")
	WebElement addLanguageProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[13]/div/div[2]/div/div[3]//*[@class='MuiSvgIcon-root groupRemoveIcon']")
	WebElement removeLanguageAndProfeciancy;

	@FindBy(xpath = "//span[text()='Create User']")
	WebElement createUser;

	@FindBy(xpath = "//span[text()='Clear']")
	WebElement clear;

	@FindBy(xpath = "//span[text()='Users']")
	WebElement users;

	@FindBy(xpath = "//input[@id='searchval']")
	WebElement searchUser;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]/table//tbody/tr[1]/td[4]//*[@title='Edit User']")
	WebElement editUsers;

	@FindBy(xpath = "//input[@id='firstName']")
	WebElement userFirstName;

	@FindBy(xpath = "//input[@id='lastName']")
	WebElement userLastName;

	@FindBy(xpath = "//input[@id='email']")
	WebElement userEmail;

	@FindBy(xpath = "//input[@id='contactNumber']")
	WebElement userContactNumber;

	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[5]/div[1]/div[2]/div/div[1]")
	WebElement userRole;

	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[6]/div[1]/div[2]/div/div[1]")
	WebElement userGroup;

	@FindBy(xpath = "//div[@class='MuiDialogActions-root MuiDialogActions-spacing']/div/button[1]/span[1]")
	WebElement userUpdate;

	@FindBy(xpath = "//div[@class='MuiDialogActions-root MuiDialogActions-spacing']/div/button[2]/span[1]")
	WebElement userCancel;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]/table//tbody/tr[1]/td[4]/span[@class='MuiSwitch-root MuiSwitch-sizeSmall']")
	WebElement UserStatus;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]/table//tbody/tr[1]/td[5]//*[@title='View User']")
	WebElement viewUser;

	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiButton-root MuiButton-contained closeContentBtn']")
	WebElement viewCancel;

	@FindBy(xpath = "//span[text()='User Mapping']")
	WebElement userMapping;

	@FindBy(xpath = "//li[text()='Role Mapping']")
	WebElement roleMapping;

	@FindBy(xpath = "//div[@class='react-dropdown-select m-t-5 css-wmw4vi-ReactDropdownSelect e1gzf2xs0']")
	WebElement selectRole;

	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiButton-root MuiButton-outlined mainContentBlue']")
	WebElement viewSelectRole;

	@FindBy(xpath = "//span[text()='Add Users']")
	WebElement addUsers;

	@FindBy(xpath = "//div[@class='react-dropdown-select halfWidth p-l-10 m-l-20 m-b-10 css-wmw4vi-ReactDropdownSelect e1gzf2xs0']")
	WebElement selectUsers;

	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-item']//*[@title='Click here to save the changes']")
	WebElement saveUser;

	@FindBy(xpath = "//button[@title='Next page']/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement nextPage;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[7]/div//*[3]")
	WebElement minimize;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[6]/div//*[3]")
	WebElement minimize1;

	@FindBy(xpath = "//div[@class='MuiDialogActions-root MuiDialogActions-spacing']/button[2]/span[1]")
	WebElement removeUserNo;

	@FindBy(xpath = "//div[@class='MuiDialogActions-root MuiDialogActions-spacing']/button[1]/span[1]")
	WebElement removeUserYes;

	@FindBy(xpath = "//li[text()='Group Mapping']")
	WebElement groupMapping;

	@FindBy(xpath = "//div[@class='react-dropdown-select m-t-5 css-wmw4vi-ReactDropdownSelect e1gzf2xs0']")
	WebElement selectGroup;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement viewSelectGroup;

	@FindBy(xpath = "//span[text()='CC Mapping']")
	WebElement ccMapping;

	@FindBy(xpath = "//li[text()='Channel Mapping']")
	WebElement channelMapping;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[1]/div/div/div")
	WebElement CCselectChannel;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[2]/div/div/div")
	WebElement CCselectSubChannel;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[3]/div/button/span")
	WebElement CCViewButton;

	@FindBy(xpath = "//span[text()='Add Users']")
	WebElement CCaddUser;

	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select halfWidth')]")
	WebElement CCselectUser;

	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-item']//*[@aria-label='save']")
	WebElement CCsaveUser;

	@FindBy(xpath = "//button[@title='Next page']/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement CCnextPage;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[6]//*[@aria-label='removw']")
	WebElement CCremoveUser;

	@FindBy(xpath = "//span[text()='NO']")
	WebElement CCremoveUserNO;

	@FindBy(xpath = "//span[text()='YES']")
	WebElement CCremoveUserYES;

	@FindBy(xpath = "//li[text()='Skillset Mapping']")
	WebElement skillsetMapping;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[1]/div/div/div")
	WebElement CCskill;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[2]/div/div/div")
	WebElement CCskillProficiency;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[5]//*[@aria-label='removw']")
	WebElement CCremoveUserSM;

	@FindBy(xpath = "//li[text()='Language Mapping']")
	WebElement languageMapping;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[1]/div/div/div")
	WebElement CClanguage;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[2]/div/div/div")
	WebElement CClanguageProficiency;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[4]//*[@aria-label='removw']")
	WebElement CCremoveUserLM;

	@FindBy(xpath = "//li[text()='Chat Configuration']")
	WebElement chatConfiguration;

	@FindBy(xpath = "//input[@id='autoRejectTime']")
	WebElement autoRejectTime;

	@FindBy(xpath = "//input[@id='agentIdleChangeStatusTime']")
	WebElement agentIdleChangeStatusTime;

	@FindBy(xpath = "//input[@id='maxRequestsInQueue']")
	WebElement maxRequestInQueue;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div[1]/div[4]/div/span/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement alertSupCheckBox;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div[1]/div[4]/div/span/span[1]/input")
	WebElement alertSupCheckBox1;

	@FindBy(xpath = "//textarea[@id='welcomeMessage']")
	WebElement welcomeMessage;

	@FindBy(xpath = "//textarea[@id='queueMessage']")
	WebElement queueMessage;

	@FindBy(xpath = "//textarea[@id='agentNAMessage']")
	WebElement agentNAmsg;

	@FindBy(xpath = "//textarea[@id='maxQueueMessage']")
	WebElement maxQueueMessage;

	@FindBy(xpath = "//span[text()='CLEAR']")
	WebElement clearCC;

	@FindBy(xpath = "//span[text()=' SAVE']")
	WebElement saveCC;

	@FindBy(xpath = "//li[text()='Routing Configuration']")
	WebElement routingConfiguration;

	@FindBy(xpath = "//input[@id='globalConcurrency']")
	WebElement globalConcurrency;
//
//	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div[1]/div[1]/div[2]/div[2]/span/span[1]/input")
//	WebElement channelWiseConcurrencyRate;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div[1]/div[1]/div[2]/div[2]/span/span[1]//*[2]")
	WebElement channelWiseConcurrencyRate;

	@FindBy(xpath = "//input[@id='channelConcurrency0']")
	WebElement voice;

	@FindBy(xpath = "//input[@id='channelConcurrency1']")
	WebElement chat;

	@FindBy(xpath = "//input[@id='globalDelayTime']")
	WebElement ACWTime;

	@FindBy(xpath = "//div[@class='m-l-10 m-b-25']/div/div[2]/div[1]/div/div")
	WebElement routingAlgorithmDP;

	@FindBy(xpath = "//div[@class='m-l-10 m-b-25']/div/div[3]//*[@class='MuiSvgIcon-root']")
	WebElement routingAlgorithmDP_Eye;

	@FindBy(xpath = "//input[@id='skillWeightage']")
	WebElement skillWeightage;

	@FindBy(xpath = "//input[@id='languageWeightage']")
	WebElement languageWeightage;

	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement CANCEL;

	@FindBy(xpath = "//span[text()='SAVE']")
	WebElement SAVE;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-30']/div/div/label[3]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement complaintType;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-30']/div/div/label[2]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement skillGroup;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-30']/div/div/label[1]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement Channel;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-20 m-t-20']/div/div/label[1]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement channelBasedRoutingAll;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-20 m-t-20']/div/div/label[2]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement channelBasedRoutingIndividual;

	@FindBy(xpath = "//span[text()='CLEAR']")
	WebElement CLEAR;

	@FindBy(xpath = "//span[text()='SUBMIT']")
	WebElement SUBMIT;

	@FindBy(xpath = "//li[text()='Module Mapping']")
	WebElement Module_Mapping;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root m-l')]/div/div/div")
	WebElement Module_Mapping_selectRole;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root text-right MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-2')]/div/button/span")
	WebElement selectRole_view;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div/table//tbody/tr[1]/td[2]/center/span/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement checkBox1;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div/div[4]/div/div/table/tbody/tr[2]/td[2]/div/div/div/div/table/tbody/tr[4]/td[3]/center/span/span[1]//*[2]")
	WebElement ChatCondWritecheckBox;

	@FindBy(xpath = "//span[text()='Save Module']")
	WebElement saveModule;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div/div[4]/div/div/table/tbody/tr[1]/td[1]/center/button/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement downArrow1;

	public UserManagementClient() {
		PageFactory.initElements(driver, this);
	}

	public boolean displayStatusOfusername() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", username);
		Thread.sleep(1000);
		if (username.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(username);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of username is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(username);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of username is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return username.isDisplayed();
	}

	public boolean enableStatusOfusername() throws InterruptedException {
		if (username.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(username);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of username is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(username);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of username is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return username.isEnabled();
	}

	public void enterDataInusername(String Username) throws InterruptedException {
		username.sendKeys(Username);
	}

	public boolean displayStatusOfpassword() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", password);
		Thread.sleep(1000);
		if (password.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(password);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of password is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(password);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of password is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return password.isDisplayed();
	}

	public boolean enableStatusOfpassword() throws InterruptedException {
		if (password.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(password);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of password is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(password);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of password is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return password.isEnabled();
	}

	public void enterDataInpassword(String Password) {
		password.sendKeys(Password);
	}

	public boolean displayStatusOfeye() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", eye);
		Thread.sleep(1000);
		if (eye.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of eye is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of eye is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return eye.isDisplayed();
	}

	public boolean enableStatusOfeye() throws InterruptedException {
		if (eye.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of eye is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of eye is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return eye.isEnabled();
	}

	public void clickOnEye() {
		eye.click();
	}

	public boolean displayStatusOflogin() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", login);
		Thread.sleep(1000);
		if (login.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(login);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of login is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(login);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of login is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return login.isDisplayed();
	}

	public boolean enableStatusOflogin() throws InterruptedException {
		if (login.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(login);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of login is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(login);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of login is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return login.isEnabled();
	}

	public void clickOnlogin() {
		login.click();
	}

	public boolean displayStatusOfmaster() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", master);
		Thread.sleep(1000);
		if (master.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(master);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of master is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(master);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of master is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return master.isDisplayed();
	}

	public boolean enableStatusOfmaster() throws InterruptedException {
		if (master.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(master);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of master is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(master);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of master is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return master.isEnabled();
	}

	public void clickOnmaster() {
		master.click();
	}

	public boolean displayStatusOfrole() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", role);
		Thread.sleep(1000);
		if (role.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(role);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of role is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(role);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of role is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return role.isDisplayed();
	}

	public boolean enableStatusOfrole() throws InterruptedException {
		if (role.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(role);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of role is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(role);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of role is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return role.isEnabled();
	}

	public void clickOnrole() {
		role.click();
	}

	public boolean displayStatusOfcreateRole() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", createRole);
		Thread.sleep(1000);
		if (createRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createRole.isDisplayed();
	}

	public boolean enableStatusOfcreateRole() throws InterruptedException {
		if (createRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createRole.isEnabled();
	}

	public void clickOncreateRole() {
		createRole.click();
	}

	public boolean displayStatusOfroleName() throws InterruptedException {
		if (roleName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleName.isDisplayed();
	}

	public boolean enableStatusOfroleName() throws InterruptedException {
		if (roleName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleName.isEnabled();
	}

	public void enterDataInroleName(String RoleName) {
		roleName.sendKeys(RoleName);
	}

	public boolean displayStatusOfroleDiscription() throws InterruptedException {
		if (roleDiscription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleDiscription.isDisplayed();
	}

	public boolean enableStatusOfroleDiscription() throws InterruptedException {
		if (roleDiscription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleDiscription.isEnabled();
	}

	public void enterDataInroleDiscription(String RoleDiscription) {
		roleDiscription.sendKeys(RoleDiscription);
	}

	public boolean displayStatusOfclose() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfclose() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfcancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancel() {
		cancel.click();
	}

	public boolean displayStatusOfsubmit() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmit() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmit() {
		submit.click();
	}

	public boolean displayStatusOfedit() throws InterruptedException {
		if (edit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit.isDisplayed();
	}

	public boolean enableStatusOfedit() throws InterruptedException {
		if (edit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit.isEnabled();
	}

	public void clickOnedit() {
		edit.click();
	}

	public boolean displayStatusOfedit_roleName() throws InterruptedException {
		if (edit_roleName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_roleName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_roleName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleName.isDisplayed();
	}

	public boolean enableStatusOfedit_roleName() throws InterruptedException {
		if (edit_roleName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_roleName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_roleName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_roleName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleName.isEnabled();
	}

	public void clearTheRoleName() {
		new Actions(driver).click(edit_roleName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(edit_roleName, Keys.DELETE).build().perform();
	}

	public void enterDataInedit_roleName(String edit_RoleName) throws InterruptedException {
		edit_roleName.sendKeys(edit_RoleName);
	}

	public boolean displayStatusOfedit_roleDiscription() throws InterruptedException {
		if (edit_roleDiscription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_roleDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_roleDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleDiscription.isDisplayed();
	}

	public boolean enableStatusOfroleedit_Discription() throws InterruptedException {
		if (edit_roleDiscription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_roleDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_roleDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_roleDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleDiscription.isEnabled();
	}

	public void enterDataInedit_roleDiscription(String edit_RoleDiscription) throws InterruptedException {
		edit_roleDiscription.clear();
		Thread.sleep(1200);
		edit_roleDiscription.sendKeys(edit_RoleDiscription);
	}

	public boolean displayStatusOfedit_close() throws InterruptedException {
		if (edit_close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_close.isDisplayed();
	}

	public boolean enableStatusOfedit_close() throws InterruptedException {
		if (edit_close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_close.isEnabled();
	}

	public boolean displayStatusOfedit_cancel() throws InterruptedException {
		if (edit_cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancel() throws InterruptedException {
		if (edit_cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_cancel.isEnabled();
	}

	public void clickOnedit_cancel() {
		edit_cancel.click();
	}

	public boolean displayStatusOfupdateRole() throws InterruptedException {
		if (updateRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateRole.isDisplayed();
	}

	public boolean enableStatusOfupdateRole() throws InterruptedException {
		if (updateRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateRole.isEnabled();
	}

	public void clickOnupdateRole() {
		updateRole.click();
	}

	public boolean displayStatusOfstatus() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", status);
		Thread.sleep(1000);
		if (status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return status.isDisplayed();
	}

	public boolean enableStatusOfstatus() throws InterruptedException {
		if (status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return status.isEnabled();
	}

	public void clickOnstatus() throws InterruptedException {
		status.click();
		Thread.sleep(3000);
		status.click();
	}

	public boolean displayStatusOfgroup() throws InterruptedException {
		if (group.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(group);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of group is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(group);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of group is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return group.isDisplayed();
	}

	public boolean enableStatusOfgroup() throws InterruptedException {
		if (group.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(group);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of group is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(group);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of group is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return group.isEnabled();
	}

	public void clickOngroup() throws InterruptedException {
		group.click();

	}

	public boolean displayStatusOfcreateGroup() throws InterruptedException {
		if (createGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createGroup.isDisplayed();
	}

	public boolean enableStatusOfcreateGroup() throws InterruptedException {
		if (createGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createGroup.isEnabled();
	}

	public void clickOncreateGroup() throws InterruptedException {
		createGroup.click();

	}

	public boolean displayStatusOfgroupName() throws InterruptedException {
		if (groupName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupName.isDisplayed();
	}

	public boolean enableStatusOfgroupName() throws InterruptedException {
		if (groupName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupName.isEnabled();
	}

	public void enterDataIngroupName(String GroupName) {
		groupName.sendKeys(GroupName);
	}

	public boolean displayStatusOfgroupNameDiscription() throws InterruptedException {
		if (groupNameDiscription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupNameDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupNameDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupNameDiscription.isDisplayed();
	}

	public boolean enableStatusOfgroupNameDiscription() throws InterruptedException {
		if (groupNameDiscription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupNameDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupNameDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupNameDiscription.isEnabled();
	}

	public void enterDataIngroupNameDiscription(String GroupNameDiscription) {
		groupNameDiscription.sendKeys(GroupNameDiscription);
	}

	public boolean displayStatusOfclosegroup() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfclosegroup() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfcancelgroup() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancelgroup() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancelDiscription() {
		cancel.click();
	}

	public boolean displayStatusOfsubmitgroup() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmitgroup() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmitDiscription() {
		submit.click();
	}

	public boolean displayStatusOfeditgroup() throws InterruptedException {
		if (edit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit.isDisplayed();
	}

	public boolean enableStatusOfeditgroup() throws InterruptedException {
		if (edit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit.isEnabled();
	}

	public void clickOneditDiscription() {
		edit.click();
	}

	public boolean displayStatusOfedit_groupName() throws InterruptedException {
		if (groupName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupName.isDisplayed();
	}

	public boolean enableStatusOfedit_groupName() throws InterruptedException {
		if (groupName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupName.isEnabled();
	}

	public void clearThegroupName() {
		new Actions(driver).click(groupName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(groupName, Keys.DELETE).build().perform();
	}

	public void enterDataInedit_groupNameDiscription(String edit_GroupName) throws InterruptedException {
		groupName.sendKeys(edit_GroupName);
	}

	public boolean displayStatusOfedit_groupNamegroup() throws InterruptedException {
		if (groupNameDiscription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupNameDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupNameDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupNameDiscription.isDisplayed();
	}

	public boolean enableStatusOfroleedit_groupNamegroup() throws InterruptedException {
		if (groupNameDiscription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupNameDiscription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupNameDiscription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupNameDiscription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_roleDiscription.isEnabled();
	}

	public void enterDataInedit_groupNamegroup(String edit_GroupNameDiscription) throws InterruptedException {
		groupNameDiscription.clear();
		Thread.sleep(1200);
		groupNameDiscription.sendKeys(edit_GroupNameDiscription);
	}

	public boolean displayStatusOfedit_closegroup() throws InterruptedException {
		if (edit_close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_close.isDisplayed();
	}

	public boolean enableStatusOfedit_closegroup() throws InterruptedException {
		if (edit_close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_close.isEnabled();
	}

	public boolean displayStatusOfedit_cancelgroup() throws InterruptedException {
		if (edit_cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancelgroup() throws InterruptedException {
		if (edit_cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_cancel.isEnabled();
	}

	public void clickOnedit_cancelgroup() {
		edit_cancel.click();
	}

	public boolean displayStatusOfupdateGroup() throws InterruptedException {
		if (updateGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateGroup.isDisplayed();
	}

	public boolean enableStatusOfupdateGroup() throws InterruptedException {
		if (updateGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateGroup.isEnabled();
	}

	public void clickOnupdateGroup() {
		updateGroup.click();
	}

	public boolean displayStatusOfstatusgroup() throws InterruptedException {
		if (status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return status.isDisplayed();
	}

	public boolean enableStatusOfstatusgroup() throws InterruptedException {
		if (status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return status.isEnabled();
	}

	public void clickOnstatusgroup() throws InterruptedException {
		status.click();
		Thread.sleep(3000);
		status.click();
	}

	public boolean displayStatusOfchannel() throws InterruptedException {
		if (channel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channel.isDisplayed();
	}

	public boolean enableStatusOfchannel() throws InterruptedException {
		if (channel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channel.isEnabled();
	}

	public void clickOnchannel() throws InterruptedException {
		channel.click();
	}

	public boolean displayStatusOfchannelStatus1() throws InterruptedException {
		if (channelStatus1.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelStatus1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelStatus1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelStatus1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelStatus1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelStatus1.isDisplayed();
	}

	public boolean enableStatusOfchannelStatus1() throws InterruptedException {
		if (channelStatus1.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelStatus1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelStatus1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelStatus1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelStatus1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelStatus1.isEnabled();
	}

	public void clickOnchannelStatus1() throws InterruptedException {
		channelStatus1.click();
		Thread.sleep(501);
		channelStatus1.click();

	}

	public boolean displayStatusOfdownArrow() throws InterruptedException {
		if (downArrow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return downArrow.isDisplayed();
	}

	public boolean enableStatusOfdownArrow() throws InterruptedException {
		if (downArrow.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of downArrow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of downArrow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return downArrow.isEnabled();
	}

	public void clickOnchanneldownArrow() throws InterruptedException {
		downArrow.click();
	}

	public boolean displayStatusOfchannelSub1() throws InterruptedException {
		if (channelSub1.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub1.isDisplayed();
	}

	public boolean enableStatusOfchannelSub1() throws InterruptedException {
		if (channelSub1.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub1.isEnabled();
	}

	public void clickOnchannelSub1() throws InterruptedException {
		channelSub1.click();
		Thread.sleep(501);
		channelSub1.click();
	}

	public boolean displayStatusOfchannelSub2() throws InterruptedException {
		if (channelSub2.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub2);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub2 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub2);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub2 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub2.isDisplayed();
	}

	public boolean enableStatusOfchannelSub2() throws InterruptedException {
		if (channelSub2.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub2);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub2 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub2);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub2 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub2.isEnabled();
	}

	public void clickOnchannelSub2() throws InterruptedException {
		channelSub2.click();
		Thread.sleep(501);
		channelSub2.click();
	}

	public boolean displayStatusOfchannelSub3() throws InterruptedException {
		if (channelSub3.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub3);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub3 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub3);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelSub3 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub3.isDisplayed();
	}

	public boolean enableStatusOfchannelSub3() throws InterruptedException {
		if (channelSub3.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelSub3);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub3 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelSub3);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelSub3 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelSub3.isEnabled();
	}

	public void clickOnchannelSub3() throws InterruptedException {
		channelSub3.click();
		Thread.sleep(501);
		channelSub3.click();
	}

	public boolean displayStatusOfdownArrow2() throws InterruptedException {
		if (downArrow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return downArrow.isDisplayed();
	}

	public boolean enableStatusOfdownArrow2() throws InterruptedException {
		if (downArrow.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of downArrow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of downArrow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return downArrow.isEnabled();
	}

	public void clickOndownArrow2() throws InterruptedException {
		downArrow.click();
	}

	public boolean displayStatusOfStatus() throws InterruptedException {
		if (Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status.isDisplayed();
	}

	public boolean enableStatusOfStatus() throws InterruptedException {
		if (Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status.isEnabled();
	}

	public void clickOnStatus() throws InterruptedException {
		Status.click();
	}

	public boolean displayStatusOfcreate_Status() throws InterruptedException {
		if (create_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(create_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of create_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(create_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of create_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return create_Status.isDisplayed();
	}

	public boolean enableStatusOfcreate_Status() throws InterruptedException {
		if (create_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(create_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of create_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(create_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of create_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return create_Status.isEnabled();
	}

	public void clickOncreate_Status() throws InterruptedException {
		create_Status.click();
	}

	public boolean displayStatusOfStatus_Name() throws InterruptedException {
		if (Status_Name.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Name is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Name is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Name.isDisplayed();
	}

	public boolean enableStatusOfStatus_Name() throws InterruptedException {
		if (Status_Name.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Name is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Name is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Name.isEnabled();
	}

	public void eneterDataInStatus_Name(String Status_name) throws InterruptedException {
		Status_Name.sendKeys(Status_name);
	}

	public boolean displayStatusOfStatus_Discription() throws InterruptedException {
		if (Status_Discription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Discription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display create_Status of Status_Discription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Discription.isDisplayed();
	}

	public boolean enableStatusOfStatus_Discription() throws InterruptedException {
		if (Status_Discription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Discription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Discription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Discription.isEnabled();
	}

	public void eneterDataInStatus_Discription(String Status_discription) throws InterruptedException {
		Status_Discription.sendKeys(Status_discription);
	}

	public boolean displayStatusOfStatus_close() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfStatus_close() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfStatus_cancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfStatus_cancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnStatus_cancel() {
		cancel.click();
	}

	public boolean displayStatusOfStatus_submit() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfStatus_submit() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnStatus_submit() {
		submit.click();
	}

	public boolean displayStatusOfedit_status() throws InterruptedException {
		if (edit_status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of edit_status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_status.isDisplayed();
	}

	public boolean enableStatusOfedit_status() throws InterruptedException {
		if (edit_status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(edit_status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(edit_status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of edit_status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return edit_status.isEnabled();
	}

	public void clickOnedit_status() {
		edit_status.click();
	}

	public boolean displayStatusOfedit_Status_Name() throws InterruptedException {
		if (Status_Name.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Name is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Name is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Name.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_Name() throws InterruptedException {
		if (Status_Name.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Name is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Name);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Name is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Name.isEnabled();
	}

	public void eneterDataInedit_Status_Name(String Status_name) throws InterruptedException {
		new Actions(driver).click(Status_Name).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(Status_Name, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		Status_Name.sendKeys(Status_name);
	}

	public boolean displayStatusOfedit_Status_Discription() throws InterruptedException {
		if (Status_Discription.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display create_Status of Status_Discription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display create_Status of Status_Discription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Discription.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_Discription() throws InterruptedException {
		if (Status_Discription.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Discription is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Discription);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable create_Status of Status_Discription is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Discription.isEnabled();
	}

	public void eneterDataInedit_Status_Discription(String edit_Status_discription) throws InterruptedException {
		new Actions(driver).click(Status_Discription).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(Status_Discription, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		Status_Discription.sendKeys(edit_Status_discription);
	}

	public boolean displayStatusOfedit_Status_close() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_close() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfedit_Status_cancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_cancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_Status_cancel() {
		cancel.click();
	}

	public boolean displayStatusOfedit_Status_updateStatus() throws InterruptedException {
		if (updateStatus.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateStatus.isDisplayed();
	}

	public boolean enableStatusOfedit_Status_updateStatus() throws InterruptedException {
		if (updateStatus.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateStatus.isEnabled();
	}

	public void clickOnedit_Status_updateStatus() {
		updateStatus.click();
	}

	public boolean displayStatusOfStatus_Status() throws InterruptedException {
		if (Status_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Status_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Status_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Status.isDisplayed();
	}

	public boolean enableStatusOfStatus_Status() throws InterruptedException {
		if (Status_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Status_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Status_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Status_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Status_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Status_Status.isEnabled();
	}

	public void clickOnStatus_Status() throws InterruptedException {
		Status_Status.click();
		Thread.sleep(501);
		Status_Status.click();
	}

	public boolean displayStatusOfskillSet() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillSet);
		Thread.sleep(1000);
		if (skillSet.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillSet);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillSet is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillSet);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillSet is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillSet.isDisplayed();
	}

	public boolean enableStatusOfskillSet() throws InterruptedException {
		if (skillSet.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillSet);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillSet is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillSet);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillSet is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillSet.isEnabled();
	}

	public void clickOnskillSet() {
		skillSet.click();
	}

	public boolean displayStatusOfcreateSkill() throws InterruptedException {
		if (createSkill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createSkill.isDisplayed();
	}

	public boolean enableStatusOfcreateSkill() throws InterruptedException {
		if (createSkill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createSkill.isEnabled();
	}

	public void clickOncreateSkill() {
		createSkill.click();
	}

	public boolean displayStatusOfskillName() throws InterruptedException {
		if (skillName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillName.isDisplayed();
	}

	public boolean enableStatusOfskillName() throws InterruptedException {
		if (skillName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillName.isEnabled();
	}

	public void enterDataInskillName(String SkillName) {
		skillName.sendKeys(SkillName);
	}

	public boolean displayStatusOfskill_close() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfskill_close() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfskill_cancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfskill_cancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnskill_cancel() {
		cancel.click();
	}

	public boolean displayStatusOfSkillsubmit() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfSkillsubmit() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnskillsubmit() {
		submit.click();
	}

	public boolean displayStatusOfeditSkill() throws InterruptedException {
		if (editSkill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editSkill.isDisplayed();
	}

	public boolean enableStatusOfeditSkill() throws InterruptedException {
		if (editSkill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editSkill.isEnabled();
	}

	public void clickOneditSkill() {
		editSkill.click();
	}

	public boolean displayStatusOfedit_skillName() throws InterruptedException {
		if (skillName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillName.isDisplayed();
	}

	public boolean enableStatusOfedit_skillName() throws InterruptedException {
		if (skillName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillName.isEnabled();
	}

	public void enterDataInedit_skillName(String SkillName) throws InterruptedException {
		new Actions(driver).click(skillName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(skillName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		skillName.sendKeys(SkillName);
	}

	public boolean displayStatusOfedit_skill_close() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_skill_close() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public boolean displayStatusOfedit_skill_cancel() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_skill_cancel() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_skill_cancel() {
		cancel.click();
	}

	public boolean displayStatusOfupdateSkill() throws InterruptedException {
		if (updateSkill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateSkill.isDisplayed();
	}

	public boolean enableStatusOfupdateSkill() throws InterruptedException {
		Thread.sleep(2000);
		if (updateSkill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateSkill.isEnabled();
	}

	public void clickOnupdateSkill() {
		updateSkill.click();
	}

	public boolean displayStatusOfskill_Status() throws InterruptedException {
		if (skill_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skill_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skill_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skill_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skill_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skill_Status.isDisplayed();
	}

	public boolean enableStatusOfskill_Status() throws InterruptedException {
		if (skill_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skill_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skill_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skill_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skill_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skill_Status.isEnabled();
	}

	public void clickOnskill_Status() throws InterruptedException {
		skill_Status.click();
		Thread.sleep(501);
		skill_Status.click();
	}

	public boolean displayStatusOfskillProfeciancy() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillProfeciancy);
		Thread.sleep(1000);
		if (skillProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfskillProfeciancy() throws InterruptedException {
		if (skillProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancy.isEnabled();
	}

	public void clickOnskillProfeciancy() throws InterruptedException {
		skillProfeciancy.click();
	}

	public boolean displayStatusOfcreateProfeciancy() throws InterruptedException {
		if (createProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfcreateProfeciancy() throws InterruptedException {
		if (createProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createProfeciancy.isEnabled();
	}

	public void clickOncreateProfeciancy() throws InterruptedException {
		createProfeciancy.click();
	}

	public boolean displayStatusOfskillProfeciancyName() throws InterruptedException {
		if (skillProfeciancyName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancyName.isDisplayed();
	}

	public boolean enableStatusOfskillProfeciancyName() throws InterruptedException {
		if (skillProfeciancyName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancyName.isEnabled();
	}

	public void entertDataInskillProfeciancyName(String SkillProfeciancyName) throws InterruptedException {
		skillProfeciancyName.sendKeys(SkillProfeciancyName);
	}

	public boolean displayStatusOfcloseProfeciancy() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfcloseProfeciancy() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOncloseProfeciancy() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfsubmitProfeciancy() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmitProfeciancy() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmitProfeciancy() throws InterruptedException {
		submit.click();
	}

	public boolean displayStatusOfcancelProfeciancy() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancelProfeciancy() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancelProfeciancy() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfeditProfeciancy() throws InterruptedException {
		if (editProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfeditProfeciancy() throws InterruptedException {
		if (editProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editProfeciancy.isEnabled();
	}

	public void clickOneditProfeciancy() throws InterruptedException {
		editProfeciancy.click();
	}

	public boolean displayStatusOfedit_skillProfeciancyName() throws InterruptedException {
		if (skillProfeciancyName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillProfeciancyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancyName.isDisplayed();
	}

	public boolean enableStatusOfedit_skillProfeciancyName() throws InterruptedException {
		if (skillProfeciancyName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillProfeciancyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillProfeciancyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillProfeciancyName.isEnabled();
	}

	public void entertDataInedit_skillProfeciancyName(String SkillProfeciancyName) throws InterruptedException {
		new Actions(driver).click(skillProfeciancyName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(skillProfeciancyName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		skillProfeciancyName.sendKeys(SkillProfeciancyName);
	}

	public boolean displayStatusOfedit_closeProfeciancy() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_closeProfeciancy() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOnedit_closeProfeciancy() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfedit_updateProfeciancy() throws InterruptedException {
		if (updateProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfedit_updateProfeciancy() throws InterruptedException {
		if (updateProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateProfeciancy.isEnabled();
	}

	public void clickOnedit_updateProfeciancy() throws InterruptedException {
		updateProfeciancy.click();
	}

	public boolean displayStatusOfedit_cancelProfeciancy() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancelProfeciancy() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_cancelProfeciancy() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfprofeciancy_Status() throws InterruptedException {
		if (profeciancy_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(profeciancy_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of profeciancy_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(profeciancy_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of profeciancy_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return profeciancy_Status.isDisplayed();
	}

	public boolean enableStatusOfprofeciancy_Status() throws InterruptedException {
		if (profeciancy_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(profeciancy_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of profeciancy_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(profeciancy_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of profeciancy_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return profeciancy_Status.isEnabled();
	}

	public void clickOnprofeciancy_Status() throws InterruptedException {
		profeciancy_Status.click();
		Thread.sleep(501);
		profeciancy_Status.click();
	}

	public boolean displayStatusOflanguage() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", language);
		Thread.sleep(1000);
		if (language.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(language);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of language is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(language);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of language is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return language.isDisplayed();
	}

	public boolean enableStatusOflanguage() throws InterruptedException {
		if (language.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(language);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of language is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(language);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of language is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return language.isEnabled();
	}

	public void clickOnlanguage() throws InterruptedException {
		language.click();
	}

	public boolean displayStatusOfcreateLanguage() throws InterruptedException {
		if (createLanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createLanguage.isDisplayed();
	}

	public boolean enableStatusOfcreateLanguage() throws InterruptedException {
		if (createLanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createLanguage.isEnabled();
	}

	public void clickOncreateLanguage() throws InterruptedException {
		createLanguage.click();
	}

	public boolean displayStatusOflanguageName() throws InterruptedException {
		if (languageName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageName.isDisplayed();
	}

	public boolean enableStatusOflanguageName() throws InterruptedException {
		if (languageName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageName.isEnabled();
	}

	public void enterDataInlanguageName(String LanguageName) throws InterruptedException {
		languageName.sendKeys(LanguageName);
	}

	public boolean displayStatusOflanguageCode() throws InterruptedException {
		if (languageCode.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageCode is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageCode is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageCode.isDisplayed();
	}

	public boolean enableStatusOflanguageCode() throws InterruptedException {
		if (languageCode.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageCode is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageCode is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageCode.isEnabled();
	}

	public void enterDataInlanguageCode(String LanguageName) throws InterruptedException {
		languageCode.sendKeys(LanguageName);
	}

	public boolean displayStatusOfcloseLanguage() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfcloseLanguage() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOncloseLanguage() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfsubmitLanguage() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmitLanguage() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmitLanguage() throws InterruptedException {
		submit.click();
	}

	public boolean displayStatusOfcancelLanguage() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancelLanguage() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancelLanguage() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfedit_Language() throws InterruptedException {
		if (editLanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editLanguage.isDisplayed();
	}

	public boolean enableStatusOfedit_Language() throws InterruptedException {
		if (editLanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editLanguage.isEnabled();
	}

	public void clickOnedit_Language() throws InterruptedException {
		editLanguage.click();
	}

	public boolean displayStatusOfedit_languageName() throws InterruptedException {
		if (languageName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageName.isDisplayed();
	}

	public boolean enableStatusOfedit_languageName() throws InterruptedException {
		if (languageName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageName.isEnabled();
	}

	public void enterDataInedit_languageName(String LanguageName) throws InterruptedException {
		new Actions(driver).click(languageName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(languageName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		languageName.sendKeys(LanguageName);
	}

	public boolean displayStatusOfedit_languageCode() throws InterruptedException {
		if (languageCode.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageCode is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageCode is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageCode.isDisplayed();
	}

	public boolean enableStatusOfedit_languageCode() throws InterruptedException {
		if (languageCode.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageCode is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageCode);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageCode is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageCode.isEnabled();
	}

	public void enterDataInedit_languageCode(String LanguageCode) throws InterruptedException {
		new Actions(driver).click(languageCode).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(languageCode, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		languageCode.sendKeys(LanguageCode);
	}

	public boolean displayStatusOfedit_closeLanguage() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_closeLanguage() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOnedit_closeLanguage() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfedit_updateLanguage() throws InterruptedException {
		if (updateLanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updateLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateLanguage.isDisplayed();
	}

	public boolean enableStatusOfedit_updateLanguage() throws InterruptedException {
		if (updateLanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updateLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updateLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updateLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updateLanguage.isEnabled();
	}

	public void clickOnedit_updateLanguage() throws InterruptedException {
		updateLanguage.click();
	}

	public boolean displayStatusOfedit_cancelLanguage() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancelLanguage() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_cancelLanguage() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfedit_Language_Status() throws InterruptedException {
		if (Language_Status.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Language_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Language_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Language_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Language_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Language_Status.isDisplayed();
	}

	public boolean enableStatusOfedit_Language_Status() throws InterruptedException {
		if (Language_Status.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Language_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Language_Status is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Language_Status);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Language_Status is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Language_Status.isEnabled();
	}

	public void clickOnedit_Language_Status() throws InterruptedException {
		Language_Status.click();
		Thread.sleep(501);
		Language_Status.click();
	}

	public boolean displayStatusOflanguage_Proficiency() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", language_Proficiency);
		Thread.sleep(1000);
		if (language_Proficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(language_Proficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of language_Proficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(language_Proficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of language_Proficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return language_Proficiency.isDisplayed();
	}

	public boolean enableStatusOflanguage_Proficiency() throws InterruptedException {
		if (language_Proficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(language_Proficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of language_Proficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(language_Proficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of language_Proficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return language_Proficiency.isEnabled();
	}

	public void clickOnlanguage_Proficiency() throws InterruptedException {
		language_Proficiency.click();
	}

	public boolean displayStatusOfcreateProficiency() throws InterruptedException {
		if (createProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createProficiency.isDisplayed();
	}

	public boolean enableStatusOfcreateProficiency() throws InterruptedException {
		if (createProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createProficiency.isEnabled();
	}

	public void clickOncreateProficiency() throws InterruptedException {
		createProficiency.click();
	}

	public boolean displayStatusOflanguageProficiencyName() throws InterruptedException {
		if (languageProficiencyName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyName.isDisplayed();
	}

	public boolean enableStatusOflanguageProficiencyName() throws InterruptedException {
		if (languageProficiencyName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyName.isEnabled();
	}

	public void enterDataInlanguageProficiencyName(String LanguageProficiencyName) throws InterruptedException {
		languageProficiencyName.sendKeys(LanguageProficiencyName);
	}

	public boolean displayStatusOfcloseLanguageProficiency() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfcloseLanguageProficiency() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOncloseLanguageProficiency() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfsubmitLanguageProficiency() throws InterruptedException {
		if (submit.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isDisplayed();
	}

	public boolean enableStatusOfsubmitLanguageProficiency() throws InterruptedException {
		if (submit.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(submit);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of submit is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return submit.isEnabled();
	}

	public void clickOnsubmitLanguageProficiency() throws InterruptedException {
		submit.click();
	}

	public boolean displayStatusOfcancelLanguageProficiency() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfcancelLanguageProficiency() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOncancelLanguageProficiency() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfedit_LanguageProficiency() throws InterruptedException {
		if (editlanguageProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editlanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editlanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editlanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editlanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editlanguageProficiency.isDisplayed();
	}

	public boolean enableStatusOfedit_LanguageProficiency() throws InterruptedException {
		if (editlanguageProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editlanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editlanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editlanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editlanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editlanguageProficiency.isEnabled();
	}

	public void clickOnedit_LanguageProficiency() throws InterruptedException {
		editlanguageProficiency.click();
	}

	public boolean displayStatusOfedit_languageProficiencyName() throws InterruptedException {
		if (languageProficiencyName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyName.isDisplayed();
	}

	public boolean enableStatusOfedit_languageProficiencyName() throws InterruptedException {
		if (languageProficiencyName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyName.isEnabled();
	}

	public void enterDataInedit_languageProficiencyName(String LanguageName) throws InterruptedException {
		new Actions(driver).click(languageProficiencyName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(languageProficiencyName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		languageProficiencyName.sendKeys(LanguageName);
	}

	public boolean displayStatusOfedit_closeLanguageProficiency() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfedit_closeLanguageProficiency() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOnedit_closeLanguageProficiency() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfedit_updateLanguageProficiency() throws InterruptedException {
		if (updatelanguageProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updatelanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of updatelanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updatelanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of updatelanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updatelanguageProficiency.isDisplayed();
	}

	public boolean enableStatusOfedit_updateLanguageProficiency() throws InterruptedException {
		if (updatelanguageProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(updatelanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updatelanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(updatelanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of updatelanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return updatelanguageProficiency.isEnabled();
	}

	public void clickOnedit_updateLanguageProficiency() throws InterruptedException {
		updatelanguageProficiency.click();
	}

	public boolean displayStatusOfedit_cancelLanguageProficiency() throws InterruptedException {
		if (cancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isDisplayed();
	}

	public boolean enableStatusOfedit_cancelLanguageProficiency() throws InterruptedException {
		if (cancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(cancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of cancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return cancel.isEnabled();
	}

	public void clickOnedit_cancelLanguageProficiency() throws InterruptedException {
		cancel.click();
	}

	public boolean displayStatusOfedit_languageProficiencyStatus() throws InterruptedException {
		if (languageProficiencyStatus.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageProficiencyStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of languageProficiencyStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyStatus.isDisplayed();
	}

	public boolean enableStatusOfedit_languageProficiencyStatus() throws InterruptedException {
		if (languageProficiencyStatus.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageProficiencyStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageProficiencyStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageProficiencyStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageProficiencyStatus.isEnabled();
	}

	public void clickOnedit_languageProficiencyStatus() throws InterruptedException {
		languageProficiencyStatus.click();
		Thread.sleep(501);
		languageProficiencyStatus.click();
	}

	public boolean displayStatusOfedit_routingAlgorithm() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", routingAlgorithm);
		Thread.sleep(1000);
		if (routingAlgorithm.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithm);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithm is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithm);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithm is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithm.isDisplayed();
	}

	public boolean enableStatusOfedit_routingAlgorithm() throws InterruptedException {
		if (routingAlgorithm.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithm);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithm is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithm);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithm is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithm.isEnabled();
	}

	public void clickOnedit_routingAlgorithm() throws InterruptedException {
		routingAlgorithm.click();
	}

	public boolean displayStatusOfedit_routingAlgorithmStatus() throws InterruptedException {
		if (routingAlgorithmStatus.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmStatus.isDisplayed();
	}

	public boolean enableStatusOfedit_routingAlgorithmStatus() throws InterruptedException {
		if (routingAlgorithmStatus.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmStatus.isEnabled();
	}

	public void clickOnedit_routingAlgorithmStatus() throws InterruptedException {
		routingAlgorithmStatus.click();
		Thread.sleep(501);
		routingAlgorithmStatus.click();
		Thread.sleep(2000);
		master.click();
	}

	public boolean displayStatusOfmoduleMaster() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", moduleMaster);
		Thread.sleep(1000);
		if (moduleMaster.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(moduleMaster);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of moduleMaster is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(moduleMaster);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of moduleMaster is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return moduleMaster.isDisplayed();
	}

	public boolean enableStatusOfmoduleMaster() throws InterruptedException {
		if (moduleMaster.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(moduleMaster);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of moduleMaster is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(moduleMaster);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of moduleMaster is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return moduleMaster.isEnabled();
	}

	public void clickOnmoduleMaster() throws InterruptedException {
		moduleMaster.click();
	}

	public boolean displayStatusOfselectAppName() throws InterruptedException {
		if (selectAppName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectAppName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectAppName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectAppName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectAppName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectAppName.isDisplayed();
	}

	public boolean enableStatusOfselectAppName() throws InterruptedException {
		if (selectAppName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectAppName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectAppName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectAppName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectAppName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectAppName.isEnabled();
	}

	public void clickOnselectAppName() throws InterruptedException {
		selectAppName.click();
	}

	public void selectTheDpValueFromSelectAppName(String appNAme) {

		driver.findElement(By.xpath("//span[text()='" + appNAme + "']")).click();
	}

	public boolean displayStatusOfcreateClient() throws InterruptedException {
		if (createClient.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createClient is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createClient is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createClient.isDisplayed();
	}

	public boolean enableStatusOfcreateClient() throws InterruptedException {
		if (createClient.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createClient is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createClient is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createClient.isEnabled();
	}

	public void clickOncreateClient() throws InterruptedException {
		createClient.click();
	}

	public boolean displayStatusOffirstName() throws InterruptedException {
		if (firstName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(firstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of firstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(firstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of firstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return firstName.isDisplayed();
	}

	public boolean enableStatusOffirstName() throws InterruptedException {
		if (firstName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(firstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of firstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(firstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of firstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return firstName.isEnabled();
	}

	public void enterDataInfirstName(String FirstName) throws InterruptedException {
		firstName.sendKeys(FirstName);
	}

	public boolean displayStatusOflastName() throws InterruptedException {
		if (lastName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(lastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of lastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(lastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of lastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return lastName.isDisplayed();
	}

	public boolean enableStatusOflastName() throws InterruptedException {
		if (lastName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(lastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of lastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(lastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of lastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return lastName.isEnabled();
	}

	public void enterDataInlastName(String LastName) throws InterruptedException {
		lastName.sendKeys(LastName);
	}

	public boolean displayStatusOfemail() throws InterruptedException {
		if (email.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(email);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of email is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(email);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of email is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return email.isDisplayed();
	}

	public boolean enableStatusOfemail() throws InterruptedException {
		if (email.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(email);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of email is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(email);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of email is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return email.isEnabled();
	}

	public void enterDataInemail(String Email) throws InterruptedException {
		email.sendKeys(Email);
	}

	public boolean displayStatusOfcontactNumber() throws InterruptedException {
		if (contactNumber.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(contactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of contactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(contactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of contactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return contactNumber.isDisplayed();
	}

	public boolean enableStatusOfcontactNumber() throws InterruptedException {
		if (contactNumber.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(contactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of contactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(contactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of contactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return contactNumber.isEnabled();
	}

	public void enterDataIncontactNumber(String ContactNumber) throws InterruptedException {
		contactNumber.sendKeys(ContactNumber);
	}

	public boolean displayStatusOfclientPassword() throws InterruptedException {
		if (clientPassword.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientPassword is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientPassword is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientPassword.isDisplayed();
	}

	public boolean enableStatusOfclientPassword() throws InterruptedException {
		if (clientPassword.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientPassword is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientPassword is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientPassword.isEnabled();
	}

	public void enterDataInclientPassword(String ClientPassword) throws InterruptedException {
		clientPassword.sendKeys(ClientPassword);
	}

	public boolean displayStatusOfclientPasswordShow() throws InterruptedException {
		if (clientPasswordShow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientPasswordShow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientPasswordShow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientPasswordShow.isDisplayed();
	}

	public boolean enableStatusOfclientPasswordShow() throws InterruptedException {
		if (clientPasswordShow.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientPasswordShow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientPasswordShow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientPasswordShow.isEnabled();
	}

	public void clickclientPasswordShow() throws InterruptedException {
		clientPasswordShow.click();
	}

	public boolean displayStatusOfclientConfirmPassword() throws InterruptedException {
		if (clientConfirmPassword.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientConfirmPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientConfirmPassword is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientConfirmPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientConfirmPassword is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientConfirmPassword.isDisplayed();
	}

	public boolean enableStatusOfclientConfirmPassword() throws InterruptedException {
		if (clientConfirmPassword.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientConfirmPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientConfirmPassword is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientConfirmPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientConfirmPassword is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientConfirmPassword.isEnabled();
	}

	public void enterDataInclientConfirmPassword(String ClientConfirmPassword) throws InterruptedException {
		clientConfirmPassword.sendKeys(ClientConfirmPassword);
	}

	public boolean displayStatusOfclientConfirmPasswordShow() throws InterruptedException {
		if (clientConfirmPasswordShow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientConfirmPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientConfirmPasswordShow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientConfirmPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of clientConfirmPasswordShow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientConfirmPasswordShow.isDisplayed();
	}

	public boolean enableStatusOfclientConfirmPasswordShow() throws InterruptedException {
		if (clientConfirmPasswordShow.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientConfirmPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientConfirmPasswordShow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientConfirmPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientConfirmPasswordShow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientConfirmPasswordShow.isEnabled();
	}

	public void clickConfirmPasswordShow() throws InterruptedException {
		clientConfirmPasswordShow.click();
	}

	public boolean displayStatusOfclientRole() throws InterruptedException {
		if (clientRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientRole.isDisplayed();
	}

	public boolean enableStatusOfclientRole() throws InterruptedException {
		if (clientRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientRole.isEnabled();
	}

	public void clickOnclientRole() throws InterruptedException {
		clientRole.click();
	}

	public void selectRoleFromDP(String role) {
		driver.findElement(By.xpath("//span[text()='" + role + "']")).click();
	}

	public boolean displayStatusOfclientGroup() throws InterruptedException {
		if (clientGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientGroup.isDisplayed();
	}

	public boolean enableStatusOfclientGroup() throws InterruptedException {
		if (clientGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientGroup.isEnabled();
	}

	public void clickOnclientGroup() throws InterruptedException {
		clientGroup.click();
	}

	public void selectGroupFromDP(String group) {
		driver.findElement(By.xpath("//span[text()='" + group + "']")).click();
	}

	public boolean displayStatusOfclientChannel() throws InterruptedException {
		if (clientChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientChannel.isDisplayed();
	}

	public boolean enableStatusOfclientChannel() throws InterruptedException {
		if (clientChannel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientChannel.isEnabled();
	}

	public void clickOnclientChannel() throws InterruptedException {
		clientChannel.click();
	}

	public void selectChannelFromDP(String channel) {
		driver.findElement(By.xpath("//span[text()='" + channel + "']")).click();
	}

	public boolean displayStatusOfclientSubChannel() throws InterruptedException {
		if (clientSubChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientSubChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientSubChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientSubChannel.isDisplayed();
	}

	public boolean enableStatusOfclientSubChannel() throws InterruptedException {
		if (clientSubChannel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientSubChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientSubChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientSubChannel.isEnabled();
	}

	public void clickOnclientSubChannel() throws InterruptedException {
		clientSubChannel.click();
	}

	public void selectsubChannelFromDP(String subChannel) {
		driver.findElement(By.xpath("//span[text()='" + subChannel + "']")).click();
	}

	public boolean displayStatusOfaddSkillAndProfeciancy() throws InterruptedException {
		if (addSkillAndProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkillAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkillAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkillAndProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfaddSkillAndProfeciancy() throws InterruptedException {
		if (addSkillAndProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkillAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkillAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkillAndProfeciancy.isEnabled();
	}

	public void clickOnaddSkillAndProfeciancy() throws InterruptedException {
		addSkillAndProfeciancy.click();
	}

	public boolean displayStatusOfaddSkill() throws InterruptedException {
		if (addSkill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkill.isDisplayed();
	}

	public boolean enableStatusOfaddSkill() throws InterruptedException {
		if (addSkill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkill.isEnabled();
	}

	public void clickOnaddSkill() throws InterruptedException {
		addSkill.click();
	}

	public void selectDPValueFromAddSkill(String skill) {
		driver.findElement(By.xpath("//span[text()='" + skill + "']")).click();
	}

	public boolean displayStatusOfaddSkillProfeciancy() throws InterruptedException {
		if (addSkillProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkillProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkillProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkillProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfaddSkillProfeciancy() throws InterruptedException {
		if (addSkillProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkillProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkillProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkillProfeciancy.isEnabled();
	}

	public void clickOnaddSkillProfeciancy() throws InterruptedException {
		addSkillProfeciancy.click();
	}

	public void selectDPValueFromAddSkillProfeciancy() {
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfremoveSkillAndProfeciancy() throws InterruptedException {
		if (removeSkillAndProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeSkillAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of removeSkillAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeSkillAndProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfremoveSkillAndProfeciancy() throws InterruptedException {
		if (removeSkillAndProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeSkillAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeSkillAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeSkillAndProfeciancy.isEnabled();
	}

	public void clickOnremoveSkillAndProfeciancy() throws InterruptedException {
		removeSkillAndProfeciancy.click();
	}

	public boolean displayStatusOfaddLanguageAndProfeciancy() throws InterruptedException {
		if (addLanguageAndProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguageAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of addLanguageAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguageAndProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfaddLanguageAndProfeciancy() throws InterruptedException {
		if (addLanguageAndProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguageAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguageAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguageAndProfeciancy.isEnabled();
	}

	public void clickOnaddLanguageAndProfeciancy() throws InterruptedException {
		addLanguageAndProfeciancy.click();
	}

	public boolean displayStatusOfaddLanguage() throws InterruptedException {
		if (addLanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguage.isDisplayed();
	}

	public boolean enableStatusOfaddLanguage() throws InterruptedException {
		if (addLanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguage.isEnabled();
	}

	public void clickOnaddLanguage() throws InterruptedException {
		addLanguage.click();
	}

	public void selectDPValueFromAddLanguage(String language) {
		driver.findElement(By.xpath("//span[text()='" + language + "']")).click();
	}

	public boolean displayStatusOfaddLanguageProfeciancy() throws InterruptedException {
		if (addLanguageProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguageProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguageProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguageProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguageProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguageProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfaddLanguageProfeciancy() throws InterruptedException {
		if (addLanguageProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguageProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguageProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguageProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguageProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguageProfeciancy.isEnabled();
	}

	public void clickOnaddLanguageProfeciancy() throws InterruptedException {
		addLanguageProfeciancy.click();
	}

	public void selectDPValueFromAddLanguageProfeciancy() {
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfremoveLanguageAndProfeciancy() throws InterruptedException {
		if (removeLanguageAndProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of removeLanguageAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of removeLanguageAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeLanguageAndProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfremoveLanguageAndProfeciancy() throws InterruptedException {
		if (removeLanguageAndProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of removeLanguageAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of removeLanguageAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeLanguageAndProfeciancy.isEnabled();
	}

	public void clickOnremoveLanguageAndProfeciancy() throws InterruptedException {
		removeLanguageAndProfeciancy.click();
	}

	public boolean displayStatusOfcreateUser() throws InterruptedException {
		new Actions(driver).moveToElement(createUser).build().perform();
		Thread.sleep(1000);
		if (createUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createUser.isDisplayed();
	}

	public boolean enableStatusOfcreateUser() throws InterruptedException {
		if (createUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createUser.isEnabled();
	}

	public void clickOncreateUser() throws InterruptedException {
		createUser.click();
	}

	public boolean displayStatusOfclear() throws InterruptedException {
		if (clear.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clear);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clear is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clear);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clear is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clear.isDisplayed();
	}

	public boolean enableStatusOfclear() throws InterruptedException {
		if (clear.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clear);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clear is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clear);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clear is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clear.isEnabled();
	}

	public void clickOnclear() throws InterruptedException {
		clear.click();
	}

	public boolean displayStatusOfusers() throws InterruptedException {
		if (users.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(users);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of users is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(users);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of users is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return users.isDisplayed();
	}

	public boolean enableStatusOfusers() throws InterruptedException {
		if (users.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(users);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of users is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(users);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of users is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return users.isEnabled();
	}

	public void clickOnusers() throws InterruptedException {
		users.click();
	}

	public boolean displayStatusOfsearchUser() throws InterruptedException {
		if (searchUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(searchUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of searchUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(searchUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of searchUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return searchUser.isDisplayed();
	}

	public boolean enableStatusOfsearchUser() throws InterruptedException {
		if (searchUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(searchUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of searchUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(searchUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of searchUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return searchUser.isEnabled();
	}

	public void clickOnsearchUser() throws InterruptedException {
		searchUser.click();
	}

	public void enterDataInsearchUser(String SearchUser) {
		searchUser.sendKeys(SearchUser);
	}

	public boolean displayStatusOfeditUsers() throws InterruptedException {
		if (editUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editUsers.isDisplayed();
	}

	public boolean enableStatusOfeditUsers() throws InterruptedException {
		if (editUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editUsers.isEnabled();
	}

	public void clickOneditUsers() throws InterruptedException {
		editUsers.click();
	}

	public boolean displayStatusOfuserFirstName() throws InterruptedException {
		if (userFirstName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userFirstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userFirstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userFirstName.isDisplayed();
	}

	public boolean enableStatusOfuserFirstName() throws InterruptedException {
		if (userFirstName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userFirstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userFirstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userFirstName.isEnabled();
	}

	public void enterDataInuserFirstName(String UserFirstName) throws InterruptedException {
		new Actions(driver).click(userFirstName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(userFirstName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		userFirstName.sendKeys(UserFirstName);
	}

	public boolean displayStatusOfuserLastName() throws InterruptedException {
		if (userLastName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userLastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userLastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userLastName.isDisplayed();
	}

	public boolean enableStatusOfuserLastName() throws InterruptedException {
		if (userLastName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userLastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userLastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userLastName.isEnabled();
	}

	public void enterDataInuserLastName(String UserLastName) throws InterruptedException {
		new Actions(driver).click(userLastName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(userLastName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		userLastName.sendKeys(UserLastName);
	}

	public boolean displayStatusOfuserEmail() throws InterruptedException {
		if (userEmail.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userEmail is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userEmail is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userEmail.isDisplayed();
	}

	public boolean enableStatusOfuserEmail() throws InterruptedException {
		if (userEmail.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userEmail is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userEmail is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userEmail.isEnabled();
	}

	public void enterDataInuserEmail(String UserEmail) throws InterruptedException {
		new Actions(driver).click(userEmail).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(userEmail, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		userEmail.sendKeys(UserEmail);
	}

	public boolean displayStatusOfuserContactNumber() throws InterruptedException {
		if (userContactNumber.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userContactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userContactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userContactNumber.isDisplayed();
	}

	public boolean enableStatusOfuserContactNumber() throws InterruptedException {
		if (userContactNumber.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userContactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userContactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userContactNumber.isEnabled();
	}

	public void enterDataInuserContactNumber(String UserContactNumber) throws InterruptedException {
		new Actions(driver).click(userContactNumber).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(userContactNumber, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		userContactNumber.sendKeys(UserContactNumber);
	}

	public boolean displayStatusOfuserRole() throws InterruptedException {
		if (userRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userRole.isDisplayed();
	}

	public boolean enableStatusOfuserRole() throws InterruptedException {
		if (userRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userRole.isEnabled();
	}

	public void enterDataInuserRole(String UserRole) throws InterruptedException {
		new Actions(driver).click(userRole).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(1500);
		userRole.click();
		driver.findElement(By.xpath("//span[text()='" + UserRole + "']")).click();
	}

	public boolean displayStatusOfuserGroup() throws InterruptedException {
		if (userGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userGroup.isDisplayed();
	}

	public boolean enableStatusOfuserGroup() throws InterruptedException {
		if (userGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userGroup.isEnabled();
	}

	public void enterDataInuserGroup(String UserGroup) throws InterruptedException {
		new Actions(driver).click(userGroup).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(1500);
		userGroup.click();
		driver.findElement(By.xpath("//span[text()='" + UserGroup + "']")).click();
	}

	public boolean displayStatusOfcloseUserWin() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfcloseUserWin() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOncloseUserWin() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfuserUpdateUserWin() throws InterruptedException {
		if (userUpdate.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userUpdate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userUpdate is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userUpdate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userUpdate is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userUpdate.isDisplayed();
	}

	public boolean enableStatusOfuserUpdateUserWin() throws InterruptedException {
		if (userUpdate.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userUpdate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userUpdate is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userUpdate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userUpdate is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userUpdate.isEnabled();
	}

	public void clickOnuserUpdateUserWin() throws InterruptedException {
		userUpdate.click();
	}

	public boolean displayStatusOfuserCancelUserWin() throws InterruptedException {
		if (userCancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userCancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userCancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userCancel.isDisplayed();
	}

	public boolean enableStatusOfuserCancelUserWin() throws InterruptedException {
		if (userCancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userCancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userCancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userCancel.isEnabled();
	}

	public void clickOnuserCancelUserWin() throws InterruptedException {
		userCancel.click();
	}

	public boolean displayStatusOfUserStatusUserWin() throws InterruptedException {
		if (UserStatus.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(UserStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of UserStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(UserStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of UserStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return UserStatus.isDisplayed();
	}

	public boolean enableStatusOfUserStatusUserWin() throws InterruptedException {
		if (UserStatus.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(UserStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of UserStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(UserStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of UserStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return UserStatus.isEnabled();
	}

	public void clickOnUserStatus() throws InterruptedException {
		try {
			UserStatus.click();
		} catch (Exception e) {
			new Actions(driver).click(UserStatus).build().perform();
		}
		Thread.sleep(3000);
		try {
			UserStatus.click();
		} catch (Exception e) {
			new Actions(driver).click(UserStatus).build().perform();
		}
	}

	public boolean displayStatusOfView_viewUserUserWin() throws InterruptedException {
		if (viewUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewUser.isDisplayed();
	}

	public boolean enableStatusOfView_viewUserUserWin() throws InterruptedException {
		if (viewUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewUser.isEnabled();
	}

	public void clickOnviewUser() {
		viewUser.click();
	}

	public boolean displayStatusOfView_userFirstName() throws InterruptedException {
		if (userFirstName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userFirstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userFirstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userFirstName.isDisplayed();
	}

	public boolean enableStatusOfView_userFirstName() throws InterruptedException {
		if (userFirstName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userFirstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userFirstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userFirstName.isEnabled();
	}

	public void enterDataInuserFirstNameText(String UserFirstName) {
		userFirstName.sendKeys(UserFirstName);
	}

	public boolean displayStatusOfView_userLastName() throws InterruptedException {
		if (userLastName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userLastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userLastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userLastName.isDisplayed();
	}

	public boolean enableStatusOfView_userLastName() throws InterruptedException {
		if (userLastName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userLastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userLastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userLastName.isEnabled();
	}

	public boolean displayStatusOfView_userEmail() throws InterruptedException {
		if (userEmail.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userEmail is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userEmail is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userEmail.isDisplayed();
	}

	public boolean enableStatusOfView_userEmail() throws InterruptedException {
		if (userEmail.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userEmail is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userEmail is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userEmail.isEnabled();
	}

	public boolean displayStatusOfView_userContactNumber() throws InterruptedException {
		if (userContactNumber.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userContactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userContactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userContactNumber.isDisplayed();
	}

	public boolean enableStatusOfView_userContactNumber() throws InterruptedException {
		if (userContactNumber.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userContactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userContactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userContactNumber.isEnabled();
	}

	public boolean displayStatusOfView_userRole() throws InterruptedException {
		if (userRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userRole.isDisplayed();
	}

	public boolean enableStatusOfView_userRole() throws InterruptedException {
		if (userRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userRole.isEnabled();
	}

	public boolean displayStatusOfView_userGroup() throws InterruptedException {
		if (userGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userGroup.isDisplayed();
	}

	public boolean enableStatusOfView_userGroup() throws InterruptedException {
		if (userGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userGroup.isEnabled();
	}

	public boolean displayStatusOfView_viewCancel() throws InterruptedException {
		if (viewCancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewCancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewCancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewCancel.isDisplayed();
	}

	public boolean enableStatusOfView_viewCancel() throws InterruptedException {
		if (viewCancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewCancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewCancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewCancel.isEnabled();
	}

	public void clickOnviewCancel() {
		viewCancel.click();
	}

	public boolean displayStatusOfuserMapping() throws InterruptedException {
		if (userMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userMapping.isDisplayed();
	}

	public boolean enableStatusOfuserMapping() throws InterruptedException {
		if (userMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userMapping.isEnabled();
	}

	public void clickOnuserMapping() {
		userMapping.click();
	}

	public boolean displayStatusOfroleMapping() throws InterruptedException {
		if (roleMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleMapping.isDisplayed();
	}

	public boolean enableStatusOfroleMapping() throws InterruptedException {
		if (roleMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleMapping.isEnabled();
	}

	public void clickOnroleMapping() {
		roleMapping.click();
	}

	public boolean displayStatusOfselectRole() throws InterruptedException {
		if (selectRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectRole.isDisplayed();
	}

	public boolean enableStatusOfselectRole() throws InterruptedException {
		if (selectRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectRole.isEnabled();
	}

	public void clickOnselectRole(String SelectRole) throws InterruptedException {
		selectRole.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + SelectRole + "']")).click();
	}

	public boolean displayStatusOfviewSelectRole() throws InterruptedException {
		if (viewSelectRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewSelectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewSelectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewSelectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewSelectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewSelectRole.isDisplayed();
	}

	public boolean enableStatusOfviewSelectRole() throws InterruptedException {
		if (viewSelectRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewSelectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewSelectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewSelectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewSelectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewSelectRole.isEnabled();
	}

	public void clickOnSelectRole() throws InterruptedException {
		viewSelectRole.click();
	}

	public boolean displayStatusOfaddUsers() throws InterruptedException {
		if (addUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addUsers.isDisplayed();
	}

	public boolean enableStatusOfaddUsers() throws InterruptedException {
		if (addUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addUsers.isEnabled();
	}

	public void clickOnaddUsers() throws InterruptedException {
		addUsers.click();
	}

	public boolean displayStatusOfselectUsers() throws InterruptedException {
		if (selectUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectUsers.isDisplayed();
	}

	public boolean enableStatusOfselectUsers() throws InterruptedException {
		if (selectUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectUsers.isEnabled();
	}

	public void clickAndselectUsers() throws InterruptedException {
		selectUsers.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfsaveUser() throws InterruptedException {
		if (saveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveUser.isDisplayed();
	}

	public boolean enableStatusOfsaveUser() throws InterruptedException {
		if (saveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveUser.isEnabled();
	}

	public void clickOnsaveUser() throws InterruptedException {
		saveUser.click();
	}

	public boolean displayStatusOfnextPage() throws InterruptedException {
		if (nextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of nextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of nextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return nextPage.isDisplayed();
	}

	public boolean enableStatusOfnextPage() throws InterruptedException {
		if (nextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of nextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of nextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return nextPage.isEnabled();
	}

	public void clickOnnextPage() throws InterruptedException {
		Thread.sleep(3000);
		new Actions(driver).moveToElement(nextPage).click().build().perform();
		Thread.sleep(3000);
		new Actions(driver).moveToElement(nextPage).click().build().perform();
		Thread.sleep(3000);
		new Actions(driver).moveToElement(nextPage).click().build().perform();
		Thread.sleep(3000);
	}

	public boolean displayStatusOfminimize() throws InterruptedException {
		if (minimize.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(minimize);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of minimize is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(minimize);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of minimize is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return minimize.isDisplayed();
	}

	public boolean enableStatusOfminimize() throws InterruptedException {
		if (minimize.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(minimize);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of minimize is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(minimize);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of minimize is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return minimize.isEnabled();
	}

	public void clickOnminimize() throws InterruptedException {
		minimize.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfremoveUserNo() throws InterruptedException {
		if (removeUserNo.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserNo is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserNo is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserNo.isDisplayed();
	}

	public boolean enableStatusOfremoveUserNo() throws InterruptedException {
		if (removeUserNo.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserNo is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserNo is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserNo.isEnabled();
	}

	public void clickOnremoveUserNo() throws InterruptedException {
		removeUserNo.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfremoveUserYes() throws InterruptedException {
		if (removeUserYes.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserYes is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserYes is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserYes.isDisplayed();
	}

	public boolean enableStatusOfremoveUserYes() throws InterruptedException {
		if (removeUserYes.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserYes is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserYes is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserYes.isEnabled();
	}

	public void clickOnremoveUserYes() throws InterruptedException {
		removeUserYes.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfgroupMapping() throws InterruptedException {
		if (groupMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupMapping.isDisplayed();
	}

	public boolean enableStatusOfgroupMapping() throws InterruptedException {
		if (groupMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupMapping.isEnabled();
	}

	public void clickOngroupMapping() {
		groupMapping.click();
	}

	public boolean displayStatusOfselectGroup() throws InterruptedException {
		if (selectGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectGroup.isDisplayed();
	}

	public boolean enableStatusOfselectGroup() throws InterruptedException {
		if (selectGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectGroup.isEnabled();
	}

	public void clickOnselectGroup(String SelectRole) throws InterruptedException {
		selectGroup.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + SelectRole + "']")).click();
	}

	public boolean displayStatusOfviewSelectGroup() throws InterruptedException {
		if (viewSelectGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewSelectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewSelectGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewSelectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewSelectGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewSelectGroup.isDisplayed();
	}

	public boolean enableStatusOfviewSelectGroup() throws InterruptedException {
		if (viewSelectGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewSelectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewSelectGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewSelectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewSelectGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewSelectGroup.isEnabled();
	}

	public void clickOnviewSelectGroup() throws InterruptedException {
		viewSelectGroup.click();
	}

	public boolean displayStatusOfaddUsersGroupMap() throws InterruptedException {
		if (addUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addUsers.isDisplayed();
	}

	public boolean enableStatusOfaddUsersGroupMap() throws InterruptedException {
		if (addUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addUsers.isEnabled();
	}

	public void clickOnaddUsersGroupMap() throws InterruptedException {
		addUsers.click();
	}

	public boolean displayStatusOfselectUsersGroupMap() throws InterruptedException {
		if (selectUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectUsers.isDisplayed();
	}

	public boolean enableStatusOfselectUsersGroupMap() throws InterruptedException {
		if (selectUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectUsers.isEnabled();
	}

	public void clickAndselectUsersGroupMap() throws InterruptedException {
		selectUsers.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfsaveUserGroupMap() throws InterruptedException {
		if (saveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveUser.isDisplayed();
	}

	public boolean enableStatusOfsaveUserGroupMap() throws InterruptedException {
		if (saveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveUser.isEnabled();
	}

	public void clickOnsaveUserGroupMap() throws InterruptedException {
		saveUser.click();
	}

	public boolean displayStatusOfnextPageGroupMap() throws InterruptedException {
		if (nextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of nextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of nextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return nextPage.isDisplayed();
	}

	public boolean enableStatusOfnextPageGroupMap() throws InterruptedException {
		if (nextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of nextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of nextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return nextPage.isEnabled();
	}

	public void clickOnnextPageGroupMap() throws InterruptedException {
		Thread.sleep(5000);
		new Actions(driver).moveToElement(nextPage).click().build().perform();
		Thread.sleep(3000);
	}

	public boolean displayStatusOfminimize1GroupMap() throws InterruptedException {
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0 , 1000);");
        
		if (minimize1.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(minimize1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of minimize1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(minimize1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of minimize1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return minimize1.isDisplayed();
	}

	public boolean enableStatusOfminimize1GroupMap() throws InterruptedException {
		if (minimize1.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(minimize1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of minimize1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(minimize1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of minimize1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return minimize1.isEnabled();
	}

	public void clickOnminimize1GroupMap() throws InterruptedException {
		minimize1.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfremoveUserNoGroupMap() throws InterruptedException {
		if (removeUserNo.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserNo is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserNo is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserNo.isDisplayed();
	}

	public boolean enableStatusOfremoveUserNoGroupMap() throws InterruptedException {
		if (removeUserNo.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserNo is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserNo is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserNo.isEnabled();
	}

	public void clickOnremoveUserNoGroupMap() throws InterruptedException {
		removeUserNo.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfremoveUserYesGroupMap() throws InterruptedException {
		if (removeUserYes.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserYes is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserYes is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserYes.isDisplayed();
	}

	public boolean enableStatusOfremoveUserYesGroupMap() throws InterruptedException {
		if (removeUserYes.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserYes is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserYes is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserYes.isEnabled();
	}

	public void clickOnremoveUserYesGroupMap() throws InterruptedException {
		removeUserYes.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfccMapping() throws InterruptedException {
		if (ccMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ccMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ccMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ccMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ccMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ccMapping.isDisplayed();
	}

	public boolean enableStatusOfccMapping() throws InterruptedException {
		if (ccMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ccMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ccMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ccMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ccMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ccMapping.isEnabled();
	}

	public void clickOnccMapping() throws InterruptedException {
		ccMapping.click();
	}

	public boolean displayStatusOfchannelMapping() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", channelMapping);
		Thread.sleep(1000);
		if (channelMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelMapping.isDisplayed();
	}

	public boolean enableStatusOfchannelMapping() throws InterruptedException {
		if (channelMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelMapping.isEnabled();
	}

	public void clickOnchannelMapping() throws InterruptedException {
		channelMapping.click();
	}

	public boolean displayStatusOfCCselectChannel() throws InterruptedException {
		if (CCselectChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectChannel.isDisplayed();
	}

	public boolean enableStatusOfCCselectChannel() throws InterruptedException {
		if (CCselectChannel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectChannel.isEnabled();
	}

	public void clickOnCCselectChannelandSelectDPvalue(String CCSelectChannel) throws InterruptedException {
		CCselectChannel.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectChannel + "']")).click();
	}

	public boolean displayStatusOfCCselectSubChannel() throws InterruptedException {
		if (CCselectSubChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectSubChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectSubChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectSubChannel.isDisplayed();
	}

	public boolean enableStatusOfCCselectSubChannel() throws InterruptedException {
		if (CCselectSubChannel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectSubChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectSubChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectSubChannel.isEnabled();
	}

	public void clickOnCCselectSubChannelandSelectDPvalue(String CCSelectSubChannel) throws InterruptedException {
		CCselectSubChannel.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectSubChannel + "']")).click();
	}

	public boolean displayStatusOfCCViewButton() throws InterruptedException {
		if (CCViewButton.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isDisplayed();
	}

	public boolean enableStatusOfCCViewButton() throws InterruptedException {
		if (CCViewButton.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isEnabled();
	}

	public void clickOnCCViewButton() throws InterruptedException {
		CCViewButton.click();
	}

	public boolean displayStatusOfCCaddUser() throws InterruptedException {
		if (CCaddUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isDisplayed();
	}

	public boolean enableStatusOfCCaddUser() throws InterruptedException {
		if (CCaddUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isEnabled();
	}

	public void clickOnCCaddUser() throws InterruptedException {
		CCaddUser.click();
	}

	public boolean displayStatusOfCCselectUser() throws InterruptedException {
		if (CCselectUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isDisplayed();
	}

	public boolean enableStatusOfCCselectUser() throws InterruptedException {
		if (CCselectUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isEnabled();
	}

	public void clickOnCCselectUserandSelectDPvalue() throws InterruptedException {
		CCselectUser.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfCCsaveUser() throws InterruptedException {
		if (CCsaveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isDisplayed();
	}

	public boolean enableStatusOfCCsaveUser() throws InterruptedException {
		if (CCsaveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isEnabled();
	}

	public void clickOnCCsaveUser() throws InterruptedException {
		CCsaveUser.click();
	}

	public boolean displayStatusOfCCnextPage() throws InterruptedException {
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0 , 1000);");
		if (CCnextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isDisplayed();
	}

	public boolean enableStatusOfCCnextPage() throws InterruptedException {
		if (CCnextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isEnabled();
	}

	public void clickOnCCnextPage() throws InterruptedException {
		Thread.sleep(3000);
		new Actions(driver).moveToElement(CCnextPage).click().build().perform();
	}

	public boolean displayStatusOfCCremoveUser() throws InterruptedException {
		if (CCremoveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUser.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUser() throws InterruptedException {
		if (CCremoveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUser.isEnabled();
	}

	public void clickOnCCremoveUser() throws InterruptedException {
		CCremoveUser.click();
	}

	public boolean displayStatusOfCCremoveUserNO() throws InterruptedException {
		if (CCremoveUserNO.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserNO() throws InterruptedException {
		if (CCremoveUserNO.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isEnabled();
	}

	public void clickOnCCremoveUserNO() throws InterruptedException {
		CCremoveUserNO.click();
	}

	public boolean displayStatusOfCCremoveUserYES() throws InterruptedException {
		if (CCremoveUserYES.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserYES() throws InterruptedException {
		if (CCremoveUserYES.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isEnabled();
	}

	public void clickOnCCremoveUserYES() throws InterruptedException {
		CCremoveUserYES.click();
	}

	public boolean displayStatusOfskillsetMapping() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillsetMapping);
		Thread.sleep(1000);
		if (skillsetMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillsetMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillsetMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillsetMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillsetMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillsetMapping.isDisplayed();
	}

	public boolean enableStatusOfskillsetMapping() throws InterruptedException {
		if (skillsetMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillsetMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillsetMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillsetMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillsetMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillsetMapping.isEnabled();
	}

	public void clickOnskillsetMapping() throws InterruptedException {
		skillsetMapping.click();
	}

	public boolean displayStatusOfCCskillSM() throws InterruptedException {
		if (CCskill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCskill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCskill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCskill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCskill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCskill.isDisplayed();
	}

	public boolean enableStatusOfCCskillSM() throws InterruptedException {
		if (CCskill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCskill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCskill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCskill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCskill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCskill.isEnabled();
	}

	public void clickOnCCskillandSelectDPvalueSM(String CCSelectChannelSM) throws InterruptedException {
		CCskill.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectChannelSM + "']")).click();
	}

	public boolean displayStatusOfCCskillProficiencySM() throws InterruptedException {
		if (CCskillProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCskillProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCskillProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCskillProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCskillProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCskillProficiency.isDisplayed();
	}

	public boolean enableStatusOfCCskillProficiencySM() throws InterruptedException {
		if (CCskillProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCskillProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCskillProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCskillProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCskillProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCskillProficiency.isEnabled();
	}

	public void clickOnCCskillProficiencyandSelectDPvalueSM(String CCSelectSubChannelSM) throws InterruptedException {
		CCskillProficiency.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectSubChannelSM + "']")).click();
	}

	public boolean displayStatusOfCCViewButtonSM() throws InterruptedException {
		if (CCViewButton.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isDisplayed();
	}

	public boolean enableStatusOfCCViewButtonSM() throws InterruptedException {
		if (CCViewButton.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isEnabled();
	}

	public void clickOnCCViewButtonSM() throws InterruptedException {
		CCViewButton.click();
	}

	public boolean displayStatusOfCCaddUserSM() throws InterruptedException {
		if (CCaddUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isDisplayed();
	}

	public boolean enableStatusOfCCaddUserSM() throws InterruptedException {
		if (CCaddUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isEnabled();
	}

	public void clickOnCCaddUserSM() throws InterruptedException {
		CCaddUser.click();
	}

	public boolean displayStatusOfCCselectUserSM() throws InterruptedException {
		if (CCselectUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isDisplayed();
	}

	public boolean enableStatusOfCCselectUserSM() throws InterruptedException {
		if (CCselectUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isEnabled();
	}

	public void clickOnCCselectUserandSelectDPvalueSM() throws InterruptedException {
		CCselectUser.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfCCsaveUserSM() throws InterruptedException {
		if (CCsaveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isDisplayed();
	}

	public boolean enableStatusOfCCsaveUserSM() throws InterruptedException {
		if (CCsaveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isEnabled();
	}

	public void clickOnCCsaveUserSM() throws InterruptedException {
		CCsaveUser.click();
	}

	public boolean displayStatusOfCCnextPageSM() throws InterruptedException {
		if (CCnextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isDisplayed();
	}

	public boolean enableStatusOfCCnextPageSM() throws InterruptedException {
		if (CCnextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isEnabled();
	}

	public void clickOnCCnextPageSM() throws InterruptedException {
		Thread.sleep(2500);
		new Actions(driver).moveToElement(CCnextPage).click().build().perform();
	}

	public boolean displayStatusOfCCremoveUserSM() throws InterruptedException {
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0 , 1000);");
		
		if (CCremoveUserSM.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserSM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserSM is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserSM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserSM is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserSM.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserSM() throws InterruptedException {
		if (CCremoveUserSM.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserSM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserSM is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserSM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserSM is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserSM.isEnabled();
	}

	public void clickOnCCremoveUserSM() throws InterruptedException {
		CCremoveUserSM.click();
	}

	public boolean displayStatusOfCCremoveUserNOSM() throws InterruptedException {
		if (CCremoveUserNO.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserNOSM() throws InterruptedException {
		if (CCremoveUserNO.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isEnabled();
	}

	public void clickOnCCremoveUserNOSM() throws InterruptedException {
		CCremoveUserNO.click();
	}

	public boolean displayStatusOfCCremoveUserYESSM() throws InterruptedException {
		if (CCremoveUserYES.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserYESSM() throws InterruptedException {
		if (CCremoveUserYES.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isEnabled();
	}

	public void clickOnCCremoveUserYESSM() throws InterruptedException {
		CCremoveUserYES.click();
	}

	public boolean displayStatusOflanguageMapping() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", languageMapping);
		Thread.sleep(1000);
		if (languageMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageMapping.isDisplayed();
	}

	public boolean enableStatusOflanguageMapping() throws InterruptedException {
		if (languageMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageMapping.isEnabled();
	}

	public void clickOnlanguageMapping() throws InterruptedException {
		languageMapping.click();
	}

	public boolean displayStatusOfCClanguageLM() throws InterruptedException {
		if (CClanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CClanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CClanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CClanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CClanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CClanguage.isDisplayed();
	}

	public boolean enableStatusOfCClanguageLM() throws InterruptedException {
		if (CClanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CClanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CClanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CClanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CClanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CClanguage.isEnabled();
	}

	public void clickOnCClanguageandSelectDPvalueLM(String CCSelectChannelLM) throws InterruptedException {
		CClanguage.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectChannelLM + "']")).click();
	}

	public boolean displayStatusOfCClanguageProficiencyLM() throws InterruptedException {
		if (CClanguageProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CClanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CClanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CClanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CClanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CClanguageProficiency.isDisplayed();
	}

	public boolean enableStatusOfCClanguageProficiencyLM() throws InterruptedException {
		if (CClanguageProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CClanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CClanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CClanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CClanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CClanguageProficiency.isEnabled();
	}

	public void clickOnCClanguageProficiencyandSelectDPvalueLM(String CCSelectSubChannelLM)
			throws InterruptedException {
		CClanguageProficiency.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectSubChannelLM + "']")).click();
	}

	public boolean displayStatusOfCCViewButtonLM() throws InterruptedException {
		if (CCViewButton.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isDisplayed();
	}

	public boolean enableStatusOfCCViewButtonLM() throws InterruptedException {
		if (CCViewButton.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isEnabled();
	}

	public void clickOnCCViewButtonLM() throws InterruptedException {
		CCViewButton.click();
	}

	public boolean displayStatusOfCCaddUserLM() throws InterruptedException {
		if (CCaddUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isDisplayed();
	}

	public boolean enableStatusOfCCaddUserLM() throws InterruptedException {
		if (CCaddUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isEnabled();
	}

	public void clickOnCCaddUserLM() throws InterruptedException {
		CCaddUser.click();
	}

	public boolean displayStatusOfCCselectUserLM() throws InterruptedException {
		if (CCselectUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isDisplayed();
	}

	public boolean enableStatusOfCCselectUserLM() throws InterruptedException {
		if (CCselectUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isEnabled();
	}

	public void clickOnCCselectUserandSelectDPvalueLM() throws InterruptedException {
		CCselectUser.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfCCsaveUserLM() throws InterruptedException {
		if (CCsaveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isDisplayed();
	}

	public boolean enableStatusOfCCsaveUserLM() throws InterruptedException {
		if (CCsaveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isEnabled();
	}

	public void clickOnCCsaveUserLM() throws InterruptedException {
		CCsaveUser.click();
	}

	public boolean displayStatusOfCCnextPageLM() throws InterruptedException {
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0 , 1000);");
		if (CCnextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isDisplayed();
	}

	public boolean enableStatusOfCCnextPageLM() throws InterruptedException {
		if (CCnextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isEnabled();
	}

	public void clickOnCCnextPageLM() throws InterruptedException {
		Thread.sleep(3000);
		new Actions(driver).moveToElement(CCnextPage).click().build().perform();
	}

	public boolean displayStatusOfCCremoveUserLM() throws InterruptedException {
		if (CCremoveUserLM.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserLM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserLM is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserLM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserLM is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserLM.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserLM() throws InterruptedException {
		if (CCremoveUserLM.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserLM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserLM is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserLM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserLM is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserLM.isEnabled();
	}

	public void clickOnCCremoveUserLM() throws InterruptedException {
		CCremoveUserLM.click();
	}

	public boolean displayStatusOfCCremoveUserNOLM() throws InterruptedException {
		if (CCremoveUserNO.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserNOLM() throws InterruptedException {
		if (CCremoveUserNO.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isEnabled();
	}

	public void clickOnCCremoveUserNOLM() throws InterruptedException {
		CCremoveUserNO.click();
	}

	public boolean displayStatusOfCCremoveUserYESLM() throws InterruptedException {
		if (CCremoveUserYES.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserYESLM() throws InterruptedException {
		if (CCremoveUserYES.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isEnabled();
	}

	public void clickOnCCremoveUserYESLM() throws InterruptedException {
		CCremoveUserYES.click();
	}

	public boolean displayStatusOfchatConfigurationCC() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", chatConfiguration);
		Thread.sleep(1000);
		if (chatConfiguration.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chatConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatConfiguration is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chatConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatConfiguration is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chatConfiguration.isDisplayed();
	}

	public boolean enableStatusOfchatConfigurationCC() throws InterruptedException {
		if (chatConfiguration.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chatConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of chatConfiguration is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chatConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of chatConfiguration is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chatConfiguration.isEnabled();
	}

	public void clickOnchatConfigurationCC() throws InterruptedException {
		chatConfiguration.click();
	}

	public boolean displayStatusOfautoRejectTimeCC() throws InterruptedException {
		if (autoRejectTime.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(autoRejectTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of autoRejectTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(autoRejectTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of autoRejectTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return autoRejectTime.isDisplayed();
	}

	public boolean enableStatusOfautoRejectTimeCC() throws InterruptedException {
		if (autoRejectTime.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(autoRejectTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of autoRejectTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(autoRejectTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of autoRejectTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return autoRejectTime.isEnabled();
	}

	public void enterDataInautoRejectTimeCC() throws InterruptedException {
		autoRejectTime.click();
		String AutoRejectTime = autoRejectTime.getAttribute("value");
		System.out.println("AutoRejectTime : " + AutoRejectTime);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		autoRejectTime.sendKeys(AutoRejectTime);
	}

	public boolean displayStatusOfagentIdleChangeStatusTimeCC() throws InterruptedException {
		if (agentIdleChangeStatusTime.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(agentIdleChangeStatusTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of agentIdleChangeStatusTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(agentIdleChangeStatusTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of agentIdleChangeStatusTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return agentIdleChangeStatusTime.isDisplayed();
	}

	public boolean enableStatusOfagentIdleChangeStatusTimeCC() throws InterruptedException {
		if (agentIdleChangeStatusTime.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(agentIdleChangeStatusTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of agentIdleChangeStatusTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(agentIdleChangeStatusTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of agentIdleChangeStatusTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return agentIdleChangeStatusTime.isEnabled();
	}

	public void enterDataInagentIdleChangeStatusTimeCC() throws InterruptedException {
		agentIdleChangeStatusTime.click();
		String AgentIdleChangeStatusTime = agentIdleChangeStatusTime.getAttribute("value");
		System.out.println("AgentIdleChangeStatusTime : " + AgentIdleChangeStatusTime);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		agentIdleChangeStatusTime.sendKeys(AgentIdleChangeStatusTime);
	}

	public boolean displayStatusOfmaxRequestInQueueCC() throws InterruptedException {
		if (maxRequestInQueue.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(maxRequestInQueue);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of maxRequestInQueue is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(maxRequestInQueue);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of maxRequestInQueue is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return maxRequestInQueue.isDisplayed();
	}

	public boolean enableStatusOfmaxRequestInQueueCC() throws InterruptedException {
		if (maxRequestInQueue.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(maxRequestInQueue);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of maxRequestInQueue is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(maxRequestInQueue);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of maxRequestInQueue is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return maxRequestInQueue.isEnabled();
	}

	public void enterDataInmaxRequestInQueueCC() throws InterruptedException {
		maxRequestInQueue.click();
		String MaxRequestInQueue = maxRequestInQueue.getAttribute("value");
		System.out.println("MaxRequestInQueue : " + MaxRequestInQueue);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		maxRequestInQueue.sendKeys(MaxRequestInQueue);
	}

	public boolean displayStatusOfalertSupCheckBoxCC() throws InterruptedException {
		if (alertSupCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(alertSupCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of alertSupCheckBox is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(alertSupCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of alertSupCheckBox is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return alertSupCheckBox.isDisplayed();
	}

	public boolean enableStatusOfalertSupCheckBoxCC() throws InterruptedException {
		if (alertSupCheckBox.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(alertSupCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of alertSupCheckBox is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(alertSupCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of alertSupCheckBox is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return alertSupCheckBox.isEnabled();
	}

	public void clickOnalertSupCheckBoxCC() throws InterruptedException {
		alertSupCheckBox1.click();
		Thread.sleep(501);
		alertSupCheckBox1.click();
	}

	public boolean displayStatusOfwelcomeMessageCC() throws InterruptedException {
		if (welcomeMessage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(welcomeMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of welcomeMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(welcomeMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of welcomeMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return welcomeMessage.isDisplayed();
	}

	public boolean enableStatusOfwelcomeMessageCC() throws InterruptedException {
		if (welcomeMessage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(welcomeMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of welcomeMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(welcomeMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of welcomeMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return welcomeMessage.isEnabled();
	}

	public void enterDataInwelcomeMessageCC() throws InterruptedException {
		welcomeMessage.click();
		String WelcomeMessage = welcomeMessage.getAttribute("value");
		System.out.println("WelcomeMessage : " + WelcomeMessage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		welcomeMessage.sendKeys(WelcomeMessage);
	}

	public boolean displayStatusOfqueueMessageCC() throws InterruptedException {
		if (queueMessage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(queueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of queueMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(queueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of queueMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return queueMessage.isDisplayed();
	}

	public boolean enableStatusOfqueueMessageCC() throws InterruptedException {
		if (queueMessage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(queueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of queueMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(queueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of queueMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return queueMessage.isEnabled();
	}

	public void enterDataInqueueMessageCC() throws InterruptedException {
		queueMessage.click();
		String QueueMessage = queueMessage.getAttribute("value");
		System.out.println("QueueMessage : " + QueueMessage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		queueMessage.sendKeys(QueueMessage);
	}

	public boolean displayStatusOfagentNAmsgCC() throws InterruptedException {
		if (agentNAmsg.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(agentNAmsg);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of agentNAmsg is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(agentNAmsg);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of agentNAmsg is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return agentNAmsg.isDisplayed();
	}

	public boolean enableStatusOfagentNAmsgCC() throws InterruptedException {
		if (agentNAmsg.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(agentNAmsg);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of agentNAmsg is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(agentNAmsg);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of agentNAmsg is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return agentNAmsg.isEnabled();
	}

	public void enterDataInagentNAmsgCC() throws InterruptedException {
		agentNAmsg.click();
		String AgentNAmsg = agentNAmsg.getAttribute("value");
		System.out.println("AgentNAmsg : " + AgentNAmsg);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		agentNAmsg.sendKeys(AgentNAmsg);
	}

	public boolean displayStatusOfmaxQueueMessageCC() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", maxQueueMessage);
		Thread.sleep(1000);
		if (maxQueueMessage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(maxQueueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of maxQueueMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(maxQueueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of maxQueueMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return maxQueueMessage.isDisplayed();
	}

	public boolean enableStatusOfmaxQueueMessageCC() throws InterruptedException {
		if (maxQueueMessage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(maxQueueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of maxQueueMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(maxQueueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of maxQueueMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return maxQueueMessage.isEnabled();
	}

	public void enterDataInmaxQueueMessageCC() throws InterruptedException {
		maxQueueMessage.click();
		String MaxQueueMessage = maxQueueMessage.getAttribute("value");
		System.out.println("MaxQueueMessage : " + MaxQueueMessage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		maxQueueMessage.sendKeys(MaxQueueMessage);
	}

	public boolean displayStatusOfclearCC() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", clearCC);
		Thread.sleep(1000);
		if (clearCC.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clearCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clearCC is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clearCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clearCC is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clearCC.isDisplayed();
	}

	public boolean enableStatusOfclearCC() throws InterruptedException {
		if (clearCC.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clearCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clearCC is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clearCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clearCC is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clearCC.isEnabled();
	}

	public void clickOnclearCC() throws InterruptedException {
		clearCC.click();
	}

	public boolean displayStatusOfsaveCC() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", saveCC);
		Thread.sleep(1000);
		if (saveCC.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveCC is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveCC is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveCC.isDisplayed();
	}

	public boolean enableStatusOfsaveCC() throws InterruptedException {
		if (saveCC.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveCC is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveCC is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveCC.isEnabled();
	}

	public void clickOnsaveCC() throws InterruptedException {
		saveCC.click();
	}

	public boolean displayStatusOfroutingConfiguration() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", routingConfiguration);
		Thread.sleep(1000);
		if (routingConfiguration.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingConfiguration is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingConfiguration is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingConfiguration.isDisplayed();
	}

	public boolean enableStatusOfroutingConfiguration() throws InterruptedException {
		if (routingConfiguration.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingConfiguration is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingConfiguration is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingConfiguration.isEnabled();
	}

	public void clickOnroutingConfiguration() throws InterruptedException {
		routingConfiguration.click();
	}

	public boolean displayStatusOfglobalConcurrency() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", globalConcurrency);
		Thread.sleep(1000);
		if (globalConcurrency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(globalConcurrency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of globalConcurrency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(globalConcurrency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of globalConcurrency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return globalConcurrency.isDisplayed();
	}

	public boolean enableStatusOfglobalConcurrency() throws InterruptedException {
		if (globalConcurrency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(globalConcurrency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of globalConcurrency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(globalConcurrency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of globalConcurrency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return globalConcurrency.isEnabled();
	}

	public void enterDataInglobalConcurrency() throws InterruptedException {
		globalConcurrency.click();
		String GlobalConcurrency = globalConcurrency.getAttribute("value");
		System.out.println("GlobalConcurrency : " + GlobalConcurrency);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		globalConcurrency.sendKeys(GlobalConcurrency);
	}

	public boolean displayStatusOfchannelWiseConcurrencyRate() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", channelWiseConcurrencyRate);
		Thread.sleep(1000);
		if (channelWiseConcurrencyRate.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelWiseConcurrencyRate);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of channelWiseConcurrencyRate is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelWiseConcurrencyRate);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of channelWiseConcurrencyRate is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelWiseConcurrencyRate.isDisplayed();
	}

	public boolean enableStatusOfchannelWiseConcurrencyRate() throws InterruptedException {
		if (channelWiseConcurrencyRate.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelWiseConcurrencyRate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelWiseConcurrencyRate is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelWiseConcurrencyRate);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of channelWiseConcurrencyRate is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelWiseConcurrencyRate.isEnabled();
	}

	public void clickOnchannelWiseConcurrencyRate() throws InterruptedException {
		try {
			channelWiseConcurrencyRate.click();
		} catch (Exception e) {
			new Actions(driver).click(channelWiseConcurrencyRate).build().perform();
		}
		Thread.sleep(501);
		try {
			channelWiseConcurrencyRate.click();
		} catch (Exception e) {
			new Actions(driver).click(channelWiseConcurrencyRate).build().perform();
		}
	}

	public boolean displayStatusOfvoice() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", voice);
		Thread.sleep(1000);
		if (voice.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(voice);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of voice is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(voice);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of voice is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return voice.isDisplayed();
	}

	public boolean enableStatusOfvoice() throws InterruptedException {
		if (voice.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(voice);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of voice is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(voice);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of voice is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return voice.isEnabled();
	}

	public void enterDataInvoice() throws InterruptedException {
		voice.click();
		String Voice = voice.getAttribute("value");
		System.out.println("Voice : " + Voice);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		voice.sendKeys(Voice);
	}

	public boolean displayStatusOfchat() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", chat);
		Thread.sleep(1000);
		if (chat.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chat);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chat is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chat);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chat is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chat.isDisplayed();
	}

	public boolean enableStatusOfchat() throws InterruptedException {
		if (chat.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chat);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of chat is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chat);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of chat is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chat.isEnabled();
	}

	public void enterDataInchat() throws InterruptedException {
		chat.click();
		String Chat = chat.getAttribute("value");
		System.out.println("Chat : " + Chat);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		chat.sendKeys(Chat);
	}

	public boolean displayStatusOfACWTime() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", ACWTime);
		Thread.sleep(1000);
		if (ACWTime.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ACWTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ACWTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ACWTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ACWTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ACWTime.isDisplayed();
	}

	public boolean enableStatusOfACWTime() throws InterruptedException {
		if (ACWTime.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ACWTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ACWTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ACWTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ACWTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ACWTime.isEnabled();
	}

	public void enterDataInACWTime() throws InterruptedException {
		ACWTime.click();
		String ACWtime = ACWTime.getAttribute("value");
		System.out.println("ACWtime : " + ACWtime);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		ACWTime.sendKeys(ACWtime);
	}

	public boolean displayStatusOfroutingAlgorithmDP() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", routingAlgorithmDP);
		Thread.sleep(1000);
		if (routingAlgorithmDP.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmDP);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmDP is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmDP);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmDP is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmDP.isDisplayed();
	}

	public boolean enableStatusOfroutingAlgorithmDP() throws InterruptedException {
		if (routingAlgorithmDP.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmDP);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmDP is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmDP);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmDP is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmDP.isEnabled();
	}

	public void clickOnroutingAlgorithmDPandSelectVAlue(String RoutingAlgorithmDP) throws InterruptedException {
		routingAlgorithmDP.click();
		Thread.sleep(1500);
		driver.findElement(By.xpath("//span[text()='" + RoutingAlgorithmDP + "']")).click();
		Thread.sleep(1000);
//		routingAlgorithmDP.click();
//		Thread.sleep(1500);
//		driver.findElement(By.xpath("//span[text()='"+RoutingAlgorithmDP1+"'")).click();
	}

	public boolean displayStatusOfroutingAlgorithmDP_Eye() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", routingAlgorithmDP_Eye);
		Thread.sleep(1000);
		if (routingAlgorithmDP_Eye.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmDP_Eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmDP_Eye is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmDP_Eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmDP_Eye is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmDP_Eye.isDisplayed();
	}

	public boolean enableStatusOfroutingAlgorithmDP_Eye() throws InterruptedException {
		if (routingAlgorithmDP_Eye.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmDP_Eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmDP_Eye is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmDP_Eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmDP_Eye is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmDP_Eye.isEnabled();
	}

	public void clickOnroutingAlgorithmDP_Eye() throws InterruptedException {
		routingAlgorithmDP_Eye.click();
	}

	public boolean displayStatusOfskillWeightage() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillWeightage);
		Thread.sleep(1000);
		if (skillWeightage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillWeightage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillWeightage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillWeightage.isDisplayed();
	}

	public boolean enableStatusOfskillWeightage() throws InterruptedException {
		if (skillWeightage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillWeightage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillWeightage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillWeightage.isEnabled();
	}

	public void enterDataInskillWeightage() throws InterruptedException {
		skillWeightage.click();
		String SkillWeightage = skillWeightage.getAttribute("value");
		System.out.println("SkillWeightage : " + SkillWeightage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		skillWeightage.sendKeys(SkillWeightage);
	}

	public boolean displayStatusOflanguageWeightage() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", languageWeightage);
		Thread.sleep(1000);
		if (languageWeightage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageWeightage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageWeightage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageWeightage.isDisplayed();
	}

	public boolean enableStatusOflanguageWeightage() throws InterruptedException {
		if (languageWeightage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageWeightage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageWeightage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageWeightage.isEnabled();
	}

	public void enterDataInlanguageWeightage() throws InterruptedException {
		languageWeightage.click();
		String LanguageWeightage = languageWeightage.getAttribute("value");
		System.out.println("LanguageWeightage : " + LanguageWeightage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		languageWeightage.sendKeys(LanguageWeightage);
	}

	public boolean displayStatusOfCANCEL() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", CANCEL);
		Thread.sleep(1000);
		if (CANCEL.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CANCEL);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CANCEL is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CANCEL);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CANCEL is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CANCEL.isDisplayed();
	}

	public boolean enableStatusOfCANCEL() throws InterruptedException {
		if (CANCEL.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CANCEL);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CANCEL is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CANCEL);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CANCEL is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CANCEL.isEnabled();
	}

	public void clickOnCANCEL() throws InterruptedException {
		CANCEL.click();
	}

	public boolean displayStatusOfSAVE() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", SAVE);
		Thread.sleep(1000);
		if (SAVE.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(SAVE);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of SAVE is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(SAVE);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of SAVE is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return SAVE.isDisplayed();
	}

	public boolean enableStatusOfSAVE() throws InterruptedException {
		if (SAVE.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(SAVE);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of SAVE is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(SAVE);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of SAVE is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return SAVE.isEnabled();
	}

	public void clickOnSAVE() throws InterruptedException {
		SAVE.click();
	}

	public boolean displayStatusOfcomplaintType() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", complaintType);
		Thread.sleep(1000);
		if (complaintType.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(complaintType);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of complaintType is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(complaintType);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of complaintType is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return complaintType.isDisplayed();
	}

	public boolean enableStatusOfcomplaintType() throws InterruptedException {
		if (complaintType.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(complaintType);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of complaintType is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(complaintType);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of complaintType is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return complaintType.isEnabled();
	}

	public boolean IsSelectedStatusOfcomplaintTypeBeforeSelectingRadioBtn() throws InterruptedException {
		return complaintType.isSelected();
	}

	public void clickOncomplaintTypeandSelectVAlue() throws InterruptedException {
		try {
			complaintType.click();
		} catch (Exception e) {
			new Actions(driver).click(complaintType).build().perform();
		}
	}

	public boolean IsSelectedStatusOfcomplaintTypeAfterSelectingRadioBtn() throws InterruptedException {
		return complaintType.isSelected();
	}

	public boolean displayStatusOfskillGroup() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillGroup);
		Thread.sleep(1000);
		if (skillGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillGroup.isDisplayed();
	}

	public boolean enableStatusOfskillGroup() throws InterruptedException {
		if (skillGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillGroup.isEnabled();
	}

	public boolean IsSelectedStatusOfskillGroupBeforeSelectingRadioBtn() throws InterruptedException {
		return skillGroup.isSelected();
	}

	public void clickOnskillGroupandSelectVAlue() throws InterruptedException {
		try {
			skillGroup.click();
		} catch (Exception e) {
			new Actions(driver).click(skillGroup).build().perform();
		}
	}

	public boolean IsSelectedStatusOfskillGroupAfterSelectingRadioBtn() throws InterruptedException {
		return skillGroup.isSelected();
	}

	public boolean displayStatusOfChannel() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", Channel);
		Thread.sleep(1000);
		if (Channel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Channel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Channel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Channel.isDisplayed();
	}

	public boolean enableStatusOfChannel() throws InterruptedException {
		if (Channel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Channel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Channel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Channel.isEnabled();
	}

	public boolean IsSelectedStatusOfChannelBeforeSelectingRadioBtn() throws InterruptedException {
		return Channel.isSelected();
	}

	public void clickOnChannel() throws InterruptedException {
		try {
			Channel.click();
		} catch (Exception e) {
			new Actions(driver).click(Channel).build().perform();
		}
	}

	public boolean IsSelectedStatusOfChannelAfterSelectingRadioBtn() throws InterruptedException {
		return Channel.isSelected();
	}

	public boolean displayStatusOfchannelBasedRoutingAll() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", channelBasedRoutingAll);
		Thread.sleep(1000);
		if (channelBasedRoutingAll.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelBasedRoutingAll);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelBasedRoutingAll is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelBasedRoutingAll);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelBasedRoutingAll is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelBasedRoutingAll.isDisplayed();
	}

	public boolean enableStatusOfchannelBasedRoutingAll() throws InterruptedException {
		if (channelBasedRoutingAll.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelBasedRoutingAll);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelBasedRoutingAll is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelBasedRoutingAll);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelBasedRoutingAll is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelBasedRoutingAll.isEnabled();
	}

	public boolean IsSelectedStatusOfchannelBasedRoutingAllBeforeSelectingRadioBtn() throws InterruptedException {
		return channelBasedRoutingAll.isSelected();
	}

	public void clickOnchannelBasedRoutingAll() throws InterruptedException {
		try {
			channelBasedRoutingAll.click();
		} catch (Exception e) {
			new Actions(driver).click(channelBasedRoutingAll).build().perform();
		}
	}

	public boolean IsSelectedStatusOfchannelBasedRoutingAllAfterSelectingRadioBtn() throws InterruptedException {
		return channelBasedRoutingAll.isSelected();
	}

	public boolean displayStatusOfchannelBasedRoutingIndividual() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", channelBasedRoutingIndividual);
		Thread.sleep(1000);
		if (channelBasedRoutingIndividual.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelBasedRoutingIndividual);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of channelBasedRoutingIndividual is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelBasedRoutingIndividual);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of channelBasedRoutingIndividual is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelBasedRoutingIndividual.isDisplayed();
	}

	public boolean enableStatusOfchannelBasedRoutingIndividual() throws InterruptedException {
		if (channelBasedRoutingIndividual.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelBasedRoutingIndividual);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of channelBasedRoutingIndividual is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelBasedRoutingIndividual);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of channelBasedRoutingIndividual is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelBasedRoutingIndividual.isEnabled();
	}

	public boolean IsSelectedStatusOfchannelBasedRoutingIndividualBeforeSelectingRadioBtn()
			throws InterruptedException {
		return channelBasedRoutingIndividual.isSelected();
	}

	public void clickOnchannelBasedRoutingIndividual() throws InterruptedException {
		try {
			channelBasedRoutingIndividual.click();
		} catch (Exception e) {
			new Actions(driver).click(channelBasedRoutingIndividual).build().perform();
		}
	}

	public boolean IsSelectedStatusOfchannelBasedRoutingIndividualAfterSelectingRadioBtn() throws InterruptedException {
		return channelBasedRoutingIndividual.isSelected();
	}

	public boolean displayStatusOfCLEAR() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", CLEAR);
		Thread.sleep(1000);
		if (CLEAR.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CLEAR);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CLEAR is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CLEAR);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CLEAR is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CLEAR.isDisplayed();
	}

	public boolean enableStatusOfCLEAR() throws InterruptedException {
		if (CLEAR.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CLEAR);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CLEAR is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CLEAR);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CLEAR is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CLEAR.isEnabled();
	}

	public void clickOnCLEAR() throws InterruptedException {
		try {
			CLEAR.click();
		} catch (Exception e) {
			new Actions(driver).click(CLEAR).build().perform();
		}
	}

	public boolean displayStatusOfSUBMIT() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", SUBMIT);
		Thread.sleep(1000);
		if (SUBMIT.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(SUBMIT);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of SUBMIT is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(SUBMIT);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of SUBMIT is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return SUBMIT.isDisplayed();
	}

	public boolean enableStatusOfSUBMIT() throws InterruptedException {
		if (SUBMIT.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(SUBMIT);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of SUBMIT is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(SUBMIT);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of SUBMIT is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return SUBMIT.isEnabled();
	}

	public void clickOnSUBMIT() throws InterruptedException {
		try {
			SUBMIT.click();
		} catch (Exception e) {
			new Actions(driver).click(SUBMIT).build().perform();
		}
	}

	public boolean displayStatusOfModule_Mapping() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", Module_Mapping);
		Thread.sleep(1000);
		if (Module_Mapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Module_Mapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Module_Mapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Module_Mapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Module_Mapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Module_Mapping.isDisplayed();
	}

	public boolean enableStatusOfModule_Mapping() throws InterruptedException {
		if (Module_Mapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Module_Mapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Module_Mapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Module_Mapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Module_Mapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Module_Mapping.isEnabled();
	}

	public void clickOnModule_Mapping() throws InterruptedException {
		Module_Mapping.click();
	}
	
	public boolean displayStatusOfModule_Mapping_selectRole() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", Module_Mapping_selectRole);
		Thread.sleep(1000);
		if (Module_Mapping_selectRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Module_Mapping_selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Module_Mapping_selectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Module_Mapping_selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Module_Mapping_selectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Module_Mapping_selectRole.isDisplayed();
	}
	
	public boolean enableStatusOfModule_Mapping_selectRole() throws InterruptedException {
		if (Module_Mapping_selectRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Module_Mapping_selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Module_Mapping_selectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Module_Mapping_selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Module_Mapping_selectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Module_Mapping_selectRole.isEnabled();
	}
	
	public void clickOnModule_Mapping_selectRoleandSelectValue(String Text) throws InterruptedException {
		Module_Mapping_selectRole.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='"+Text+"']")).click();
	}
	
	public boolean displayStatusOfselectRole_view() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", selectRole_view);
		Thread.sleep(1000);
		if (selectRole_view.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectRole_view);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectRole_view is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectRole_view);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectRole_view is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectRole_view.isDisplayed();
	}
	
	public boolean enableStatusOfselectRole_view() throws InterruptedException {
		if (selectRole_view.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectRole_view);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectRole_view is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectRole_view);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectRole_view is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectRole_view.isEnabled();
	}
	
	public void clickOnselectRole_viewandSelectValue() throws InterruptedException {
		selectRole_view.click();
	}
	
	public boolean displayStatusOfcheckBox1() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", checkBox1);
		Thread.sleep(1000);
		if (checkBox1.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(checkBox1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of checkBox1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(checkBox1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of checkBox1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return checkBox1.isDisplayed();
	}
	
	public boolean enableStatusOfcheckBox1() throws InterruptedException {
		if (checkBox1.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(checkBox1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of checkBox1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(checkBox1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of checkBox1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return checkBox1.isEnabled();
	}
	
	public void clickOncheckBox1andSelectValue() throws InterruptedException {
		Thread.sleep(501);
		try {
			checkBox1.click();
		} catch (Exception e) {
			new Actions(driver).click(checkBox1).build().perform();
		}
		Thread.sleep(1000);
		try {
			checkBox1.click();
		} catch (Exception e) {
			new Actions(driver).click(checkBox1).build().perform();
		}

		
	}
	
	public boolean displayStatusOfChatCondWritecheckBox() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", ChatCondWritecheckBox);
		Thread.sleep(1000);
		if (ChatCondWritecheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ChatCondWritecheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ChatCondWritecheckBox is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ChatCondWritecheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ChatCondWritecheckBox is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ChatCondWritecheckBox.isDisplayed();
	}
	
	public boolean enableStatusOfChatCondWritecheckBox() throws InterruptedException {
		if (ChatCondWritecheckBox.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ChatCondWritecheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ChatCondWritecheckBox is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ChatCondWritecheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ChatCondWritecheckBox is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ChatCondWritecheckBox.isEnabled();
	}
	
	public void clickOnChatCondWritecheckBoxandSelectValue() throws InterruptedException {
		try {
			ChatCondWritecheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(ChatCondWritecheckBox).build().perform();
		}
	}
	public boolean displayStatusOfsaveModule() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", saveModule);
		Thread.sleep(1000);
		if (saveModule.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveModule);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveModule is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveModule);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveModule is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveModule.isDisplayed();
	}
	
	public boolean enableStatusOfsaveModule() throws InterruptedException {
		if (saveModule.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveModule);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveModule is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveModule);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveModule is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveModule.isEnabled();
	}
	
	public void clickOnsaveModuleandSelectValue() throws InterruptedException {
		saveModule.click();
	}
	public void againSameOpeForVerified(String Text1 ,String Text2) throws InterruptedException {
		Thread.sleep(501);
		Module_Mapping_selectRole.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='"+Text1+"']")).click();
		Thread.sleep(501);
		Module_Mapping_selectRole.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='"+Text2+"']")).click();
		Thread.sleep(501);
		selectRole_view.click();		
		Thread.sleep(501);
		try {
			downArrow1.click();
		} catch (Exception e) {
			new Actions(driver).click(downArrow1).build().perform();
		}
		Thread.sleep(501);
		try {
			ChatCondWritecheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(ChatCondWritecheckBox).build().perform();
		}
		Thread.sleep(501);
		saveModule.click();
		Thread.sleep(501);
		try {
			checkBox1.click();
		} catch (Exception e) {
			new Actions(driver).click(checkBox1).build().perform();
		}
		Thread.sleep(501);
		
	}

}
