package AgentCreation;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class TataNeo {
	public static WebDriver driver;

	public static void windoHandles(int i) {
		Set<String> windowHandles = driver.getWindowHandles();
		ArrayList<String> arr = new ArrayList<String>(windowHandles);
		driver.switchTo().window(arr.get(i));
	}

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("--disable-notifications");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		driver.get("https://www.tatadigital.com/v2/homepage");
		Thread.sleep(2000);
		WebElement Mobile = driver.findElement(By.xpath("(//img[@alt='media'])[44]"));
		new Actions(driver).scrollToElement(Mobile).click(Mobile).build().perform();
		Thread.sleep(5000);
		WebElement Apple = driver.findElement(By.xpath("(//img[@alt='media'])[21]"));
		new Actions(driver).scrollToElement(Apple).click(Apple).build().perform();
		Thread.sleep(2000);
		System.out.println(driver.getTitle());
		windoHandles(1);
		System.out.println(driver.getTitle());
		WebElement findElement = driver.findElement(By.xpath("(//a[@href='/apple-iphone-13-128gb-starlight-white-/p/243460'])[1]"));
		System.out.println(findElement.getText());
		findElement.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[text()='256GB']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[text()='Red']")).click();
		Thread.sleep(2000);
		WebElement findElement2 = driver.findElement(By.xpath("//button[text()='Add to Cart']"));
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0 , 200);");
		new Actions(driver).click(findElement2).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='close-btn mini-cart-dialog-close-mob']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='Proceed to Cart']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='Remove']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='Yes']")).click();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		new Actions(driver)
				.scrollToElement(driver.findElement(By.xpath("(//div[@class='cp-keyfeature pd-eligibility-wrap'])[1]"))).build().perform();
		Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("(//div[@class='cp-keyfeature pd-eligibility-wrap'])[1]")).getText());
	}
}
