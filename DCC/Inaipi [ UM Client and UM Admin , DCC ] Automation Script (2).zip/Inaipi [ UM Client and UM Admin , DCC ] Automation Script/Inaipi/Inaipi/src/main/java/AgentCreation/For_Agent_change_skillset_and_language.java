package AgentCreation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import UtilsLayerPackage.ExcelReader;

public class For_Agent_change_skillset_and_language {
	public static WebDriver driver ; 
	public static WebDriverWait wait ; 
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\AgentCreation.xlsx");
		String url = excel.getDataFromExcelSheet(0, 6, 0);
		driver.get(url);
		
		String username = excel.getDataFromExcelSheet(0, 2, 0);
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys(username);
		
		String password = excel.getDataFromExcelSheet(0, 3, 0);
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(password);

		driver.findElement(By.xpath("//span[text()='LOGIN']")).click();
		
		WebElement user = driver.findElement(By.xpath("//span[text()='Users']"));
		user.click();
		
		for(int i=313 ; i<=409;i++) {
			
		WebElement search = driver.findElement(By.xpath("//input[@id='searchval']"));
		new Actions(driver).click(search).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(3000);
		search.click();
		String FirstName = excel.getDataFromExcelSheet(2, i, 0);
		search.sendKeys(FirstName);
		Thread.sleep(3000);
		WebElement edit = driver.findElement(By.xpath("(//td[@class='MuiTableCell-root MuiTableCell-body'])[4]//*[@class='MuiSvgIcon-root m-r-20 text-a MuiSvgIcon-fontSizeSmall']"));
		edit.click();
		Thread.sleep(2000);
		WebElement skill = driver.findElement(By.xpath("(//div[@aria-label='Dropdown select'])[5]"));
		skill.click();
		Thread.sleep(1000);
		new Actions(driver).click(skill).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(800);
		skill.click();
		Thread.sleep(1000);
		String addskillName = excel.getDataFromExcelSheet(2, i, 10);
		driver.findElement(By.xpath("//span[text()='"+addskillName+"']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//div[@aria-label='Dropdown select'])[7]")).click();
		Thread.sleep(1000);
		WebElement addLanguage = driver.findElement(By.xpath("(//div[@aria-label='Dropdown select'])[7]"));
		new Actions(driver).click(addLanguage).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(500);
		addLanguage.click();
		Thread.sleep(1200);
		String addLanguageName = excel.getDataFromExcelSheet(2, i, 12);
		driver.findElement(By.xpath("//span[text()='"+addLanguageName+"']")).click();
		Thread.sleep(500);
		WebElement update = driver.findElement(By.xpath("//span[text()='EDIT USER']"));
		update.click();
		}
	}
}
