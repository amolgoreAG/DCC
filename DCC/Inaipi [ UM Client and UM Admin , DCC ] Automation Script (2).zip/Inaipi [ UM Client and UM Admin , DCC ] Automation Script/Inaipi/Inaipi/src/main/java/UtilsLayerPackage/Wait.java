package UtilsLayerPackage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseLayerPackage.BaseClass;

public class Wait extends BaseClass {

	public static void WebDriverWait(String search) {
		WebDriverWait wait = new WebDriverWait(driver , Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(search)));
	}
}
