package UtilsLayerPackage;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import BaseLayerPackage.BaseClass;

public class HandleMouseOverAndKeyBoardOverOperation extends BaseClass {

	public static void click() {
		new Actions(driver).click().build().perform();
	}

	public static void right_Click() {
		 new Actions(driver).contextClick().build().perform();
	}

	public static void double_Click() {
		new Actions(driver).doubleClick().build().perform();
	}

	public static void click_and_Hold() {
		new Actions(driver).clickAndHold().build().perform();
	}

	public static void release() {
		new Actions(driver).release().build().perform();
	}

	public static void drag_and_Drop(WebElement source, WebElement target) {
		new Actions(driver).dragAndDrop(source, target).build().perform();
	}

	public static void move_To_Element(WebElement target) {
		new Actions(driver).moveToElement(target).build().perform();
	}

	public static void send_Data_In_Textbox(WebElement wb, String value) {
		new Actions(driver).sendKeys(wb, value).build().perform();
	}

	public static void copy_All_Data(WebElement wb, String a, String c) {
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys(wb, a).sendKeys(c).keyUp(Keys.CONTROL).build().perform();
	}

	public static void paste_All_Data(WebElement wb, String v) {
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys(wb, v).keyUp(Keys.CONTROL).build().perform();
	}
	
	public static void press_Enter_Button() {
		new Actions(driver).keyDown(Keys.ENTER).keyUp(Keys.ENTER).build().perform();
	}
	
	public static void press_Space_Button() {
		new Actions(driver).keyDown(Keys.SPACE).keyUp(Keys.SPACE).build().perform();
	}
	
	public static void press_DownArrow_Button() {
		new Actions(driver).keyDown(Keys.ARROW_DOWN).keyUp(Keys.ARROW_DOWN).build().perform();
	}

}
