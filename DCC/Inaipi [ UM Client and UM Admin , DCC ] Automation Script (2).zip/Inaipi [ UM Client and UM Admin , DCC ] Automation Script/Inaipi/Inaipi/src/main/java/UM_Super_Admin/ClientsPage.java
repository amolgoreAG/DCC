package UM_Super_Admin;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class ClientsPage extends BaseClass{


	@FindBy(xpath = "//span[text()='Clients']")
	WebElement clients;
	
	@FindBy(xpath = "//span[text()='Create Client']")
	WebElement createClient;
	
	@FindBy(xpath = "//input[@id='clientName']")
	WebElement clientName;
	
	@FindBy(xpath = "//button[@id='logo']/span[1]")
	WebElement companyLogo;
	
	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[3]/div/div[2]/input")
	WebElement companyLogo1;
	
	@FindBy(xpath = "//input[@id='maxUsers']")
	WebElement maxUser;
	
	@FindBy(xpath = "//input[@id='primaryColor']")
	WebElement primaryColor;
	
	@FindBy(xpath = "//input[@id='headerColor']")
	WebElement headerColor;
	
	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiIconButton-root float-r']/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement close;
	
	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement cancel;
	
	@FindBy(xpath = "//span[text()='CREATE CLIENT']")
	WebElement create_Client;
	
	public ClientsPage() {
		PageFactory.initElements(driver, this);
	}
	public boolean displayStatusOfclients() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clients, "clients");
		return clients.isDisplayed();
	}
	
	public boolean enableStatusOfclients() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clients, "clients");
		return clients.isEnabled();
	}
	
	public void clickOnclients() {
		clients.click();
	}
	public boolean displayStatusOfcreateClient() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(createClient, "createClient");
		return createClient.isDisplayed();
	}
	
	public boolean enableStatusOfcreateClient() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(createClient, "createClient");
		return createClient.isEnabled();
	}
	
	public void clickOncreateClient() {
		createClient.click();
	}
	public boolean displayStatusOfclientName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clientName, "clientName");
		return clientName.isDisplayed();
	}
	
	public boolean enableStatusOfclientName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clientName, "clientName");
		return clientName.isEnabled();
	}
	
	public void enterDataInclientName(String ClientName) {
		clientName.sendKeys(ClientName);
	}
	public boolean displayStatusOfcompanyLogo() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(companyLogo, "companyLogo");
		return companyLogo.isDisplayed();
	}
	
	public boolean enableStatusOfcompanyLogo() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(companyLogo, "companyLogo");
		return companyLogo.isEnabled();
	}
	
	public void attachedFileTocompanyLogo(String CompanyLogo) throws InterruptedException {
			companyLogo1.sendKeys(CompanyLogo);
	}
	public boolean displayStatusOfmaxUser() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(maxUser, "maxUser");
		return maxUser.isDisplayed();
	}
	
	public boolean enableStatusOfmaxUser() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(maxUser, "maxUser");
		return maxUser.isEnabled();
	}
	
	public void enterDataInmaxUser(String MaxUser) throws InterruptedException {
		maxUser.sendKeys(MaxUser);
	}
	public boolean displayStatusOfprimaryColor() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(primaryColor, "primaryColor");
		return primaryColor.isDisplayed();
	}
	
	public boolean enableStatusOfprimaryColor() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(primaryColor, "primaryColor");
		return primaryColor.isEnabled();
	}
	
	public void clickOnprimaryColor() throws InterruptedException {
//		primaryColor.click();
//		Thread.sleep(1000);1
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		jse.executeScript("document.getElementById('primaryColor').value='#1E4694';");
	}
	public boolean displayStatusOfheaderColor() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(headerColor, "headerColor");
		return headerColor.isDisplayed();
	}
	
	public boolean enableStatusOfheaderColor() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(headerColor, "headerColor");
		return headerColor.isEnabled();
	}
	
	public void clickOnheaderColor() throws InterruptedException {
//		headerColor.click();
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		jse.executeScript("document.getElementById('headerColor').value='#16DA5A';");

	}
	public boolean displayStatusOfclose() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfclose() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnclose() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfcancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfcancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOncancel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfcreate_Client() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(create_Client, "create_Client");
		return create_Client.isDisplayed();
	}
	
	public boolean enableStatusOfcreate_Client() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(create_Client, "create_Client");
		return create_Client.isEnabled();
	}
	
	public void clickOncreate_Client() throws InterruptedException {
		create_Client.click();
	}


}
