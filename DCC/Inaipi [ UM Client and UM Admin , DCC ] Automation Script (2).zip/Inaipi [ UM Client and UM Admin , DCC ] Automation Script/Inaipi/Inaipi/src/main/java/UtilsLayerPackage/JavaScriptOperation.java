package UtilsLayerPackage;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import BaseLayerPackage.BaseClass;

public class JavaScriptOperation extends BaseClass{

	public static void highlightTestBoxByGreen(WebElement wb) {
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green';", wb);
	}
	public static void highlightTestBoxByRed(WebElement wb) {
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red';", wb);
	}
	public static void scrollBy(int a , int b) {
		((JavascriptExecutor)driver).executeScript("window.scrollBy(a , b);");
		
	}
}
