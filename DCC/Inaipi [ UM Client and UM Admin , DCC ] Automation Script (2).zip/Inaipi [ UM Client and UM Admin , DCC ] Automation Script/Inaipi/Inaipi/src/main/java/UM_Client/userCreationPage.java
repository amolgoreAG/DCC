package UM_Client;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class userCreationPage extends BaseClass {


	@FindBy(xpath = "//span[text()='User Creation']")
	WebElement createClient;

	@FindBy(xpath = "//input[@id='firstName']")
	WebElement firstName;

	@FindBy(xpath = "//input[@id='lastName']")
	WebElement lastName;

	@FindBy(xpath = "//input[@id='email']")
	WebElement email;

	@FindBy(xpath = "//input[@id='contactNumber']")
	WebElement contactNumber;

	@FindBy(xpath = "//input[@id='password']")
	WebElement clientPassword;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[5]/div/div[2]/div/div/div//*[@class='MuiSvgIcon-root']")
	WebElement clientPasswordShow;

	@FindBy(xpath = "//input[@id='confirmPassword']")
	WebElement clientConfirmPassword;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[6]/div/div[2]/div/div/div//*[@class='MuiSvgIcon-root']")
	WebElement clientConfirmPasswordShow;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[7]/div[1]/div[2]/div")
	WebElement clientRole;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[8]/div[1]/div[2]/div")
	WebElement clientGroup;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[10]/div[1]/div[2]/div")
	WebElement clientChannel;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[11]/div[1]/div[2]/div")
	WebElement clientSubChannel;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[12]/div/div[1]/span[2]/button")
	WebElement addSkillAndProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[12]/div/div[2]/div/div[1]/div/div")
	WebElement addSkill;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[12]/div/div[2]/div/div[2]/div/div")
	WebElement addSkillProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[12]/div/div[2]/div/div[3]//*[@class='MuiSvgIcon-root groupRemoveIcon']")
	WebElement removeSkillAndProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[13]/div/div[1]/span[2]/button")
	WebElement addLanguageAndProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[13]/div/div[2]/div/div[1]/div/div")
	WebElement addLanguage;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[13]/div/div[2]/div/div[2]/div/div")
	WebElement addLanguageProfeciancy;

	@FindBy(xpath = "//div[@class='text-left square-text']/div[1]/div[13]/div/div[2]/div/div[3]//*[@class='MuiSvgIcon-root groupRemoveIcon']")
	WebElement removeLanguageAndProfeciancy;

	@FindBy(xpath = "//span[text()='Create User']")
	WebElement createUser;

	@FindBy(xpath = "//span[text()='Clear']")
	WebElement clear;
	
	public userCreationPage(){
		PageFactory.initElements(driver, this);
	}
	public boolean displayStatusOfcreateClient() throws InterruptedException {
		if (createClient.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createClient is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createClient is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createClient.isDisplayed();
	}

	public boolean enableStatusOfcreateClient() throws InterruptedException {
		if (createClient.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createClient is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createClient is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createClient.isEnabled();
	}

	public void clickOncreateClient() throws InterruptedException {
		createClient.click();
	}

	public boolean displayStatusOffirstName() throws InterruptedException {
		if (firstName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(firstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of firstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(firstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of firstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return firstName.isDisplayed();
	}

	public boolean enableStatusOffirstName() throws InterruptedException {
		if (firstName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(firstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of firstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(firstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of firstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return firstName.isEnabled();
	}

	public void enterDataInfirstName(String FirstName) throws InterruptedException {
		firstName.sendKeys(FirstName);
	}

	public boolean displayStatusOflastName() throws InterruptedException {
		if (lastName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(lastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of lastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(lastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of lastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return lastName.isDisplayed();
	}

	public boolean enableStatusOflastName() throws InterruptedException {
		if (lastName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(lastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of lastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(lastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of lastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return lastName.isEnabled();
	}

	public void enterDataInlastName(String LastName) throws InterruptedException {
		lastName.sendKeys(LastName);
	}

	public boolean displayStatusOfemail() throws InterruptedException {
		if (email.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(email);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of email is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(email);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of email is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return email.isDisplayed();
	}

	public boolean enableStatusOfemail() throws InterruptedException {
		if (email.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(email);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of email is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(email);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of email is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return email.isEnabled();
	}

	public void enterDataInemail(String Email) throws InterruptedException {
		email.sendKeys(Email);
	}

	public boolean displayStatusOfcontactNumber() throws InterruptedException {
		if (contactNumber.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(contactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of contactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(contactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of contactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return contactNumber.isDisplayed();
	}

	public boolean enableStatusOfcontactNumber() throws InterruptedException {
		if (contactNumber.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(contactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of contactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(contactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of contactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return contactNumber.isEnabled();
	}

	public void enterDataIncontactNumber(String ContactNumber) throws InterruptedException {
		contactNumber.sendKeys(ContactNumber);
	}

	public boolean displayStatusOfclientPassword() throws InterruptedException {
		if (clientPassword.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientPassword is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientPassword is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientPassword.isDisplayed();
	}

	public boolean enableStatusOfclientPassword() throws InterruptedException {
		if (clientPassword.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientPassword is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientPassword is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientPassword.isEnabled();
	}

	public void enterDataInclientPassword(String ClientPassword) throws InterruptedException {
		clientPassword.sendKeys(ClientPassword);
	}

	public boolean displayStatusOfclientPasswordShow() throws InterruptedException {
		if (clientPasswordShow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientPasswordShow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientPasswordShow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientPasswordShow.isDisplayed();
	}

	public boolean enableStatusOfclientPasswordShow() throws InterruptedException {
		if (clientPasswordShow.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientPasswordShow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientPasswordShow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientPasswordShow.isEnabled();
	}

	public void clickclientPasswordShow() throws InterruptedException {
		clientPasswordShow.click();
	}

	public boolean displayStatusOfclientConfirmPassword() throws InterruptedException {
		if (clientConfirmPassword.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientConfirmPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientConfirmPassword is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientConfirmPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientConfirmPassword is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientConfirmPassword.isDisplayed();
	}

	public boolean enableStatusOfclientConfirmPassword() throws InterruptedException {
		if (clientConfirmPassword.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientConfirmPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientConfirmPassword is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientConfirmPassword);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientConfirmPassword is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientConfirmPassword.isEnabled();
	}

	public void enterDataInclientConfirmPassword(String ClientConfirmPassword) throws InterruptedException {
		clientConfirmPassword.sendKeys(ClientConfirmPassword);
	}

	public boolean displayStatusOfclientConfirmPasswordShow() throws InterruptedException {
		if (clientConfirmPasswordShow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientConfirmPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientConfirmPasswordShow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientConfirmPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of clientConfirmPasswordShow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientConfirmPasswordShow.isDisplayed();
	}

	public boolean enableStatusOfclientConfirmPasswordShow() throws InterruptedException {
		if (clientConfirmPasswordShow.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientConfirmPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientConfirmPasswordShow is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientConfirmPasswordShow);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientConfirmPasswordShow is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientConfirmPasswordShow.isEnabled();
	}

	public void clickConfirmPasswordShow() throws InterruptedException {
		clientConfirmPasswordShow.click();
	}

	public boolean displayStatusOfclientRole() throws InterruptedException {
		if (clientRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientRole.isDisplayed();
	}

	public boolean enableStatusOfclientRole() throws InterruptedException {
		if (clientRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientRole.isEnabled();
	}

	public void clickOnclientRole() throws InterruptedException {
		clientRole.click();
	}

	public void selectRoleFromDP(String role) {
		driver.findElement(By.xpath("//span[text()='" + role + "']")).click();
	}

	public boolean displayStatusOfclientGroup() throws InterruptedException {
		if (clientGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientGroup.isDisplayed();
	}

	public boolean enableStatusOfclientGroup() throws InterruptedException {
		if (clientGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientGroup.isEnabled();
	}

	public void clickOnclientGroup() throws InterruptedException {
		clientGroup.click();
	}

	public void selectGroupFromDP(String group) {
		driver.findElement(By.xpath("//span[text()='" + group + "']")).click();
	}

	public boolean displayStatusOfclientChannel() throws InterruptedException {
		if (clientChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientChannel.isDisplayed();
	}

	public boolean enableStatusOfclientChannel() throws InterruptedException {
		if (clientChannel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientChannel.isEnabled();
	}

	public void clickOnclientChannel() throws InterruptedException {
		clientChannel.click();
	}

	public void selectChannelFromDP(String channel) {
		driver.findElement(By.xpath("//span[text()='" + channel + "']")).click();
	}

	public boolean displayStatusOfclientSubChannel() throws InterruptedException {
		if (clientSubChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientSubChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clientSubChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientSubChannel.isDisplayed();
	}

	public boolean enableStatusOfclientSubChannel() throws InterruptedException {
		if (clientSubChannel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clientSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientSubChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clientSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clientSubChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clientSubChannel.isEnabled();
	}

	public void clickOnclientSubChannel() throws InterruptedException {
		clientSubChannel.click();
	}

	public void selectsubChannelFromDP(String subChannel) {
		driver.findElement(By.xpath("//span[text()='" + subChannel + "']")).click();
	}

	public boolean displayStatusOfaddSkillAndProfeciancy() throws InterruptedException {
		if (addSkillAndProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkillAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkillAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkillAndProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfaddSkillAndProfeciancy() throws InterruptedException {
		if (addSkillAndProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkillAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkillAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkillAndProfeciancy.isEnabled();
	}

	public void clickOnaddSkillAndProfeciancy() throws InterruptedException {
		addSkillAndProfeciancy.click();
	}

	public boolean displayStatusOfaddSkill() throws InterruptedException {
		if (addSkill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkill.isDisplayed();
	}

	public boolean enableStatusOfaddSkill() throws InterruptedException {
		if (addSkill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkill.isEnabled();
	}

	public void clickOnaddSkill() throws InterruptedException {
		addSkill.click();
	}

	public void selectDPValueFromAddSkill(String skill) {
		driver.findElement(By.xpath("//span[text()='" + skill + "']")).click();
	}

	public boolean displayStatusOfaddSkillProfeciancy() throws InterruptedException {
		if (addSkillProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkillProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSkillProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkillProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfaddSkillProfeciancy() throws InterruptedException {
		if (addSkillProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSkillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkillProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSkillProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addSkillProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addSkillProfeciancy.isEnabled();
	}

	public void clickOnaddSkillProfeciancy() throws InterruptedException {
		addSkillProfeciancy.click();
	}

	public void selectDPValueFromAddSkillProfeciancy(String skillProf) {
		driver.findElement(By.xpath("//span[text()='" + skillProf + "']")).click();
	}

	public boolean displayStatusOfremoveSkillAndProfeciancy() throws InterruptedException {
		if (removeSkillAndProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeSkillAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of removeSkillAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeSkillAndProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfremoveSkillAndProfeciancy() throws InterruptedException {
		if (removeSkillAndProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeSkillAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeSkillAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeSkillAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeSkillAndProfeciancy.isEnabled();
	}

	public void clickOnremoveSkillAndProfeciancy() throws InterruptedException {
		removeSkillAndProfeciancy.click();
	}

	public boolean displayStatusOfaddLanguageAndProfeciancy() throws InterruptedException {
		if (addLanguageAndProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguageAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of addLanguageAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguageAndProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfaddLanguageAndProfeciancy() throws InterruptedException {
		if (addLanguageAndProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguageAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguageAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguageAndProfeciancy.isEnabled();
	}

	public void clickOnaddLanguageAndProfeciancy() throws InterruptedException {
		addLanguageAndProfeciancy.click();
	}

	public boolean displayStatusOfaddLanguage() throws InterruptedException {
		if (addLanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguage.isDisplayed();
	}

	public boolean enableStatusOfaddLanguage() throws InterruptedException {
		if (addLanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguage.isEnabled();
	}

	public void clickOnaddLanguage() throws InterruptedException {
		addLanguage.click();
	}

	public void selectDPValueFromAddLanguage(String language) {
		driver.findElement(By.xpath("//span[text()='" + language + "']")).click();
	}

	public boolean displayStatusOfaddLanguageProfeciancy() throws InterruptedException {
		if (addLanguageProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguageProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguageProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguageProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addLanguageProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguageProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfaddLanguageProfeciancy() throws InterruptedException {
		if (addLanguageProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addLanguageProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguageProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addLanguageProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addLanguageProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addLanguageProfeciancy.isEnabled();
	}

	public void clickOnaddLanguageProfeciancy() throws InterruptedException {
		addLanguageProfeciancy.click();
	}

	public void selectDPValueFromAddLanguageProfeciancy(String LanguageProf) {
		driver.findElement(By.xpath("//span[text()='" + LanguageProf + "']")).click();
	}

	public boolean displayStatusOfremoveLanguageAndProfeciancy() throws InterruptedException {
		if (removeLanguageAndProfeciancy.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of removeLanguageAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of removeLanguageAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeLanguageAndProfeciancy.isDisplayed();
	}

	public boolean enableStatusOfremoveLanguageAndProfeciancy() throws InterruptedException {
		if (removeLanguageAndProfeciancy.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of removeLanguageAndProfeciancy is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeLanguageAndProfeciancy);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of removeLanguageAndProfeciancy is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeLanguageAndProfeciancy.isEnabled();
	}

	public void clickOnremoveLanguageAndProfeciancy() throws InterruptedException {
		removeLanguageAndProfeciancy.click();
	}

	public boolean displayStatusOfcreateUser() throws InterruptedException {
		new Actions(driver).moveToElement(createUser).build().perform();
		Thread.sleep(1000);
		if (createUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of createUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createUser.isDisplayed();
	}

	public boolean enableStatusOfcreateUser() throws InterruptedException {
		if (createUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(createUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(createUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of createUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return createUser.isEnabled();
	}

	public void clickOncreateUser() throws InterruptedException {
		createUser.click();
	}

	public boolean displayStatusOfclear() throws InterruptedException {
		if (clear.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clear);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clear is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clear);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clear is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clear.isDisplayed();
	}

	public boolean enableStatusOfclear() throws InterruptedException {
		if (clear.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clear);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clear is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clear);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clear is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clear.isEnabled();
	}

	public void clickOnclear() throws InterruptedException {
		clear.click();
	}


}
