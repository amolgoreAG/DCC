package UM_Super_Admin;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class ClientMappingPage extends BaseClass {

	@FindBy(xpath = "//li[@id='4']")
	WebElement clientMapping;
	
	@FindBy(xpath = "//li[text()='Channel Mapping']")
	WebElement clientChannelMapping;
	
	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select m')]")
	WebElement selectClientCM;
	
	@FindBy(xpath = "//span[text()='View']")
	WebElement viewClient;
	
	@FindBy(xpath = "(//span[@class='MuiIconButton-label'])[4]//*[@class='MuiSvgIcon-root']")
	WebElement chatCheckBox;
	
	@FindBy(xpath = "//tbody[@class='MuiTableBody-root']/tr[2]/td[1]/center/span/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement twitterCheckBox;
	
	@FindBy(xpath = "//span[text()='SAVE CHANNEL']")
	WebElement saveChaneel;
	
	@FindBy(xpath = "//li[text()='Routing Mapping']")
	WebElement routingMapping;
	
	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select m')]")
	WebElement selectClientRM;
	
	@FindBy(xpath = "//span[text()='View']")
	WebElement viewRouter;
	
	@FindBy(xpath = "//span[text()='Add Router']")
	WebElement addRouter;
	
	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select h')]")
	WebElement selectRouter;
	
	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-item']//*[@title='Click here to save the changes']")
	WebElement saveRouter;
	
	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-item']//*[@title='Click here to delete the changes']")
	WebElement cancelRouter;
	
	public ClientMappingPage() {
		PageFactory.initElements(driver, this);
	}
	public boolean displayStatusOfclientMapping() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clientMapping, "clientMapping");
		return clientMapping.isDisplayed();
	}
	
	public boolean enableStatusOfclientMapping() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clientMapping, "clientMapping");
		return clientMapping.isEnabled();
	}
	
	public void clickOnclientMapping() throws InterruptedException {
		try {
			clientMapping.click();
		} catch (Exception e) {
			new Actions(driver).click(clientMapping).build().perform();

		}
	}
	public boolean displayStatusOfclientChannelMapping() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clientChannelMapping, "clientChannelMapping");
		return clientChannelMapping.isDisplayed();
	}
	
	public boolean enableStatusOfclientChannelMapping() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clientChannelMapping, "clientChannelMapping");
		return clientChannelMapping.isEnabled();
	}
	
	public void clickOnclientChannelMapping() throws InterruptedException {
		try {
			clientChannelMapping.click();
		} catch (Exception e) {
			new Actions(driver).click(clientChannelMapping).build().perform();

		}
	}
	public boolean displayStatusOfselectClientCM() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectClientCM, "selectClientCM");
		return selectClientCM.isDisplayed();
	}
	
	public boolean enableStatusOfselectClientCM() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectClientCM, "selectClientCM");
		return selectClientCM.isEnabled();
	}
	
	public void clickOnselectClientCMandSelectDPValue(String SelectClientCM) throws InterruptedException {
		selectClientCM.click();
		driver.findElement(By.xpath("//span[text()='"+SelectClientCM+"']")).click();
	}
	public boolean displayStatusOfviewClient() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(viewClient, "viewClient");
		return viewClient.isDisplayed();
	}
	
	public boolean enableStatusOfviewClient() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(viewClient, "viewClient");
		return viewClient.isEnabled();
	}
	
	public void clickOnviewClient() throws InterruptedException {
		try {
			viewClient.click();
		} catch (Exception e) {
			new Actions(driver).click(viewClient).build().perform();

		}
	}
	public boolean displayStatusOfchatCheckBox() throws InterruptedException {
		if (chatCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chatCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatCheckBox is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chatCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatCheckBox is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chatCheckBox.isDisplayed();
	}
	
	public boolean enableStatusOfchatCheckBox() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(chatCheckBox, "chatCheckBox");
		return chatCheckBox.isEnabled();
	}
	
	public void clickOnchatCheckBox() throws InterruptedException {
		try {
			chatCheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(chatCheckBox).build().perform();

		}
	}
	public boolean displayStatusOftwitterCheckBox() throws InterruptedException {
		if (twitterCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(twitterCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of twitterCheckBox is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(twitterCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of twitterCheckBox is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return twitterCheckBox.isDisplayed();
	}
	
	public boolean enableStatusOftwitterCheckBox() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(twitterCheckBox, "twitterCheckBox");
		return twitterCheckBox.isEnabled();
	}
	
	public void clickOntwitterCheckBox() throws InterruptedException {
		WebElement chechBox = driver.findElement(By.xpath("//tbody[@class='MuiTableBody-root']/tr[2]/td[1]/center/span/span[1]/input"));
		try {
			chechBox.click();
		} catch (Exception e) {
			new Actions(driver).click(chechBox).build().perform();

		}
	}
	public boolean displayStatusOfsaveChaneel() throws InterruptedException {
		if (saveChaneel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveChaneel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveChaneel is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveChaneel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveChaneel is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveChaneel.isDisplayed();
	}
	
	public boolean enableStatusOfsaveChaneel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(saveChaneel, "saveChaneel");
		return saveChaneel.isEnabled();
	}
	
	public void clickOnsaveChaneel() throws InterruptedException {
		saveChaneel.click();
	}
	public boolean displayStatusOfselectClientCM2() throws InterruptedException {
		if (selectClientCM.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectClientCM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectClientCM is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectClientCM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectClientCM is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectClientCM.isDisplayed();
	}
	
	public boolean enableStatusOfselectClientCM2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectClientCM, "selectClientCM");
		return selectClientCM.isEnabled();
	}
	
	public void clickOnselectClientCMandSelectDPValue2(String SelectClientCM1, String SelectClientCM2) throws InterruptedException {
		selectClientCM.click();
		driver.findElement(By.xpath("//span[text()='"+SelectClientCM1+"']")).click();
		Thread.sleep(2000);
		selectClientCM.click();
		driver.findElement(By.xpath("//span[text()='"+SelectClientCM2+"']")).click();
	}
	public boolean displayStatusOfviewClient2() throws InterruptedException {
		if (viewClient.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewClient is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewClient is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewClient.isDisplayed();
	}
	
	public boolean enableStatusOfviewClient2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(viewClient, "viewClient");
		return viewClient.isEnabled();
	}
	
	public void clickOnviewClient2() throws InterruptedException {
		viewClient.click();
	}
	public boolean displayStatusOfchatCheckBox2() throws InterruptedException {
		if (chatCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chatCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatCheckBox is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chatCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatCheckBox is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chatCheckBox.isDisplayed();
	}
	
	public boolean enableStatusOfchatCheckBox2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(chatCheckBox, "chatCheckBox");
		return chatCheckBox.isEnabled();
	}
	
	public void clickOnchatCheckBox2() throws InterruptedException {
		try {
			chatCheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(chatCheckBox).build().perform();

		}
	}
	public boolean displayStatusOftwitterCheckBox2() throws InterruptedException {
		if (twitterCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(twitterCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of twitterCheckBox is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(twitterCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of twitterCheckBox is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return twitterCheckBox.isDisplayed();
	}
	
	public boolean enableStatusOftwitterCheckBox2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(twitterCheckBox, "twitterCheckBox");
		return twitterCheckBox.isEnabled();
	}
	
	public void clickOntwitterCheckBox2() throws InterruptedException {
		try {
			twitterCheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(twitterCheckBox).build().perform();

		}
	}
	public boolean displayStatusOfsaveChaneel2() throws InterruptedException {
		if (saveChaneel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveChaneel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveChaneel is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveChaneel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveChaneel is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveChaneel.isDisplayed();
	}
	
	public boolean enableStatusOfsaveChaneel2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(saveChaneel, "saveChaneel");
		return saveChaneel.isEnabled();
	}
	
	public void clickOnsaveChaneel2() throws InterruptedException {
		saveChaneel.click();
	}
	public boolean displayStatusOfroutingMapping() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routingMapping, "routingMapping");
		return routingMapping.isDisplayed();
	}
	
	public boolean enableStatusOfroutingMapping() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routingMapping, "routingMapping");
		return routingMapping.isEnabled();
	}
	
	public void clickOnroutingMapping() throws InterruptedException {
		routingMapping.click();
	}
	public boolean displayStatusOfselectClientRM() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectClientRM, "selectClientRM");
		return selectClientRM.isDisplayed();
	}
	
	public boolean enableStatusOfselectClientRM() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectClientRM, "selectClientRM");
		return selectClientRM.isEnabled();
	}
	
	public void clickOnselectClientRMandSelectDPValue(String SelectClientRM) throws InterruptedException {
		selectClientRM.click();
		driver.findElement(By.xpath("//span[text()='"+SelectClientRM+"']")).click();
	}
	public boolean displayStatusOfviewRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(viewRouter, "viewRouter");
		return viewRouter.isDisplayed();
	}
	
	public boolean enableStatusOfviewRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(viewRouter, "viewRouter");
		return viewRouter.isEnabled();
	}
	
	public void clickOnviewRouter() throws InterruptedException {
		viewRouter.click();
	}
	public boolean displayStatusOfaddRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(addRouter, "addRouter");
		return addRouter.isDisplayed();
	}
	
	public boolean enableStatusOfaddRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(addRouter, "addRouter");
		return addRouter.isEnabled();
	}
	
	public void clickOnaddRouter() throws InterruptedException {
		addRouter.click();
	}
	public boolean displayStatusOfselectRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectRouter, "selectRouter");
		return selectRouter.isDisplayed();
	}
	
	public boolean enableStatusOfselectRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectRouter, "selectRouter");
		return selectRouter.isEnabled();
	}
	
	public void clickOnselectRouterandSelectDPValue(String SelectClientRM) throws InterruptedException {
		selectRouter.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='"+SelectClientRM+"']")).click();
	}
	public boolean displayStatusOfsaveRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(saveRouter, "saveRouter");
		return saveRouter.isDisplayed();
	}
	
	public boolean enableStatusOfsaveRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(saveRouter, "saveRouter");
		return saveRouter.isEnabled();
	}
	
	public void clickOnsaveRouterandSelectDPValue() throws InterruptedException {
		saveRouter.click();
	}
	public boolean displayStatusOfcancelRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancelRouter, "cancelRouter");
		return cancelRouter.isDisplayed();
	}
	
	public boolean enableStatusOfcancelRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancelRouter, "cancelRouter");
		return cancelRouter.isEnabled();
	}
	
	public void clickOncancelRouterandSelectDPValue() throws InterruptedException {
		cancelRouter.click();
	}
}
