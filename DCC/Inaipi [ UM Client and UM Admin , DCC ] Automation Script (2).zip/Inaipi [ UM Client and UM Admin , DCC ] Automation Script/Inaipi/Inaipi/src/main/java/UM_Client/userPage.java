package UM_Client;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class userPage extends BaseClass {


	@FindBy(xpath = "//span[text()='Users']")
	WebElement users;

	@FindBy(xpath = "//input[@id='searchval']")
	WebElement searchUser;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]/table//tbody/tr[1]/td[4]//*[@title='Edit User']")
	WebElement editUsers;

	@FindBy(xpath = "//input[@id='firstName']")
	WebElement userFirstName;

	@FindBy(xpath = "//input[@id='lastName']")
	WebElement userLastName;

	@FindBy(xpath = "//input[@id='email']")
	WebElement userEmail;

	@FindBy(xpath = "//input[@id='contactNumber']")
	WebElement userContactNumber;

	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[5]/div[1]/div[2]/div/div[1]")
	WebElement userRole;

	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[6]/div[1]/div[2]/div/div[1]")
	WebElement userGroup;

	@FindBy(xpath = "//div[@class='MuiDialogActions-root MuiDialogActions-spacing']/div/button[1]/span[1]")
	WebElement userUpdate;

	@FindBy(xpath = "//div[@class='MuiDialogActions-root MuiDialogActions-spacing']/div/button[2]/span[1]")
	WebElement userCancel;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]/table//tbody/tr[1]/td[4]/span[@class='MuiSwitch-root MuiSwitch-sizeSmall']")
	WebElement UserStatus;

	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]/table//tbody/tr[1]/td[5]//*[@title='View User']")
	WebElement viewUser;

	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiButton-root MuiButton-contained closeContentBtn']")
	WebElement viewCancel;
	
	@FindBy(xpath = "//div[@class='MuiDialogTitle-root']//span[1]")
	WebElement close;

	public userPage() {
		PageFactory.initElements(driver, this);
	}


	public boolean displayStatusOfusers() throws InterruptedException {
		if (users.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(users);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of users is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(users);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of users is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return users.isDisplayed();
	}

	public boolean enableStatusOfusers() throws InterruptedException {
		if (users.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(users);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of users is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(users);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of users is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return users.isEnabled();
	}

	public void clickOnusers() throws InterruptedException {
		users.click();
	}

	public boolean displayStatusOfsearchUser() throws InterruptedException {
		if (searchUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(searchUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of searchUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(searchUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of searchUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return searchUser.isDisplayed();
	}

	public boolean enableStatusOfsearchUser() throws InterruptedException {
		if (searchUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(searchUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of searchUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(searchUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of searchUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return searchUser.isEnabled();
	}

	public void clickOnsearchUser() throws InterruptedException {
		searchUser.click();
	}

	public void enterDataInsearchUser(String SearchUser) {
		searchUser.sendKeys(SearchUser);
	}

	public boolean displayStatusOfeditUsers() throws InterruptedException {
		if (editUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of editUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editUsers.isDisplayed();
	}

	public boolean enableStatusOfeditUsers() throws InterruptedException {
		if (editUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(editUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(editUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of editUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return editUsers.isEnabled();
	}

	public void clickOneditUsers() throws InterruptedException {
		editUsers.click();
	}

	public boolean displayStatusOfuserFirstName() throws InterruptedException {
		if (userFirstName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userFirstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userFirstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userFirstName.isDisplayed();
	}

	public boolean enableStatusOfuserFirstName() throws InterruptedException {
		if (userFirstName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userFirstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userFirstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userFirstName.isEnabled();
	}

	public void enterDataInuserFirstName(String UserFirstName) throws InterruptedException {
		new Actions(driver).click(userFirstName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(userFirstName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		userFirstName.sendKeys(UserFirstName);
	}

	public boolean displayStatusOfuserLastName() throws InterruptedException {
		if (userLastName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userLastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userLastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userLastName.isDisplayed();
	}

	public boolean enableStatusOfuserLastName() throws InterruptedException {
		if (userLastName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userLastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userLastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userLastName.isEnabled();
	}

	public void enterDataInuserLastName(String UserLastName) throws InterruptedException {
		new Actions(driver).click(userLastName).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(userLastName, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		userLastName.sendKeys(UserLastName);
	}

	public boolean displayStatusOfuserEmail() throws InterruptedException {
		if (userEmail.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userEmail is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userEmail is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userEmail.isDisplayed();
	}

	public boolean enableStatusOfuserEmail() throws InterruptedException {
		if (userEmail.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userEmail is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userEmail is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userEmail.isEnabled();
	}

	public void enterDataInuserEmail(String UserEmail) throws InterruptedException {
		new Actions(driver).click(userEmail).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(userEmail, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		userEmail.sendKeys(UserEmail);
	}

	public boolean displayStatusOfuserContactNumber() throws InterruptedException {
		if (userContactNumber.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userContactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userContactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userContactNumber.isDisplayed();
	}

	public boolean enableStatusOfuserContactNumber() throws InterruptedException {
		if (userContactNumber.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userContactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userContactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userContactNumber.isEnabled();
	}

	public void enterDataInuserContactNumber(String UserContactNumber) throws InterruptedException {
		new Actions(driver).click(userContactNumber).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
				.sendKeys(userContactNumber, Keys.DELETE).build().perform();
		Thread.sleep(1500);
		userContactNumber.sendKeys(UserContactNumber);
	}

	public boolean displayStatusOfuserRole() throws InterruptedException {
		if (userRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userRole.isDisplayed();
	}

	public boolean enableStatusOfuserRole() throws InterruptedException {
		if (userRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userRole.isEnabled();
	}

	public void enterDataInuserRole(String UserRole) throws InterruptedException {
		new Actions(driver).click(userRole).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(1500);
		userRole.click();
		driver.findElement(By.xpath("//span[text()='" + UserRole + "']")).click();
	}

	public boolean displayStatusOfuserGroup() throws InterruptedException {
		if (userGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userGroup.isDisplayed();
	}

	public boolean enableStatusOfuserGroup() throws InterruptedException {
		if (userGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userGroup.isEnabled();
	}

	public void enterDataInuserGroup(String UserGroup) throws InterruptedException {
		new Actions(driver).click(userGroup).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(1500);
		userGroup.click();
		driver.findElement(By.xpath("//span[text()='" + UserGroup + "']")).click();
	}

	public boolean displayStatusOfcloseUserWin() throws InterruptedException {
		if (close.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isDisplayed();
	}

	public boolean enableStatusOfcloseUserWin() throws InterruptedException {
		if (close.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(close);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of close is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return close.isEnabled();
	}

	public void clickOncloseUserWin() throws InterruptedException {
		close.click();
	}

	public boolean displayStatusOfuserUpdateUserWin() throws InterruptedException {
		if (userUpdate.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userUpdate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userUpdate is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userUpdate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userUpdate is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userUpdate.isDisplayed();
	}

	public boolean enableStatusOfuserUpdateUserWin() throws InterruptedException {
		if (userUpdate.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userUpdate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userUpdate is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userUpdate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userUpdate is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userUpdate.isEnabled();
	}

	public void clickOnuserUpdateUserWin() throws InterruptedException {
		userUpdate.click();
	}

	public boolean displayStatusOfuserCancelUserWin() throws InterruptedException {
		if (userCancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userCancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userCancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userCancel.isDisplayed();
	}

	public boolean enableStatusOfuserCancelUserWin() throws InterruptedException {
		if (userCancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userCancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userCancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userCancel.isEnabled();
	}

	public void clickOnuserCancelUserWin() throws InterruptedException {
		userCancel.click();
	}

	public boolean displayStatusOfUserStatusUserWin() throws InterruptedException {
		if (UserStatus.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(UserStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of UserStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(UserStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of UserStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return UserStatus.isDisplayed();
	}

	public boolean enableStatusOfUserStatusUserWin() throws InterruptedException {
		if (UserStatus.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(UserStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of UserStatus is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(UserStatus);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of UserStatus is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return UserStatus.isEnabled();
	}

	public void clickOnUserStatus() throws InterruptedException {
		try {
			UserStatus.click();
		} catch (Exception e) {
			new Actions(driver).click(UserStatus).build().perform();
		}
		Thread.sleep(3000);
		try {
			UserStatus.click();
		} catch (Exception e) {
			new Actions(driver).click(UserStatus).build().perform();
		}
	}

	public boolean displayStatusOfView_viewUserUserWin() throws InterruptedException {
		if (viewUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewUser.isDisplayed();
	}

	public boolean enableStatusOfView_viewUserUserWin() throws InterruptedException {
		if (viewUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewUser.isEnabled();
	}

	public void clickOnviewUser() {
		viewUser.click();
	}

	public boolean displayStatusOfView_userFirstName() throws InterruptedException {
		if (userFirstName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userFirstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userFirstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userFirstName.isDisplayed();
	}

	public boolean enableStatusOfView_userFirstName() throws InterruptedException {
		if (userFirstName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userFirstName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userFirstName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userFirstName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userFirstName.isEnabled();
	}

	public void enterDataInuserFirstNameText(String UserFirstName) {
		userFirstName.sendKeys(UserFirstName);
	}

	public boolean displayStatusOfView_userLastName() throws InterruptedException {
		if (userLastName.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userLastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userLastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userLastName.isDisplayed();
	}

	public boolean enableStatusOfView_userLastName() throws InterruptedException {
		if (userLastName.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userLastName is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userLastName);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userLastName is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userLastName.isEnabled();
	}

	public boolean displayStatusOfView_userEmail() throws InterruptedException {
		if (userEmail.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userEmail is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userEmail is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userEmail.isDisplayed();
	}

	public boolean enableStatusOfView_userEmail() throws InterruptedException {
		if (userEmail.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userEmail is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userEmail);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userEmail is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userEmail.isEnabled();
	}

	public boolean displayStatusOfView_userContactNumber() throws InterruptedException {
		if (userContactNumber.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userContactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userContactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userContactNumber.isDisplayed();
	}

	public boolean enableStatusOfView_userContactNumber() throws InterruptedException {
		if (userContactNumber.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userContactNumber is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userContactNumber);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userContactNumber is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userContactNumber.isEnabled();
	}

	public boolean displayStatusOfView_userRole() throws InterruptedException {
		if (userRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userRole.isDisplayed();
	}

	public boolean enableStatusOfView_userRole() throws InterruptedException {
		if (userRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userRole.isEnabled();
	}

	public boolean displayStatusOfView_userGroup() throws InterruptedException {
		if (userGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userGroup.isDisplayed();
	}

	public boolean enableStatusOfView_userGroup() throws InterruptedException {
		if (userGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userGroup.isEnabled();
	}

	public boolean displayStatusOfView_viewCancel() throws InterruptedException {
		if (viewCancel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewCancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewCancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewCancel.isDisplayed();
	}

	public boolean enableStatusOfView_viewCancel() throws InterruptedException {
		if (viewCancel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewCancel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewCancel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewCancel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewCancel.isEnabled();
	}

	public void clickOnviewCancel() {
		viewCancel.click();
	}

}
