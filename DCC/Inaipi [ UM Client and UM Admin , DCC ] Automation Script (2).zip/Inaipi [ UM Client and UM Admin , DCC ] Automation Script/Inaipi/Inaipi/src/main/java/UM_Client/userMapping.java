package UM_Client;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class userMapping extends BaseClass{

	@FindBy(xpath = "//span[text()='User Mapping']")
	WebElement userMapping;

	@FindBy(xpath = "//li[text()='Role Mapping']")
	WebElement roleMapping;

	@FindBy(xpath = "//div[@class='react-dropdown-select m-t-5 css-wmw4vi-ReactDropdownSelect e1gzf2xs0']")
	WebElement selectRole;

	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiButton-root MuiButton-outlined mainContentBlue']")
	WebElement viewSelectRole;

	@FindBy(xpath = "//span[text()='Add Users']")
	WebElement addUsers;

	@FindBy(xpath = "//div[@class='react-dropdown-select halfWidth p-l-10 m-l-20 m-b-10 css-wmw4vi-ReactDropdownSelect e1gzf2xs0']")
	WebElement selectUsers;

	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-item']//*[@title='Click here to save the changes']")
	WebElement saveUser;

	@FindBy(xpath = "//button[@title='Next page']/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement nextPage;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[7]/div//*[3]")
	WebElement minimize;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[2]/div//*[3]")
	WebElement minimize1;

	@FindBy(xpath = "//div[@class='MuiDialogActions-root MuiDialogActions-spacing']/button[2]/span[1]")
	WebElement removeUserNo;

	@FindBy(xpath = "//div[@class='MuiDialogActions-root MuiDialogActions-spacing']/button[1]/span[1]")
	WebElement removeUserYes;

	@FindBy(xpath = "//li[text()='Group Mapping']")
	WebElement groupMapping;

	@FindBy(xpath = "//div[@class='react-dropdown-select m-t-5 css-wmw4vi-ReactDropdownSelect e1gzf2xs0']")
	WebElement selectGroup;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement viewSelectGroup;

	public userMapping() {
		PageFactory.initElements(driver, this);
	}
	public boolean displayStatusOfuserMapping() throws InterruptedException {
		if (userMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of userMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userMapping.isDisplayed();
	}

	public boolean enableStatusOfuserMapping() throws InterruptedException {
		if (userMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(userMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(userMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of userMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return userMapping.isEnabled();
	}

	public void clickOnuserMapping() {
		userMapping.click();
	}

	public boolean displayStatusOfroleMapping() throws InterruptedException {
		if (roleMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of roleMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleMapping.isDisplayed();
	}

	public boolean enableStatusOfroleMapping() throws InterruptedException {
		if (roleMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(roleMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(roleMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of roleMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return roleMapping.isEnabled();
	}

	public void clickOnroleMapping() {
		roleMapping.click();
	}

	public boolean displayStatusOfselectRole() throws InterruptedException {
		if (selectRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectRole.isDisplayed();
	}

	public boolean enableStatusOfselectRole() throws InterruptedException {
		if (selectRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectRole.isEnabled();
	}

	public void clickOnselectRole(String SelectRole) throws InterruptedException {
		selectRole.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + SelectRole + "']")).click();
	}

	public boolean displayStatusOfviewSelectRole() throws InterruptedException {
		if (viewSelectRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewSelectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewSelectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewSelectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewSelectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewSelectRole.isDisplayed();
	}

	public boolean enableStatusOfviewSelectRole() throws InterruptedException {
		if (viewSelectRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewSelectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewSelectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewSelectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewSelectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewSelectRole.isEnabled();
	}

	public void clickOnSelectRole() throws InterruptedException {
		viewSelectRole.click();
	}

	public boolean displayStatusOfaddUsers() throws InterruptedException {
		if (addUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addUsers.isDisplayed();
	}

	public boolean enableStatusOfaddUsers() throws InterruptedException {
		if (addUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addUsers.isEnabled();
	}

	public void clickOnaddUsers() throws InterruptedException {
		addUsers.click();
	}

	public boolean displayStatusOfselectUsers() throws InterruptedException {
		if (selectUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectUsers.isDisplayed();
	}

	public boolean enableStatusOfselectUsers() throws InterruptedException {
		if (selectUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectUsers.isEnabled();
	}

	public void clickAndselectUsers() throws InterruptedException {
		selectUsers.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfsaveUser() throws InterruptedException {
		if (saveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveUser.isDisplayed();
	}

	public boolean enableStatusOfsaveUser() throws InterruptedException {
		if (saveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveUser.isEnabled();
	}

	public void clickOnsaveUser() throws InterruptedException {
		saveUser.click();
	}

	public boolean displayStatusOfnextPage() throws InterruptedException {
		if (nextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of nextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of nextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return nextPage.isDisplayed();
	}

	public boolean enableStatusOfnextPage() throws InterruptedException {
		if (nextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of nextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of nextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return nextPage.isEnabled();
	}

	public void clickOnnextPage() throws InterruptedException {
		Thread.sleep(3000);
		new Actions(driver).moveToElement(nextPage).click().build().perform();
		Thread.sleep(3000);
		new Actions(driver).moveToElement(nextPage).click().build().perform();
		Thread.sleep(3000);
		new Actions(driver).moveToElement(nextPage).click().build().perform();
		Thread.sleep(3000);
	}

	public boolean displayStatusOfminimize() throws InterruptedException {
		if (minimize.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(minimize);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of minimize is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(minimize);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of minimize is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return minimize.isDisplayed();
	}

	public boolean enableStatusOfminimize() throws InterruptedException {
		if (minimize.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(minimize);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of minimize is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(minimize);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of minimize is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return minimize.isEnabled();
	}

	public void clickOnminimize() throws InterruptedException {
		minimize.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfremoveUserNo() throws InterruptedException {
		if (removeUserNo.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserNo is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserNo is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserNo.isDisplayed();
	}

	public boolean enableStatusOfremoveUserNo() throws InterruptedException {
		if (removeUserNo.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserNo is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserNo is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserNo.isEnabled();
	}

	public void clickOnremoveUserNo() throws InterruptedException {
		removeUserNo.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfremoveUserYes() throws InterruptedException {
		if (removeUserYes.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserYes is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserYes is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserYes.isDisplayed();
	}

	public boolean enableStatusOfremoveUserYes() throws InterruptedException {
		if (removeUserYes.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserYes is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserYes is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserYes.isEnabled();
	}

	public void clickOnremoveUserYes() throws InterruptedException {
		removeUserYes.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfgroupMapping() throws InterruptedException {
		if (groupMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of groupMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupMapping.isDisplayed();
	}

	public boolean enableStatusOfgroupMapping() throws InterruptedException {
		if (groupMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(groupMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(groupMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of groupMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return groupMapping.isEnabled();
	}

	public void clickOngroupMapping() {
		groupMapping.click();
	}

	public boolean displayStatusOfselectGroup() throws InterruptedException {
		if (selectGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectGroup.isDisplayed();
	}

	public boolean enableStatusOfselectGroup() throws InterruptedException {
		if (selectGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectGroup.isEnabled();
	}

	public void clickOnselectGroup() throws InterruptedException {
		selectGroup.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfviewSelectGroup() throws InterruptedException {
		if (viewSelectGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewSelectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewSelectGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewSelectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewSelectGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewSelectGroup.isDisplayed();
	}

	public boolean enableStatusOfviewSelectGroup() throws InterruptedException {
		if (viewSelectGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewSelectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewSelectGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewSelectGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of viewSelectGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewSelectGroup.isEnabled();
	}

	public void clickOnviewSelectGroup() throws InterruptedException {
		viewSelectGroup.click();
	}

	public boolean displayStatusOfaddUsersGroupMap() throws InterruptedException {
		if (addUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addUsers.isDisplayed();
	}

	public boolean enableStatusOfaddUsersGroupMap() throws InterruptedException {
		if (addUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of addUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return addUsers.isEnabled();
	}

	public void clickOnaddUsersGroupMap() throws InterruptedException {
		addUsers.click();
	}

	public boolean displayStatusOfselectUsersGroupMap() throws InterruptedException {
		if (selectUsers.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectUsers.isDisplayed();
	}

	public boolean enableStatusOfselectUsersGroupMap() throws InterruptedException {
		if (selectUsers.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectUsers is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectUsers);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectUsers is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectUsers.isEnabled();
	}

	public void clickAndselectUsersGroupMap() throws InterruptedException {
		selectUsers.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfsaveUserGroupMap() throws InterruptedException {
		if (saveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveUser.isDisplayed();
	}

	public boolean enableStatusOfsaveUserGroupMap() throws InterruptedException {
		if (saveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveUser.isEnabled();
	}

	public void clickOnsaveUserGroupMap() throws InterruptedException {
		saveUser.click();
	}

	public boolean displayStatusOfnextPageGroupMap() throws InterruptedException {
		if (nextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of nextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of nextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return nextPage.isDisplayed();
	}

	public boolean enableStatusOfnextPageGroupMap() throws InterruptedException {
		if (nextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of nextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(nextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of nextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return nextPage.isEnabled();
	}

	public void clickOnnextPageGroupMap() throws InterruptedException {
		Thread.sleep(5000);
		new Actions(driver).moveToElement(nextPage).click().build().perform();
		Thread.sleep(3000);
	}

	public boolean displayStatusOfminimize1GroupMap() throws InterruptedException {
		if (minimize1.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(minimize1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of minimize1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(minimize1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of minimize1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return minimize1.isDisplayed();
	}

	public boolean enableStatusOfminimize1GroupMap() throws InterruptedException {
		if (minimize1.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(minimize1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of minimize1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(minimize1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of minimize1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return minimize1.isEnabled();
	}

	public void clickOnminimize1GroupMap() throws InterruptedException {
		minimize1.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfremoveUserNoGroupMap() throws InterruptedException {
		if (removeUserNo.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserNo is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserNo is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserNo.isDisplayed();
	}

	public boolean enableStatusOfremoveUserNoGroupMap() throws InterruptedException {
		if (removeUserNo.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserNo is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserNo);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserNo is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserNo.isEnabled();
	}

	public void clickOnremoveUserNoGroupMap() throws InterruptedException {
		removeUserNo.click();
		Thread.sleep(501);
	}

	public boolean displayStatusOfremoveUserYesGroupMap() throws InterruptedException {
		if (removeUserYes.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserYes is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of removeUserYes is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserYes.isDisplayed();
	}

	public boolean enableStatusOfremoveUserYesGroupMap() throws InterruptedException {
		if (removeUserYes.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserYes is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(removeUserYes);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of removeUserYes is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return removeUserYes.isEnabled();
	}

	public void clickOnremoveUserYesGroupMap() throws InterruptedException {
		removeUserYes.click();
		Thread.sleep(501);
	}



}
