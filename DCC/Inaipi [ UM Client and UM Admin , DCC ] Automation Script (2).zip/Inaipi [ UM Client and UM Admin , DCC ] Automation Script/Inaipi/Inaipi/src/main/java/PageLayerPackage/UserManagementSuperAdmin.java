package PageLayerPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class UserManagementSuperAdmin extends BaseClass {

//	public static Logger logger 
//	Loggerlogger = Logger.getLogger(UserManagementSuperAdmin.class);
//	Logger log = Lo
	
	// login page

	@FindBy(xpath = "//input[@id='email']")
	WebElement username;

	@FindBy(xpath = "//input[@id='password']")
	WebElement password;

	@FindBy(xpath = "//div[@class='MuiInputAdornment-root MuiInputAdornment-positionEnd MuiInputAdornment-marginDense']")
	WebElement eye;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement login;
	
	@FindBy(xpath = "//span[text()='Clients']")
	WebElement clients;
	
	@FindBy(xpath = "//span[text()='Create Client']")
	WebElement createClient;
	
	@FindBy(xpath = "//input[@id='clientName']")
	WebElement clientName;
	
	@FindBy(xpath = "//button[@id='logo']/span[1]")
	WebElement companyLogo;
	
	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[3]/div/div[2]/input")
	WebElement companyLogo1;
	
	@FindBy(xpath = "//input[@id='maxUsers']")
	WebElement maxUser;
	
	@FindBy(xpath = "//input[@id='primaryColor']")
	WebElement primaryColor;
	
	@FindBy(xpath = "//input[@id='headerColor']")
	WebElement headerColor;
	
	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiIconButton-root float-r']/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement close;
	
	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement cancel;
	
	@FindBy(xpath = "//span[text()='CREATE CLIENT']")
	WebElement create_Client;
	
	@FindBy(xpath = "//li[@id='1']")
	WebElement master;
	
	@FindBy(xpath = "//li[text()='Channels']")
	WebElement channel;
	
	@FindBy(xpath = "//span[text()='Create Channel']")
	WebElement createChannel;
	
	@FindBy(xpath = "//input[@id='channelName']")
	WebElement channelName;
	
	@FindBy(xpath = "//textarea[@id='channelDesc']")
	WebElement channelDiscription;
	
	@FindBy(xpath = "//span[text()='SUBMIT']")
	WebElement submit;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]//tbody/tr[1]/td[5]/center//*[starts-with(@class,'MuiSvgIcon-root m-r-20 text-a')]")
	WebElement editChannel;
	
	@FindBy(xpath = "//span[text()='UPDATE CHANNEL']")
	WebElement updateChannel;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div/table/tbody/tr[1]/td[1]/center/button/span//*[@class='MuiSvgIcon-root']")
	WebElement downArrow;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div/table/tbody/tr[1]/td[5]//*[@title='Create SubChannel']")
	WebElement addSubChannel;
	
	@FindBy(xpath = "//tr[@class='MuiTableRow-root subTable']/td[2]/div/div/div/div/table/tbody/tr[1]/td[4]/center//*[@title='Edit Channel']")
	WebElement editSubChannel;
	
	@FindBy(xpath = "//li[text()='Routers']")
	WebElement router;
	
	@FindBy(xpath = "//span[text()='Create Router']")
	WebElement createRouter;
	
	@FindBy(xpath = "//input[@id='name']")
	WebElement routerName;
	
	@FindBy(xpath = "//textarea[@id='desc']")
	WebElement routerDiscription;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div//tbody/tr[1]/td[5]/center//*[@title='Edit Router']")
	WebElement editRouter;
	
	@FindBy(xpath = "//span[text()='UPDATE ROUTER']")
	WebElement updateRouter;
	
	@FindBy(xpath = "//span[text()='Client Admin']")
	WebElement clientAdmin;
	
	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select m')]")
	WebElement selectClient;
	
	@FindBy(xpath = "//span[text()='View']")
	WebElement view;
	
	@FindBy(xpath = "//span[text()='Add Admin']")
	WebElement addAdmin;
	
	@FindBy(xpath = "//input[@id='firstName']")
	WebElement firstName;
	
	@FindBy(xpath = "//input[@id='lastName']")
	WebElement lastName;
	
	@FindBy(xpath = "//input[@id='email']")
	WebElement email;
	
	@FindBy(xpath = "//input[@id='contactNumber']")
	WebElement contactNumber;
	
	@FindBy(xpath = "//input[@id='password']")
	WebElement adminPassword;
	
	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[5]/div/div[2]/div/div/div//*[@class='MuiSvgIcon-root']")
	WebElement adminPasswordShow;
	
	@FindBy(xpath = "//input[@id='confirmPassword']")
	WebElement adminConfirmPassword;
	
	@FindBy(xpath = "//div[@class='MuiDialogContent-root']/div/div/div[6]/div/div[2]/div/div/div//*[@class='MuiSvgIcon-root']")
	WebElement adminConfirmPasswordShow;
	
	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement adminCancel;
	
	@FindBy(xpath = "//span[text()='ADD ADMIN']")
	WebElement adminAddAdmin;
	
	@FindBy(xpath = "//span[text()='EDIT ADMIN']")
	WebElement updateAddAdmin;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]//tbody/tr[1]/td[4]//*[@title='Edit Client']")
	WebElement editAdmin;
	
	@FindBy(xpath = "//div[@class='dataTables_wrapper']/div[1]//tbody/tr[1]/td[4]//label/span[1]")
	WebElement adminStatus;
	
	@FindBy(xpath = "//li[@id='4']")
	WebElement clientMapping;
	
	@FindBy(xpath = "//li[text()='Channel Mapping']")
	WebElement clientChannelMapping;
	
	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select m')]")
	WebElement selectClientCM;
	
	@FindBy(xpath = "//span[text()='View']")
	WebElement viewClient;
	
	@FindBy(xpath = "(//span[@class='MuiIconButton-label'])[4]//*[@class='MuiSvgIcon-root']")
	WebElement chatCheckBox;
	
	@FindBy(xpath = "//tbody[@class='MuiTableBody-root']/tr[2]/td[1]/center/span/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement twitterCheckBox;
	
	@FindBy(xpath = "//span[text()='SAVE CHANNEL']")
	WebElement saveChaneel;
	
	@FindBy(xpath = "//li[text()='Routing Mapping']")
	WebElement routingMapping;
	
	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select m')]")
	WebElement selectClientRM;
	
	@FindBy(xpath = "//span[text()='View']")
	WebElement viewRouter;
	
	@FindBy(xpath = "//span[text()='Add Router']")
	WebElement addRouter;
	
	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select h')]")
	WebElement selectRouter;
	
	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-item']//*[@title='Click here to save the changes']")
	WebElement saveRouter;
	
	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-item']//*[@title='Click here to delete the changes']")
	WebElement cancelRouter;
	

	public UserManagementSuperAdmin() {
		PageFactory.initElements(driver, this);
	}
	
	public boolean displayStatusOfusername() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(username, "username");
		return username.isDisplayed();
	}

	public boolean enableStatusOfusername() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(username, "username");
		return username.isEnabled();
	}

	public void enterDataInusername(String Username) {
		username.sendKeys(Username);
	}

	public boolean displayStatusOfpassword() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(password, "password");
		return password.isDisplayed();
	}

	public boolean enableStatusOfpassword() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(password, "password");
		return password.isEnabled();
	}

	public void enterDataInpassword(String Password) {
		password.sendKeys(Password);
	}
	public boolean displayStatusOfeye() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(eye, "eye");
		return eye.isDisplayed();
	}
	
	public boolean enableStatusOfeye() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(eye, "eye");
		return eye.isEnabled();
	}
	
	public void clickOneye() {
		eye.click();
	}
	public boolean displayStatusOflogin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(login, "login");
		return login.isDisplayed();
	}
	
	public boolean enableStatusOflogin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(login, "login");
		return login.isEnabled();
	}
	
	public void clickOnlogin() {
		login.click();
	}
	public boolean displayStatusOfclients() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clients, "clients");
		return clients.isDisplayed();
	}
	
	public boolean enableStatusOfclients() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clients, "clients");
		return clients.isEnabled();
	}
	
	public void clickOnclients() {
		clients.click();
	}
	public boolean displayStatusOfcreateClient() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(createClient, "createClient");
		return createClient.isDisplayed();
	}
	
	public boolean enableStatusOfcreateClient() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(createClient, "createClient");
		return createClient.isEnabled();
	}
	
	public void clickOncreateClient() {
		createClient.click();
	}
	public boolean displayStatusOfclientName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clientName, "clientName");
		return clientName.isDisplayed();
	}
	
	public boolean enableStatusOfclientName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clientName, "clientName");
		return clientName.isEnabled();
	}
	
	public void enterDataInclientName(String ClientName) {
		clientName.sendKeys(ClientName);
	}
	public boolean displayStatusOfcompanyLogo() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(companyLogo, "companyLogo");
		return companyLogo.isDisplayed();
	}
	
	public boolean enableStatusOfcompanyLogo() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(companyLogo, "companyLogo");
		return companyLogo.isEnabled();
	}
	
	public void attachedFileTocompanyLogo(String CompanyLogo) throws InterruptedException {
			companyLogo1.sendKeys(CompanyLogo);
	}
	public boolean displayStatusOfmaxUser() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(maxUser, "maxUser");
		return maxUser.isDisplayed();
	}
	
	public boolean enableStatusOfmaxUser() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(maxUser, "maxUser");
		return maxUser.isEnabled();
	}
	
	public void enterDataInmaxUser(String MaxUser) throws InterruptedException {
		maxUser.sendKeys(MaxUser);
	}
	public boolean displayStatusOfprimaryColor() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(primaryColor, "primaryColor");
		return primaryColor.isDisplayed();
	}
	
	public boolean enableStatusOfprimaryColor() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(primaryColor, "primaryColor");
		return primaryColor.isEnabled();
	}
	
	public void clickOnprimaryColor() throws InterruptedException {
//		primaryColor.click();
//		Thread.sleep(1000);1
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		jse.executeScript("document.getElementById('primaryColor').value='#1E4694';");
	}
	public boolean displayStatusOfheaderColor() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(headerColor, "headerColor");
		return headerColor.isDisplayed();
	}
	
	public boolean enableStatusOfheaderColor() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(headerColor, "headerColor");
		return headerColor.isEnabled();
	}
	
	public void clickOnheaderColor() throws InterruptedException {
//		headerColor.click();
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		jse.executeScript("document.getElementById('headerColor').value='#16DA5A';");

	}
	public boolean displayStatusOfclose() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfclose() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnclose() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfcancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfcancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOncancel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfcreate_Client() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(create_Client, "create_Client");
		return create_Client.isDisplayed();
	}
	
	public boolean enableStatusOfcreate_Client() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(create_Client, "create_Client");
		return create_Client.isEnabled();
	}
	
	public void clickOncreate_Client() throws InterruptedException {
		create_Client.click();
	}
	public boolean displayStatusOfmaster() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(master, "master");
		return master.isDisplayed();
	}
	
	public boolean enableStatusOfmaster() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(master, "master");
		return master.isEnabled();
	}
	
	public void clickOnmaster() throws InterruptedException {
		master.click();
	}
	public boolean displayStatusOfchannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channel, "channel");
		return channel.isDisplayed();
	}
	
	public boolean enableStatusOfchannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channel, "channel");
		return channel.isEnabled();
	}
	
	public void clickOnchannel() throws InterruptedException {
		channel.click();
	}
	public boolean displayStatusOfcreateChannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(createChannel, "createChannel");
		return createChannel.isDisplayed();
	}
	
	public boolean enableStatusOfcreateChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(createChannel, "createChannel");
		return createChannel.isEnabled();
	}
	
	public void clickOncreateChannel() throws InterruptedException {
		createChannel.click();
	}
	public boolean displayStatusOfchannelName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelName, "channelName");
		return channelName.isDisplayed();
	}
	
	public boolean enableStatusOfchannelName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelName, "channelName");
		return channelName.isEnabled();
	}
	
	public void enterDataInchannelName(String ChannelName) throws InterruptedException {
		channelName.sendKeys(ChannelName);
	}
	public boolean displayStatusOfchannelDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfchannelDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isEnabled();
	}
	
	public void enterDataInchannelDiscription(String ChannelDiscription) throws InterruptedException {
		channelDiscription.sendKeys(ChannelDiscription);
	}
	public boolean displayStatusOfcloseCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfcloseCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOncloseCreateChnnel() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfcancelCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfcancelCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOncancelCreateChnnel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfsubmitCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(submit, "submit");
		return submit.isDisplayed();
	}
	
	public boolean enableStatusOfsubmitCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(submit, "submit");
		return submit.isEnabled();
	}
	
	public void clickOnsubmitCreateChnnel() throws InterruptedException {
		submit.click();
	}
	public boolean displayStatusOfeditChannelCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(editChannel, "editChannel");
		return editChannel.isDisplayed();
	}
	
	public boolean enableStatusOfeditChannelCreateChnnel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(editChannel, "editChannel");
		return editChannel.isEnabled();
	}
	
	public void clickOneditChannelCreateChnnel() throws InterruptedException {
		editChannel.click();
	}
	public boolean displayStatusOfeditMain_channelName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelName, "channelName");
		return channelName.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_channelName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelName, "channelName");
		return channelName.isEnabled();
	}
	
	public void enterDataIneditMain_channelName(String ChannelName) throws InterruptedException {
		channelName.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		channelName.sendKeys(ChannelName);
	}
	public boolean displayStatusOfeditMain_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isEnabled();
	}
	
	public void enterDataIneditMain_channelDiscription(String ChannelDiscription) throws InterruptedException {
		channelDiscription.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		channelDiscription.sendKeys(ChannelDiscription);
	}
	public boolean displayStatusOfeditMain_close() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_close() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOneditMain_close() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfeditMain_cancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_cancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOneditMain_cancel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfeditMain_updateChannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(updateChannel, "updateChannel");
		return updateChannel.isDisplayed();
	}
	
	public boolean enableStatusOfeditMain_updateChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(updateChannel, "updateChannel");
		return updateChannel.isEnabled();
	}
	
	public void clickOneditMain_updateChannel() throws InterruptedException {
		updateChannel.click();
	}
	public boolean displayStatusOfedit_downArrow() throws InterruptedException {
		if (downArrow.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(downArrow);
			Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("alert('Display Status Of downArrow is True')");
			Thread.sleep(1000);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(500);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(downArrow);
			Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of downArrow is False')");
			Thread.sleep(1000);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(500);
		}
		return downArrow.isDisplayed();
	}
	
	public boolean enableStatusOfedit_downArrow() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(downArrow, "downArrow");
		return downArrow.isEnabled();
	}
	
	public void clickOnedit_downArrow() throws InterruptedException {
		downArrow.click();
	}
	public boolean displayStatusOfedit_addSubChannel() throws InterruptedException {
		if (addSubChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(addSubChannel);
			Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("alert('Display Status Of addSubChannel is True')");
			Thread.sleep(1000);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(500);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(addSubChannel);
			Thread.sleep(500);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of addSubChannel is False')");
			Thread.sleep(1000);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(500);
		}
		return addSubChannel.isDisplayed();
	}
	
	public boolean enableStatusOfedit_addSubChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(addSubChannel, "addSubChannel");
		return addSubChannel.isEnabled();
	}
	
	public void clickOnedit_addSubChannel() throws InterruptedException {
		try {
			addSubChannel.click();
		} catch (Exception e) {
			new Actions(driver).click(addSubChannel).build().perform();
		}
	}
	public boolean displayStatusOfaddsub_channelName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelName, "channelName");
		return channelName.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_channelName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelName, "channelName");
		return channelName.isEnabled();
	}
	
	public void enterDataInaddsub_channelName(String ChannelName) throws InterruptedException {
		channelName.sendKeys(ChannelName);
	}
	public boolean displayStatusOfaddsub_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isEnabled();
	}
	
	public void enterDataInaddsub_channelDiscription(String ChannelDiscription) throws InterruptedException {
		channelDiscription.sendKeys(ChannelDiscription);
	}
	public boolean displayStatusOfaddsub_close() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_close() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnaddsub_close() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfaddsub_cancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_cancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOnaddsub_cancel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfaddsub_submit() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(submit, "submit");
		return submit.isDisplayed();
	}
	
	public boolean enableStatusOfaddsub_submit() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(submit, "submit");
		return submit.isEnabled();
	}
	
	public void clickOnaddsub_submit() throws InterruptedException {
		submit.click();
	}
	public boolean displayStatusOfeditsub_editSubChannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(editSubChannel, "editSubChannel");
		return editSubChannel.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_editSubChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(editSubChannel, "editSubChannel");
		return editSubChannel.isEnabled();
	}
	
	public void clickOneditsub_editSubChannel() throws InterruptedException {
		editSubChannel.click();
	}
	public boolean displayStatusOfeditsub_channelName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelName, "channelName");
		return channelName.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_channelName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelName, "channelName");
		return channelName.isEnabled();
	}
	
	public void enterDataIneditsub_channelName(String ChannelName) throws InterruptedException {
		channelName.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		channelName.sendKeys(ChannelName);
	}
	public boolean displayStatusOfeditsub_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_channelDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(channelDiscription, "channelDiscription");
		return channelDiscription.isEnabled();
	}
	
	public void enterDataIneditsub_channelDiscription(String ChannelDiscription) throws InterruptedException {
		channelDiscription.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		channelDiscription.sendKeys(ChannelDiscription);
	}
	public boolean displayStatusOfeditsub_close() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_close() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOneditsub_close() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfeditsub_cancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_cancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOneditsub_cancel() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfeditsub_updateChannel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(updateChannel, "updateChannel");
		return updateChannel.isDisplayed();
	}
	
	public boolean enableStatusOfeditsub_updateChannel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(updateChannel, "updateChannel");
		return updateChannel.isEnabled();
	}
	
	public void clickOneditsub_updateChannel() throws InterruptedException {
		updateChannel.click();
	}
	public boolean displayStatusOfrouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(router, "router");
		return router.isDisplayed();
	}
	
	public boolean enableStatusOfrouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(router, "router");
		return router.isEnabled();
	}
	
	public void clickOnrouter() throws InterruptedException {
		router.click();
	}
	public boolean displayStatusOfcreateRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(createRouter, "createRouter");
		return createRouter.isDisplayed();
	}
	
	public boolean enableStatusOfcreateRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(createRouter, "createRouter");
		return createRouter.isEnabled();
	}
	
	public void clickOncreateRouter() throws InterruptedException {
		createRouter.click();
	}
	public boolean displayStatusOfrouterName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routerName, "routerName");
		return routerName.isDisplayed();
	}
	
	public boolean enableStatusOfrouterName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routerName, "routerName");
		return routerName.isEnabled();
	}
	
	public void enterDataInrouterName(String RouterName) throws InterruptedException {
		routerName.sendKeys(RouterName);
	}
	public boolean displayStatusOfrouterDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routerDiscription, "routerDiscription");
		return routerDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfrouterDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routerDiscription, "routerDiscription");
		return routerDiscription.isEnabled();
	}
	
	public void enterDataInrouterDiscription(String RouterDiscription) throws InterruptedException {
		routerDiscription.sendKeys(RouterDiscription);
	}
	public boolean displayStatusOfclose1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfclose1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnclose1() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfcancel1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfcancel1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOncancel1() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfsubmit1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(submit, "submit");
		return submit.isDisplayed();
	}
	
	public boolean enableStatusOfsubmit1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(submit, "submit");
		return submit.isEnabled();
	}
	
	public void clickOnsubmit1() throws InterruptedException {
		submit.click();
	}
	public boolean displayStatusOfeditRouter1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(editRouter, "editRouter");
		return editRouter.isDisplayed();
	}
	
	public boolean enableStatusOfeditRouter1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(editRouter, "editRouter");
		return editRouter.isEnabled();
	}
	
	public void clickOneditRouter1() throws InterruptedException {
		editRouter.click();
	}
	public boolean displayStatusOfupdate_routerName() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routerName, "routerName");
		return routerName.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_routerName() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routerName, "routerName");
		return routerName.isEnabled();
	}
	
	public void enterDataInupdate_routerName(String RouterName) throws InterruptedException {
		routerName.sendKeys(RouterName);
	}
	public boolean displayStatusOfupdate_routerDiscription() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routerDiscription, "routerDiscription");
		return routerDiscription.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_routerDiscription() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routerDiscription, "routerDiscription");
		return routerDiscription.isEnabled();
	}
	
	public void enterDataInupdate_routerDiscription(String RouterDiscription) throws InterruptedException {
		routerDiscription.sendKeys(RouterDiscription);
	}
	public boolean displayStatusOfupdate_close1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_close1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnupdate_close1() throws InterruptedException {
		close.click();
	}
	public boolean displayStatusOfupdate_cancel1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancel, "cancel");
		return cancel.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_cancel1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancel, "cancel");
		return cancel.isEnabled();
	}
	
	public void clickOnupdate_cancel1() throws InterruptedException {
		cancel.click();
	}
	public boolean displayStatusOfupdate_updateRouter1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(updateRouter, "updateRouter");
		return updateRouter.isDisplayed();
	}
	
	public boolean enableStatusOfupdate_updateRouter1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(updateRouter, "updateRouter");
		return updateRouter.isEnabled();
	}
	
	public void clickOnupdate_updateRouter1() throws InterruptedException {
		updateRouter.click();
		Thread.sleep(2000);
		master.click();
	}
	public boolean displayStatusOfclientAdmin1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clientAdmin, "clientAdmin");
		return clientAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfclientAdmin1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clientAdmin, "clientAdmin");
		return clientAdmin.isEnabled();
	}
	
	public void clickOnclientAdmin1() throws InterruptedException {
		clientAdmin.click();
	}
	public boolean displayStatusOfselectClient1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectClient, "selectClient");
		return selectClient.isDisplayed();
	}
	
	public boolean enableStatusOfselectClient1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectClient, "selectClient");
		return selectClient.isEnabled();
	}
	
	public void clickOnselectClient1andSelectAdminFromDP(String ClientName) throws InterruptedException {
		selectClient.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='"+ClientName+"']")).click();
	}
	public boolean displayStatusOfview1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(view, "view");
		return view.isDisplayed();
	}
	
	public boolean enableStatusOfview1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(view, "view");
		return view.isEnabled();
	}
	
	public void clickOnview1() throws InterruptedException {
		view.click();
	}
	public boolean displayStatusOfaddAdmin1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(addAdmin, "addAdmin");
		return addAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfaddAdmin1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(addAdmin, "addAdmin");
		return addAdmin.isEnabled();
	}
	
	public void clickOnaddAdmin1() throws InterruptedException {
		addAdmin.click();
	}
	public boolean displayStatusOffirstName1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(firstName, "firstName");
		return firstName.isDisplayed();
	}
	
	public boolean enableStatusOffirstName1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(firstName, "firstName");
		return firstName.isEnabled();
	}
	
	public void enterDataInfirstName1(String FirstName) throws InterruptedException {
		firstName.sendKeys(FirstName);
	}
	public boolean displayStatusOflastName1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(lastName, "lastName");
		return lastName.isDisplayed();
	}
	
	public boolean enableStatusOflastName1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(lastName, "lastName");
		return lastName.isEnabled();
	}
	
	public void enterDataInlastName1(String LastName) throws InterruptedException {
		lastName.sendKeys(LastName);
	}
	public boolean displayStatusOfemail1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(email, "email");
		return email.isDisplayed();
	}
	
	public boolean enableStatusOfemail1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(email, "email");
		return email.isEnabled();
	}
	
	public void enterDataInemail1(String Email) throws InterruptedException {
		email.sendKeys(Email);
	}
	public boolean displayStatusOfcontactNumber1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(contactNumber, "contactNumber");
		return contactNumber.isDisplayed();
	}
	
	public boolean enableStatusOfcontactNumber1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(contactNumber, "contactNumber");
		return contactNumber.isEnabled();
	}
	
	public void enterDataIncontactNumber1(String ContactNumber) throws InterruptedException {
		contactNumber.sendKeys(ContactNumber);
	}
	public boolean displayStatusOfadminPassword1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminPassword, "adminPassword");
		return adminPassword.isDisplayed();
	}
	
	public boolean enableStatusOfadminPassword1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminPassword, "adminPassword");
		return adminPassword.isEnabled();
	}
	
	public void enterDataInadminPassword1(String AdminPassword) throws InterruptedException {
		adminPassword.sendKeys(AdminPassword);
	}
	public boolean displayStatusOfadminPasswordShow1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminPasswordShow, "adminPasswordShow");
		return adminPasswordShow.isDisplayed();
	}
	
	public boolean enableStatusOfadminPasswordShow1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminPasswordShow, "adminPasswordShow");
		return adminPasswordShow.isEnabled();
	}
	
	public void clickOnadminPasswordShow1() throws InterruptedException {
		try {
			adminPasswordShow.click();
		} catch (Exception e) {
			new Actions(driver).click(adminPasswordShow).build().perform();
		}
	}
	public boolean displayStatusOfadminConfirmPassword1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminConfirmPassword, "adminConfirmPassword");
		return adminConfirmPassword.isDisplayed();
	}
	
	public boolean enableStatusOfadminConfirmPassword1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminConfirmPassword, "adminConfirmPassword");
		return adminConfirmPassword.isEnabled();
	}
	
	public void enterDataInadminConfirmPassword1(String AdminConfirmPassword) throws InterruptedException {
		adminConfirmPassword.sendKeys(AdminConfirmPassword);
	}
	public boolean displayStatusOfadminConfirmPasswordShow1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminConfirmPasswordShow, "adminConfirmPasswordShow");
		return adminConfirmPasswordShow.isDisplayed();
	}
	
	public boolean enableStatusOfadminConfirmPasswordShow1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminConfirmPasswordShow, "adminConfirmPasswordShow");
		return adminConfirmPasswordShow.isEnabled();
	}
	
	public void clickOnadminConfirmPasswordShow1() throws InterruptedException {
		try {
			adminConfirmPasswordShow.click();
		} catch (Exception e) {
			new Actions(driver).click(adminConfirmPasswordShow).build().perform();

		}
	}
	public boolean displayStatusOfclose2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfclose2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnclose2() throws InterruptedException {
		try {
			close.click();
		} catch (Exception e) {
			new Actions(driver).click(close).build().perform();

		}
	}
	public boolean displayStatusOfadminCancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminCancel, "adminCancel");
		return adminCancel.isDisplayed();
	}
	
	public boolean enableStatusOfadminCancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminCancel, "adminCancel");
		return adminCancel.isEnabled();
	}
	
	public void clickOnadminCancel() throws InterruptedException {
		try {
			adminCancel.click();
		} catch (Exception e) {
			new Actions(driver).click(adminCancel).build().perform();

		}
	}
	public boolean displayStatusOfadminAddAdmin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminAddAdmin, "adminAddAdmin");
		return adminAddAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfadminAddAdmin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminAddAdmin, "adminAddAdmin");
		return adminAddAdmin.isEnabled();
	}
	
	public void clickOnadminAddAdmin() throws InterruptedException {
		try {
			adminAddAdmin.click();
		} catch (Exception e) {
			new Actions(driver).click(adminAddAdmin).build().perform();

		}
	}
	public boolean displayStatusOfeditAdmin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(editAdmin, "editAdmin");
		return editAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfeditAdmin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(editAdmin, "editAdmin");
		return editAdmin.isEnabled();
	}
	
	public void clickOneditAdmin() throws InterruptedException {
		try {
			new Actions(driver).click(editAdmin).build().perform();
		} catch (Exception e) {
			editAdmin.click();
		}
	}
	public boolean displayStatusOfedit_firstName1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(firstName, "firstName");
		return firstName.isDisplayed();
	}
	
	public boolean enableStatusOfedit_firstName1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(firstName, "firstName");
		return firstName.isEnabled();
	}
	
	public void enterDataInedit_firstName1() throws InterruptedException {
		firstName.click();
		String FirstName = firstName.getAttribute("value");
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		firstName.sendKeys(FirstName);
	}
	public boolean displayStatusOfedit_lastName1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(lastName, "lastName");
		return lastName.isDisplayed();
	}
	
	public boolean enableStatusOfedit_lastName1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(lastName, "lastName");
		return lastName.isEnabled();
	}
	
	public void enterDataInedit_lastName1() throws InterruptedException {
		lastName.click();
		String LastName = lastName.getAttribute("value");
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		lastName.sendKeys(LastName);
	}
	public boolean displayStatusOfedit_email1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(email, "email");
		return email.isDisplayed();
	}
	
	public boolean enableStatusOfedit_email1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(email, "email");
		return email.isEnabled();
	}
	
	public void enterDataInedit_email1() throws InterruptedException {
		email.click();
		String Email = email.getAttribute("value");
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		email.sendKeys(Email);
	}
	public boolean displayStatusOfedit_contactNumber1() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(contactNumber, "contactNumber");
		return contactNumber.isDisplayed();
	}
	
	public boolean enableStatusOfedit_contactNumber1() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(contactNumber, "contactNumber");
		return contactNumber.isEnabled();
	}
	
	public void enterDataInedit_contactNumber1(String ContactNumber) throws InterruptedException {
		contactNumber.click();
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		Thread.sleep(2000);
		contactNumber.sendKeys(ContactNumber);
	}
	public boolean displayStatusOfedit_close2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "close");
		return close.isDisplayed();
	}
	
	public boolean enableStatusOfedit_close2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "close");
		return close.isEnabled();
	}
	
	public void clickOnedit_close2() throws InterruptedException {
		try {
			close.click();
		} catch (Exception e) {
			new Actions(driver).click(close).build().perform();

		}
	}
	public boolean displayStatusOfedit_adminCancel() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminCancel, "adminCancel");
		return adminCancel.isDisplayed();
	}
	
	public boolean enableStatusOfedit_adminCancel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminCancel, "adminCancel");
		return adminCancel.isEnabled();
	}
	
	public void clickOnedit_adminCancel() throws InterruptedException {
		try {
			adminCancel.click();
		} catch (Exception e) {
			new Actions(driver).click(adminCancel).build().perform();

		}
	}
	public boolean displayStatusOfedit_updateAddAdmin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(updateAddAdmin, "updateAddAdmin");
		return updateAddAdmin.isDisplayed();
	}
	
	public boolean enableStatusOfedit_updateAddAdmin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(updateAddAdmin, "updateAddAdmin");
		return updateAddAdmin.isEnabled();
	}
	
	public void clickOnedit_updateAddAdmin() throws InterruptedException {
		try {
			updateAddAdmin.click();
		} catch (Exception e) {
			new Actions(driver).click(updateAddAdmin).build().perform();

		}
	}
	public boolean displayStatusOfadminAddAdminStatus() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(adminStatus, "adminStatus");
		return adminStatus.isDisplayed();
	}
	
	public boolean enableStatusOfadminAddAdminStatus() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(adminStatus, "adminStatus");
		return adminStatus.isEnabled();
	}
	
	public void clickOnadminAddAdminStatus() throws InterruptedException {
		try {
			adminStatus.click();
		} catch (Exception e) {
			new Actions(driver).click(adminStatus).build().perform();

		}
		Thread.sleep(3000);
		try {
			adminStatus.click();
		} catch (Exception e) {
			new Actions(driver).click(adminStatus).build().perform();

		}
	}
	
	public boolean displayStatusOfclientMapping() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clientMapping, "clientMapping");
		return clientMapping.isDisplayed();
	}
	
	public boolean enableStatusOfclientMapping() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clientMapping, "clientMapping");
		return clientMapping.isEnabled();
	}
	
	public void clickOnclientMapping() throws InterruptedException {
		try {
			clientMapping.click();
		} catch (Exception e) {
			new Actions(driver).click(clientMapping).build().perform();

		}
	}
	public boolean displayStatusOfclientChannelMapping() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(clientChannelMapping, "clientChannelMapping");
		return clientChannelMapping.isDisplayed();
	}
	
	public boolean enableStatusOfclientChannelMapping() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(clientChannelMapping, "clientChannelMapping");
		return clientChannelMapping.isEnabled();
	}
	
	public void clickOnclientChannelMapping() throws InterruptedException {
		try {
			clientChannelMapping.click();
		} catch (Exception e) {
			new Actions(driver).click(clientChannelMapping).build().perform();

		}
	}
	public boolean displayStatusOfselectClientCM() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectClientCM, "selectClientCM");
		return selectClientCM.isDisplayed();
	}
	
	public boolean enableStatusOfselectClientCM() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectClientCM, "selectClientCM");
		return selectClientCM.isEnabled();
	}
	
	public void clickOnselectClientCMandSelectDPValue(String SelectClientCM) throws InterruptedException {
		selectClientCM.click();
		driver.findElement(By.xpath("//span[text()='"+SelectClientCM+"']")).click();
	}
	public boolean displayStatusOfviewClient() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(viewClient, "viewClient");
		return viewClient.isDisplayed();
	}
	
	public boolean enableStatusOfviewClient() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(viewClient, "viewClient");
		return viewClient.isEnabled();
	}
	
	public void clickOnviewClient() throws InterruptedException {
		try {
			viewClient.click();
		} catch (Exception e) {
			new Actions(driver).click(viewClient).build().perform();

		}
	}
	public boolean displayStatusOfchatCheckBox() throws InterruptedException {
		if (chatCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chatCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatCheckBox is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chatCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatCheckBox is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chatCheckBox.isDisplayed();
	}
	
	public boolean enableStatusOfchatCheckBox() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(chatCheckBox, "chatCheckBox");
		return chatCheckBox.isEnabled();
	}
	
	public void clickOnchatCheckBox() throws InterruptedException {
		try {
			chatCheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(chatCheckBox).build().perform();

		}
	}
	public boolean displayStatusOftwitterCheckBox() throws InterruptedException {
		if (twitterCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(twitterCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of twitterCheckBox is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(twitterCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of twitterCheckBox is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return twitterCheckBox.isDisplayed();
	}
	
	public boolean enableStatusOftwitterCheckBox() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(twitterCheckBox, "twitterCheckBox");
		return twitterCheckBox.isEnabled();
	}
	
	public void clickOntwitterCheckBox() throws InterruptedException {
		WebElement chechBox = driver.findElement(By.xpath("//tbody[@class='MuiTableBody-root']/tr[2]/td[1]/center/span/span[1]/input"));
		try {
			chechBox.click();
		} catch (Exception e) {
			new Actions(driver).click(chechBox).build().perform();

		}
	}
	public boolean displayStatusOfsaveChaneel() throws InterruptedException {
		if (saveChaneel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveChaneel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveChaneel is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveChaneel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveChaneel is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveChaneel.isDisplayed();
	}
	
	public boolean enableStatusOfsaveChaneel() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(saveChaneel, "saveChaneel");
		return saveChaneel.isEnabled();
	}
	
	public void clickOnsaveChaneel() throws InterruptedException {
		saveChaneel.click();
	}
	public boolean displayStatusOfselectClientCM2() throws InterruptedException {
		if (selectClientCM.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectClientCM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectClientCM is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectClientCM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectClientCM is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectClientCM.isDisplayed();
	}
	
	public boolean enableStatusOfselectClientCM2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectClientCM, "selectClientCM");
		return selectClientCM.isEnabled();
	}
	
	public void clickOnselectClientCMandSelectDPValue2(String SelectClientCM2) throws InterruptedException {
		selectClientCM.click();
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
		Thread.sleep(2000);
		selectClientCM.click();
		driver.findElement(By.xpath("//span[text()='"+SelectClientCM2+"']")).click();
	}
	public boolean displayStatusOfviewClient2() throws InterruptedException {
		if (viewClient.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(viewClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewClient is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(viewClient);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of viewClient is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return viewClient.isDisplayed();
	}
	
	public boolean enableStatusOfviewClient2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(viewClient, "viewClient");
		return viewClient.isEnabled();
	}
	
	public void clickOnviewClient2() throws InterruptedException {
		viewClient.click();
	}
	public boolean displayStatusOfchatCheckBox2() throws InterruptedException {
		if (chatCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chatCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatCheckBox is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chatCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatCheckBox is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chatCheckBox.isDisplayed();
	}
	
	public boolean enableStatusOfchatCheckBox2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(chatCheckBox, "chatCheckBox");
		return chatCheckBox.isEnabled();
	}
	
	public void clickOnchatCheckBox2() throws InterruptedException {
		try {
			chatCheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(chatCheckBox).build().perform();
		}
	}
	public boolean displayStatusOftwitterCheckBox2() throws InterruptedException {
		Thread.sleep(2000);
		if (twitterCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(twitterCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of twitterCheckBox is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(twitterCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of twitterCheckBox is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return twitterCheckBox.isDisplayed();
	}
	
	public boolean enableStatusOftwitterCheckBox2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(twitterCheckBox, "twitterCheckBox");
		return twitterCheckBox.isEnabled();
	}
	
	public void clickOntwitterCheckBox2() throws InterruptedException {
		try {
			twitterCheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(twitterCheckBox).build().perform();

		}
	}
	public boolean displayStatusOfsaveChaneel2() throws InterruptedException {
		if (saveChaneel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveChaneel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveChaneel is True')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveChaneel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveChaneel is False')");
			Thread.sleep(912);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveChaneel.isDisplayed();
	}
	
	public boolean enableStatusOfsaveChaneel2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(saveChaneel, "saveChaneel");
		return saveChaneel.isEnabled();
	}
	
	public void clickOnsaveChaneel2() throws InterruptedException {
		saveChaneel.click();
	}
	public boolean displayStatusOfroutingMapping() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(routingMapping, "routingMapping");
		return routingMapping.isDisplayed();
	}
	
	public boolean enableStatusOfroutingMapping() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(routingMapping, "routingMapping");
		return routingMapping.isEnabled();
	}
	
	public void clickOnroutingMapping() throws InterruptedException {
		routingMapping.click();
	}
	public boolean displayStatusOfselectClientRM() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectClientRM, "selectClientRM");
		return selectClientRM.isDisplayed();
	}
	
	public boolean enableStatusOfselectClientRM() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectClientRM, "selectClientRM");
		return selectClientRM.isEnabled();
	}
	
	public void clickOnselectClientRMandSelectDPValue(String SelectClientRM) throws InterruptedException {
		selectClientRM.click();
		driver.findElement(By.xpath("//span[text()='"+SelectClientRM+"']")).click();
	}
	public boolean displayStatusOfviewRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(viewRouter, "viewRouter");
		return viewRouter.isDisplayed();
	}
	
	public boolean enableStatusOfviewRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(viewRouter, "viewRouter");
		return viewRouter.isEnabled();
	}
	
	public void clickOnviewRouter() throws InterruptedException {
		viewRouter.click();
	}
	public boolean displayStatusOfaddRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(addRouter, "addRouter");
		return addRouter.isDisplayed();
	}
	
	public boolean enableStatusOfaddRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(addRouter, "addRouter");
		return addRouter.isEnabled();
	}
	
	public void clickOnaddRouter() throws InterruptedException {
		addRouter.click();
	}
	public boolean displayStatusOfselectRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectRouter, "selectRouter");
		return selectRouter.isDisplayed();
	}
	
	public boolean enableStatusOfselectRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectRouter, "selectRouter");
		return selectRouter.isEnabled();
	}
	
	public void clickOnselectRouterandSelectDPValue() throws InterruptedException {
		selectRouter.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}
	public boolean displayStatusOfsaveRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(saveRouter, "saveRouter");
		return saveRouter.isDisplayed();
	}
	
	public boolean enableStatusOfsaveRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(saveRouter, "saveRouter");
		return saveRouter.isEnabled();
	}
	
	public void clickOnsaveRouterandSelectDPValue() throws InterruptedException {
		saveRouter.click();
	}
	public boolean displayStatusOfcancelRouter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(cancelRouter, "cancelRouter");
		return cancelRouter.isDisplayed();
	}
	
	public boolean enableStatusOfcancelRouter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(cancelRouter, "cancelRouter");
		return cancelRouter.isEnabled();
	}
	
	public void clickOncancelRouterandSelectDPValue() throws InterruptedException {
		cancelRouter.click();
	}
	
}
