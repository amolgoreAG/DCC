package UM_Client;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class loginPage extends BaseClass{

	@FindBy(xpath = "//input[@id='email']")
	WebElement username;

	@FindBy(xpath = "//input[@id='password']")
	WebElement password;

	@FindBy(xpath = "//div[@class='MuiInputAdornment-root MuiInputAdornment-positionEnd MuiInputAdornment-marginDense']")
	WebElement eye;

	@FindBy(xpath = "//span[@class='MuiButton-label']")
	WebElement login;
	
	public loginPage() {
		PageFactory.initElements(driver, this);
	}
	public boolean displayStatusOfusername() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", username);
		Thread.sleep(1000);
		if (username.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(username);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of username is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(username);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of username is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return username.isDisplayed();
	}

	public boolean enableStatusOfusername() throws InterruptedException {
		if (username.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(username);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of username is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(username);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of username is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return username.isEnabled();
	}

	public void enterDataInusername(String Username) throws InterruptedException {
		username.sendKeys(Username);
	}

	public boolean displayStatusOfpassword() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", password);
		Thread.sleep(1000);
		if (password.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(password);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of password is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(password);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of password is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return password.isDisplayed();
	}

	public boolean enableStatusOfpassword() throws InterruptedException {
		if (password.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(password);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of password is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(password);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of password is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return password.isEnabled();
	}

	public void enterDataInpassword(String Password) {
		password.sendKeys(Password);
	}

	public boolean displayStatusOfeye() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", eye);
		Thread.sleep(1000);
		if (eye.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of eye is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of eye is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return eye.isDisplayed();
	}

	public boolean enableStatusOfeye() throws InterruptedException {
		if (eye.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of eye is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of eye is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return eye.isEnabled();
	}

	public void clickOnEye() {
		eye.click();
	}

	public boolean displayStatusOflogin() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", login);
		Thread.sleep(1000);
		if (login.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(login);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of login is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(login);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of login is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return login.isDisplayed();
	}

	public boolean enableStatusOflogin() throws InterruptedException {
		if (login.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(login);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of login is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(login);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of login is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return login.isEnabled();
	}

	public void clickOnlogin() {
		login.click();
	}


}
