package AgentCreation;

import java.util.Random;
import java.util.Set;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TwoAgentTwoCustomer {

	public static String url ;
	public static int randomInt() {
		Random random = new Random();
		return random.nextInt(2000);
	}

	public static WebDriver  driver ; 
	public static WebDriver  driver1 ; 
	public static WebDriver  driver2 ; 
	public static WebDriver  driver3 ; 
	public static WebDriver  driver4 ; 

	@Test
	public void Astarting() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\loadTest\\Driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("--blink-settings=imagesEnabled=false");
		option.addArguments("--ignore-certificate-errors");
		option.addArguments("--ignore-ssl-errors=yes");
		 driver = new ChromeDriver(option);
//		driver = new HtmlUnitDriver();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//		 driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		driver.get("https://dcc.inaipi.ae/?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
	}

	@Test
	public void Blogin() throws InterruptedException {
		
		for(int i = 0 ; i <= 2  ; i++) {
			WebElement username = driver.findElement(By.xpath("(//input[@id='exampleFormControlInput1'])[1]"));
			
			username.sendKeys("Nandhini@gmail.com");
			Thread.sleep(2001);
			WebElement password = driver.findElement(By.xpath("(//input[@id='exampleFormControlInput1'])[2]"));
			password.sendKeys("Welcome@123");
			Thread.sleep(2001);
			WebElement loginbtn = driver.findElement(By.xpath("//div[text()='Login']"));
			loginbtn.click();
			Thread.sleep(2001);
			String currentUrl = driver.getCurrentUrl();
			System.out.println(currentUrl);
			
			if(currentUrl.equalsIgnoreCase("https://dcc.inaipi.ae/dashboard")) {
				Thread.sleep(2001);
				WebElement status = driver.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--connected ']"));
				status.click();
				Thread.sleep(2001);
				WebElement goready = driver.findElement(By.xpath("//button[@class='btn btn-success work-start']"));
				goready.click();
				Thread.sleep(2001);
				WebElement close = driver.findElement(By.xpath("//span[@class='neo-icon-close user-close']"));
				close.click();
				Thread.sleep(2001);
//				WebElement message = driver.findElement(By.xpath("(//button[@class='tablinks'])[1]//*[@stroke='currentColor']"));
//				message.click();
//				Thread.sleep(2001);
			}else {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				logout.click();
				Thread.sleep(2001);
				WebElement username1 = driver.findElement(By.xpath("(//input[@id='exampleFormControlInput1'])[1]"));
				username1.sendKeys("Nandhini@gmail.com");
				Thread.sleep(2001);
				WebElement password1 = driver.findElement(By.xpath("(//input[@id='exampleFormControlInput1'])[2]"));
				password1.sendKeys("Welcome@123");
				Thread.sleep(2001);
				WebElement loginbtn1 = driver.findElement(By.xpath("//div[text()='Login']"));
				loginbtn1.click();
				Thread.sleep(2001);
				WebElement status = driver.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--connected ']"));
				status.click();
				Thread.sleep(2001);
				WebElement goready = driver.findElement(By.xpath("//button[@class='btn btn-success work-start']"));
				goready.click();
				Thread.sleep(2001);
				WebElement close = driver.findElement(By.xpath("//span[@class='neo-icon-close user-close']"));
				close.click();
				Thread.sleep(2001);
//				WebElement message = driver.findElement(By.xpath("(//button[@class='tablinks'])[1]//*[@stroke='currentColor']"));
//				message.click();
//				Thread.sleep(2001);
				String url = driver.getCurrentUrl();
			}
	}
	}

	@Test
	public void CustomerPortal0() throws InterruptedException {
		Thread.sleep(2002);
		driver.navigate().to("https://dcc.inaipi.ae/CustomerPortal?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
		Thread.sleep(2002);
		WebElement chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2002);
		WebElement Username = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		Username.sendKeys("Amol" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(2002);
		WebElement email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Amol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(2002);
		WebElement mobileNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		mobileNumber.sendKeys("987321" + UtilsLayerPackage.RandomIntData.randomInt() + "5");
		Thread.sleep(2002);
		WebElement skill = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skill).selectByVisibleText("Banking");
		Thread.sleep(2002);
		WebElement language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("English");
		Thread.sleep(2002);
		WebElement complaintType = driver.findElement(By.xpath("//select[@id='select_complain_type']"));
		new Select(complaintType).selectByVisibleText("Help");
		Thread.sleep(2002);
		WebElement chatNow = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		chatNow.click();
		Thread.sleep(2002);
	
	}
	@Test
	public void DCustomerPortal1() throws InterruptedException {
		Thread.sleep(2002);
		WebDriverManager.chromedriver().setup();
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("--blink-settings=imagesEnabled=false");
		option.addArguments("incognito");
		option.addArguments("--ignore-certificate-errors");
		option.addArguments("--ignore-ssl-errors=yes");
		driver1 = new ChromeDriver(option);
		driver1.manage().window().maximize();
//		driver1.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//		 driver1.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver1.navigate().to("https://dcc.inaipi.ae/CustomerPortal?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
		Thread.sleep(2002);
		WebElement chat = driver1.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2002);
		WebElement Username = driver1.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		Username.sendKeys("Amol" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(2002);
		WebElement email = driver1.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Amol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(2002);
		WebElement mobileNumber = driver1.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		mobileNumber.sendKeys("987321" + UtilsLayerPackage.RandomIntData.randomInt() + "5");
		Thread.sleep(2002);
		WebElement skill = driver1.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skill).selectByVisibleText("Banking");
		Thread.sleep(2002);
		WebElement language = driver1.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Arabic");
		Thread.sleep(2002);
		WebElement complaintType = driver1.findElement(By.xpath("//select[@id='select_complain_type']"));
		new Select(complaintType).selectByVisibleText("Help");
		Thread.sleep(2002);
		WebElement chatNow = driver1.findElement(By.xpath("//button[text()='Chat Now']"));
		chatNow.click();
		Thread.sleep(2002);
		driver1.manage().window().minimize();
		
	}
	
	@Test
	public void EreceivedCall() throws InterruptedException {
		driver.navigate().back();
//		driver.navigate().back();
		Thread.sleep(2001);
		WebElement message = driver.findElement(By.xpath("(//button[@class='tablinks'])[1]//*[@stroke='currentColor']"));
		message.click();
		Thread.sleep(2002);
		WebElement acceptCall1 = driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i"));
		new Actions(driver).click(acceptCall1).build().perform();
		Thread.sleep(3000);
		WebElement acceptCall2 = driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i"));
		new Actions(driver).click(acceptCall2).build().perform();
		Thread.sleep(2002);
		WebElement acceptCall3 = driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i"));
		new Actions(driver).click(acceptCall3).build().perform();
		Thread.sleep(2002);
		WebElement acceptCall4 = driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i"));
		new Actions(driver).click(acceptCall4).build().perform();
		Thread.sleep(2002);
		WebElement acceptCall5 = driver.findElement(By.xpath("//div[@class='incomecall_details  p-3']/div/div/div[2]/div[2]/button[1]/i"));
		new Actions(driver).click(acceptCall5).build().perform();
		Thread.sleep(2002);

		WebElement startChat1 = driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div/div/div[1]"));
		try {
			new Actions(driver).click(startChat1).build().perform();
		} catch (Exception e1) {
			startChat1.click();
		}
		Thread.sleep(2002);
		WebElement endChat1 = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@class='icon_top-btn']"));
		endChat1.click();
		Thread.sleep(2002);
		WebElement selectReason1 = driver.findElement(By.xpath("//select[@class='form-select']"));
		new Select(selectReason1).selectByVisibleText("Disconnected");
		Thread.sleep(2002);
		WebElement comment1 = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
		comment1.sendKeys("No");
		Thread.sleep(2002);
		WebElement submit1 = driver.findElement(By.xpath("//button[text()='Submit']"));
		submit1.click();
		Thread.sleep(2003);
		WebElement startChat2 = driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div/div/div[1]"));
		try {
			new Actions(driver).click(startChat2).build().perform();
		} catch (Exception e) {
			startChat2.click();
		}
		Thread.sleep(2002);
		WebElement endChat2 = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@class='icon_top-btn']"));
		endChat2.click();
		Thread.sleep(2002);
		WebElement selectReason2 = driver.findElement(By.xpath("//select[@class='form-select']"));
		new Select(selectReason2).selectByVisibleText("Disconnected");
		Thread.sleep(2002);
		WebElement comment2 = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
		comment2.sendKeys("No");
		Thread.sleep(2002);
		WebElement submit2 = driver.findElement(By.xpath("//button[text()='Submit']"));
		submit2.click();
		Thread.sleep(2002);
		WebElement startChat3 = driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div/div/div[1]"));
		try {
			new Actions(driver).click(startChat3).build().perform();
		} catch (Exception e) {
			startChat3.click();
		}
		Thread.sleep(2002);
		WebElement endChat3 = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@class='icon_top-btn']"));
		endChat3.click();
		Thread.sleep(2002);
		WebElement selectReason3 = driver.findElement(By.xpath("//select[@class='form-select']"));
		new Select(selectReason3).selectByVisibleText("Disconnected");
		Thread.sleep(2002);
		WebElement comment3 = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
		comment3.sendKeys("No");
		Thread.sleep(2002);
		WebElement submit3 = driver.findElement(By.xpath("//button[text()='Submit']"));
		submit3.click();
		Thread.sleep(2002);
		WebElement startChat4 = driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div/div/div[1]"));
		try {
			new Actions(driver).click(startChat4).build().perform();
		} catch (Exception e) {
			startChat4.click();
		}
		Thread.sleep(2002);
		WebElement endChat4 = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@class='icon_top-btn']"));
		endChat4.click();
		Thread.sleep(2002);
		WebElement selectReason4 = driver.findElement(By.xpath("//select[@class='form-select']"));
		new Select(selectReason4).selectByVisibleText("Disconnected");
		Thread.sleep(2002);
		WebElement comment4 = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
		comment4.sendKeys("No");
		Thread.sleep(2002);
		WebElement submit4 = driver.findElement(By.xpath("//button[text()='Submit']"));
		submit4.click();
		Thread.sleep(2003);
		WebElement startChat5 = driver.findElement(By.xpath("//div[@class='chat-contacts mt-2']/div/div/div[1]"));
		try {
			new Actions(driver).click(startChat5).build().perform();
		} catch (Exception e) {
			startChat5.click();
		}
		Thread.sleep(2002);
		WebElement endChat5 = driver.findElement(By.xpath("//div[@class='call']/div/button[6]//*[@class='icon_top-btn']"));
		endChat5.click();
		Thread.sleep(2002);
		WebElement selectReason5 = driver.findElement(By.xpath("//select[@class='form-select']"));
		new Select(selectReason5).selectByVisibleText("Disconnected");
		Thread.sleep(2002);
		WebElement comment5 = driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']"));
		comment5.sendKeys("No");
		Thread.sleep(2002);
		WebElement submit5 = driver.findElement(By.xpath("//button[text()='Submit']"));
		submit5.click();
		Thread.sleep(2002);
		WebElement status = driver.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--ready']"));
		status.click();
		Thread.sleep(2002);
		WebElement endwork = driver.findElement(By.xpath("//button[@class='btn btn-primary']//span[@aria-label='end work']"));
		endwork.click();
		Thread.sleep(2002);
		WebElement signout = driver.findElement(By.xpath("//div[@class='sign-out']/span[2]"));
		signout.click();
		Thread.sleep(2002);
	}
}
