package PageLayerPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import BaseLayerPackage.BaseClass;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TransferToAgent extends BaseClass {
	public static String customerPortal ;
	public static String Agent1 ;
	public static String Agent2 ;

		@FindBy(xpath = "//input[@id='exampleFormControlInput1']")
		WebElement username;

		@FindBy(xpath = "//input[@id='exampleFormControlInput2']")
		WebElement password;

		@FindBy(xpath = "//div[text()='Login']")
		WebElement login;

		@FindBy(xpath = "//button[text()='Logout']")
		WebElement logout;

		@FindBy(xpath = "//div[@class='neo-nav-status neo-nav-status--connected ']")
		WebElement status;

		@FindBy(xpath = "//button[@class='btn btn-success work-start']")
		WebElement goready;

		@FindBy(xpath = "//span[@class='neo-icon-close user-close']")
		WebElement close;

		@FindBy(xpath = "//button[@class='chatbox-open call-animation']/i")
		WebElement chat;

		@FindBy(xpath = "//input[@id='exampleFormControlInput1']")
		WebElement CPusername;

		@FindBy(xpath = "//input[@id='exampleFormControlInput2']")
		WebElement CPemail;

		@FindBy(xpath = "//input[@id='exampleFormControlInput3']")
		WebElement CPphoneNumber;

		@FindBy(xpath = "//select[@id='select_skillset']")
		WebElement CPskillSet;

		@FindBy(xpath = "//select[@id='select_language']")
		WebElement CPselectLanguage;

		@FindBy(xpath = "//select[@id='select_complain_type']")
		WebElement CPcomplaintType;

		@FindBy(xpath = "//div[text()='Chat Now']")
		WebElement CPchatButton;

		@FindBy(xpath = "//i[text()='sms']")
		WebElement message;

		@FindBy(xpath = "//button[@id='accept_client_chat']//p[text()='Accept']")
		WebElement acceptCall;

		@FindBy(xpath = "//div[@class='d-flex justify-content-between w-100']")
		WebElement startChat;
		
		@FindBy(xpath = "//textarea[@placeholder='Enter your message...']")
		WebElement messageBox;
		
		@FindBy(xpath = "//span[text()='send']")
		WebElement sendMsg;
		
		@FindBy(xpath = "//div[@class='react-input-emoji--wrapper']/div[2]")
		WebElement CPmessageBox;
		
		@FindBy(xpath = "//button[@class='btn btn-grad']/i")
		WebElement CPsendMsg;
		

		@FindBy(xpath = "(//button[@type='button'])[9]//*[@stroke='currentColor']")
		WebElement tab_on_three_dot;
		
		@FindBy(xpath = "(//button[@type='button'])[12]//*[@stroke='currentColor']")
		WebElement transferToAgent;
		
		@FindBy(xpath = "(//select[@class='form-select form-select-sm '])[1]")
		WebElement choseSkillSet;
		
		@FindBy(xpath = "(//select[@class='form-select form-select-sm '])[2]")
		WebElement choseLanguage;
		
		@FindBy(xpath = "//select[@class='form-select form-select-sm mt-4 ']")
		WebElement availableAgent;
		
		@FindBy(xpath = "//button[text()='TRANSFER']")
		WebElement transfer;
		
		@FindBy(xpath = "//button[@class='react-input-emoji--button']//*[@class='react-input-emoji--button--icon']")
		WebElement CPemoji;
		
		@FindBy(xpath = "(//button[@aria-label='👍, +1, thumbsup'])[1]/span")
		WebElement CPbestLuckEmoji;
		
		@FindBy(xpath = "//input[@id='attach']")
		WebElement CPattachedFile;
		
		@FindBy(xpath = "//button[text()='Send']")
		WebElement CPsendBtn;
		
		@FindBy(xpath = "//div[@class='smiley btn-sm border-0 me-2 ']/i")
		WebElement AP1emoji;
		
		@FindBy(xpath = "//div[@class='epr-body']//ul/li[2]/div[2]/button[7]")
		WebElement AP1bestLuckEmoji;
		
		@FindBy(xpath = "//span[text()='send']")
		WebElement AP1send;
		
		@FindBy(xpath = "//input[@type='file']")
		WebElement AP1attachedFile;
		
		@FindBy(xpath = "(//button[@class='btn btn-outline-secondary border-0 btn-sm'])[1]//*[@stroke='currentColor']")
		WebElement AP1transferToAgent;
		
		@FindBy(xpath = "(//button[@class='btn btn-outline-secondary border-0 btn-sm'])[5]//*[@class='icon_top-btn']")
		WebElement endChat;
		
		@FindBy(xpath = "//select[@class='form-select']")
		WebElement selectReason;
		
		@FindBy(xpath = "//input[@id='floatingTextarea2']")
		WebElement comment;
		
		@FindBy(xpath = "//button[text()='SUBMIT']")
		WebElement submit;
		
		public TransferToAgent() {
			PageFactory.initElements(driver, this);
		}

		public boolean displayStatusOfUsername() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(username, "UserName");
			return username.isDisplayed();
		}

		public boolean enableStatusOfUsername() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(username, "UserName");
			return username.isEnabled();
		}

		public boolean displayStatusOfPassword() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(password, "Password");
			return password.isDisplayed();
		}

		public boolean enableStatusOfPassword() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(password, "Password");
			return password.isEnabled();
		}

		public boolean displayStatusOfLogin() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(login, "Login");
			return login.isDisplayed();
		}

		public boolean enableStatusOfLogin() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(login, "Login");
			return login.isEnabled();
		}

		public void enterLoginCredentialandLogin(String Username, String Password) throws InterruptedException {
			username.sendKeys(Username);
			System.out.println("User id : " + username.getAttribute("value"));
			Thread.sleep(2000);
			password.sendKeys(Password);
			System.out.println("password : " + password.getAttribute("value"));
			Thread.sleep(2000);
			login.click();
			Thread.sleep(2001);
			String currentUrl = driver.getCurrentUrl();
			System.out.println(currentUrl);
			Thread.sleep(2000);
			if (driver.getCurrentUrl().equalsIgnoreCase("https://dcc.inaipi.ae/main/Dashboard")) {

				System.out.println("Welcome in chat interface home page");
				
			} else {
				Thread.sleep(2000);
				logout.click();
				Thread.sleep(2001);
				username.sendKeys(Username);
				Thread.sleep(2001);
				password.sendKeys(Password);
				Thread.sleep(2001);
				login.click();
			}
			Thread.sleep(2000);
			System.out.println("Welcome in chat interface home page");

		}

		public boolean displayStatusOfstatus() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(status, "Status");
			return status.isDisplayed();
		}

		public boolean enableStatusOfstatus() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(status, "Status");
			return status.isEnabled();
		}

		public void clickOnstatus() {
			status.click();
		}

		public boolean displayStatusOfgoready() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(goready, "Goready");
			return goready.isDisplayed();
		}

		public boolean enableStatusOfgoready() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(goready, "Goready");
			return goready.isEnabled();
		}

		public void clickOngoready() {
			goready.click();
		}

		public boolean displayStatusOfclose() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(close, "Close");
			return close.isDisplayed();
		}

		public boolean enableStatusOfclose() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(close, "Close");
			return close.isEnabled();
		}

		public void clickOnclose() {
			close.click();
		}

		public void navigatetoCustomerPortal() {
			driver.navigate().to("https://dcc.inaipi.ae/CustomerPortal?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
		}

		public boolean displayStatusOfchat() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(chat, "Chat");
			return chat.isDisplayed();
		}

		public boolean enableStatusOfchat() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(chat, "Chat");
			return chat.isEnabled();
		}

		public void clickOnchat() {
			chat.click();
		}

		public boolean displayStatusOfCPusername() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(CPusername, "CPUsername");
			return CPusername.isDisplayed();
		}

		public boolean enableStatusOfCPusername() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(CPusername, "CPUsername");
			return CPusername.isEnabled();
		}

		public void enterDataInCPusername(String CPusernames) {
			CPusername.sendKeys(CPusernames);
			System.out.println("Username : " + CPusername.getAttribute("value"));
		}

		public boolean displayStatusOfCPemail() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(CPemail, "CPEmail");
			return CPemail.isDisplayed();
		}

		public boolean enableStatusOfCPemail() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(CPemail, "CPEmail");
			return CPemail.isEnabled();
		}

		public void enterDataInCPemail(String CPemails) {
			CPemail.sendKeys(CPemails);
			System.out.println("Email : " + CPemail.getAttribute("value"));
		}

		public boolean displayStatusOfCPphoneNumber() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(CPphoneNumber, "CPPhoneNumber");
			return CPphoneNumber.isDisplayed();
		}

		public boolean enableStatusOfCPphoneNumber() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(CPphoneNumber, "CPPhoneNumber");
			return CPphoneNumber.isEnabled();
		}

		public void enterDataInCPphoneNumber(String CPphoneNumbers) {
			CPphoneNumber.sendKeys(CPphoneNumbers);
			System.out.println("Mobile number  : " + CPphoneNumber.getAttribute("value"));
		}

		public boolean displayStatusOfCPskillSet() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(CPskillSet, "CPSkillSet");
			return CPskillSet.isDisplayed();
		}

		public boolean enableStatusOfCPskillSet() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(CPskillSet, "CPSkillSet");
			return CPskillSet.isEnabled();
		}

		public void selectSkillsetfromDPCPskillSet(String CPskillSets) {
			new Select(CPskillSet).selectByVisibleText(CPskillSets);
			System.out.println("Skill Set : " + CPskillSet.getAttribute("value"));
		}

		public boolean displayStatusOfCPselectLanguage() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(CPselectLanguage, "CPSelectLanguage");
			return CPselectLanguage.isDisplayed();
		}

		public boolean enableStatusOfCPselectLanguage() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(CPselectLanguage, "CPSelectLanguage");
			return CPselectLanguage.isEnabled();
		}

		public void selectSkillsetfromDPCPselectLanguage(String CPselectLanguages) {
			new Select(CPselectLanguage).selectByVisibleText(CPselectLanguages);
			System.out.println("Language : " + CPselectLanguage.getAttribute("value"));
		}

		public boolean displayStatusOfCPcomplaintType() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(CPcomplaintType, "CPComplaintType");
			return CPcomplaintType.isDisplayed();
		}

		public boolean enableStatusOfCPcomplaintType() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(CPcomplaintType, "CPComplaintType");
			return CPcomplaintType.isEnabled();
		}

		public void selectSkillsetfromDPCPcomplaintType(String CPcomplaintTypes) {
			new Select(CPcomplaintType).selectByVisibleText(CPcomplaintTypes);
			System.out.println("Complaint Type : " + CPcomplaintType.getAttribute("value"));
		}

		public boolean displayStatusOfCPchatButton() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(CPchatButton, "CPChatButton");
			return CPchatButton.isDisplayed();
		}

		public boolean enableStatusOfCPchatButton() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(CPchatButton, "CPChatButton");
			return CPchatButton.isEnabled();
		}

		public void clickOnCPchatButton() throws InterruptedException {
			customerPortal = driver.getCurrentUrl();
			CPchatButton.click();
			Thread.sleep(3000);
		}

		public void navigatebacktoAgentPortal() {
			driver.navigate().back();
		}

		public boolean displayStatusOfmessage() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(message, "Message");
			return message.isDisplayed();
		}

		public boolean enableStatusOfmessage() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(message, "Message");
			return message.isEnabled();
		}

		public void clickOnmessage() throws InterruptedException {
			message.click();
		}

		public boolean displayStatusOfacceptCall() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(acceptCall, "AcceptCall");
			return acceptCall.isDisplayed();
		}

		public boolean enableStatusOfacceptCall() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(acceptCall, "AcceptCall");
			return acceptCall.isEnabled();
		}

		public void clickOnacceptCall() throws InterruptedException {
			acceptCall.click();
		}

		public boolean displayStatusOfstartChat() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(startChat, "StartChat");
			return startChat.isDisplayed();
		}

		public boolean enableStatusOfstartChat() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(startChat, "StartChat");
			return startChat.isEnabled();
		}

		public void clickOnstartChat() throws InterruptedException {
			startChat.click();
		}
//		public boolean displayStatusOfmessageBox() throws InterruptedException {
//			UtilsLayerPackage.displayStatus.DisplayStatus(messageBox, "MessageBox");
//			return messageBox.isDisplayed();
//		}
	//	
//		public boolean enableStatusOfmessageBox() throws InterruptedException {
//			UtilsLayerPackage.enableStatus.EnabledStatus(messageBox, "MessageBox");
//			return messageBox.isEnabled();
//		}
		
		public void clickOnmessageBox() throws InterruptedException {
			messageBox.click();
		}
		public void sendDataInMessageBox(String Message_Box) {
			messageBox.sendKeys(Message_Box);
		}
//		public boolean displayStatusOfsendMsg() throws InterruptedException {
//			UtilsLayerPackage.displayStatus.DisplayStatus(sendMsg, "SendMsg");
//			return sendMsg.isDisplayed();
//		}
	//	
//		public boolean enableStatusOfsendMsg() throws InterruptedException {
//			UtilsLayerPackage.enableStatus.EnabledStatus(sendMsg, "SendMsg");
//			return sendMsg.isEnabled();
//		}
		
		public void clickOnsendMsg() throws InterruptedException {
			sendMsg.click();
			Thread.sleep(3000);
		}
		public void navigatetoCustomerportal1() throws InterruptedException {
			driver.navigate().to(customerPortal);
			Thread.sleep(3000);
			chat.click();
		}
		public void enterDataInCPmessageBox(String CPMessageBox) throws InterruptedException {
			Thread.sleep(3000);
			CPmessageBox.click();
			Thread.sleep(3000);
			CPmessageBox.sendKeys(CPMessageBox);
			Thread.sleep(3000);
		}
		public void clickOnCPsendMsg() throws InterruptedException {
			CPsendMsg.click();
			Thread.sleep(3000);
		}
		public void navigatebacktoagent1() throws InterruptedException {
			driver.navigate().back();
			Thread.sleep(3000);
			startChat.click();
			Agent1 = driver.getCurrentUrl();
		}
		public void openChromeIncognito() throws InterruptedException {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
			ChromeOptions option = new ChromeOptions();
			option.addArguments("--remote-allow-origins=*");
			option.addArguments("--blink-settings=imagesEnabled=false");
			option.addArguments("incognito");
			option.addArguments("--ignore-certificate-errors");
			option.addArguments("--ignore-ssl-errors=yes");
			driver2 = new ChromeDriver(option);
			driver2.manage().window().maximize();
//			driver1.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
//			 driver1.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
			driver2.navigate().to("https://dcc.inaipi.ae/?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
		}

		public void Agent2Login(String Username, String Password) throws InterruptedException {
			WebElement username2 = driver2.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
			username2.sendKeys(Username);
			Thread.sleep(2000);
			WebElement password2 = driver2.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
			password2.sendKeys(Password);
			Thread.sleep(2000);
			WebElement login2 = driver2.findElement(By.xpath("//div[text()='Login']"));
			login2.click();
			Thread.sleep(2001);
			String currentUrl = driver2.getCurrentUrl();
			System.out.println(currentUrl);

			if (currentUrl.equalsIgnoreCase("https://dcc.inaipi.ae/main/Dashboard")) {

			} else {
				WebElement logout2 = driver2.findElement(By.xpath("//button[text()='Logout']"));
				logout2.click();
				Thread.sleep(2001);
				WebElement usernames2 = driver2.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
				usernames2.sendKeys(Username);
				Thread.sleep(2001);
				WebElement passwords2 = driver2.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
				passwords2.sendKeys(Password);
				Thread.sleep(2001);
				WebElement logins2 = driver2.findElement(By.xpath("//div[text()='Login']"));
				logins2.click();
			}
			System.out.println("Welcome in chat interface home page in Inconito Tab in Chrome");
			
		}

		public boolean displayStatusOfstatus2() throws InterruptedException {
			Thread.sleep(3000);
			WebElement status2 = driver2.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--connected ']"));
			return status2.isDisplayed();
		}

		public boolean enableStatusOfstatus2() throws InterruptedException {
			Thread.sleep(1000);
			WebElement status2 = driver2.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--connected ']"));
			return status2.isEnabled();
		}

		public void clickOnstatus2() {
			WebElement status2 = driver2.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--connected ']"));
			status2.click();
		}

		public boolean displayStatusOfgoready2() throws InterruptedException {
			Thread.sleep(3000);
			WebElement goready2 = driver2.findElement(By.xpath("//button[@class='btn btn-success work-start']"));
			return goready2.isDisplayed();
		}

		public boolean enableStatusOfgoready2() throws InterruptedException {
			WebElement goready2 = driver2.findElement(By.xpath("//button[@class='btn btn-success work-start']"));
			return goready2.isEnabled();
		}

		public void clickOngoready2() {
			WebElement goready2 = driver2.findElement(By.xpath("//button[@class='btn btn-success work-start']"));
			goready2.click();
		}

		public boolean displayStatusOfclose2() throws InterruptedException {
			Thread.sleep(3000);
			WebElement close2 = driver2.findElement(By.xpath("//span[@class='neo-icon-close user-close']"));
			return close2.isDisplayed();
		}

		public boolean enableStatusOfclose2() throws InterruptedException {
			WebElement close2 = driver2.findElement(By.xpath("//span[@class='neo-icon-close user-close']"));
			return close2.isEnabled();
		}

		public void clickOnclose2() {
			Agent2 = driver2.getCurrentUrl();
			WebElement close2 = driver2.findElement(By.xpath("//span[@class='neo-icon-close user-close']"));
			close2.click();
			driver2.manage().window().minimize();
		
		}

		public void gotoAgent1() throws InterruptedException {
			driver.navigate().to(Agent1);
			driver.manage().window().maximize();
			Thread.sleep(4000);
			startChat.click();
			Thread.sleep(2000);
			tab_on_three_dot.click();
		}

		public boolean displayStatusOfconferenceToAgent() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(transferToAgent, "ConferenceToAgent");
			return transferToAgent.isDisplayed();
		}
		public boolean enableStatusOfconferenceToAgent() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(transferToAgent, "ConferenceToAgent");
			return transferToAgent.isEnabled();
		}
		public void clickOnTransferToAgent() {
			new Actions(driver).click(transferToAgent).build().perform();
		}
		
		public boolean displayStatusOfchoseSkillSet() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(choseSkillSet, "choseSkillSet");
			return choseSkillSet.isDisplayed();
		}
		public boolean enableStatusOfchoseSkillSet() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(choseSkillSet, "choseSkillSet");
			return choseSkillSet.isEnabled();
		}
		public void selectSkillSetFromchoseSkillSet(String ChoseSkillSet) throws InterruptedException {
			choseSkillSet.click();
			Thread.sleep(2000);
			new Select(choseSkillSet).selectByVisibleText(ChoseSkillSet);
		}
		public boolean displayStatusOfchoseLanguage() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(choseLanguage, "choseLanguage");
			return choseLanguage.isDisplayed();
		}
		public boolean enableStatusOfchoseLanguage() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(choseLanguage, "choseLanguage");
			return choseLanguage.isEnabled();
		}
		public void selectSkillSetFromchoseLanguage(String ChoseLanguage) throws InterruptedException {
			choseLanguage.click();
			Thread.sleep(2000);
			new Select(choseLanguage).selectByVisibleText(ChoseLanguage);
		}
		public boolean displayStatusOfavailableAgent() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(availableAgent, "availableAgent");
			return availableAgent.isDisplayed();
		}
		public boolean enableStatusOfavailableAgent() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(availableAgent, "availableAgent");
			return availableAgent.isEnabled();
		}
		public void selectSkillSetFromavailableAgent(String AvailableAgent) throws InterruptedException {
			availableAgent.click();
			Thread.sleep(2000);
			new Select(availableAgent).selectByVisibleText(AvailableAgent);
		}
		public boolean displayStatusOftransfer() throws InterruptedException {
			UtilsLayerPackage.displayStatus.DisplayStatus(transfer, "transfer");
			return transfer.isDisplayed();
		}
		public boolean enableStatusOftransfer() throws InterruptedException {
			UtilsLayerPackage.enableStatus.EnabledStatus(transfer, "transfer");
			return transfer.isEnabled();
		}
		public void clickOntransfer() throws InterruptedException {
			transfer.click();
			Thread.sleep(2000);
			driver.manage().window().minimize();
		}
		public void gotoAgent2andAcceptThaRequest() throws InterruptedException {
			driver2.manage().window().maximize();
			driver2.navigate().to(Agent2);
			Thread.sleep(3000);
			WebElement messageAgent2 = driver2.findElement(By.xpath("//i[text()='sms']"));
			messageAgent2.click();
			Thread.sleep(3000);
			WebElement acceptCallAgent2 = driver2.findElement(By.xpath("//button[@id='accept_client_chat']//p[text()='Accept']"));
			new Actions(driver2).click(acceptCallAgent2).build().perform();
//			WebElement messageAgent2 = driver2.findElement(By.xpath("(//button[@class='tablinks'])[1]//*[@stroke='currentColor']"));
//			messageAgent2.click();
			Thread.sleep(2000);
			WebElement startChatAgent2 = driver2.findElement(By.xpath("//div[@class='d-flex justify-content-between w-100']"));
			startChatAgent2.click();
		}
		public void enterMsginAgent2MessageBox(String Agent2MessageBoxs) throws InterruptedException {
			Thread.sleep(2000);
			WebElement Agent2MessageBox = driver2.findElement(By.xpath("//textarea[@placeholder='Enter your message...']"));
			Agent2MessageBox.click();
			Thread.sleep(1500);
			Agent2MessageBox.sendKeys(Agent2MessageBoxs);
		}
		public void clickOnSendMessagefromAgentPortal() throws InterruptedException {
			Thread.sleep(1500);
			WebElement sendMsg = driver2.findElement(By.xpath("//span[text()='send']"));
			sendMsg.click();
			driver2.manage().window().minimize();
		}
		public void gotoagent1ToCheckMsgCommingOrNotandsignout() throws InterruptedException {
			driver.manage().window().maximize();
			driver.navigate().to(Agent1);
			Thread.sleep(4000);
			driver.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--ready']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[@id='finish_work']/span")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//span[text()='Sign Out']")).click();
			Thread.sleep(2000);
		}
		public void gotoCustomer1ToCheckMsgCommingOrNot() throws InterruptedException {
			driver.navigate().to(customerPortal);
			Thread.sleep(1500);
			chat.click();
		}
		public void ClickandEnterMessageInCustomerMsgBoxandSend(String CPMessageBox) throws InterruptedException {
			Thread.sleep(1500);
			CPmessageBox.click();
			Thread.sleep(1500);
			CPmessageBox.sendKeys(CPMessageBox);
			Thread.sleep(1500);
			CPsendMsg.click();
		}
		public void sendMsgFromCustomerPortal() throws InterruptedException {
//			Thread.sleep(1500);
//			CPemoji.click();
//			Thread.sleep(3500);
//			new Actions(driver).moveToElement(CPbestLuckEmoji).click().build().perform();
//			Thread.sleep(3500);
//			CPsendMsg.click();
//			Thread.sleep(1000);
			Thread.sleep(3000);
			CPmessageBox.click();
			Thread.sleep(3000);
			CPmessageBox.sendKeys("Hello");
			Thread.sleep(3000);
			CPsendMsg.click();
		}
		public void sendFileFromCustomerPortal(String CPAttachedFile) throws InterruptedException {
			Thread.sleep(1500);
			CPattachedFile.sendKeys(CPAttachedFile);
			Thread.sleep(5000);
			CPsendBtn.click();
			Thread.sleep(1500);
			driver.manage().window().minimize();
		}

		public void sendEmojiFromAgent1Portal() throws InterruptedException {
			driver.navigate().to(Agent2);
			driver2.manage().window().maximize();
			Thread.sleep(2500);
			WebElement AP2emoji = driver2.findElement(By.xpath("//div[@class='smiley btn-sm border-0 me-2 ']/i"));
			AP2emoji.click();
			Thread.sleep(3500);
			WebElement AP2bestLuckEmoji = driver2.findElement(By.xpath("//div[@class='epr-body']//ul/li[2]/div[2]/button[7]"));
			try {
				new Actions(driver2).moveToElement(AP2bestLuckEmoji).click().build().perform();
			} catch (Exception e) {
				new Actions(driver2).click(AP2bestLuckEmoji).build().perform();
			}
			Thread.sleep(3500);
			WebElement AP2send = driver2.findElement(By.xpath("//span[text()='send']"));
			AP2send.click();
			Thread.sleep(1000);
		}
		public void sendFileFromAgent1Portal(String CPAttachedFile) throws InterruptedException {
			Thread.sleep(1500);
			WebElement AP2attachedFile = driver2.findElement(By.xpath("//input[@type='file']"));
			AP2attachedFile.sendKeys(CPAttachedFile);
			Thread.sleep(5000);
			WebElement AP1sendBtn = driver2.findElement(By.xpath("//button[text()='Send']"));
			AP1sendBtn.click();
			Thread.sleep(3000);
			WebElement threedotss = driver2.findElement(By.xpath("(//button[@type='button'])[9]//*[@fill='currentColor']"));
			new Actions(driver2).click(threedotss).build().perform();
		}
		public void clickOnendChat2() throws InterruptedException {
			WebElement endChat = driver2.findElement(By.xpath("(//button[@class='btn btn-outline-secondary border-0 btn-sm'])[9]"));
			((JavascriptExecutor)driver2).executeScript("arguments[0].style.border='3px solid green';", endChat);
			Thread.sleep(1500);
			new Actions(driver2).click(endChat).build().perform();
		}
		public void selectReasonforDisconnect2(String SelectReason) throws InterruptedException {
			WebElement selectReason2 = driver2.findElement(By.xpath("//select[@aria-label='Default select example']"));
			((JavascriptExecutor)driver2).executeScript("arguments[0].style.border='3px solid green';", selectReason2);
			Thread.sleep(1500);
			new Select(selectReason2).selectByVisibleText(SelectReason);
		}
		public void enterComment2(String Comment) throws InterruptedException {
			WebElement comment2 = driver2.findElement(By.xpath("//input[@id='floatingTextarea2']"));
			((JavascriptExecutor)driver2).executeScript("arguments[0].style.border='3px solid green';", comment2);
			Thread.sleep(1500);
			comment2.sendKeys(Comment);
		}
		public void clickOnSUbmitandsignout2() throws InterruptedException {
			WebElement submit2 = driver2.findElement(By.xpath("//button[text()='SUBMIT']"));
			((JavascriptExecutor)driver2).executeScript("arguments[0].style.border='3px solid green';", submit2);
			Thread.sleep(1500);
			submit2.click();
			Thread.sleep(4000);
			driver2.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--ready']")).click();
			Thread.sleep(2000);
			driver2.findElement(By.xpath("//button[@id='finish_work']/span")).click();
			Thread.sleep(2000);
			driver2.findElement(By.xpath("//span[text()='Sign Out']")).click();
			Thread.sleep(2000);
			driver2.manage().window().minimize();
		}

		public void navigateToCustomerandendthecall() throws InterruptedException {
			Thread.sleep(2000);
			driver.navigate().to(customerPortal);
			driver.manage().window().maximize();
			Thread.sleep(2000);
			chat.click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//i[@class='fa fa-close']")).click();
		}
		


}
