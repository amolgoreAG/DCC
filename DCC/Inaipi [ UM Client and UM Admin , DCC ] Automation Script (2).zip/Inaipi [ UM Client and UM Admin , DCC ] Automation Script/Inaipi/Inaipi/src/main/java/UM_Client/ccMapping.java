package UM_Client;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class ccMapping extends BaseClass{

	@FindBy(xpath = "//span[text()='CC Mapping']")
	WebElement ccMapping;

	@FindBy(xpath = "//li[text()='Channel Mapping']")
	WebElement channelMapping;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[1]/div/div/div")
	WebElement CCselectChannel;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[2]/div/div/div")
	WebElement CCselectSubChannel;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[3]/div/button/span")
	WebElement CCViewButton;

	@FindBy(xpath = "//span[text()='Add Users']")
	WebElement CCaddUser;

	@FindBy(xpath = "//div[starts-with(@class,'react-dropdown-select halfWidth')]")
	WebElement CCselectUser;

	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-item']//*[@aria-label='save']")
	WebElement CCsaveUser;

	@FindBy(xpath = "//button[@title='Next page']/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement CCnextPage;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[9]//*[@aria-label='removw']")
	WebElement CCremoveUser;

	@FindBy(xpath = "//span[text()='NO']")
	WebElement CCremoveUserNO;

	@FindBy(xpath = "//span[text()='YES']")
	WebElement CCremoveUserYES;

	@FindBy(xpath = "//li[text()='Skillset Mapping']")
	WebElement skillsetMapping;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[1]/div/div/div")
	WebElement CCskill;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[2]/div/div/div")
	WebElement CCskillProficiency;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[2]//*[@aria-label='removw']")
	WebElement CCremoveUserSM;

	@FindBy(xpath = "//li[text()='Language Mapping']")
	WebElement languageMapping;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[1]/div/div/div")
	WebElement CClanguage;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root dataTables_wrapper square-text')]/div[2]/div/div/div")
	WebElement CClanguageProficiency;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div[4]//*[@aria-label='removw']")
	WebElement CCremoveUserLM;

	@FindBy(xpath = "//li[text()='Chat Configuration']")
	WebElement chatConfiguration;

	@FindBy(xpath = "//input[@id='autoRejectTime']")
	WebElement autoRejectTime;

	@FindBy(xpath = "//input[@id='agentIdleChangeStatusTime']")
	WebElement agentIdleChangeStatusTime;

	@FindBy(xpath = "//input[@id='maxRequestsInQueue']")
	WebElement maxRequestInQueue;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div[1]/div[4]/div/span/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement alertSupCheckBox;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div[1]/div[4]/div/span/span[1]/input")
	WebElement alertSupCheckBox1;

	@FindBy(xpath = "//textarea[@id='welcomeMessage']")
	WebElement welcomeMessage;

	@FindBy(xpath = "//textarea[@id='queueMessage']")
	WebElement queueMessage;

	@FindBy(xpath = "//textarea[@id='agentNAMessage']")
	WebElement agentNAmsg;

	@FindBy(xpath = "//textarea[@id='maxQueueMessage']")
	WebElement maxQueueMessage;

	@FindBy(xpath = "//span[text()='CLEAR']")
	WebElement clearCC;

	@FindBy(xpath = "//span[text()=' SAVE']")
	WebElement saveCC;

	@FindBy(xpath = "//li[text()='Routing Configuration']")
	WebElement routingConfiguration;

	@FindBy(xpath = "//input[@id='globalConcurrency']")
	WebElement globalConcurrency;
//
//	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div[1]/div[1]/div[2]/div[2]/span/span[1]/input")
//	WebElement channelWiseConcurrencyRate;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div[1]/div[1]/div[2]/div[2]/span/span[1]//*[2]")
	WebElement channelWiseConcurrencyRate;

	@FindBy(xpath = "//input[@id='channelConcurrency0']")
	WebElement voice;

	@FindBy(xpath = "//input[@id='channelConcurrency1']")
	WebElement chat;

	@FindBy(xpath = "//input[@id='globalDelayTime']")
	WebElement ACWTime;

	@FindBy(xpath = "//div[@class='m-l-10 m-b-25']/div/div[2]/div[1]/div/div")
	WebElement routingAlgorithmDP;

	@FindBy(xpath = "//div[@class='m-l-10 m-b-25']/div/div[3]//*[@class='MuiSvgIcon-root']")
	WebElement routingAlgorithmDP_Eye;

	@FindBy(xpath = "//input[@id='skillWeightage']")
	WebElement skillWeightage;

	@FindBy(xpath = "//input[@id='languageWeightage']")
	WebElement languageWeightage;

	@FindBy(xpath = "//span[text()='CANCEL']")
	WebElement CANCEL;

	@FindBy(xpath = "//span[text()='SAVE']")
	WebElement SAVE;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-30']/div/div/label[3]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement complaintType;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-30']/div/div/label[2]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement skillGroup;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-30']/div/div/label[1]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement Channel;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-20 m-t-20']/div/div/label[1]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement channelBasedRoutingAll;

	@FindBy(xpath = "//div[@class='m-l-20 m-b-20 m-t-20']/div/div/label[2]/span[1]/span[1]/div//*[@class='MuiSvgIcon-root']")
	WebElement channelBasedRoutingIndividual;

	@FindBy(xpath = "//span[text()='CLEAR']")
	WebElement CLEAR;

	@FindBy(xpath = "//span[text()='SUBMIT']")
	WebElement SUBMIT;

	@FindBy(xpath = "//li[text()='Module Mapping']")
	WebElement Module_Mapping;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root m-l')]/div/div/div")
	WebElement Module_Mapping_selectRole;

	@FindBy(xpath = "//div[starts-with(@class,'MuiGrid-root text-right MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-md-2')]/div/button/span")
	WebElement selectRole_view;

	@FindBy(xpath = "//div[@class='fullWidth']/div/div/table//tbody/tr[1]/td[2]/center/span/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement checkBox1;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div/div[4]/div/div/table/tbody/tr[2]/td[2]/div/div/div/div/table/tbody/tr[4]/td[3]/center/span/span[1]//*[2]")
	WebElement ChatCondWritecheckBox;

	@FindBy(xpath = "//span[text()='Save Module']")
	WebElement saveModule;

	@FindBy(xpath = "//div[@id='root']/div/div[2]/div/div[2]/div/div[4]/div/div/table/tbody/tr[1]/td[1]/center/button/span[1]//*[@class='MuiSvgIcon-root']")
	WebElement downArrow1;
	
	public ccMapping() {
		PageFactory.initElements(driver, this);
	}
	public boolean displayStatusOfccMapping() throws InterruptedException {
		if (ccMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ccMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ccMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ccMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ccMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ccMapping.isDisplayed();
	}

	public boolean enableStatusOfccMapping() throws InterruptedException {
		if (ccMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ccMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ccMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ccMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ccMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ccMapping.isEnabled();
	}

	public void clickOnccMapping() throws InterruptedException {
		ccMapping.click();
	}

	public boolean displayStatusOfchannelMapping() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", channelMapping);
		Thread.sleep(1000);
		if (channelMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelMapping.isDisplayed();
	}

	public boolean enableStatusOfchannelMapping() throws InterruptedException {
		if (channelMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelMapping.isEnabled();
	}

	public void clickOnchannelMapping() throws InterruptedException {
		channelMapping.click();
	}

	public boolean displayStatusOfCCselectChannel() throws InterruptedException {
		if (CCselectChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectChannel.isDisplayed();
	}

	public boolean enableStatusOfCCselectChannel() throws InterruptedException {
		if (CCselectChannel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectChannel.isEnabled();
	}

	public void clickOnCCselectChannelandSelectDPvalue(String CCSelectChannel) throws InterruptedException {
		CCselectChannel.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectChannel + "']")).click();
	}

	public boolean displayStatusOfCCselectSubChannel() throws InterruptedException {
		if (CCselectSubChannel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectSubChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectSubChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectSubChannel.isDisplayed();
	}

	public boolean enableStatusOfCCselectSubChannel() throws InterruptedException {
		if (CCselectSubChannel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectSubChannel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectSubChannel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectSubChannel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectSubChannel.isEnabled();
	}

	public void clickOnCCselectSubChannelandSelectDPvalue(String CCSelectSubChannel) throws InterruptedException {
		CCselectSubChannel.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectSubChannel + "']")).click();
	}

	public boolean displayStatusOfCCViewButton() throws InterruptedException {
		if (CCViewButton.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isDisplayed();
	}

	public boolean enableStatusOfCCViewButton() throws InterruptedException {
		if (CCViewButton.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isEnabled();
	}

	public void clickOnCCViewButton() throws InterruptedException {
		CCViewButton.click();
	}

	public boolean displayStatusOfCCaddUser() throws InterruptedException {
		if (CCaddUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isDisplayed();
	}

	public boolean enableStatusOfCCaddUser() throws InterruptedException {
		if (CCaddUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isEnabled();
	}

	public void clickOnCCaddUser() throws InterruptedException {
		CCaddUser.click();
	}

	public boolean displayStatusOfCCselectUser() throws InterruptedException {
		if (CCselectUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isDisplayed();
	}

	public boolean enableStatusOfCCselectUser() throws InterruptedException {
		if (CCselectUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isEnabled();
	}

	public void clickOnCCselectUserandSelectDPvalue() throws InterruptedException {
		CCselectUser.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfCCsaveUser() throws InterruptedException {
		if (CCsaveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isDisplayed();
	}

	public boolean enableStatusOfCCsaveUser() throws InterruptedException {
		if (CCsaveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isEnabled();
	}

	public void clickOnCCsaveUser() throws InterruptedException {
		CCsaveUser.click();
	}

	public boolean displayStatusOfCCnextPage() throws InterruptedException {
		if (CCnextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isDisplayed();
	}

	public boolean enableStatusOfCCnextPage() throws InterruptedException {
		if (CCnextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isEnabled();
	}

	public void clickOnCCnextPage() throws InterruptedException {
		Thread.sleep(3000);
		new Actions(driver).moveToElement(CCnextPage).click().build().perform();
	}

	public boolean displayStatusOfCCremoveUser() throws InterruptedException {
		if (CCremoveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUser.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUser() throws InterruptedException {
		if (CCremoveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUser.isEnabled();
	}

	public void clickOnCCremoveUser() throws InterruptedException {
		CCremoveUser.click();
	}

	public boolean displayStatusOfCCremoveUserNO() throws InterruptedException {
		if (CCremoveUserNO.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserNO() throws InterruptedException {
		if (CCremoveUserNO.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isEnabled();
	}

	public void clickOnCCremoveUserNO() throws InterruptedException {
		CCremoveUserNO.click();
	}

	public boolean displayStatusOfCCremoveUserYES() throws InterruptedException {
		if (CCremoveUserYES.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserYES() throws InterruptedException {
		if (CCremoveUserYES.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isEnabled();
	}

	public void clickOnCCremoveUserYES() throws InterruptedException {
		CCremoveUserYES.click();
	}

	public boolean displayStatusOfskillsetMapping() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillsetMapping);
		Thread.sleep(1000);
		if (skillsetMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillsetMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillsetMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillsetMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillsetMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillsetMapping.isDisplayed();
	}

	public boolean enableStatusOfskillsetMapping() throws InterruptedException {
		if (skillsetMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillsetMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillsetMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillsetMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillsetMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillsetMapping.isEnabled();
	}

	public void clickOnskillsetMapping() throws InterruptedException {
		skillsetMapping.click();
	}

	public boolean displayStatusOfCCskillSM() throws InterruptedException {
		if (CCskill.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCskill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCskill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCskill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCskill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCskill.isDisplayed();
	}

	public boolean enableStatusOfCCskillSM() throws InterruptedException {
		if (CCskill.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCskill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCskill is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCskill);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCskill is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCskill.isEnabled();
	}

	public void clickOnCCskillandSelectDPvalueSM(String CCSelectChannelSM) throws InterruptedException {
		CCskill.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectChannelSM + "']")).click();
	}

	public boolean displayStatusOfCCskillProficiencySM() throws InterruptedException {
		if (CCskillProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCskillProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCskillProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCskillProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCskillProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCskillProficiency.isDisplayed();
	}

	public boolean enableStatusOfCCskillProficiencySM() throws InterruptedException {
		if (CCskillProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCskillProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCskillProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCskillProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCskillProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCskillProficiency.isEnabled();
	}

	public void clickOnCCskillProficiencyandSelectDPvalueSM(String CCSelectSubChannelSM) throws InterruptedException {
		CCskillProficiency.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectSubChannelSM + "']")).click();
	}

	public boolean displayStatusOfCCViewButtonSM() throws InterruptedException {
		if (CCViewButton.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isDisplayed();
	}

	public boolean enableStatusOfCCViewButtonSM() throws InterruptedException {
		if (CCViewButton.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isEnabled();
	}

	public void clickOnCCViewButtonSM() throws InterruptedException {
		CCViewButton.click();
	}

	public boolean displayStatusOfCCaddUserSM() throws InterruptedException {
		if (CCaddUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isDisplayed();
	}

	public boolean enableStatusOfCCaddUserSM() throws InterruptedException {
		if (CCaddUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isEnabled();
	}

	public void clickOnCCaddUserSM() throws InterruptedException {
		CCaddUser.click();
	}

	public boolean displayStatusOfCCselectUserSM() throws InterruptedException {
		if (CCselectUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isDisplayed();
	}

	public boolean enableStatusOfCCselectUserSM() throws InterruptedException {
		if (CCselectUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isEnabled();
	}

	public void clickOnCCselectUserandSelectDPvalueSM() throws InterruptedException {
		CCselectUser.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfCCsaveUserSM() throws InterruptedException {
		if (CCsaveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isDisplayed();
	}

	public boolean enableStatusOfCCsaveUserSM() throws InterruptedException {
		if (CCsaveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isEnabled();
	}

	public void clickOnCCsaveUserSM() throws InterruptedException {
		CCsaveUser.click();
	}

	public boolean displayStatusOfCCnextPageSM() throws InterruptedException {
		if (CCnextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isDisplayed();
	}

	public boolean enableStatusOfCCnextPageSM() throws InterruptedException {
		if (CCnextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isEnabled();
	}

	public void clickOnCCnextPageSM() throws InterruptedException {
		Thread.sleep(2500);
		new Actions(driver).moveToElement(CCnextPage).click().build().perform();
	}

	public boolean displayStatusOfCCremoveUserSM() throws InterruptedException {
		if (CCremoveUserSM.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserSM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserSM is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserSM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserSM is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserSM.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserSM() throws InterruptedException {
		if (CCremoveUserSM.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserSM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserSM is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserSM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserSM is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserSM.isEnabled();
	}

	public void clickOnCCremoveUserSM() throws InterruptedException {
		CCremoveUserSM.click();
	}

	public boolean displayStatusOfCCremoveUserNOSM() throws InterruptedException {
		if (CCremoveUserNO.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserNOSM() throws InterruptedException {
		if (CCremoveUserNO.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isEnabled();
	}

	public void clickOnCCremoveUserNOSM() throws InterruptedException {
		CCremoveUserNO.click();
	}

	public boolean displayStatusOfCCremoveUserYESSM() throws InterruptedException {
		if (CCremoveUserYES.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserYESSM() throws InterruptedException {
		if (CCremoveUserYES.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isEnabled();
	}

	public void clickOnCCremoveUserYESSM() throws InterruptedException {
		CCremoveUserYES.click();
	}

	public boolean displayStatusOflanguageMapping() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", languageMapping);
		Thread.sleep(1000);
		if (languageMapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageMapping.isDisplayed();
	}

	public boolean enableStatusOflanguageMapping() throws InterruptedException {
		if (languageMapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageMapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageMapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageMapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageMapping.isEnabled();
	}

	public void clickOnlanguageMapping() throws InterruptedException {
		languageMapping.click();
	}

	public boolean displayStatusOfCClanguageLM() throws InterruptedException {
		if (CClanguage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CClanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CClanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CClanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CClanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CClanguage.isDisplayed();
	}

	public boolean enableStatusOfCClanguageLM() throws InterruptedException {
		if (CClanguage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CClanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CClanguage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CClanguage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CClanguage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CClanguage.isEnabled();
	}

	public void clickOnCClanguageandSelectDPvalueLM(String CCSelectChannelLM) throws InterruptedException {
		CClanguage.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectChannelLM + "']")).click();
	}

	public boolean displayStatusOfCClanguageProficiencyLM() throws InterruptedException {
		if (CClanguageProficiency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CClanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CClanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CClanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CClanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CClanguageProficiency.isDisplayed();
	}

	public boolean enableStatusOfCClanguageProficiencyLM() throws InterruptedException {
		if (CClanguageProficiency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CClanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CClanguageProficiency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CClanguageProficiency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CClanguageProficiency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CClanguageProficiency.isEnabled();
	}

	public void clickOnCClanguageProficiencyandSelectDPvalueLM(String CCSelectSubChannelLM)
			throws InterruptedException {
		CClanguageProficiency.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='" + CCSelectSubChannelLM + "']")).click();
	}

	public boolean displayStatusOfCCViewButtonLM() throws InterruptedException {
		if (CCViewButton.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isDisplayed();
	}

	public boolean enableStatusOfCCViewButtonLM() throws InterruptedException {
		if (CCViewButton.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCViewButton);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCViewButton is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCViewButton.isEnabled();
	}

	public void clickOnCCViewButtonLM() throws InterruptedException {
		CCViewButton.click();
	}

	public boolean displayStatusOfCCaddUserLM() throws InterruptedException {
		if (CCaddUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isDisplayed();
	}

	public boolean enableStatusOfCCaddUserLM() throws InterruptedException {
		if (CCaddUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCaddUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCaddUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCaddUser.isEnabled();
	}

	public void clickOnCCaddUserLM() throws InterruptedException {
		CCaddUser.click();
	}

	public boolean displayStatusOfCCselectUserLM() throws InterruptedException {
		if (CCselectUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isDisplayed();
	}

	public boolean enableStatusOfCCselectUserLM() throws InterruptedException {
		if (CCselectUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCselectUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCselectUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCselectUser.isEnabled();
	}

	public void clickOnCCselectUserandSelectDPvalueLM() throws InterruptedException {
		CCselectUser.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//div[@role='list']/span[1]")).click();
	}

	public boolean displayStatusOfCCsaveUserLM() throws InterruptedException {
		if (CCsaveUser.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isDisplayed();
	}

	public boolean enableStatusOfCCsaveUserLM() throws InterruptedException {
		if (CCsaveUser.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCsaveUser);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCsaveUser is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCsaveUser.isEnabled();
	}

	public void clickOnCCsaveUserLM() throws InterruptedException {
		CCsaveUser.click();
	}

	public boolean displayStatusOfCCnextPageLM() throws InterruptedException {
		if (CCnextPage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isDisplayed();
	}

	public boolean enableStatusOfCCnextPageLM() throws InterruptedException {
		if (CCnextPage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCnextPage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCnextPage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCnextPage.isEnabled();
	}

	public void clickOnCCnextPageLM() throws InterruptedException {
		Thread.sleep(3000);
		new Actions(driver).moveToElement(CCnextPage).click().build().perform();
	}

	public boolean displayStatusOfCCremoveUserLM() throws InterruptedException {
		if (CCremoveUserLM.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserLM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserLM is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserLM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserLM is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserLM.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserLM() throws InterruptedException {
		if (CCremoveUserLM.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserLM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserLM is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserLM);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserLM is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserLM.isEnabled();
	}

	public void clickOnCCremoveUserLM() throws InterruptedException {
		CCremoveUserLM.click();
	}

	public boolean displayStatusOfCCremoveUserNOLM() throws InterruptedException {
		if (CCremoveUserNO.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserNOLM() throws InterruptedException {
		if (CCremoveUserNO.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserNO);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserNO is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserNO.isEnabled();
	}

	public void clickOnCCremoveUserNOLM() throws InterruptedException {
		CCremoveUserNO.click();
	}

	public boolean displayStatusOfCCremoveUserYESLM() throws InterruptedException {
		if (CCremoveUserYES.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isDisplayed();
	}

	public boolean enableStatusOfCCremoveUserYESLM() throws InterruptedException {
		if (CCremoveUserYES.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CCremoveUserYES);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CCremoveUserYES is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CCremoveUserYES.isEnabled();
	}

	public void clickOnCCremoveUserYESLM() throws InterruptedException {
		CCremoveUserYES.click();
	}

	public boolean displayStatusOfchatConfigurationCC() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", chatConfiguration);
		Thread.sleep(1000);
		if (chatConfiguration.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chatConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatConfiguration is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chatConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chatConfiguration is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chatConfiguration.isDisplayed();
	}

	public boolean enableStatusOfchatConfigurationCC() throws InterruptedException {
		if (chatConfiguration.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chatConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of chatConfiguration is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chatConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of chatConfiguration is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chatConfiguration.isEnabled();
	}

	public void clickOnchatConfigurationCC() throws InterruptedException {
		chatConfiguration.click();
	}

	public boolean displayStatusOfautoRejectTimeCC() throws InterruptedException {
		if (autoRejectTime.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(autoRejectTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of autoRejectTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(autoRejectTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of autoRejectTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return autoRejectTime.isDisplayed();
	}

	public boolean enableStatusOfautoRejectTimeCC() throws InterruptedException {
		if (autoRejectTime.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(autoRejectTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of autoRejectTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(autoRejectTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of autoRejectTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return autoRejectTime.isEnabled();
	}

	public void enterDataInautoRejectTimeCC() throws InterruptedException {
		autoRejectTime.click();
		String AutoRejectTime = autoRejectTime.getAttribute("value");
		System.out.println("AutoRejectTime : " + AutoRejectTime);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		autoRejectTime.sendKeys(AutoRejectTime);
	}

	public boolean displayStatusOfagentIdleChangeStatusTimeCC() throws InterruptedException {
		if (agentIdleChangeStatusTime.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(agentIdleChangeStatusTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of agentIdleChangeStatusTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(agentIdleChangeStatusTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of agentIdleChangeStatusTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return agentIdleChangeStatusTime.isDisplayed();
	}

	public boolean enableStatusOfagentIdleChangeStatusTimeCC() throws InterruptedException {
		if (agentIdleChangeStatusTime.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(agentIdleChangeStatusTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of agentIdleChangeStatusTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(agentIdleChangeStatusTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of agentIdleChangeStatusTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return agentIdleChangeStatusTime.isEnabled();
	}

	public void enterDataInagentIdleChangeStatusTimeCC() throws InterruptedException {
		agentIdleChangeStatusTime.click();
		String AgentIdleChangeStatusTime = agentIdleChangeStatusTime.getAttribute("value");
		System.out.println("AgentIdleChangeStatusTime : " + AgentIdleChangeStatusTime);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		agentIdleChangeStatusTime.sendKeys(AgentIdleChangeStatusTime);
	}

	public boolean displayStatusOfmaxRequestInQueueCC() throws InterruptedException {
		if (maxRequestInQueue.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(maxRequestInQueue);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of maxRequestInQueue is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(maxRequestInQueue);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of maxRequestInQueue is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return maxRequestInQueue.isDisplayed();
	}

	public boolean enableStatusOfmaxRequestInQueueCC() throws InterruptedException {
		if (maxRequestInQueue.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(maxRequestInQueue);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of maxRequestInQueue is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(maxRequestInQueue);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of maxRequestInQueue is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return maxRequestInQueue.isEnabled();
	}

	public void enterDataInmaxRequestInQueueCC() throws InterruptedException {
		maxRequestInQueue.click();
		String MaxRequestInQueue = maxRequestInQueue.getAttribute("value");
		System.out.println("MaxRequestInQueue : " + MaxRequestInQueue);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		maxRequestInQueue.sendKeys(MaxRequestInQueue);
	}

	public boolean displayStatusOfalertSupCheckBoxCC() throws InterruptedException {
		if (alertSupCheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(alertSupCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of alertSupCheckBox is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(alertSupCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of alertSupCheckBox is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return alertSupCheckBox.isDisplayed();
	}

	public boolean enableStatusOfalertSupCheckBoxCC() throws InterruptedException {
		if (alertSupCheckBox.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(alertSupCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of alertSupCheckBox is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(alertSupCheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of alertSupCheckBox is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return alertSupCheckBox.isEnabled();
	}

	public void clickOnalertSupCheckBoxCC() throws InterruptedException {
		alertSupCheckBox1.click();
		Thread.sleep(501);
		alertSupCheckBox1.click();
	}

	public boolean displayStatusOfwelcomeMessageCC() throws InterruptedException {
		if (welcomeMessage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(welcomeMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of welcomeMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(welcomeMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of welcomeMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return welcomeMessage.isDisplayed();
	}

	public boolean enableStatusOfwelcomeMessageCC() throws InterruptedException {
		if (welcomeMessage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(welcomeMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of welcomeMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(welcomeMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of welcomeMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return welcomeMessage.isEnabled();
	}

	public void enterDataInwelcomeMessageCC() throws InterruptedException {
		welcomeMessage.click();
		String WelcomeMessage = welcomeMessage.getAttribute("value");
		System.out.println("WelcomeMessage : " + WelcomeMessage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		welcomeMessage.sendKeys(WelcomeMessage);
	}

	public boolean displayStatusOfqueueMessageCC() throws InterruptedException {
		if (queueMessage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(queueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of queueMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(queueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of queueMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return queueMessage.isDisplayed();
	}

	public boolean enableStatusOfqueueMessageCC() throws InterruptedException {
		if (queueMessage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(queueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of queueMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(queueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of queueMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return queueMessage.isEnabled();
	}

	public void enterDataInqueueMessageCC() throws InterruptedException {
		queueMessage.click();
		String QueueMessage = queueMessage.getAttribute("value");
		System.out.println("QueueMessage : " + QueueMessage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		queueMessage.sendKeys(QueueMessage);
	}

	public boolean displayStatusOfagentNAmsgCC() throws InterruptedException {
		if (agentNAmsg.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(agentNAmsg);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of agentNAmsg is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(agentNAmsg);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of agentNAmsg is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return agentNAmsg.isDisplayed();
	}

	public boolean enableStatusOfagentNAmsgCC() throws InterruptedException {
		if (agentNAmsg.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(agentNAmsg);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of agentNAmsg is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(agentNAmsg);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of agentNAmsg is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return agentNAmsg.isEnabled();
	}

	public void enterDataInagentNAmsgCC() throws InterruptedException {
		agentNAmsg.click();
		String AgentNAmsg = agentNAmsg.getAttribute("value");
		System.out.println("AgentNAmsg : " + AgentNAmsg);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		agentNAmsg.sendKeys(AgentNAmsg);
	}

	public boolean displayStatusOfmaxQueueMessageCC() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", maxQueueMessage);
		Thread.sleep(1000);
		if (maxQueueMessage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(maxQueueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of maxQueueMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(maxQueueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of maxQueueMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return maxQueueMessage.isDisplayed();
	}

	public boolean enableStatusOfmaxQueueMessageCC() throws InterruptedException {
		if (maxQueueMessage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(maxQueueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of maxQueueMessage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(maxQueueMessage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of maxQueueMessage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return maxQueueMessage.isEnabled();
	}

	public void enterDataInmaxQueueMessageCC() throws InterruptedException {
		maxQueueMessage.click();
		String MaxQueueMessage = maxQueueMessage.getAttribute("value");
		System.out.println("MaxQueueMessage : " + MaxQueueMessage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		maxQueueMessage.sendKeys(MaxQueueMessage);
	}

	public boolean displayStatusOfclearCC() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", clearCC);
		Thread.sleep(1000);
		if (clearCC.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clearCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clearCC is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clearCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of clearCC is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clearCC.isDisplayed();
	}

	public boolean enableStatusOfclearCC() throws InterruptedException {
		if (clearCC.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(clearCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clearCC is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(clearCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of clearCC is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return clearCC.isEnabled();
	}

	public void clickOnclearCC() throws InterruptedException {
		clearCC.click();
	}

	public boolean displayStatusOfsaveCC() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", saveCC);
		Thread.sleep(1000);
		if (saveCC.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveCC is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveCC is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveCC.isDisplayed();
	}

	public boolean enableStatusOfsaveCC() throws InterruptedException {
		if (saveCC.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveCC is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveCC);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveCC is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveCC.isEnabled();
	}

	public void clickOnsaveCC() throws InterruptedException {
		saveCC.click();
	}

	public boolean displayStatusOfroutingConfiguration() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", routingConfiguration);
		Thread.sleep(1000);
		if (routingConfiguration.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingConfiguration is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingConfiguration is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingConfiguration.isDisplayed();
	}

	public boolean enableStatusOfroutingConfiguration() throws InterruptedException {
		if (routingConfiguration.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingConfiguration is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingConfiguration);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingConfiguration is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingConfiguration.isEnabled();
	}

	public void clickOnroutingConfiguration() throws InterruptedException {
		routingConfiguration.click();
	}

	public boolean displayStatusOfglobalConcurrency() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", globalConcurrency);
		Thread.sleep(1000);
		if (globalConcurrency.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(globalConcurrency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of globalConcurrency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(globalConcurrency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of globalConcurrency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return globalConcurrency.isDisplayed();
	}

	public boolean enableStatusOfglobalConcurrency() throws InterruptedException {
		if (globalConcurrency.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(globalConcurrency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of globalConcurrency is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(globalConcurrency);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of globalConcurrency is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return globalConcurrency.isEnabled();
	}

	public void enterDataInglobalConcurrency() throws InterruptedException {
		globalConcurrency.click();
		String GlobalConcurrency = globalConcurrency.getAttribute("value");
		System.out.println("GlobalConcurrency : " + GlobalConcurrency);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		globalConcurrency.sendKeys(GlobalConcurrency);
	}

	public boolean displayStatusOfchannelWiseConcurrencyRate() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", channelWiseConcurrencyRate);
		Thread.sleep(1000);
		if (channelWiseConcurrencyRate.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelWiseConcurrencyRate);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of channelWiseConcurrencyRate is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelWiseConcurrencyRate);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of channelWiseConcurrencyRate is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelWiseConcurrencyRate.isDisplayed();
	}

	public boolean enableStatusOfchannelWiseConcurrencyRate() throws InterruptedException {
		if (channelWiseConcurrencyRate.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelWiseConcurrencyRate);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelWiseConcurrencyRate is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelWiseConcurrencyRate);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of channelWiseConcurrencyRate is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelWiseConcurrencyRate.isEnabled();
	}

	public void clickOnchannelWiseConcurrencyRate() throws InterruptedException {
		try {
			channelWiseConcurrencyRate.click();
		} catch (Exception e) {
			new Actions(driver).click(channelWiseConcurrencyRate).build().perform();
		}
		Thread.sleep(501);
		try {
			channelWiseConcurrencyRate.click();
		} catch (Exception e) {
			new Actions(driver).click(channelWiseConcurrencyRate).build().perform();
		}
	}

	public boolean displayStatusOfvoice() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", voice);
		Thread.sleep(1000);
		if (voice.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(voice);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of voice is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(voice);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of voice is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return voice.isDisplayed();
	}

	public boolean enableStatusOfvoice() throws InterruptedException {
		if (voice.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(voice);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of voice is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(voice);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of voice is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return voice.isEnabled();
	}

	public void enterDataInvoice() throws InterruptedException {
		voice.click();
		String Voice = voice.getAttribute("value");
		System.out.println("Voice : " + Voice);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		voice.sendKeys(Voice);
	}

	public boolean displayStatusOfchat() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", chat);
		Thread.sleep(1000);
		if (chat.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chat);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chat is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chat);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of chat is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chat.isDisplayed();
	}

	public boolean enableStatusOfchat() throws InterruptedException {
		if (chat.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(chat);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of chat is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(chat);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of chat is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return chat.isEnabled();
	}

	public void enterDataInchat() throws InterruptedException {
		chat.click();
		String Chat = chat.getAttribute("value");
		System.out.println("Chat : " + Chat);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		chat.sendKeys(Chat);
	}

	public boolean displayStatusOfACWTime() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", ACWTime);
		Thread.sleep(1000);
		if (ACWTime.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ACWTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ACWTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ACWTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ACWTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ACWTime.isDisplayed();
	}

	public boolean enableStatusOfACWTime() throws InterruptedException {
		if (ACWTime.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ACWTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ACWTime is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ACWTime);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ACWTime is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ACWTime.isEnabled();
	}

	public void enterDataInACWTime() throws InterruptedException {
		ACWTime.click();
		String ACWtime = ACWTime.getAttribute("value");
		System.out.println("ACWtime : " + ACWtime);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		ACWTime.sendKeys(ACWtime);
	}

	public boolean displayStatusOfroutingAlgorithmDP() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", routingAlgorithmDP);
		Thread.sleep(1000);
		if (routingAlgorithmDP.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmDP);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmDP is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmDP);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmDP is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmDP.isDisplayed();
	}

	public boolean enableStatusOfroutingAlgorithmDP() throws InterruptedException {
		if (routingAlgorithmDP.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmDP);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmDP is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmDP);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmDP is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmDP.isEnabled();
	}

	public void clickOnroutingAlgorithmDPandSelectVAlue(String RoutingAlgorithmDP) throws InterruptedException {
		routingAlgorithmDP.click();
		Thread.sleep(1500);
		driver.findElement(By.xpath("//span[text()='" + RoutingAlgorithmDP + "']")).click();
		Thread.sleep(1000);
//		routingAlgorithmDP.click();
//		Thread.sleep(1500);
//		driver.findElement(By.xpath("//span[text()='"+RoutingAlgorithmDP1+"'")).click();
	}

	public boolean displayStatusOfroutingAlgorithmDP_Eye() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", routingAlgorithmDP_Eye);
		Thread.sleep(1000);
		if (routingAlgorithmDP_Eye.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmDP_Eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmDP_Eye is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmDP_Eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of routingAlgorithmDP_Eye is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmDP_Eye.isDisplayed();
	}

	public boolean enableStatusOfroutingAlgorithmDP_Eye() throws InterruptedException {
		if (routingAlgorithmDP_Eye.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(routingAlgorithmDP_Eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmDP_Eye is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(routingAlgorithmDP_Eye);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of routingAlgorithmDP_Eye is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return routingAlgorithmDP_Eye.isEnabled();
	}

	public void clickOnroutingAlgorithmDP_Eye() throws InterruptedException {
		routingAlgorithmDP_Eye.click();
	}

	public boolean displayStatusOfskillWeightage() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillWeightage);
		Thread.sleep(1000);
		if (skillWeightage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillWeightage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillWeightage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillWeightage.isDisplayed();
	}

	public boolean enableStatusOfskillWeightage() throws InterruptedException {
		if (skillWeightage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillWeightage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillWeightage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillWeightage.isEnabled();
	}

	public void enterDataInskillWeightage() throws InterruptedException {
		skillWeightage.click();
		String SkillWeightage = skillWeightage.getAttribute("value");
		System.out.println("SkillWeightage : " + SkillWeightage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		skillWeightage.sendKeys(SkillWeightage);
	}

	public boolean displayStatusOflanguageWeightage() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", languageWeightage);
		Thread.sleep(1000);
		if (languageWeightage.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageWeightage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of languageWeightage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageWeightage.isDisplayed();
	}

	public boolean enableStatusOflanguageWeightage() throws InterruptedException {
		if (languageWeightage.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(languageWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageWeightage is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(languageWeightage);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of languageWeightage is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return languageWeightage.isEnabled();
	}

	public void enterDataInlanguageWeightage() throws InterruptedException {
		languageWeightage.click();
		String LanguageWeightage = languageWeightage.getAttribute("value");
		System.out.println("LanguageWeightage : " + LanguageWeightage);
		Thread.sleep(501);
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build()
				.perform();
		Thread.sleep(1900);
		languageWeightage.sendKeys(LanguageWeightage);
	}

	public boolean displayStatusOfCANCEL() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", CANCEL);
		Thread.sleep(1000);
		if (CANCEL.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CANCEL);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CANCEL is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CANCEL);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CANCEL is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CANCEL.isDisplayed();
	}

	public boolean enableStatusOfCANCEL() throws InterruptedException {
		if (CANCEL.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CANCEL);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CANCEL is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CANCEL);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CANCEL is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CANCEL.isEnabled();
	}

	public void clickOnCANCEL() throws InterruptedException {
		CANCEL.click();
	}

	public boolean displayStatusOfSAVE() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", SAVE);
		Thread.sleep(1000);
		if (SAVE.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(SAVE);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of SAVE is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(SAVE);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of SAVE is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return SAVE.isDisplayed();
	}

	public boolean enableStatusOfSAVE() throws InterruptedException {
		if (SAVE.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(SAVE);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of SAVE is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(SAVE);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of SAVE is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return SAVE.isEnabled();
	}

	public void clickOnSAVE() throws InterruptedException {
		SAVE.click();
	}

	public boolean displayStatusOfcomplaintType() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", complaintType);
		Thread.sleep(1000);
		if (complaintType.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(complaintType);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of complaintType is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(complaintType);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of complaintType is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return complaintType.isDisplayed();
	}

	public boolean enableStatusOfcomplaintType() throws InterruptedException {
		if (complaintType.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(complaintType);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of complaintType is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(complaintType);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of complaintType is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return complaintType.isEnabled();
	}

	public boolean IsSelectedStatusOfcomplaintTypeBeforeSelectingRadioBtn() throws InterruptedException {
		return complaintType.isSelected();
	}

	public void clickOncomplaintTypeandSelectVAlue() throws InterruptedException {
		try {
			complaintType.click();
		} catch (Exception e) {
			new Actions(driver).click(complaintType).build().perform();
		}
	}

	public boolean IsSelectedStatusOfcomplaintTypeAfterSelectingRadioBtn() throws InterruptedException {
		return complaintType.isSelected();
	}

	public boolean displayStatusOfskillGroup() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", skillGroup);
		Thread.sleep(1000);
		if (skillGroup.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of skillGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillGroup.isDisplayed();
	}

	public boolean enableStatusOfskillGroup() throws InterruptedException {
		if (skillGroup.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(skillGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillGroup is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(skillGroup);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of skillGroup is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return skillGroup.isEnabled();
	}

	public boolean IsSelectedStatusOfskillGroupBeforeSelectingRadioBtn() throws InterruptedException {
		return skillGroup.isSelected();
	}

	public void clickOnskillGroupandSelectVAlue() throws InterruptedException {
		try {
			skillGroup.click();
		} catch (Exception e) {
			new Actions(driver).click(skillGroup).build().perform();
		}
	}

	public boolean IsSelectedStatusOfskillGroupAfterSelectingRadioBtn() throws InterruptedException {
		return skillGroup.isSelected();
	}

	public boolean displayStatusOfChannel() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", Channel);
		Thread.sleep(1000);
		if (Channel.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Channel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Channel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Channel.isDisplayed();
	}

	public boolean enableStatusOfChannel() throws InterruptedException {
		if (Channel.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Channel is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Channel);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Channel is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Channel.isEnabled();
	}

	public boolean IsSelectedStatusOfChannelBeforeSelectingRadioBtn() throws InterruptedException {
		return Channel.isSelected();
	}

	public void clickOnChannel() throws InterruptedException {
		try {
			Channel.click();
		} catch (Exception e) {
			new Actions(driver).click(Channel).build().perform();
		}
	}

	public boolean IsSelectedStatusOfChannelAfterSelectingRadioBtn() throws InterruptedException {
		return Channel.isSelected();
	}

	public boolean displayStatusOfchannelBasedRoutingAll() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", channelBasedRoutingAll);
		Thread.sleep(1000);
		if (channelBasedRoutingAll.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelBasedRoutingAll);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelBasedRoutingAll is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelBasedRoutingAll);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of channelBasedRoutingAll is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelBasedRoutingAll.isDisplayed();
	}

	public boolean enableStatusOfchannelBasedRoutingAll() throws InterruptedException {
		if (channelBasedRoutingAll.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelBasedRoutingAll);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelBasedRoutingAll is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelBasedRoutingAll);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of channelBasedRoutingAll is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelBasedRoutingAll.isEnabled();
	}

	public boolean IsSelectedStatusOfchannelBasedRoutingAllBeforeSelectingRadioBtn() throws InterruptedException {
		return channelBasedRoutingAll.isSelected();
	}

	public void clickOnchannelBasedRoutingAll() throws InterruptedException {
		try {
			channelBasedRoutingAll.click();
		} catch (Exception e) {
			new Actions(driver).click(channelBasedRoutingAll).build().perform();
		}
	}

	public boolean IsSelectedStatusOfchannelBasedRoutingAllAfterSelectingRadioBtn() throws InterruptedException {
		return channelBasedRoutingAll.isSelected();
	}

	public boolean displayStatusOfchannelBasedRoutingIndividual() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", channelBasedRoutingIndividual);
		Thread.sleep(1000);
		if (channelBasedRoutingIndividual.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelBasedRoutingIndividual);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of channelBasedRoutingIndividual is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelBasedRoutingIndividual);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Display Status of channelBasedRoutingIndividual is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelBasedRoutingIndividual.isDisplayed();
	}

	public boolean enableStatusOfchannelBasedRoutingIndividual() throws InterruptedException {
		if (channelBasedRoutingIndividual.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(channelBasedRoutingIndividual);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of channelBasedRoutingIndividual is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(channelBasedRoutingIndividual);
			Thread.sleep(800);
			((JavascriptExecutor) driver)
					.executeScript("alert('Enable Status of channelBasedRoutingIndividual is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return channelBasedRoutingIndividual.isEnabled();
	}

	public boolean IsSelectedStatusOfchannelBasedRoutingIndividualBeforeSelectingRadioBtn()
			throws InterruptedException {
		return channelBasedRoutingIndividual.isSelected();
	}

	public void clickOnchannelBasedRoutingIndividual() throws InterruptedException {
		try {
			channelBasedRoutingIndividual.click();
		} catch (Exception e) {
			new Actions(driver).click(channelBasedRoutingIndividual).build().perform();
		}
	}

	public boolean IsSelectedStatusOfchannelBasedRoutingIndividualAfterSelectingRadioBtn() throws InterruptedException {
		return channelBasedRoutingIndividual.isSelected();
	}

	public boolean displayStatusOfCLEAR() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", CLEAR);
		Thread.sleep(1000);
		if (CLEAR.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CLEAR);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CLEAR is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CLEAR);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of CLEAR is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CLEAR.isDisplayed();
	}

	public boolean enableStatusOfCLEAR() throws InterruptedException {
		if (CLEAR.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(CLEAR);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CLEAR is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(CLEAR);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of CLEAR is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return CLEAR.isEnabled();
	}

	public void clickOnCLEAR() throws InterruptedException {
		try {
			CLEAR.click();
		} catch (Exception e) {
			new Actions(driver).click(CLEAR).build().perform();
		}
	}

	public boolean displayStatusOfSUBMIT() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", SUBMIT);
		Thread.sleep(1000);
		if (SUBMIT.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(SUBMIT);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of SUBMIT is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(SUBMIT);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of SUBMIT is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return SUBMIT.isDisplayed();
	}

	public boolean enableStatusOfSUBMIT() throws InterruptedException {
		if (SUBMIT.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(SUBMIT);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of SUBMIT is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(SUBMIT);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of SUBMIT is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return SUBMIT.isEnabled();
	}

	public void clickOnSUBMIT() throws InterruptedException {
		try {
			SUBMIT.click();
		} catch (Exception e) {
			new Actions(driver).click(SUBMIT).build().perform();
		}
	}

	public boolean displayStatusOfModule_Mapping() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", Module_Mapping);
		Thread.sleep(1000);
		if (Module_Mapping.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Module_Mapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Module_Mapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Module_Mapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Module_Mapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Module_Mapping.isDisplayed();
	}

	public boolean enableStatusOfModule_Mapping() throws InterruptedException {
		if (Module_Mapping.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Module_Mapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Module_Mapping is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Module_Mapping);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Module_Mapping is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Module_Mapping.isEnabled();
	}

	public void clickOnModule_Mapping() throws InterruptedException {
		Module_Mapping.click();
	}
	
	public boolean displayStatusOfModule_Mapping_selectRole() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", Module_Mapping_selectRole);
		Thread.sleep(1000);
		if (Module_Mapping_selectRole.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Module_Mapping_selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Module_Mapping_selectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Module_Mapping_selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of Module_Mapping_selectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Module_Mapping_selectRole.isDisplayed();
	}
	
	public boolean enableStatusOfModule_Mapping_selectRole() throws InterruptedException {
		if (Module_Mapping_selectRole.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(Module_Mapping_selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Module_Mapping_selectRole is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(Module_Mapping_selectRole);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of Module_Mapping_selectRole is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return Module_Mapping_selectRole.isEnabled();
	}
	
	public void clickOnModule_Mapping_selectRoleandSelectValue(String Text) throws InterruptedException {
		Module_Mapping_selectRole.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='"+Text+"']")).click();
	}
	
	public boolean displayStatusOfselectRole_view() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", selectRole_view);
		Thread.sleep(1000);
		if (selectRole_view.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectRole_view);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectRole_view is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectRole_view);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of selectRole_view is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectRole_view.isDisplayed();
	}
	
	public boolean enableStatusOfselectRole_view() throws InterruptedException {
		if (selectRole_view.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(selectRole_view);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectRole_view is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(selectRole_view);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of selectRole_view is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return selectRole_view.isEnabled();
	}
	
	public void clickOnselectRole_viewandSelectValue() throws InterruptedException {
		selectRole_view.click();
	}
	
	public boolean displayStatusOfcheckBox1() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", checkBox1);
		Thread.sleep(1000);
		if (checkBox1.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(checkBox1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of checkBox1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(checkBox1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of checkBox1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return checkBox1.isDisplayed();
	}
	
	public boolean enableStatusOfcheckBox1() throws InterruptedException {
		if (checkBox1.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(checkBox1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of checkBox1 is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(checkBox1);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of checkBox1 is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return checkBox1.isEnabled();
	}
	
	public void clickOncheckBox1andSelectValue() throws InterruptedException {
		Thread.sleep(501);
		try {
			checkBox1.click();
		} catch (Exception e) {
			new Actions(driver).click(checkBox1).build().perform();
		}
		Thread.sleep(1000);
		try {
			checkBox1.click();
		} catch (Exception e) {
			new Actions(driver).click(checkBox1).build().perform();
		}

		
	}
	
	public boolean displayStatusOfChatCondWritecheckBox() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", ChatCondWritecheckBox);
		Thread.sleep(1000);
		if (ChatCondWritecheckBox.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ChatCondWritecheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ChatCondWritecheckBox is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ChatCondWritecheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of ChatCondWritecheckBox is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ChatCondWritecheckBox.isDisplayed();
	}
	
	public boolean enableStatusOfChatCondWritecheckBox() throws InterruptedException {
		if (ChatCondWritecheckBox.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(ChatCondWritecheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ChatCondWritecheckBox is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(ChatCondWritecheckBox);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of ChatCondWritecheckBox is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return ChatCondWritecheckBox.isEnabled();
	}
	
	public void clickOnChatCondWritecheckBoxandSelectValue() throws InterruptedException {
		try {
			ChatCondWritecheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(ChatCondWritecheckBox).build().perform();
		}
	}
	public boolean displayStatusOfsaveModule() throws InterruptedException {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", saveModule);
		Thread.sleep(1000);
		if (saveModule.isDisplayed()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveModule);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveModule is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveModule);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Display Status of saveModule is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveModule.isDisplayed();
	}
	
	public boolean enableStatusOfsaveModule() throws InterruptedException {
		if (saveModule.isEnabled()) {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByGreen(saveModule);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveModule is True')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		} else {
			UtilsLayerPackage.JavaScriptOperation.highlightTestBoxByRed(saveModule);
			Thread.sleep(800);
			((JavascriptExecutor) driver).executeScript("alert('Enable Status of saveModule is False')");
			Thread.sleep(501);
			UtilsLayerPackage.HanldeAlertPopup.click_On_Ok_Button();
			Thread.sleep(800);
		}
		return saveModule.isEnabled();
	}
	
	public void clickOnsaveModuleandSelectValue() throws InterruptedException {
		saveModule.click();
	}
	public void againSameOpeForVerified(String Text1 ,String Text2) throws InterruptedException {
		Thread.sleep(501);
		Module_Mapping_selectRole.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='"+Text1+"']")).click();
		Thread.sleep(501);
		Module_Mapping_selectRole.click();
		Thread.sleep(501);
		driver.findElement(By.xpath("//span[text()='"+Text2+"']")).click();
		Thread.sleep(501);
		selectRole_view.click();		
		Thread.sleep(501);
		try {
			downArrow1.click();
		} catch (Exception e) {
			new Actions(driver).click(downArrow1).build().perform();
		}
		Thread.sleep(501);
		try {
			ChatCondWritecheckBox.click();
		} catch (Exception e) {
			new Actions(driver).click(ChatCondWritecheckBox).build().perform();
		}
		Thread.sleep(501);
		saveModule.click();
		Thread.sleep(501);
		try {
			checkBox1.click();
		} catch (Exception e) {
			new Actions(driver).click(checkBox1).build().perform();
		}
		Thread.sleep(501);
		
	}

}
