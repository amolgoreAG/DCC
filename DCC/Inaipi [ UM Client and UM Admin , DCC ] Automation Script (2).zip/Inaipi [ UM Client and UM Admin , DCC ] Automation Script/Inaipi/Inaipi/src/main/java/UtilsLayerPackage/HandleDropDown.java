package UtilsLayerPackage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import BaseLayerPackage.BaseClass;

public class HandleDropDown extends BaseClass {

	public static void selectByIndex(WebElement wb, int index) {
		new Select(wb).selectByIndex(index);
	}

	public static void selectByValue(WebElement wb, String value) {
		new Select(wb).selectByValue(value);
	}

	public static void selectByVisibleText(WebElement wb, String text) {
		new Select(wb).selectByVisibleText(text);
	}

	public static String to_Know_Which_Value_Seleted(WebElement wb) {
		return new Select(wb).getFirstSelectedOption().getText();
	}

	public static int to_Count_DropDown_Value(WebElement wb) {
		return new Select(wb).getOptions().size();
	}

	public static boolean check_Specific_Value_Present_In_DropDown(WebElement wb, String value) {
		for (WebElement abc : new Select(wb).getOptions()) {
			if (!abc.getText().equalsIgnoreCase(value)) {
				return true;
			}
		}
		return false;
	}

	public static void print_All_Value(WebElement wb) {
		for (WebElement abc : new Select(wb).getOptions()) {
			System.out.println(abc.getText());
		}
	}
}
