package Power_BI_Report;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseLayerPackage.BaseClass;

public class power_BI_report extends BaseClass{
	private static Logger log = Logger.getLogger(power_BI_report.class);

	@FindBy(xpath = "//input[@id='exampleFormControlInput1']")
	WebElement username;
	
	@FindBy(xpath = "//input[@id='exampleFormControlInput2']")
	WebElement password;
	
	@FindBy(xpath = "//div[text()='Login']")
	WebElement login;
	
	@FindBy(xpath = "//button[text()='Logout']")
	WebElement logout;
	
	@FindBy(xpath = "//div[@class='neo-nav-status neo-nav-status--connected ']")
	WebElement status;
	
	@FindBy(xpath = "//button[@class='btn btn-success work-start']")
	WebElement goready;
	
	@FindBy(xpath = "//i[text()='sms']")
	WebElement message;
	
	@FindBy(xpath = "//span[@class='neo-icon-close user-close']")
	WebElement close;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_IDR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_IDR;
	
	@FindBy(xpath = "//button[@aria-label='Month Picker']")
	WebElement MonthAndYear;
	
	@FindBy(xpath = "//button[@aria-label='Previous month']/i")
	WebElement PrevBtn;
	
	@FindBy(xpath = "//button[@aria-label='Next month']/i")
	WebElement NextBtn;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[2]")
	WebElement AgentName_IDR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div")
	WebElement SelectAllAgent_IDR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement SkillSet_IDR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_IDR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[3]")
	WebElement Channel_IDR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[3]/div/div/div)[1]/div/span")
	WebElement SelectAllChannel_IDR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[4]")
	WebElement Disposition_IDR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[4]/div/div/div)[1]/div/span")
	WebElement SelectAllDisposition_IDR;
	
	@FindBy(xpath = "//div[text()='Overall Interaction Report']")
	WebElement Overall_Interaction_Report;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_OIR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_OIR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement AgentName_OIR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_OIR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[2]")
	WebElement SkillSet_OIR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_OIR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[3]")
	WebElement Channel_OIR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[3]/div/div/div)[1]/div/span")
	WebElement SelectAllChannel_OIR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[4]")
	WebElement Language_OIR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[4]/div/div/div)[1]/div/span")
	WebElement SelectAllLanguage_OIR;
	
	@FindBy(xpath = "//div[text()='Interaction Summary Report']")
	WebElement Interaction_Summary_Report;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_ISR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_ISR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement AgentName_ISR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_ISR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[2]")
	WebElement SkillSet_ISR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_ISR;
	
	@FindBy(xpath = "//div[text()='Agent Skill Set Report']")
	WebElement Agent_Skill_set_report;
	

	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_ASSR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_ASSR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement AgentName_ASSR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_ASSR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[2]")
	WebElement SkillSet_ASSR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_ASSR;
	
	@FindBy(xpath = "//div[text()='Month wise performance report']")
	WebElement Month_wise_performance_report;
	
	@FindBy(xpath = "(//div[@class='slicer-dropdown-menu'])[1]")
	WebElement Month;
	
	@FindBy(xpath = "((//div[@class='visibleGroup'])[1]/div/div/div/span)[1]")
	WebElement SelectAllMonth;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[2]")
	WebElement AgentName_MWPR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_MWPR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[3]")
	WebElement SkillSet_MWPR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[3]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_MWPR;
	
	@FindBy(xpath = "//div[text()='Agent Wise Performance Report']")
	WebElement Agent_Wise_Performance_Report;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_AWPR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_AWPR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[2]")
	WebElement AgentName_AWPR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_AWPR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement SkillSet_AWPR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_AWPR;
	
	@FindBy(xpath = "//div[text()='Answered Report']")
	WebElement Answer_Report;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_AR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_AR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement AgentName_AR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_AR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[2]")
	WebElement SkillSet_AR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_AR;
	
	@FindBy(xpath = "//div[text()='Interaction Presentation report']")
	WebElement Interacton_Presentation_Report;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_IPR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_IPR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement SkillSet_IPR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_IPR;
	
	@FindBy(xpath = "//div[text()='Inbound Interaction summary']")
	WebElement Inbound_Interaction_Summary;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_IIR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_IIR;
	
	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement SkillSet_IIR;

	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllSkillSet_IIR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[2]")
	WebElement AgentName_IIR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_IIR;
	
	@FindBy(xpath = "//div[text()='Agent Not Ready Reports']")
	WebElement Agent_Not_Ready_Reports;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_ANRR;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_ANRR;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement AgentName_ANRR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_ANRR;
	
	@FindBy(xpath = "//div[text()='Agent Performance & Statistics']")
	WebElement Agent_Performance_And_Statistics;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement AgentName_APASR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_APASR;
	
	@FindBy(xpath = "//div[text()='Agent Detail Report ']")
	WebElement Agent_Details_Reports;

	@FindBy(xpath = "(//div[@class='slicer-restatement'])[1]")
	WebElement AgentName_ADR;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[1]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_ADR;
	
	@FindBy(xpath = "//div[text()='Overall Dashboard']")
	WebElement Overall_Dashboard;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_OD;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_OD;

	@FindBy(xpath = "((//div[@class='scrollRegion'])[3]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_OD;
	
	@FindBy(xpath = "//button[@data-automation-id='carousel_nextPage']/i")
	WebElement next;
	
	@FindBy(xpath = "//div[text()='Chat Dashbord']")
	WebElement Chat_Dashboard;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_CD;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_CD;

	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_CD;
	
	@FindBy(xpath = "//div[text()='Email Dashboard']")
	WebElement Email_Dashboard;

	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_ED;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_ED;

	@FindBy(xpath = "((//div[@class='scrollRegion'])[3]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_ED;
	
	@FindBy(xpath = "//div[text()='Voice Dashboard']")
	WebElement Voice_Dashboard;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[1]")
	WebElement fromcalender_VD;
	
	@FindBy(xpath = "(//button[@class='calendar-button enter-button'])[2]")
	WebElement Tocalender_VD;
	
	@FindBy(xpath = "((//div[@class='scrollRegion'])[2]/div/div/div)[1]/div/span")
	WebElement SelectAllAgent_VD;
	
	public power_BI_report() {
		PageFactory.initElements(driver, this);
	}
	public void loginInAgentPortal() throws InterruptedException {
		Thread.sleep(5000);
	try {
		username.sendKeys("sarath.k@imperiumapp.com");
		log.info("Enter UserName");
	} catch (Exception e) {
		log.error("Enter UserName showing Error");
	}
	try {
		password.sendKeys("Welcome@123");
		log.info("Enter Password");
	} catch (Exception e) {
		log.error("Enter Password showing Error");
	}
	try {
		login.click();
		log.info("Tab On Login Button");
	} catch (Exception e) {
		log.error("Tab On Login Button Showing Error");
	}
	Thread.sleep(4000);
	String currentUrl = driver.getCurrentUrl();
	System.out.println(currentUrl);
	Thread.sleep(2000);
	if(currentUrl.equalsIgnoreCase("https://dcc.inaipi.ae/main/Dashboard")) {
		Thread.sleep(5000);
		try {
			status.click();
			log.info("Tab On Status Button");
		} catch (Exception e) {
			log.error("Tab On Status Button Showing Error");
		}
		Thread.sleep(2000);
		try {
			goready.click();
			log.info("Tab On Go Ready Button");
		} catch (Exception e) {
			log.error("Tab On Go Ready Button Showing Error");
		}
		Thread.sleep(2000);
		try {
			close.click();
			log.info("Tab On Cross Button");
		} catch (Exception e) {
			log.error("Tab On Cross Button showing error");
		}
		Thread.sleep(2000);
		try {
			message.click();
			log.info("Tab On Message Button");
		} catch (Exception e) {
			log.error("Tab On Message Button shwoing error");
		}
		Thread.sleep(2000);
	}else {
		try {
			logout.click();
			log.info("Agent is already login that why click on logut button");
		} catch (Exception e) {
			log.error("Logout button showing error");
		}
		Thread.sleep(2000);
		try {
			username.sendKeys("sarath.k@imperiumapp.com");
			log.info("Eneter Username");
		} catch (Exception e) {
			log.error("Eneter Username showing error");
		}
		Thread.sleep(2000);
		try {
			password.sendKeys("Welcome@123");
			log.info("Enter Password");
		} catch (Exception e) {
			log.error("Enter Password showing error");
		}
		Thread.sleep(2000);
		try {
			login.click();
			log.info("Tab On Login Button");
		} catch (Exception e) {
			log.error("Tab On Login Button showing error");
		}
		Thread.sleep(2000);
		try {
			status.click();
			log.info("Tab On Status Button");
		} catch (Exception e) {
			log.error("Tab On Status Button showing error");
		}
		Thread.sleep(2000);
		try {
			goready.click();
			log.info("Tab On Go Ready Button");
		} catch (Exception e) {
			log.error("Tab On Go Ready Button showing error");
		}
		Thread.sleep(2000);
		try {
			close.click();
			log.info("Tab On Cross Button");
		} catch (Exception e) {
			log.error("Tab On Cross Button showing error");
		}
		Thread.sleep(2000);
	}
	}
	public void tab_on_power_BI() throws InterruptedException {
		WebElement powerbi = driver.findElement(By.xpath("//li[@id='powerBi_chat_supervisor']/i"));
		try {
			powerbi.click();
			log.info("Tab On Power BI Report Button");
		} catch (Exception e) {
			log.error("Tab On Power BI Report Button showing error");
		}
		Thread.sleep(15000);
		 driver.switchTo().frame(0);
		 Thread.sleep(2000);
	}
	public void interation_details_report() {
		log.info("Now its showing Interaction Detail Report");
	}
	public void fromcalender_IDR() {
		try {
			fromcalender_IDR.click();
			log.info("Open From calender in Interaction Detail Report");
		} catch (Exception e) {
			log.error("From calender showing error");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_IDR() {
		try {
			Tocalender_IDR.click();
			log.info("Open To calender in Interaction Detail Report");
		} catch (Exception e) {
			log.error("To calender showing error");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_IDR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_IDR.click();
		Thread.sleep(5000);
		boolean selected = SelectAllAgent_IDR.isSelected();
		System.out.println("SelectAllAgent_IDR : " + SelectAllAgent_IDR.isSelected());
		if(selected==true) {
			SelectAllAgent_IDR.click();
			log.info("Unselect the all agent from Interaction Detail Report");
		}else {
			log.error("All Agent Are already unselected in Interaction Detail Report");
		}
	
		Thread.sleep(2000);
		if(selected==false) {
			SelectAllAgent_IDR.click();
			log.info("select the All Agent from Interaction Detail Report");
		}else {
			log.error("All Agent Are already selected in Interaction Detail Report");
		}
		
	}
	public void select_SkillSet_TextBox_In_IDR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_IDR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_IDR.click();
		log.info("Unselect the all SkillSet from Interaction Detail Report");
		Thread.sleep(2000);
		SelectAllSkillSet_IDR.click();
		log.info("select the All SkillSet from Interaction Detail Report");
	}
	public void select_Channel_TextBox_In_IDR_and_select_unselect_all_Channel() throws InterruptedException {
		Thread.sleep(2000);
		Channel_IDR.click();
		Thread.sleep(1500);
		SelectAllChannel_IDR.click();
		log.info("Unselect the all Channel from Interaction Detail Report");
		Thread.sleep(2000);
		SelectAllChannel_IDR.click();
		log.info("select the All Channel from Interaction Detail Report");
	}
	public void select_Disposition_TextBox_In_IDR_and_select_unselect_all_Disposition() throws InterruptedException {
		Thread.sleep(2000);
		Disposition_IDR.click();
		Thread.sleep(1500);
		SelectAllDisposition_IDR.click();
		log.info("Unselect the all disposition from Interaction Detail Report");
		Thread.sleep(2000);
		SelectAllDisposition_IDR.click();
		log.info("select the All disposition from Interaction Detail Report");
	}
	public void Open_Overall_Interaction_ReportTest() throws InterruptedException {
		Overall_Interaction_Report.click();
		Thread.sleep(2000);
		log.info("Open Overall Interaction Report");
	}
	public void fromcalender_OIR() {
		try {
			fromcalender_OIR.click();
			log.info("Open From calender in Overall Interaction Report");
		} catch (Exception e) {
			log.error("From calender showing error in Overall Interaction Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_OIR() {
		try {
			Tocalender_OIR.click();
			log.info("Open To calender in Overall Interaction Report");
		} catch (Exception e) {
			log.error("To calender showing error in Overall Interaction Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_OIR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_OIR.click();
		Thread.sleep(1500);
		SelectAllAgent_OIR.click();
		log.info("Unselect the all agent in Overall Interaction Report");
		Thread.sleep(2000);
		SelectAllAgent_OIR.click();
		log.info("select the All Agent in Overall Interaction Report");
	}
	public void select_SkillSet_TextBox_In_OIR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_OIR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_OIR.click();
		log.info("Unselect the all SkillSet in Overall Interaction Report");
		Thread.sleep(2000);
		SelectAllSkillSet_OIR.click();
		log.info("select the All SkillSet in Overall Interaction Report");
	}
	public void select_Channel_TextBox_In_OIR_and_select_unselect_all_Channel() throws InterruptedException {
		Thread.sleep(2000);
		Channel_OIR.click();
		Thread.sleep(1500);
		SelectAllChannel_OIR.click();
		log.info("Unselect the all Channel in Overall Interaction Report");
		Thread.sleep(2000);
		SelectAllChannel_OIR.click();
		log.info("select the All Channel in Overall Interaction Report");
	}
	public void select_Language_TextBox_In_OIR_and_select_unselect_all_Channel() throws InterruptedException {
		Thread.sleep(2000);
		Language_OIR.click();
		Thread.sleep(1500);
		SelectAllLanguage_OIR.click();
		log.info("Unselect the all Channel in Overall Interaction Report");
		Thread.sleep(2000);
		SelectAllLanguage_OIR.click();
		log.info("select the All Channel in Overall Interaction Report");
		Thread.sleep(1500);
	}
	public void Open_Interaction_Summary_Report() throws InterruptedException {
		Interaction_Summary_Report.click();
		Thread.sleep(2000);
		log.info("Open Interaction Summary eport");
	}
	public void fromcalender_ISR() {
		try {
			fromcalender_ISR.click();
			log.info("Open From calender in Interaction_Summary_Report");
		} catch (Exception e) {
			log.error("From calender showing error in Interaction_Summary_Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_ISR() {
		try {
			Tocalender_ISR.click();
			log.info("Open To calender in Interaction_Summary_Report");
		} catch (Exception e) {
			log.error("To calender showing error in Interaction_Summary_Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_ISR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_ISR.click();
		Thread.sleep(1500);
		SelectAllAgent_ISR.click();
		log.info("Unselect the all agent in Interaction_Summary_Report");
		Thread.sleep(2000);
		SelectAllAgent_ISR.click();
		log.info("select the All Agent in Interaction_Summary_Report");
	}
	public void select_SkillSet_TextBox_In_ISR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_ISR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_ISR.click();
		log.info("Unselect the all SkillSet in Interaction_Summary_Report");
		Thread.sleep(2000);
		SelectAllSkillSet_ISR.click();
		log.info("select the All SkillSet in Interaction_Summary_Report");
	}
	public void Open_Agent_Skill_set_report() throws InterruptedException {
		Agent_Skill_set_report.click();
		Thread.sleep(2000);
		log.info("Open Agent Skill Set Report");
	}
	public void fromcalender_ASSR() {
		try {
			fromcalender_ASSR.click();
			log.info("Open From calender in Agent_Skill_set_report");
		} catch (Exception e) {
			log.error("From calender showing error In Agent_Skill_set_report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_ASSR() {
		try {
			Tocalender_ASSR.click();
			log.info("Open To calender In Agent_Skill_set_report");
		} catch (Exception e) {
			log.error("To calender showing error In Agent_Skill_set_report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_ASSR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_ASSR.click();
		Thread.sleep(1500);
		SelectAllAgent_ASSR.click();
		log.info("Unselect the all agent In Agent_Skill_set_report");
		Thread.sleep(2000);
		SelectAllAgent_ASSR.click();
		log.info("select the All Agent In Agent_Skill_set_report");
	}
	public void select_SkillSet_TextBox_In_ASSR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_ASSR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_ASSR.click();
		log.info("Unselect the all SkillSet In Agent_Skill_set_report");
		Thread.sleep(2000);
		SelectAllSkillSet_ASSR.click();
		log.info("select the All SkillSet In Agent_Skill_set_report");
	}
	public void Open_Month_wise_performance_report() throws InterruptedException {
		Month_wise_performance_report.click();
		Thread.sleep(2000);
		log.info("Open the Month wise performance report ");
	}
	public void open_Month() throws InterruptedException {
		Month.click();
		Thread.sleep(2000);
		log.info("Tab On Month In Month_wise_performance_report");
	}
	public void SelectAllMonthTest() throws InterruptedException {
		SelectAllMonth.click();
		Thread.sleep(2000);
		log.info("Unselect All Month In Month_wise_performance_report");
		SelectAllMonth.click();
		Thread.sleep(2000);
		log.info("Select All Month In Month_wise_performance_report");
	}
	public void select_AgentName_TextBox_In_MWPR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_MWPR.click();
		Thread.sleep(1500);
		SelectAllAgent_MWPR.click();
		log.info("Unselect the all agent In Month_wise_performance_report");
		Thread.sleep(2000);
		SelectAllAgent_MWPR.click();
		log.info("select the All Agent In Month_wise_performance_report");
	}
	public void select_SkillSet_TextBox_In_MWPR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_MWPR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_MWPR.click();
		log.info("Unselect the all SkillSet In Month_wise_performance_report");
		Thread.sleep(2000);
		SelectAllSkillSet_MWPR.click();
		log.info("select the All SkillSet In Month_wise_performance_report");
	}
	public void Open_Agent_Wise_Performance_Report() throws InterruptedException {
		Agent_Wise_Performance_Report.click();
		Thread.sleep(2000);
		log.info("Open Agent Wise Performance Report");
	}
	public void fromcalender_AWPR() {
		try {
			fromcalender_AWPR.click();
			log.info("Open From calender in Agent_Wise_Performance_Report");
		} catch (Exception e) {
			log.error("From calender showing error in Agent_Wise_Performance_Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_AWPR() {
		try {
			Tocalender_AWPR.click();
			log.info("Open To calender in Interaction Detail Report In Agent_Wise_Performance_Report");
		} catch (Exception e) {
			log.error("To calender showing error");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_AWPR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_AWPR.click();
		Thread.sleep(1500);
		SelectAllAgent_AWPR.click();
		log.info("Unselect the all agent in Agent_Wise_Performance_Report");
		Thread.sleep(2000);
		SelectAllAgent_AWPR.click();
		log.info("select the All Agent in Agent_Wise_Performance_Report");
	}
	public void select_SkillSet_TextBox_In_AWPR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_AWPR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_AWPR.click();
		log.info("Unselect the all SkillSet in Agent_Wise_Performance_Report");
		Thread.sleep(2000);
		SelectAllSkillSet_AWPR.click();
		log.info("select the All SkillSet in Agent_Wise_Performance_Report");
	}
	public void Open_Answer_ReportTest() throws InterruptedException {
		Answer_Report.click();
		Thread.sleep(2000);
		log.info("Open The Answer Report");
	}
	public void fromcalender_AR() {
		try {
			fromcalender_AR.click();
			log.info("Open From calender in Answer_Report");
		} catch (Exception e) {
			log.error("From calender showing error in Answer_Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_AR() {
		try {
			Tocalender_AR.click();
			log.info("Open To calender in Answer_Report");
		} catch (Exception e) {
			log.error("To calender showing error in Answer_Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_AR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_AR.click();
		Thread.sleep(1500);
		SelectAllAgent_AR.click();
		log.info("Unselect the all agent in Answer_Report");
		Thread.sleep(2000);
		SelectAllAgent_AR.click();
		log.info("select the All Agent in Answer_Report");
	}
	public void select_SkillSet_TextBox_In_AR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_AR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_AR.click();
		log.info("Unselect the all SkillSet in Answer_Report");
		Thread.sleep(2000);
		SelectAllSkillSet_AR.click();
		log.info("select the All SkillSet in Answer_Report");
	}
	public void Open_Interacton_Presentation_ReportTest() throws InterruptedException {
		Interacton_Presentation_Report.click();
		Thread.sleep(2000);
		log.info("Open Interacton_Presentation_Report");
	}
	public void fromcalender_IPR() {
		try {
			fromcalender_IPR.click();
			log.info("Open From calender in Interacton_Presentation_Report");
		} catch (Exception e) {
			log.error("From calender showing error in Interacton_Presentation_Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_IPR() {
		try {
			Tocalender_IPR.click();
			log.info("Open To calender in Interacton_Presentation_Report");
		} catch (Exception e) {
			log.error("To calender showing error in Interacton_Presentation_Report");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_SkillSet_TextBox_In_IPR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_IPR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_IPR.click();
		log.info("Unselect the all SkillSet in Interacton_Presentation_Report");
		Thread.sleep(2000);
		SelectAllSkillSet_IPR.click();
		log.info("select the All SkillSet Interacton_Presentation_Report");
	}
	public void movetonexttable() throws InterruptedException {
		Answer_Report.click();
		Thread.sleep(2000);
		Interacton_Presentation_Report.click();
		Thread.sleep(2000);
		new Actions(driver).keyDown(Keys.ARROW_RIGHT).keyUp(Keys.ARROW_RIGHT).build().perform();
	}
	public void Open_Inbound_Interaction_Summary() throws InterruptedException {
		Inbound_Interaction_Summary.click();
		Thread.sleep(2000);
		log.info("Open Inbound_Interaction_Summary");
	}

	public void fromcalender_IIR() {
		try {
			fromcalender_IPR.click();
			log.info("Open From calender in Inbound_Interaction_Summary");
		} catch (Exception e) {
			log.error("From calender showing error in Inbound_Interaction_Summary");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_IIR() {
		try {
			Tocalender_IIR.click();
			log.info("Open To calender in Inbound_Interaction_Summary");
		} catch (Exception e) {
			log.error("To calender showing error in Inbound_Interaction_Summary");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_SkillSet_TextBox_In_IIR_and_select_unselect_all_SkillSet() throws InterruptedException {
		Thread.sleep(2000);
		SkillSet_IIR.click();
		Thread.sleep(1500);
		SelectAllSkillSet_IIR.click();
		log.info("Unselect the all SkillSet in Inbound_Interaction_Summary");
		Thread.sleep(2000);
		SelectAllSkillSet_IIR.click();
		log.info("select the All SkillSet Inbound_Interaction_Summary");
	}
	public void select_AgentName_TextBox_In_IIR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_IIR.click();
		Thread.sleep(1500);
		SelectAllAgent_IIR.click();
		log.info("Unselect the all agent in Inbound_Interaction_Summary");
		Thread.sleep(2000);
		SelectAllAgent_IIR.click();
		log.info("select the All Agent in Inbound_Interaction_Summary");
	}
	public void Open_Agent_Not_Ready_Reports() throws InterruptedException {
		Agent_Not_Ready_Reports.click();
		Thread.sleep(2000);
		log.info("Open Agent_Not_Ready_Reports");
	}
	public void fromcalender_ANRR() {
		try {
			fromcalender_ANRR.click();
			log.info("Open From calender in Agent_Not_Ready_Reports");
		} catch (Exception e) {
			log.error("From calender showing error in Agent_Not_Ready_Reports");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("(//button[text()=' 29 '])[2]")).click();
	}
	public void Tocalender_ANRR() {
		try {
			Tocalender_ANRR.click();
			log.info("Open To calender in Agent_Not_Ready_Reports");
		} catch (Exception e) {
			log.error("To calender showing error in Agent_Not_Ready_Reports");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 3 ']")).click();
	}
	public void select_AgentName_TextBox_In_ANRR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_ANRR.click();
		Thread.sleep(1500);
		SelectAllAgent_ANRR.click();
		log.info("Unselect the all agent in Agent_Not_Ready_Reports");
		Thread.sleep(2000);
		SelectAllAgent_ANRR.click();
		log.info("select the All Agent in Agent_Not_Ready_Reports");
	}
	public void Opene_Agent_Performance_And_Statistics() throws InterruptedException {
		Agent_Performance_And_Statistics.click();
		Thread.sleep(2000);
		log.info("Open Agent_Performance_And_Statistics");
	}
	public void select_AgentName_TextBox_In_APASR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_APASR.click();
		Thread.sleep(1500);
		SelectAllAgent_APASR.click();
		log.info("Unselect the all agent in Agent_Performance_And_Statistics");
		Thread.sleep(2000);
		SelectAllAgent_APASR.click();
		log.info("select the All Agent in Agent_Performance_And_Statistics");
	}
	public void Open_Agent_Details_Reports() throws InterruptedException {
		Agent_Details_Reports.click();
		Thread.sleep(2000);
		log.info("Opne Agent_Details_Reports");
	}
	public void select_AgentName_TextBox_In_ADR_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(2000);
		AgentName_ADR.click();
		Thread.sleep(1500);
		SelectAllAgent_ADR.click();
		log.info("Unselect the all agent in Agent_Details_Reports");
		Thread.sleep(2000);
		SelectAllAgent_ADR.click();
		log.info("select the All Agent in Agent_Details_Reports");
	}
	public void Open_Overall_Dashboard() throws InterruptedException {
		Overall_Dashboard.click();
		Thread.sleep(2000);
		log.info("Open Overall_Dashboard");
	}
	public void fromcalender_OD() {
		try {
			fromcalender_OD.click();
			log.info("Open From calender in Overall_Dashboard");
		} catch (Exception e) {
			log.error("From calender showing error in Overall_Dashboard");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_OD() {
		try {
			Tocalender_OD.click();
			log.info("Open To calender in Overall_Dashboard");
		} catch (Exception e) {
			log.error("To calender showing error in Overall_Dashboard");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_OD_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(1500);
		SelectAllAgent_OD.click();
		log.info("Unselect the all agent in Overall_Dashboard");
		Thread.sleep(2000);
		SelectAllAgent_OD.click();
		log.info("select the All Agent in Overall_Dashboard");
	}
	public void next() {
		next.click();
	}
	public void Open_Chat_Dashboard() throws InterruptedException {
		Chat_Dashboard.click();
		Thread.sleep(2000);
		log.info("Open Chat_Dashboard");
	}
	public void fromcalender_CD() {
		try {
			fromcalender_CD.click();
			log.info("Open From calender in Chat_Dashboard");
		} catch (Exception e) {
			log.error("From calender showing error in Chat_Dashboard");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 21 ']")).click();
	}
	public void Tocalender_CD() {
		try {
			Tocalender_CD.click();
			log.info("Open To calender in Chat_Dashboard");
		} catch (Exception e) {
			log.error("To calender showing error in Chat_Dashboard");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_CD_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(1500);
		SelectAllAgent_CD.click();
		log.info("Unselect the all agent in Chat_Dashboard");
		Thread.sleep(2000);
		SelectAllAgent_CD.click();
		log.info("select the All Agent in Chat_Dashboard");
	}
	public void Open_Email_Dashboard() throws InterruptedException {
		Email_Dashboard.click();
		Thread.sleep(2000);
		log.info("Open Email_Dashboard");
	}
	public void fromcalender_ED() {
		try {
			fromcalender_ED.click();
			log.info("Open From calender in Email_Dashboard");
		} catch (Exception e) {
			log.error("From calender showing error in Email_Dashboard");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("July 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
			driver.findElement(By.xpath("//button[text()=' 11 ']")).click();
	}
	public void Tocalender_ED() {
		try {
			Tocalender_ED.click();
			log.info("Open To calender in Email_Dashboard");
		} catch (Exception e) {
			log.error("To calender showing error in Email_Dashboard");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 1 ']")).click();
	}
	public void select_AgentName_TextBox_In_ED_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(1500);
		SelectAllAgent_ED.click();
		log.info("Unselect the all agent in Email_Dashboard");
		Thread.sleep(2000);
		SelectAllAgent_ED.click();
		log.info("select the All Agent in Email_Dashboard");
	}
	public void Open_Voice_Dashboard() throws InterruptedException {
		Voice_Dashboard.click();
		Thread.sleep(2000);
		log.info("Open Voice_Dashboard");
	}
	public void fromcalender_VD() {
		try {
			fromcalender_VD.click();
			log.info("Open From calender in Voice_Dashboard");
		} catch (Exception e) {
			log.error("From calender showing error in Voice_Dashboard");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase("June 2023"))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 23 ']")).click();
	}
	public void Tocalender_VD() {
		try {
			Tocalender_VD.click();
			log.info("Open To calender in Voice_Dashboard");
		} catch (Exception e) {
			log.error("To calender showing error in Voice_Dashboard");
		}
		System.out.println("Month And Year : " + MonthAndYear.getText()); 
		MonthAndYear.getText();
		
		while (true) {
			if((MonthAndYear.getText().equalsIgnoreCase(MonthAndYear.getText()))) {
				break;
			}else {
				PrevBtn.click();
//				NextBtn.click();
			}
		}
		driver.findElement(By.xpath("//button[text()=' 25 ']")).click();
	}
	public void select_AgentName_TextBox_In_VD_and_select_unselect_all_agent() throws InterruptedException {
		Thread.sleep(1500);
		SelectAllAgent_VD.click();
		log.info("Unselect the all agent in Voice_Dashboard");
		Thread.sleep(2000);
		SelectAllAgent_VD.click();
		log.info("select the All Agent in Voice_Dashboard");
	}
}
