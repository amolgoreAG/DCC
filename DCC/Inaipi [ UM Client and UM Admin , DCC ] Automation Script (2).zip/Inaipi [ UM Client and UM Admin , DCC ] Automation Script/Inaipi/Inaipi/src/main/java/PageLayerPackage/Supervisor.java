package PageLayerPackage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import BaseLayerPackage.BaseClass;

public class Supervisor extends BaseClass {
	

	@FindBy(xpath = "//input[@id='exampleFormControlInput1']")
	WebElement username;

	@FindBy(xpath = "//input[@id='exampleFormControlInput2']")
	WebElement password;

	@FindBy(xpath = "//div[text()='Login']")
	WebElement login;

	@FindBy(xpath = "//button[text()='Logout']")
	WebElement logout;

	@FindBy(xpath = "//div[@class='neo-nav-status neo-nav-status--connected ']")
	WebElement status;

	@FindBy(xpath = "//button[@class='btn btn-success work-start']")
	WebElement goready;

	@FindBy(xpath = "//span[@class='neo-icon-close user-close']")
	WebElement close;
	
	@FindBy(xpath = "//li[@id='chat_chat_supervisor']")
	WebElement message;
	
	@FindBy(xpath = "//li[@id='Calender_chat_supervisor']/a")
	WebElement calender;
	
	@FindBy(xpath = "//li[@id='sessionreports_chat_supervisor']")
	WebElement sessionReport;
	
	@FindBy(xpath = "//button[text()='Filters']")
	WebElement filter;
	
	@FindBy(xpath = "(//div[@class='mb-3 d-flex flex-column text-start'])[1]/input")
	WebElement fromCalender;
	
	@FindBy(xpath = "(//div[@class='mb-3 d-flex flex-column text-start'])[2]/input")
	WebElement toCalender;
	
	@FindBy(xpath = "(//select[@class='form-select'])[1]")
	WebElement filterStatus;
	
	@FindBy(xpath = "(//select[@class='form-select'])[2]")
	WebElement selectAgent;
	
	@FindBy(xpath = "//button[text()='Submit']")
	WebElement submit;
	
	@FindBy(xpath = "//ul[@class='MuiPagination-ul css-nhb8h9']/li[6]/button//*[2]")
	WebElement nextPage;
	
	@FindBy(xpath = "//ul[@class='MuiPagination-ul css-nhb8h9']/li[6]/button//*[2]")
	WebElement nextPage2;
	
	@FindBy(xpath = "//li[@id='agentreports_chat_supervisor']/a")
	WebElement agentReport;
	
	@FindBy(xpath = "//div[@class='neo-nav-status neo-nav-status--ready']")
	WebElement status1;
	
	@FindBy(xpath = "//button[text()='Finish Work']")
	WebElement finishwork;
	
	@FindBy(xpath = "//span[text()='Sign Out']")
	WebElement signOut;
	
	public Supervisor() {
		PageFactory.initElements(driver, this);
	}

	public boolean displayStatusOfUsername() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(username, "UserName");
		return username.isDisplayed();
	}

	public boolean enableStatusOfUsername() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(username, "UserName");
		return username.isEnabled();
	}

	public boolean displayStatusOfPassword() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(password, "Password");
		return password.isDisplayed();
	}

	public boolean enableStatusOfPassword() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(password, "Password");
		return password.isEnabled();
	}

	public boolean displayStatusOfLogin() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(login, "Login");
		return login.isDisplayed();
	}

	public boolean enableStatusOfLogin() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(login, "Login");
		return login.isEnabled();
	}

	public void enterLoginCredentialandLogin(String Username, String Password) throws InterruptedException {
		username.sendKeys(Username);
		Thread.sleep(2000);
		password.sendKeys(Password);
		Thread.sleep(2000);
		login.click();
		Thread.sleep(2001);
		String currentUrl = driver.getCurrentUrl();
		System.out.println(currentUrl);

		if (currentUrl.equalsIgnoreCase("https://dcc.inaipi.ae/main/Dashboard")) {

		} else {
			logout.click();
			Thread.sleep(2001);
			username.sendKeys(Username);
			Thread.sleep(2001);
			password.sendKeys(Password);
			Thread.sleep(2001);
			login.click();
		}
		System.out.println("Welcome in chat interface home page");

	}

	public boolean displayStatusOfstatus() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(status, "Status");
		return status.isDisplayed();
	}

	public boolean enableStatusOfstatus() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(status, "Status");
		return status.isEnabled();
	}

	public void clickOnstatus() {
		status.click();
	}

	public boolean displayStatusOfgoready() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(goready, "Goready");
		return goready.isDisplayed();
	}

	public boolean enableStatusOfgoready() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(goready, "Goready");
		return goready.isEnabled();
	}

	public void clickOngoready() {
		goready.click();
	}

	public boolean displayStatusOfclose() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(close, "Close");
		return close.isDisplayed();
	}

	public boolean enableStatusOfclose() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(close, "Close");
		return close.isEnabled();
	}

	public void clickOnclose() {
		close.click();
	}
	public boolean displayStatusOfmessage() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(message, "Close");
		return message.isDisplayed();
	}
	
	public boolean enableStatusOfmessage() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(message, "Close");
		return message.isEnabled();
	}
	
	public void clickOnmessage() {
		message.click();
	}
	public boolean displayStatusOfcalender() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(calender, "Close");
		return calender.isDisplayed();
	}
	
	public boolean enableStatusOfcalender() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(calender, "Close");
		return calender.isEnabled();
	}
	
	public void clickOncalender() {
		calender.click();
	}
	public boolean displayStatusOfsessionReport() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(sessionReport, "Close");
		return sessionReport.isDisplayed();
	}
	
	public boolean enableStatusOfsessionReport() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(sessionReport, "Close");
		return sessionReport.isEnabled();
	}
	
	public void clickOnsessionReport() {
		sessionReport.click();
	}
	public boolean displayStatusOffilter() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(filter, "Close");
		return filter.isDisplayed();
	}
	
	public boolean enableStatusOffilter() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(filter, "Close");
		return filter.isEnabled();
	}
	
	public void clickOnfilter() {
		filter.click();
	}
	public boolean displayStatusOffromCalender() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(fromCalender, "Close");
		return fromCalender.isDisplayed();
	}
	
	public boolean enableStatusOffromCalender() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(fromCalender, "Close");
		return fromCalender.isEnabled();
	}
	
	public void clickOnfromCalender() throws InterruptedException {
		fromCalender.click();
		Thread.sleep(3000);
		fromCalender.sendKeys("01");
		Thread.sleep(2000);
		fromCalender.sendKeys("06");
		Thread.sleep(2000);
		fromCalender.sendKeys("2023");
		Thread.sleep(2000);
	}
	public boolean displayStatusOftoCalender() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(toCalender, "Close");
		return toCalender.isDisplayed();
	}
	
	public boolean enableStatusOftoCalender() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(toCalender, "Close");
		return toCalender.isEnabled();
	}
	
	public void clickOntoCalender() throws InterruptedException {
		toCalender.click();
		Thread.sleep(3000);
		toCalender.sendKeys("15");
		Thread.sleep(2000);
		toCalender.sendKeys("06");
		Thread.sleep(2000);
		toCalender.sendKeys("2023");
		Thread.sleep(2000);
	}
	public boolean displayStatusOffilterStatus() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(filterStatus, "Close");
		return filterStatus.isDisplayed();
	}
	
	public boolean enableStatusOffilterStatus() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(filterStatus, "Close");
		return filterStatus.isEnabled();
	}
	
	public void selectfilterStatus(String FilterStatus) throws InterruptedException {
		filterStatus.click();
		Thread.sleep(3000);
		new Select(filterStatus).selectByVisibleText(FilterStatus);
	}
	public boolean displayStatusOfselectAgent() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(selectAgent, "Close");
		return selectAgent.isDisplayed();
	}
	
	public boolean enableStatusOfselectAgent() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(selectAgent, "Close");
		return selectAgent.isEnabled();
	}
	
	public void clickOnselectAgent(String SelectAgent) throws InterruptedException {
		selectAgent.click();
		Thread.sleep(3000);
		new Select(selectAgent).selectByVisibleText(SelectAgent);
	}
	public boolean displayStatusOfsubmit() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(submit, "Close");
		return submit.isDisplayed();
	}
	
	public boolean enableStatusOfsubmit() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(submit, "Close");
		return submit.isEnabled();
	}
	
	public void clickOnsubmit() throws InterruptedException {
		submit.click();
	}
	public boolean displayStatusOfnextPage() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(nextPage, "Close");
		return nextPage.isDisplayed();
	}
	
	public boolean enableStatusOfnextPage() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(nextPage, "Close");
		return nextPage.isEnabled();
	}
	
	public void clickOnnextPage() throws InterruptedException {
		new Actions(driver).click(nextPage).build().perform();
		Thread.sleep(2000);
		new Actions(driver).click(nextPage).build().perform();
	}
	public boolean displayStatusOfagentReport() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(agentReport, "Close");
		return agentReport.isDisplayed();
	}
	
	public boolean enableStatusOfagentReport() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(agentReport, "Close");
		return agentReport.isEnabled();
	}
	
	public void clickOnagentReport() throws InterruptedException {
		agentReport.click();
	}
	public boolean displayStatusOffilter2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(filter, "Close");
		return filter.isDisplayed();
	}
	
	public boolean enableStatusOffilter2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(filter, "Close");
		return filter.isEnabled();
	}
	
	public void clickOnfilter2() {
		filter.click();
	}
	public boolean displayStatusOffromCalender2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(fromCalender, "Close");
		return fromCalender.isDisplayed();
	}
	
	public boolean enableStatusOffromCalender2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(fromCalender, "Close");
		return fromCalender.isEnabled();
	}
	
	public void clickOnfromCalender2() throws InterruptedException {
		fromCalender.click();
		Thread.sleep(3000);
		fromCalender.sendKeys("01");
		Thread.sleep(2000);
		fromCalender.sendKeys("06");
		Thread.sleep(2000);
		fromCalender.sendKeys("2023");
		Thread.sleep(2000);
	}
	public boolean displayStatusOftoCalender2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(toCalender, "Close");
		return toCalender.isDisplayed();
	}
	
	public boolean enableStatusOftoCalender2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(toCalender, "Close");
		return toCalender.isEnabled();
	}
	
	public void clickOntoCalender2() throws InterruptedException {
		toCalender.click();
		Thread.sleep(3000);
		toCalender.sendKeys("15");
		Thread.sleep(2000);
		toCalender.sendKeys("06");
		Thread.sleep(2000);
		toCalender.sendKeys("2023");
		Thread.sleep(2000);
	}
	public boolean displayStatusOfsubmit2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(submit, "Close");
		return submit.isDisplayed();
	}
	
	public boolean enableStatusOfsubmit2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(submit, "Close");
		return submit.isEnabled();
	}
	
	public void clickOnsubmit2() throws InterruptedException {
		submit.click();
	}
	public boolean displayStatusOfnextPage2() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(nextPage2, "Close");
		return nextPage2.isDisplayed();
	}
	
	public boolean enableStatusOfnextPage2() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(nextPage2, "Close");
		return nextPage2.isEnabled();
	}
	
	public void clickOnnextPage2() throws InterruptedException {
		new Actions(driver).click(nextPage2).build().perform();
		Thread.sleep(2000);
		new Actions(driver).click(nextPage2).build().perform();
	}
	public boolean displayStatusOfstatus12() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(status1, "Close");
		return status1.isDisplayed();
	}
	
	public boolean enableStatusOfstatus12() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(status1, "Close");
		return status1.isEnabled();
	}
	
	public void clickOnstatus12() throws InterruptedException {
		status1.click();
	}
	public boolean displayStatusOffinishwork() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(finishwork, "Close");
		return finishwork.isDisplayed();
	}
	
	public boolean enableStatusOffinishwork() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(finishwork, "Close");
		return finishwork.isEnabled();
	}
	
	public void clickOnfinishwork() throws InterruptedException {
		finishwork.click();
	}
	public boolean displayStatusOfsignOut() throws InterruptedException {
		UtilsLayerPackage.displayStatus.DisplayStatus(signOut, "Close");
		return signOut.isDisplayed();
	}
	
	public boolean enableStatusOfsignOut() throws InterruptedException {
		UtilsLayerPackage.enableStatus.EnabledStatus(signOut, "Close");
		return signOut.isEnabled();
	}
	
	public void clickOnsignOut() throws InterruptedException {
		signOut.click();
	}
}
