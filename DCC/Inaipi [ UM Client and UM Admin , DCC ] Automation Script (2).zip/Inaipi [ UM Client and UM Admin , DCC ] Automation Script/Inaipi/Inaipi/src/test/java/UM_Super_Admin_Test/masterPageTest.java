package UM_Super_Admin_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Super_Admin.masterPage;

public class masterPageTest extends BaseClass{

	private static Logger log = Logger.getLogger(masterPageTest.class);
	private static masterPage master;
	
	
	@Test(priority = 43)
	public void displayStatusOfmasterTest() throws InterruptedException {
		master = new masterPage();
		Assert.assertEquals(master.displayStatusOfmaster(), true);
	}

	@Test(priority = 44)
	public void enableStatusOfmasterTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfmaster(), true);
	}

	@Test(priority = 45)
	public void clickOnmasterTest() throws InterruptedException {
		master.clickOnmaster();
		log.info("click on Master");
	}

	@Test(priority = 46)
	public void displayStatusOfchannelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfchannel(), true);
	}

	@Test(priority = 47)
	public void enableStatusOfchannelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfchannel(), true);
	}

	@Test(priority = 48)
	public void clickOnchannelTest() throws InterruptedException {
		master.clickOnchannel();
		log.info("click on channel");
	}

	@Test(priority = 49)
	public void displayStatusOfcreateChannelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreateChannel(), true);
	}

	@Test(priority = 50)
	public void enableStatusOfcreateChannelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreateChannel(), true);
	}

	@Test(priority = 51)
	public void clickOncreateChannelTest() throws InterruptedException {
		master.clickOncreateChannel();
		log.info("click on create channel");
	}

	@Test(priority = 52)
	public void displayStatusOfchannelNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfchannelName(), true);
	}

	@Test(priority = 53)
	public void enableStatusOfchannelNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfchannelName(), true);
	}

	@Test(priority = 54)
	public void enterDataInchannelNameTest() throws InterruptedException {
		String channelName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 8, 1);
		master.enterDataInchannelName(channelName);
		log.info("Enter channel name : " + channelName);
	}

	@Test(priority = 55)
	public void displayStatusOfchannelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfchannelDiscription(), true);
	}

	@Test(priority = 56)
	public void enableStatusOfchannelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfchannelDiscription(), true);
	}

	@Test(priority = 57)
	public void enterDataInchannelDiscriptionTest() throws InterruptedException {
		String channel_Discription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 9, 1);
		master.enterDataInchannelDiscription(channel_Discription);
		log.info("Enter Discription of channel : " + channel_Discription);
	}

	@Test(priority = 58)
	public void displayStatusOfcloseCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcloseCreateChnnel(), true);
	}

	@Test(priority = 59)
	public void enableStatusOfcloseCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcloseCreateChnnel(), true);
	}

//	@Test(priority = 60)
//	public void clickOncloseCreateChnnelTest() throws InterruptedException {
//		master.clickOncloseCreateChnnel();
//	log.info("click on close");
//	}
	@Test(priority = 61)
	public void displayStatusOfcancelCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcancelCreateChnnel(), true);
	}

	@Test(priority = 62)
	public void enableStatusOfcancelCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcancelCreateChnnel(), true);
	}

//	@Test(priority = 63)
//	public void clickOncancelCreateChnnelTest() throws InterruptedException {
//		master.clickOncancelCreateChnnel();
//	}
	@Test(priority = 64)
	public void displayStatusOfsubmitCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfsubmitCreateChnnel(), true);
	}

	@Test(priority = 65)
	public void enableStatusOfsubmitCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfsubmitCreateChnnel(), true);
	}

	@Test(priority = 66)
	public void clickOnsubmitCreateChnnelTest() throws InterruptedException {
		master.clickOnsubmitCreateChnnel();
		log.info("Click on submit the channel");
	}

//	@Test(priority = 66)
//	public void clickOncancelCreateChnnelTest() throws InterruptedException {
//		master.clickOncancelCreateChnnel();
//	}
	@Test(priority = 67)
	public void displayStatusOfeditChannelCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditChannelCreateChnnel(), true);
	}

	@Test(priority = 68)
	public void enableStatusOfeditChannelCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditChannelCreateChnnel(), true);
	}

	@Test(priority = 69)
	public void clickOneditChannelCreateChnnelTest() throws InterruptedException {
		master.clickOneditChannelCreateChnnel();
		log.info("click on edit the channel");
	}

	@Test(priority = 70)
	public void displayStatusOfeditMain_channelNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditMain_channelName(), true);
	}

	@Test(priority = 71)
	public void enableStatusOfeditMain_channelNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditMain_channelName(), true);
	}

	@Test(priority = 72)
	public void enterDataIneditMain_channelNameTest() throws InterruptedException {
		String updatechannelName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 8, 4);
		master.enterDataIneditMain_channelName(updatechannelName);
		log.info("Enter channel name : " + updatechannelName);
	}

	@Test(priority = 73)
	public void displayStatusOfeditMain_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditMain_channelDiscription(), true);
	}

	@Test(priority = 74)
	public void enableStatusOfeditMain_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditMain_channelDiscription(), true);
	}

	@Test(priority = 75)
	public void enterDataIneditMain_channelDiscriptionTest() throws InterruptedException {
		String updatechannelDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 9, 4);
		master.enterDataIneditMain_channelDiscription(updatechannelDiscription);
		log.info("Enter channel Discription : "  +updatechannelDiscription);
	}

	@Test(priority = 76)
	public void displayStatusOfeditMain_closeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditMain_close(), true);
	}

	@Test(priority = 77)
	public void enableStatusOfeditMain_closeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditMain_close(), true);
	}

//	@Test(priority = 78)
//	public void clickOneditMain_closeTest() throws InterruptedException {
//		master.clickOneditMain_close();
//	log.info("close the channel window");
//	}
	@Test(priority = 79)
	public void displayStatusOfeditMain_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditMain_cancel(), true);
	}

	@Test(priority = 80)
	public void enableStatusOfeditMain_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditMain_cancel(), true);
	}

//	@Test(priority = 81)
//	public void clickOneditMain_cancelTest() throws InterruptedException {
//		master.clickOneditMain_cancel();
//	}
	@Test(priority = 82)
	public void displayStatusOfeditMain_updateChannelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditMain_updateChannel(), true);
	}

	@Test(priority = 83)
	public void enableStatusOfeditMain_updateChannelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditMain_updateChannel(), true);
	}

	@Test(priority = 84)
	public void clickOneditMain_updateChannelTest() throws InterruptedException {
		master.clickOneditMain_updateChannel();
		log.info("click on update the channel (update the details)");
	}

	@Test(priority = 85)
	public void displayStatusOfedit_downArrowTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_downArrow(), true);
	}

	@Test(priority = 86)
	public void enableStatusOfedit_downArrowTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_downArrow(), true);
	}

	@Test(priority = 87)
	public void clickOnedit_downArrowTest() throws InterruptedException {
		master.clickOnedit_downArrow();
		log.info("click on down Arrow");
	}

	@Test(priority = 88)
	public void displayStatusOfedit_addSubChannelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_addSubChannel(), true);
	}

	@Test(priority = 89)
	public void enableStatusOfedit_addSubChannelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_addSubChannel(), true);
	}

	@Test(priority = 90)
	public void clickOnedit_addSubChannelTest() throws InterruptedException {
		master.clickOnedit_addSubChannel();
		log.info("click on add subchannel");
	}

	@Test(priority = 91)
	public void displayStatusOfaddsub_channelNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfaddsub_channelName(), true);
	}

	@Test(priority = 92)
	public void enableStatusOfaddsub_channelNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfaddsub_channelName(), true);
	}

	@Test(priority = 93)
	public void enterDataInaddsub_channelNameTest() throws InterruptedException {
	String subchannelName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 12, 1);
		master.enterDataInaddsub_channelName(subchannelName);
		log.info("enter sub channel name : " + subchannelName);
	}

	@Test(priority = 94)
	public void displayStatusOfaddsub_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfaddsub_channelDiscription(), true);
	}

	@Test(priority = 95)
	public void enableStatusOfaddsub_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfaddsub_channelDiscription(), true);
	}

	@Test(priority = 96)
	public void enterDataInaddsub_channelDiscriptionTest() throws InterruptedException {
		String subchannelDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 13, 1);
		master.enterDataInaddsub_channelDiscription(subchannelDiscription);
		log.info("enter suchannel Discription : " + subchannelDiscription);
	}

	@Test(priority = 97)
	public void displayStatusOfaddsub_closeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfaddsub_close(), true);
	}

	@Test(priority = 98)
	public void enableStatusOfaddsub_closeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfaddsub_close(), true);
	}

//	@Test(priority = 99)
//	public void clickOnaddsub_closeTest() throws InterruptedException {
//		master.clickOnaddsub_close();
//	}
	@Test(priority = 100)
	public void displayStatusOfaddsub_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfaddsub_cancel(), true);
	}

	@Test(priority = 101)
	public void enableStatusOfaddsub_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfaddsub_cancel(), true);
	}

//	@Test(priority = 102)
//	public void clickOnaddsub_cancelTest() throws InterruptedException {
//		master.clickOnaddsub_cancel();
//	}
	@Test(priority = 103)
	public void displayStatusOfaddsub_submitTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfaddsub_submit(), true);
	}

	@Test(priority = 104)
	public void enableStatusOfaddsub_submitTets() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfaddsub_submit(), true);
	}

	@Test(priority = 105)
	public void clickOnaddsub_submitTest() throws InterruptedException {
		master.clickOnaddsub_submit();
		log.info("save the subchannel");
	}

	@Test(priority = 106)
	public void displayStatusOfeditsub_editSubChannelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditsub_editSubChannel(), true);
	}

	@Test(priority = 107)
	public void enableStatusOfeditsub_editSubChannelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditsub_editSubChannel(), true);
	}

	@Test(priority = 108)
	public void clickOneditsub_editSubChannelTest() throws InterruptedException {
		master.clickOneditsub_editSubChannel();
		log.info("click on Edit suchannel ");
	}

	@Test(priority = 109)
	public void displayStatusOfeditsub_channelNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditsub_channelName(), true);
	}

	@Test(priority = 110)
	public void enableStatusOfeditsub_channelNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditsub_channelName(), true);
	}

	@Test(priority = 111)
	public void enterDataIneditsub_channelNameTest() throws InterruptedException {
		String updatesubchannelName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 12, 4);
		master.enterDataIneditsub_channelName(updatesubchannelName);
		log.info("enter suchannel name : " + updatesubchannelName);
	}

	@Test(priority = 112)
	public void displayStatusOfeditsub_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditsub_channelDiscription(), true);
	}

	@Test(priority = 113)
	public void enableStatusOfeditsub_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditsub_channelDiscription(), true);
	}

	@Test(priority = 114)
	public void enterDataIneditsub_channelDiscriptionTest() throws InterruptedException {
		String updatesubchannelDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 13, 4);
		master.enterDataIneditsub_channelDiscription(updatesubchannelDiscription);
		log.info("enter suchannel Discription : " + updatesubchannelDiscription);
	}

	@Test(priority = 115)
	public void displayStatusOfeditsub_closeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditsub_close(), true);
	}

	@Test(priority = 116)
	public void enableStatusOfeditsub_closeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditsub_close(), true);
	}

//	@Test(priority = 117)
//	public void clickOneditsub_closeTest() throws InterruptedException {
//		master.clickOneditsub_close();
//	}
	@Test(priority = 118)
	public void displayStatusOfeditsub_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditsub_cancel(), true);
	}

	@Test(priority = 119)
	public void enableStatusOfeditsub_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditsub_cancel(), true);
	}

//	@Test(priority = 120)
//	public void clickOneditsub_cancelTest() throws InterruptedException {
//		master.clickOneditsub_cancel();
//	}
	@Test(priority = 121)
	public void displayStatusOfeditsub_updateChannelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditsub_updateChannel(), true);
	}

	@Test(priority = 122)
	public void enableStatusOfeditsub_updateChannelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditsub_updateChannel(), true);
	}

	@Test(priority = 123)
	public void clickOneditsub_updateChannelTest() throws InterruptedException {
		master.clickOneditsub_updateChannel();
		log.info("update the subchannel ");
	}

	@Test(priority = 124)
	public void displayStatusOfrouterTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfrouter(), true);
	}

	@Test(priority = 125)
	public void enableStatusOfrouterTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfrouter(), true);
	}

	@Test(priority = 126)
	public void clickOnrouterTest() throws InterruptedException {
		master.clickOnrouter();
		log.info("Click on Router");
	}

	@Test(priority = 127)
	public void displayStatusOfcreateRouterTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreateRouter(), true);
	}

	@Test(priority = 128)
	public void enableStatusOfcreateRouterTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreateRouter(), true);
	}

	@Test(priority = 129)
	public void clickOncreateRouterTest() throws InterruptedException {
		master.clickOncreateRouter();
		log.info("Click on create a router");
	}

	@Test(priority = 130)
	public void displayStatusOfrouterNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfrouterName(), true);
	}

	@Test(priority = 131)
	public void enableStatusOfrouterNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfrouterName(), true);
	}

	@Test(priority = 132)
	public void enterDataInrouterNameTest() throws InterruptedException {
		String routerName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 17, 1);
		master.enterDataInrouterName(routerName);
		log.info("enter router name : " + routerName);
	}

	@Test(priority = 133)
	public void displayStatusOfrouterDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfrouterDiscription(), true);
	}

	@Test(priority = 134)
	public void enableStatusOfrouterDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfrouterDiscription(), true);
	}

	@Test(priority = 135)
	public void enterDataInrouterDiscriptionTest() throws InterruptedException {
		String routerDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 18, 1);
		master.enterDataInrouterDiscription(routerDiscription);
		log.info("enter router discription : " + routerDiscription);
	}

	@Test(priority = 136)
	public void displayStatusOfclose1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfclose1(), true);
	}

	@Test(priority = 137)
	public void enableStatusOfclose1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfclose1(), true);
	}

//	@Test(priority = 138)
//	public void clickOnclose1Test() throws InterruptedException {
//		master.clickOnclose1();
//	}
	@Test(priority = 139)
	public void displayStatusOfcancel1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcancel1(), true);
	}

	@Test(priority = 140)
	public void enableStatusOfcancel1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcancel1(), true);
	}

//	@Test(priority = 141)
//	public void clickOncancel1Test() throws InterruptedException {
//		master.clickOncancel1();
//	}
	@Test(priority = 142)
	public void displayStatusOfsubmit1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfsubmit1(), true);
	}

	@Test(priority = 143)
	public void enableStatusOfsubmit1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfsubmit1(), true);
	}

	@Test(priority = 144)
	public void clickOnsubmit1Test() throws InterruptedException {
		master.clickOnsubmit1();
		log.info("click on submit the router");
	}

	@Test(priority = 145)
	public void displayStatusOfeditRouter1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditRouter1(), true);
	}

	@Test(priority = 146)
	public void enableStatusOfeditRouter1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditRouter1(), true);
	}

	@Test(priority = 147)
	public void clickOneditRouter1Test() throws InterruptedException {
		master.clickOneditRouter1();
		log.info("click on update router");
	}

	@Test(priority = 148)
	public void displayStatusOfupdate_routerNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfupdate_routerName(), true);
	}

	@Test(priority = 149)
	public void enableStatusOfupdate_routerNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfupdate_routerName(), true);
	}

	@Test(priority = 150)
	public void enterDataInupdate_routerNameTest() throws InterruptedException {
		String updaterouterName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 17, 4);
		master.enterDataInupdate_routerName(updaterouterName);
		log.info("enter router name : " + updaterouterName);
	}

	@Test(priority = 151)
	public void displayStatusOfupdate_routerDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfupdate_routerDiscription(), true);
	}

	@Test(priority = 152)
	public void enableStatusOfupdate_routerDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfupdate_routerDiscription(), true);
	}

	@Test(priority = 153)
	public void enterDataInupdate_routerDiscriptionTest() throws InterruptedException {
		String updaterouterDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 18, 4);
		master.enterDataInupdate_routerDiscription(updaterouterDiscription);
		log.info("enter router discription : " + updaterouterDiscription);
	}

	@Test(priority = 154)
	public void displayStatusOfupdate_close1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfupdate_close1(), true);
	}

	@Test(priority = 155)
	public void enableStatusOfupdate_close1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfupdate_close1(), true);
	}

//	@Test(priority = 156)
//	public void clickOnupdate_close1Test() throws InterruptedException {
//		master.clickOnupdate_close1();
//	}
	@Test(priority = 157)
	public void displayStatusOfupdate_cancel1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfupdate_cancel1(), true);
	}

	@Test(priority = 158)
	public void enableStatusOfupdate_cancel1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfupdate_cancel1(), true);
	}

//	@Test(priority = 159)
//	public void clickOnupdate_cancel1Test() throws InterruptedException {
//		master.clickOnupdate_cancel1();
//	}
	@Test(priority = 160)
	public void displayStatusOfupdate_updateRouter1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfupdate_updateRouter1(), true);
	}

	@Test(priority = 161)
	public void enableStatusOfupdate_updateRouter1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfupdate_updateRouter1(), true);
	}

	@Test(priority = 162)
	public void clickOnupdate_updateRouter1Test() throws InterruptedException {
		master.clickOnupdate_updateRouter1();
		log.info("click on update router");
	}
}
