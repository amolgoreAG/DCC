package UM_Client_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Client.loginPage;

public class loginPageTest extends BaseClass{

	private static final Logger log = Logger.getLogger(loginPageTest.class);
	public static loginPage login;
	
	@BeforeClass
	public void start() {
		BaseClass.StartingUMClient();
	}

	@Test(priority = 1)
	public void displayStatusOfusernameTest() throws InterruptedException {
		login = new loginPage();
		Assert.assertEquals(login.displayStatusOfusername(), true);
	}

	@Test(priority = 2)
	public void enableStatusOfusernameTest() throws InterruptedException {
		Assert.assertEquals(login.enableStatusOfusername(), true);
	}

	@Test(priority = 3)
	public void enterDataInusernameTest() throws InterruptedException {
//		String username = UtilsLayerPackage.GetDataFromDCCExcel.excel(0, 4, 1);
		login.enterDataInusername("pragadeeswar.j@cognicx.com");
		log.info("Enter Username : " + "pragadeeswar.j@cognicx.com");
		
	}

	@Test(priority = 4)
	public void displayStatusOfpasswordTest() throws InterruptedException {
		Assert.assertEquals(login.displayStatusOfpassword(), true);

	}

	@Test(priority = 5)
	public void enableStatusOfpasswordTest() throws InterruptedException {
		Assert.assertEquals(login.enableStatusOfpassword(), true);

	}

	@Test(priority = 6)
	public void enterDataInpasswordTest() {
		String password = UtilsLayerPackage.GetDataFromDCCExcel.excel(0, 5, 1);
		login.enterDataInpassword(password);
		log.info("Enter Password : " + password);
	}

	@Test(priority = 7)
	public void displayStatusOfeyeTest() throws InterruptedException {
		Assert.assertEquals(login.displayStatusOfeye(), true);

	}

	@Test(priority = 8)
	public void enableStatusOfeyeTest() throws InterruptedException {
		Assert.assertEquals(login.enableStatusOfeye(), true);

	}

	@Test(priority = 9)
	public void clickOnEyeTest() {
		login.clickOnEye();
		log.info("click on eye button");
	}

	@Test(priority = 10)
	public void displayStatusOfloginTest() throws InterruptedException {
		Assert.assertEquals(login.displayStatusOflogin(), true);

	}

	@Test(priority = 11)
	public void enableStatusOfloginTest() throws InterruptedException {
		Assert.assertEquals(login.enableStatusOflogin(), true);

	}

	@Test(priority = 12)
	public void clickOnloginTest() {
		login.clickOnlogin();
		log.info("click on login button");
	}


}
