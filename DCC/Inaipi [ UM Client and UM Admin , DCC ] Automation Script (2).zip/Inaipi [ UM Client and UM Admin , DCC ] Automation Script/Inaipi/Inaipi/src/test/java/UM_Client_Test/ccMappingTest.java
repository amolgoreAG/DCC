package UM_Client_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Client.ccMapping;

public class ccMappingTest extends BaseClass{

	private static Logger log = Logger.getLogger(ccMappingTest.class);
	private static ccMapping ccmap ; 
	@Test(priority = 519)
	public void displayStatusOfccMappingTest() throws InterruptedException {
		ccmap = new ccMapping();
		Assert.assertEquals(ccmap.displayStatusOfccMapping(), true);
	}

	@Test(priority = 520)
	public void enableStatusOfccMappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfccMapping(), true);
	}

	@Test(priority = 521)
	public void clickOnccMappingTest() throws InterruptedException {
		ccmap.clickOnccMapping();
	}

	@Test(priority = 522)
	public void displayStatusOfchannelMappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfchannelMapping(), true);
	}

	@Test(priority = 523)
	public void enableStatusOfchannelMappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfchannelMapping(), true);
	}

	@Test(priority = 524)
	public void clickOnchannelMappingTest() throws InterruptedException {
		ccmap.clickOnchannelMapping();
	}

	@Test(priority = 525)
	public void displayStatusOfCCselectChannelTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCselectChannel(), true);
	}

	@Test(priority = 526)
	public void enableStatusOfCCselectChannelTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCselectChannel(), true);
	}

	@Test(priority = 527)
	public void clickOnCCselectChannelandSelectDPvalueTest() throws InterruptedException {
		ccmap.clickOnCCselectChannelandSelectDPvalue("Chat");
	}

	@Test(priority = 528)
	public void displayStatusOfCCselectSubChannelTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCselectSubChannel(), true);
	}

	@Test(priority = 529)
	public void enableStatusOfCCselectSubChannelTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCselectSubChannel(), true);
	}

	@Test(priority = 530)
	public void clickOnCCselectSubChannelandSelectDPvalueTest() throws InterruptedException {
		ccmap.clickOnCCselectSubChannelandSelectDPvalue("whatsapp");
	}

	@Test(priority = 531)
	public void displayStatusOfCCViewButtonTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCViewButton(), true);
	}

	@Test(priority = 532)
	public void enableStatusOfCCViewButtonTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCViewButton(), true);
	}

	@Test(priority = 533)
	public void clickOnCCViewButtonTest() throws InterruptedException {
		ccmap.clickOnCCViewButton();
	}

	@Test(priority = 534)
	public void displayStatusOfCCaddUserTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCaddUser(), true);
	}

	@Test(priority = 535)
	public void enableStatusOfCCaddUserTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCaddUser(), true);
	}

	@Test(priority = 536)
	public void clickOnCCaddUserTest() throws InterruptedException {
		ccmap.clickOnCCaddUser();
	}

	@Test(priority = 537)
	public void displayStatusOfCCselectUserTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCselectUser(), true);
	}

	@Test(priority = 538)
	public void enableStatusOfCCselectUserTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCselectUser(), true);
	}

	@Test(priority = 539)
	public void clickOnCCselectUserandSelectDPvalueTest() throws InterruptedException {
		ccmap.clickOnCCselectUserandSelectDPvalue();
	}

	@Test(priority = 540)
	public void displayStatusOfCCsaveUserTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCsaveUser(), true);
	}

	@Test(priority = 541)
	public void enableStatusOfCCsaveUserTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCsaveUser(), true);
	}

	@Test(priority = 542)
	public void clickOnCCsaveUserTest() throws InterruptedException {
		ccmap.clickOnCCsaveUser();
	}

	@Test(priority = 543)
	public void displayStatusOfCCnextPageTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCnextPage(), true);
	}

	@Test(priority = 544)
	public void enableStatusOfCCnextPageTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCnextPage(), true);
	}

	@Test(priority = 545)
	public void clickOnCCnextPageTest() throws InterruptedException {
		ccmap.clickOnCCnextPage();
	}

	@Test(priority = 546)
	public void displayStatusOfCCremoveUserTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUser(), true);
	}

	@Test(priority = 547)
	public void enableStatusOfCCremoveUserTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUser(), true);
	}

	@Test(priority = 548)
	public void clickOnCCremoveUserTest() throws InterruptedException {
		ccmap.clickOnCCremoveUser();
	}

	@Test(priority = 549)
	public void displayStatusOfCCremoveUserNOTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUserNO(), true);
	}

	@Test(priority = 550)
	public void enableStatusOfCCremoveUserNOTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUserNO(), true);
	}

//	@Test(priority = 551)
//	public void clickOnCCremoveUserNOTest() throws InterruptedException {
//		ccmap.clickOnCCremoveUserNO();
//	}
	@Test(priority = 552)
	public void displayStatusOfCCremoveUserYESTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUserYES(), true);
	}

	@Test(priority = 553)
	public void enableStatusOfCCremoveUserYESTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUserYES(), true);
	}

	@Test(priority = 554)
	public void clickOnCCremoveUserYESTest() throws InterruptedException {
		ccmap.clickOnCCremoveUserYES();
	}

	@Test(priority = 555)
	public void displayStatusOfskillsetMappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfskillsetMapping(), true);
	}

	@Test(priority = 556)
	public void enableStatusOfskillsetMappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfskillsetMapping(), true);
	}

	@Test(priority = 557)
	public void clickOnskillsetMappingTest() throws InterruptedException {
		ccmap.clickOnskillsetMapping();
	}

	@Test(priority = 558)
	public void displayStatusOfCCskillSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCskillSM(), true);
	}

	@Test(priority = 559)
	public void enableStatusOfCCskillSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCskillSM(), true);
	}

	@Test(priority = 560)
	public void clickOnCCskillandSelectDPvalueSMTest() throws InterruptedException {
		ccmap.clickOnCCskillandSelectDPvalueSM("HR");
	}

	@Test(priority = 561)
	public void displayStatusOfCCskillProficiencySMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCskillProficiencySM(), true);
	}

	@Test(priority = 562)
	public void enableStatusOfCCskillProficiencySMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCskillProficiencySM(), true);
	}

	@Test(priority = 563)
	public void clickOnCCskillProficiencyandSelectDPvalueSMTest() throws InterruptedException {
		ccmap.clickOnCCskillProficiencyandSelectDPvalueSM("Proficient");
	}

	@Test(priority = 564)
	public void displayStatusOfCCViewButtonSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCViewButtonSM(), true);
	}

	@Test(priority = 565)
	public void enableStatusOfCCViewButtonSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCViewButtonSM(), true);
	}

	@Test(priority = 566)
	public void clickOnCCViewButtonSMTest() throws InterruptedException {
		ccmap.clickOnCCViewButtonSM();
	}

	@Test(priority = 567)
	public void displayStatusOfCCaddUserSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCaddUserSM(), true);
	}

	@Test(priority = 568)
	public void enableStatusOfCCaddUserSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCaddUserSM(), true);
	}

	@Test(priority = 569)
	public void clickOnCCaddUserSMTest() throws InterruptedException {
		ccmap.clickOnCCaddUserSM();
	}

	@Test(priority = 570)
	public void displayStatusOfCCselectUserSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCselectUserSM(), true);
	}

	@Test(priority = 571)
	public void enableStatusOfCCselectUserSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCselectUserSM(), true);
	}

	@Test(priority = 572)
	public void clickOnCCselectUserandSelectDPvalueSMTest() throws InterruptedException {
		ccmap.clickOnCCselectUserandSelectDPvalueSM();
	}

	@Test(priority = 573)
	public void displayStatusOfCCsaveUserSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCsaveUserSM(), true);
	}

	@Test(priority = 574)
	public void enableStatusOfCCsaveUserSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCsaveUserSM(), true);
	}

	@Test(priority = 575)
	public void clickOnCCsaveUserSMTest() throws InterruptedException {
		ccmap.clickOnCCsaveUserSM();
	}

	@Test(priority = 576)
	public void displayStatusOfCCnextPageSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCnextPageSM(), true);
	}

	@Test(priority = 577)
	public void enableStatusOfCCnextPageSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCnextPageSM(), true);
	}

	@Test(priority = 578)
	public void clickOnCCnextPageSMTest() throws InterruptedException {
		ccmap.clickOnCCnextPageSM();
	}

	@Test(priority = 579)
	public void displayStatusOfCCremoveUserSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUserSM(), true);
	}

	@Test(priority = 580)
	public void enableStatusOfCCremoveUserSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUserSM(), true);
	}

	@Test(priority = 581)
	public void clickOnCCremoveUserSMTest() throws InterruptedException {
		ccmap.clickOnCCremoveUserSM();
	}

	@Test(priority = 582)
	public void displayStatusOfCCremoveUserNOSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUserNOSM(), true);
	}

	@Test(priority = 583)
	public void enableStatusOfCCremoveUserNOSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUserNOSM(), true);
	}

//	@Test(priority = 584)
//	public void clickOnCCremoveUserNOSMTest() throws InterruptedException {
//		ccmap.clickOnCCremoveUserNOSM();
//	}
	@Test(priority = 585)
	public void displayStatusOfCCremoveUserYESSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUserYESSM(), true);
	}

	@Test(priority = 586)
	public void enableStatusOfCCremoveUserYESSMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUserYESSM(), true);
	}

	@Test(priority = 587)
	public void clickOnCCremoveUserYESSMTest() throws InterruptedException {
		ccmap.clickOnCCremoveUserYESSM();
	}

	@Test(priority = 588)
	public void displayStatusOflanguageMappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOflanguageMapping(), true);
	}

	@Test(priority = 589)
	public void enableStatusOflanguageMappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOflanguageMapping(), true);
	}

	@Test(priority = 590)
	public void clickOnlanguageMappingTest() throws InterruptedException {
		ccmap.clickOnlanguageMapping();
	}

	@Test(priority = 591)
	public void displayStatusOfCClanguageLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCClanguageLM(), true);
	}

	@Test(priority = 592)
	public void enableStatusOfCClanguageLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCClanguageLM(), true);
	}

	@Test(priority = 593)
	public void clickOnCClanguageandSelectDPvalueLMTest() throws InterruptedException {
		ccmap.clickOnCClanguageandSelectDPvalueLM("Hindi");
	}

	@Test(priority = 594)
	public void displayStatusOfCClanguageProficiencyLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCClanguageProficiencyLM(), true);
	}

	@Test(priority = 595)
	public void enableStatusOfCClanguageProficiencyLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCClanguageProficiencyLM(), true);
	}

	@Test(priority = 596)
	public void clickOnCClanguageProficiencyandSelectDPvalueLMTest() throws InterruptedException {
		ccmap.clickOnCClanguageProficiencyandSelectDPvalueLM("Proficient ");
	}

	@Test(priority = 597)
	public void displayStatusOfCCViewButtonLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCViewButtonLM(), true);
	}

	@Test(priority = 598)
	public void enableStatusOfCCViewButtonLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCViewButtonLM(), true);
	}

	@Test(priority = 599)
	public void clickOnCCViewButtonLMTest() throws InterruptedException {
		ccmap.clickOnCCViewButtonLM();
	}

	@Test(priority = 600)
	public void displayStatusOfCCaddUserLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCaddUserLM(), true);
	}

	@Test(priority = 601)
	public void enableStatusOfCCaddUserLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCaddUserLM(), true);
	}

	@Test(priority = 602)
	public void clickOnCCaddUserLMTest() throws InterruptedException {
		ccmap.clickOnCCaddUserLM();
	}

	@Test(priority = 603)
	public void displayStatusOfCCselectUserLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCselectUserLM(), true);
	}

	@Test(priority = 604)
	public void enableStatusOfCCselectUserLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCselectUserLM(), true);
	}

	@Test(priority = 605)
	public void clickOnCCselectUserandSelectDPvalueLMTest() throws InterruptedException {
		ccmap.clickOnCCselectUserandSelectDPvalueLM();
	}

	@Test(priority = 606)
	public void displayStatusOfCCsaveUserLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCsaveUserLM(), true);
	}

	@Test(priority = 607)
	public void enableStatusOfCCsaveUserLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCsaveUserLM(), true);
	}

	@Test(priority = 608)
	public void clickOnCCsaveUserLMTest() throws InterruptedException {
		ccmap.clickOnCCsaveUserLM();
	}

	@Test(priority = 609)
	public void displayStatusOfCCnextPageLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCnextPageLM(), true);
	}

	@Test(priority = 610)
	public void enableStatusOfCCnextPageLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCnextPageLM(), true);
	}

	@Test(priority = 611)
	public void clickOnCCnextPageLMTest() throws InterruptedException {
		ccmap.clickOnCCnextPageLM();
	}

	@Test(priority = 612)
	public void displayStatusOfCCremoveUserLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUserLM(), true);
	}

	@Test(priority = 613)
	public void enableStatusOfCCremoveUserLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUserLM(), true);
	}

	@Test(priority = 614)
	public void clickOnCCremoveUserLMTest() throws InterruptedException {
		ccmap.clickOnCCremoveUserLM();
	}

	@Test(priority = 615)
	public void displayStatusOfCCremoveUserNOLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUserNOLM(), true);
	}

	@Test(priority = 616)
	public void enableStatusOfCCremoveUserNOLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUserNOLM(), true);
	}

//	@Test(priority = 617)
//	public void clickOnCCremoveUserNOLMTest() throws InterruptedException {
//		ccmap.clickOnCCremoveUserNOLM();
//	}
	@Test(priority = 618)
	public void displayStatusOfCCremoveUserYESLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCCremoveUserYESLM(), true);
	}

	@Test(priority = 619)
	public void enableStatusOfCCremoveUserYESLMTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCCremoveUserYESLM(), true);
	}

	@Test(priority = 620)
	public void clickOnCCremoveUserYESLMTest() throws InterruptedException {
		ccmap.clickOnCCremoveUserYESLM();
	}

	@Test(priority = 621)
	public void displayStatusOfchatConfigurationCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfchatConfigurationCC(), true);
	}

	@Test(priority = 622)
	public void enableStatusOfchatConfigurationCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfchatConfigurationCC(), true);
	}

	@Test(priority = 623)
	public void clickOnchatConfigurationCCTest() throws InterruptedException {
		ccmap.clickOnchatConfigurationCC();
	}

	@Test(priority = 624)
	public void displayStatusOfautoRejectTimeCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfautoRejectTimeCC(), true);
	}

	@Test(priority = 625)
	public void enableStatusOfautoRejectTimeCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfautoRejectTimeCC(), true);
	}

	@Test(priority = 626)
	public void enterDataInautoRejectTimeCCTest() throws InterruptedException {
		ccmap.enterDataInautoRejectTimeCC();
	}

	@Test(priority = 627)
	public void displayStatusOfagentIdleChangeStatusTimeCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfagentIdleChangeStatusTimeCC(), true);
	}

	@Test(priority = 628)
	public void enableStatusOfagentIdleChangeStatusTimeCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfagentIdleChangeStatusTimeCC(), true);
	}

	@Test(priority = 629)
	public void enterDataInagentIdleChangeStatusTimeCCTest() throws InterruptedException {
		ccmap.enterDataInagentIdleChangeStatusTimeCC();
	}

	@Test(priority = 630)
	public void displayStatusOfmaxRequestInQueueCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfmaxRequestInQueueCC(), true);
	}

	@Test(priority = 631)
	public void enableStatusOfmaxRequestInQueueCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfmaxRequestInQueueCC(), true);
	}

	@Test(priority = 632)
	public void enterDataInmaxRequestInQueueCCTest() throws InterruptedException {
		ccmap.enterDataInmaxRequestInQueueCC();
	}

	@Test(priority = 633)
	public void displayStatusOfalertSupCheckBoxCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfalertSupCheckBoxCC(), true);
	}

	@Test(priority = 634)
	public void enableStatusOfalertSupCheckBoxCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfalertSupCheckBoxCC(), true);
	}

	@Test(priority = 635)
	public void clickOnalertSupCheckBoxCCTest() throws InterruptedException {
		ccmap.clickOnalertSupCheckBoxCC();
	}

	@Test(priority = 636)
	public void displayStatusOfwelcomeMessageCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfwelcomeMessageCC(), true);
	}

	@Test(priority = 637)
	public void enableStatusOfwelcomeMessageCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfwelcomeMessageCC(), true);
	}

	@Test(priority = 638)
	public void enterDataInwelcomeMessageCCTest() throws InterruptedException {
		ccmap.enterDataInwelcomeMessageCC();
	}

	@Test(priority = 639)
	public void displayStatusOfqueueMessageCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfqueueMessageCC(), true);
	}

	@Test(priority = 640)
	public void enableStatusOfqueueMessageCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfqueueMessageCC(), true);
	}

	@Test(priority = 641)
	public void enterDataInqueueMessageCCTest() throws InterruptedException {
		ccmap.enterDataInqueueMessageCC();
	}

	@Test(priority = 642)
	public void displayStatusOfagentNAmsgCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfagentNAmsgCC(), true);
	}

	@Test(priority = 643)
	public void enableStatusOfagentNAmsgCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfagentNAmsgCC(), true);
	}

	@Test(priority = 644)
	public void enterDataInagentNAmsgCCTest() throws InterruptedException {
		ccmap.enterDataInagentNAmsgCC();
	}

	@Test(priority = 645)
	public void displayStatusOfmaxQueueMessageCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfmaxQueueMessageCC(), true);
	}

	@Test(priority = 646)
	public void enableStatusOfmaxQueueMessageCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfmaxQueueMessageCC(), true);
	}

	@Test(priority = 647)
	public void enterDataInmaxQueueMessageCCTest() throws InterruptedException {
		ccmap.enterDataInmaxQueueMessageCC();
	}

	@Test(priority = 648)
	public void displayStatusOfclearCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfclearCC(), true);
	}

	@Test(priority = 649)
	public void enableStatusOfclearCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfclearCC(), true);
	}

//	@Test(priority = 650)
//	public void clickOnclearCCTest() throws InterruptedException {
//		ccmap.clickOnclearCC();
//	}
	@Test(priority = 651)
	public void displayStatusOfsaveCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfsaveCC(), true);
	}

	@Test(priority = 652)
	public void enableStatusOfsaveCCTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfsaveCC(), true);
	}

	@Test(priority = 653)
	public void clickOnsaveCCTest() throws InterruptedException {
		ccmap.clickOnsaveCC();
	}

	@Test(priority = 654)
	public void displayStatusOfroutingConfigurationTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfroutingConfiguration(), true);
	}

	@Test(priority = 655)
	public void enableStatusOfroutingConfigurationTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfroutingConfiguration(), true);
	}

	@Test(priority = 656)
	public void clickOnroutingConfigurationTest() throws InterruptedException {
		ccmap.clickOnroutingConfiguration();
	}

	@Test(priority = 657)
	public void displayStatusOfglobalConcurrencyTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfglobalConcurrency(), true);
	}

	@Test(priority = 658)
	public void enableStatusOfglobalConcurrencyTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfglobalConcurrency(), true);
	}

	@Test(priority = 659)
	public void enterDataInglobalConcurrencyTest() throws InterruptedException {
		ccmap.enterDataInglobalConcurrency();
	}

	@Test(priority = 660)
	public void displayStatusOfchannelWiseConcurrencyRateTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfchannelWiseConcurrencyRate(), true);
	}

	@Test(priority = 661)
	public void enableStatusOfchannelWiseConcurrencyRateTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfchannelWiseConcurrencyRate(), true);
	}

	@Test(priority = 662)
	public void clickOnchannelWiseConcurrencyRateTest() throws InterruptedException {
		ccmap.clickOnchannelWiseConcurrencyRate();
	}

	@Test(priority = 663)
	public void displayStatusOfvoiceTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfvoice(), true);
	}

	@Test(priority = 664)
	public void enableStatusOfvoiceTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfvoice(), true);
	}

	@Test(priority = 665)
	public void enterDataInvoiceTest() throws InterruptedException {
		ccmap.enterDataInvoice();
	}

	@Test(priority = 666)
	public void displayStatusOfchatTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfchat(), true);
	}

	@Test(priority = 667)
	public void enableStatusOfchatTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfchat(), true);
	}

	@Test(priority = 668)
	public void enterDataInchatTest() throws InterruptedException {
		ccmap.enableStatusOfchat();
	}

	@Test(priority = 669)
	public void displayStatusOfACWTimeTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfACWTime(), true);
	}

	@Test(priority = 670)
	public void enableStatusOfACWTimeTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfACWTime(), true);
	}

	@Test(priority = 671)
	public void enterDataInACWTimeTest() throws InterruptedException {
		ccmap.enterDataInACWTime();
	}

	@Test(priority = 672)
	public void displayStatusOfroutingAlgorithmDPTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfroutingAlgorithmDP(), true);
	}

	@Test(priority = 673)
	public void enableStatusOfroutingAlgorithmDPTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfroutingAlgorithmDP(), true);
	}

	@Test(priority = 674)
	public void clickOnroutingAlgorithmDPandSelectVAlueTest() throws InterruptedException {
		ccmap.clickOnroutingAlgorithmDPandSelectVAlue("Round Robin");
		Thread.sleep(2000);
		ccmap.clickOnroutingAlgorithmDPandSelectVAlue("Precision Routing");
	}

	@Test(priority = 675)
	public void displayStatusOfroutingAlgorithmDP_EyeTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfroutingAlgorithmDP_Eye(), true);
	}

	@Test(priority = 676)
	public void enableStatusOfroutingAlgorithmDP_EyeTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfroutingAlgorithmDP_Eye(), true);
	}

	@Test(priority = 677)
	public void clickOnroutingAlgorithmDP_EyeTest() throws InterruptedException {
		ccmap.clickOnroutingAlgorithmDP_Eye();
	}

	@Test(priority = 678)
	public void displayStatusOfskillWeightageTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfskillWeightage(), true);
	}

	@Test(priority = 679)
	public void enableStatusOfskillWeightageTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfskillWeightage(), true);
	}

	@Test(priority = 680)
	public void enterDataInskillWeightageTest() throws InterruptedException {
		ccmap.enterDataInskillWeightage();
	}

	@Test(priority = 681)
	public void displayStatusOflanguageWeightageTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOflanguageWeightage(), true);
	}

	@Test(priority = 682)
	public void enableStatusOflanguageWeightageTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOflanguageWeightage(), true);
	}

	@Test(priority = 683)
	public void enterDataInlanguageWeightageTest() throws InterruptedException {
		ccmap.enterDataInlanguageWeightage();
	}

	@Test(priority = 684)
	public void displayStatusOfCANCELTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCANCEL(), true);
	}

	@Test(priority = 685)
	public void enableStatusOfCANCELTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCANCEL(), true);
	}

//	@Test(priority = 686)
//	public void clickOnCANCELTest() throws InterruptedException {
//		ccmap.clickOnCANCEL();
//	}
	@Test(priority = 687)
	public void displayStatusOfSAVETest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfSAVE(), true);
	}

	@Test(priority = 688)
	public void enableStatusOfSAVETest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfSAVE(), true);
	}

	@Test(priority = 689)
	public void clickOnSAVETest() throws InterruptedException {
		ccmap.clickOnSAVE();
	}

	@Test(priority = 690)
	public void displayStatusOfcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfcomplaintType(), true);
	}

	@Test(priority = 691)
	public void enableStatusOfcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfcomplaintType(), true);
	}

	@Test(priority = 692)
	public void IsSelectedStatusOfcomplaintTypeBeforeSelectingRadioBtnTest() throws InterruptedException {
		Assert.assertEquals(ccmap.IsSelectedStatusOfcomplaintTypeBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 693)
	public void clickOncomplaintTypeandSelectVAlueTest() throws InterruptedException {
		ccmap.clickOncomplaintTypeandSelectVAlue();
	}

//	@Test(priority = 694)
//	public void IsSelectedStatusOfcomplaintTypeAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(ccmap.IsSelectedStatusOfcomplaintTypeAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 695)
	public void displayStatusOfskillGroupTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfskillGroup(), true);
	}

	@Test(priority = 696)
	public void enableStatusOfskillGroupTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfskillGroup(), true);
	}

	@Test(priority = 697)
	public void IsSelectedStatusOfskillGroupBeforeSelectingRadioBtnTest() throws InterruptedException {
		Assert.assertEquals(ccmap.IsSelectedStatusOfskillGroupBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 698)
	public void clickOnskillGroupandSelectVAlueTest() throws InterruptedException {
		ccmap.clickOnskillGroupandSelectVAlue();
	}

//	@Test(priority = 699)
//	public void IsSelectedStatusOfskillGroupAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(ccmap.IsSelectedStatusOfskillGroupAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 700)
	public void displayStatusOfChannelTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfChannel(), true);
	}

	@Test(priority = 701)
	public void enableStatusOfChannelTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfChannel(), true);
	}

	@Test(priority = 702)
	public void IsSelectedStatusOfChannelBeforeSelectingRadioBtnTest() throws InterruptedException {
		Assert.assertEquals(ccmap.IsSelectedStatusOfChannelBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 703)
	public void clickOnChannelTest() throws InterruptedException {
		ccmap.clickOnChannel();
	}

//	@Test(priority = 704)
//	public void IsSelectedStatusOfChannelAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(ccmap.IsSelectedStatusOfChannelAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 705)
	public void displayStatusOfchannelBasedRoutingAllTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfchannelBasedRoutingAll(), true);
	}

	@Test(priority = 706)
	public void enableStatusOfchannelBasedRoutingAllTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfchannelBasedRoutingAll(), true);
	}

	@Test(priority = 707)
	public void IsSelectedStatusOfchannelBasedRoutingAllBeforeSelectingRadioBtnTest() throws InterruptedException {
		Assert.assertEquals(ccmap.IsSelectedStatusOfchannelBasedRoutingAllBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 708)
	public void clickOnchannelBasedRoutingAllTest() throws InterruptedException {
		ccmap.clickOnchannelBasedRoutingAll();
	}

//	@Test(priority = 709)
//	public void IsSelectedStatusOfchannelBasedRoutingAllAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(ccmap.IsSelectedStatusOfchannelBasedRoutingAllAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 710)
	public void displayStatusOfchannelBasedRoutingIndividualTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfchannelBasedRoutingIndividual(), true);
	}

	@Test(priority = 711)
	public void enableStatusOfchannelBasedRoutingIndividualTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfchannelBasedRoutingIndividual(), true);
	}

	@Test(priority = 712)
	public void IsSelectedStatusOfchannelBasedRoutingIndividualBeforeSelectingRadioBtnTest()
			throws InterruptedException {
		Assert.assertEquals(ccmap.IsSelectedStatusOfchannelBasedRoutingIndividualBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 713)
	public void clickOnchannelBasedRoutingIndividualTest() throws InterruptedException {
		ccmap.clickOnchannelBasedRoutingIndividual();
	}

//	@Test(priority = 714)
//	public void IsSelectedStatusOfchannelBasedRoutingIndividualAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(ccmap.IsSelectedStatusOfchannelBasedRoutingIndividualAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 715)
	public void displayStatusOfCLEARTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfCLEAR(), true);
	}

	@Test(priority = 716)
	public void enableStatusOfCLEARTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfCLEAR(), true);
	}

//	@Test(priority = 717)
//	public void clickOnCLEARTest() throws InterruptedException {
//		ccmap.clickOnCLEAR();
//	}
	@Test(priority = 718)
	public void displayStatusOfSUBMITTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfSUBMIT(), true);
	}

	@Test(priority = 719)
	public void enableStatusOfSUBMITTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfSUBMIT(), true);
	}

	@Test(priority = 720)
	public void clickOnSUBMITTest() throws InterruptedException {
		ccmap.clickOnSUBMIT();
	}

	@Test(priority = 721)
	public void displayStatusOfModule_MappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfModule_Mapping(), true);
	}

	@Test(priority = 722)
	public void enableStatusOfModule_MappingTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfModule_Mapping(), true);
	}

	@Test(priority = 723)
	public void clickOnModule_MappingTest() throws InterruptedException {
		ccmap.clickOnModule_Mapping();
	}

	@Test(priority = 724)
	public void displayStatusOfModule_Mapping_selectRoleTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfModule_Mapping_selectRole(), true);
	}

	@Test(priority = 725)
	public void enableStatusOfModule_Mapping_selectRoleTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfModule_Mapping_selectRole(), true);
	}

	@Test(priority = 726)
	public void clickOnModule_Mapping_selectRoleandSelectValueTest() throws InterruptedException {
		ccmap.clickOnModule_Mapping_selectRoleandSelectValue("Supervisor");
	}

	@Test(priority = 727)
	public void displayStatusOfselectRole_viewTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfselectRole_view(), true);
	}

	@Test(priority = 728)
	public void enableStatusOfselectRole_viewTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfselectRole_view(), true);
	}

	@Test(priority = 729)
	public void clickOnselectRole_viewandSelectValueTest() throws InterruptedException {
		ccmap.clickOnselectRole_viewandSelectValue();
	}

	@Test(priority = 730)
	public void displayStatusOfcheckBox1Test() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfcheckBox1(), true);
	}

	@Test(priority = 731)
	public void enableStatusOfcheckBox1Test() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfcheckBox1(), true);
	}

	@Test(priority = 732)
	public void clickOncheckBox1andSelectValueTest() throws InterruptedException {
		ccmap.clickOncheckBox1andSelectValue();
	}

	@Test(priority = 733)
	public void displayStatusOfChatCondWritecheckBoxTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfChatCondWritecheckBox(), true);
	}

	@Test(priority = 734)
	public void enableStatusOfChatCondWritecheckBoxTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfChatCondWritecheckBox(), true);
	}

	@Test(priority = 735)
	public void clickOnChatCondWritecheckBoxandSelectValueTest() throws InterruptedException {
		ccmap.clickOnChatCondWritecheckBoxandSelectValue();
	}

	@Test(priority = 736)
	public void displayStatusOfsaveModuleTest() throws InterruptedException {
		Assert.assertEquals(ccmap.displayStatusOfsaveModule(), true);
	}

	@Test(priority = 737)
	public void enableStatusOfsaveModuleTest() throws InterruptedException {
		Assert.assertEquals(ccmap.enableStatusOfsaveModule(), true);
	}

	@Test(priority = 738)
	public void clickOnsaveModuleandSelectValueTest() throws InterruptedException {
		ccmap.clickOnsaveModuleandSelectValue();
	}

	@Test(priority = 739)
	public void againSameOpeForVerifiedTest() throws InterruptedException {
		ccmap.againSameOpeForVerified("abc", "Supervisor");
	}
}
