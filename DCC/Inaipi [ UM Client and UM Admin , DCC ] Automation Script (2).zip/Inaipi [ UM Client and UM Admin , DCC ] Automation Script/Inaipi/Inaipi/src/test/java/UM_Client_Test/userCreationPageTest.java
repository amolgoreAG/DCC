package UM_Client_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Client.userCreationPage;

public class userCreationPageTest extends BaseClass{

	private static final Logger log = Logger.getLogger(userCreationPageTest.class);
	public static userCreationPage usercreate;
	
	@Test(priority = 321)
	public void displayStatusOfcreateClientTest() throws InterruptedException {
		usercreate = new userCreationPage();
		Assert.assertEquals(usercreate.displayStatusOfcreateClient(), true);
	}

	@Test(priority = 322)
	public void enableStatusOfcreateClientTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfcreateClient(), true);
	}

	@Test(priority = 323)
	public void clickOncreateClientTest() throws InterruptedException {
		usercreate.clickOncreateClient();
	}

	@Test(priority = 324)
	public void displayStatusOffirstNameTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOffirstName(), true);
	}

	@Test(priority = 325)
	public void enableStatusOffirstNameTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOffirstName(), true);
	}

	@Test(priority = 326)
	public void enterDataInfirstNameTest() throws InterruptedException {
		usercreate.enterDataInfirstName("Amol");
	}

	@Test(priority = 327)
	public void displayStatusOflastNameTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOflastName(), true);
	}

	@Test(priority = 328)
	public void enableStatusOflastNameTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOflastName(), true);
	}

	@Test(priority = 329)
	public void enterDataInlastNameTest() throws InterruptedException {
		usercreate.enterDataInlastName("G");
	}

	@Test(priority = 330)
	public void displayStatusOfemailTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfemail(), true);
	}

	@Test(priority = 331)
	public void enableStatusOfemailTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfemail(), true);
	}

	@Test(priority = 332)
	public void enterDataInemailTest() throws InterruptedException {
		usercreate.enterDataInemail("Abc123@gmail.com");
	}

	@Test(priority = 333)
	public void displayStatusOfcontactNumberTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfcontactNumber(), true);
	}

	@Test(priority = 334)
	public void enableStatusOfcontactNumberTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfcontactNumber(), true);
	}

	@Test(priority = 335)
	public void enterDataIncontactNumberTest() throws InterruptedException {
		usercreate.enterDataIncontactNumber("9876581234");
	}

	@Test(priority = 336)
	public void displayStatusOfclientPasswordTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclientPassword(), true);
	}

	@Test(priority = 337)
	public void enableStatusOfclientPasswordTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclientPassword(), true);
	}

	@Test(priority = 338)
	public void enterDataInclientPasswordTest() throws InterruptedException {
		usercreate.enterDataInclientPassword("Welcome@123");
	}

	@Test(priority = 339)
	public void displayStatusOfclientPasswordShowTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclientPasswordShow(), true);
	}

	@Test(priority = 340)
	public void enableStatusOfclientPasswordShowTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclientPasswordShow(), true);
	}

	@Test(priority = 341)
	public void clickclientPasswordShowTest() throws InterruptedException {
		usercreate.clickclientPasswordShow();
	}

	@Test(priority = 342)
	public void displayStatusOfclientConfirmPasswordTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclientConfirmPassword(), true);
	}

	@Test(priority = 343)
	public void enableStatusOfclientConfirmPasswordTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclientConfirmPassword(), true);
	}

	@Test(priority = 344)
	public void enterDataInclientConfirmPasswordTest() throws InterruptedException {
		usercreate.enterDataInclientConfirmPassword("Welcome@123");
	}

	@Test(priority = 345)
	public void displayStatusOfclientConfirmPasswordShowTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclientConfirmPasswordShow(), true);
	}

	@Test(priority = 346)
	public void enableStatusOfclientConfirmPasswordShowTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclientConfirmPasswordShow(), true);
	}

	@Test(priority = 347)
	public void clickConfirmPasswordShowTest() throws InterruptedException {
		usercreate.clickConfirmPasswordShow();
	}

	@Test(priority = 348)
	public void displayStatusOfclientRoleTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclientRole(), true);
	}

	@Test(priority = 349)
	public void enableStatusOfclientRoleTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclientRole(), true);
	}

	@Test(priority = 350)
	public void clickOnclientRoleTest() throws InterruptedException {
		usercreate.clickOnclientRole();
	}

	@Test(priority = 351)
	public void selectRoleFromDPTest() throws InterruptedException {
		usercreate.selectRoleFromDP("Agent");
	}

	@Test(priority = 352)
	public void displayStatusOfclientGroupTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclientGroup(), true);
	}

	@Test(priority = 353)
	public void enableStatusOfclientGroupTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclientGroup(), true);
	}

	@Test(priority = 354)
	public void clickOnclientGroupTest() throws InterruptedException {
		usercreate.clickOnclientGroup();
	}

	@Test(priority = 355)
	public void selectGroupFromDPTets() throws InterruptedException {
		usercreate.selectGroupFromDP("IT");
	}

	@Test(priority = 356)
	public void displayStatusOfclientChannelTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclientChannel(), true);
	}

	@Test(priority = 357)
	public void enableStatusOfclientChannelTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclientChannel(), true);
	}

	@Test(priority = 358)
	public void clickOnclientChannelTest() throws InterruptedException {
		usercreate.clickOnclientChannel();
	}

	@Test(priority = 359)
	public void selectChannelFromDPTest() throws InterruptedException {
		usercreate.selectChannelFromDP("Chat");
	}

	@Test(priority = 360)
	public void displayStatusOfclientSubChannelTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclientSubChannel(), true);
	}

	@Test(priority = 361)
	public void enableStatusOfclientSubChannelTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclientSubChannel(), true);
	}

	@Test(priority = 362)
	public void clickOnclientSubChannelTest() throws InterruptedException {
		usercreate.clickOnclientSubChannel();
	}

	@Test(priority = 363)
	public void selectsubChannelFromDPTest() throws InterruptedException {
		usercreate.selectsubChannelFromDP("whatsapp");
	}

	@Test(priority = 364)
	public void displayStatusOfaddSkillAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfaddSkillAndProfeciancy(), true);
	}

	@Test(priority = 365)
	public void enableStatusOfaddSkillAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfaddSkillAndProfeciancy(), true);
	}

	@Test(priority = 366)
	public void clickOnaddSkillAndProfeciancyTest() throws InterruptedException {
		usercreate.clickOnaddSkillAndProfeciancy();
	}

	@Test(priority = 367)
	public void displayStatusOfaddSkillTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfaddSkill(), true);
	}

	@Test(priority = 368)
	public void enableStatusOfaddSkillTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfaddSkill(), true);
	}

	@Test(priority = 369)
	public void clickOnaddSkillTest() throws InterruptedException {
		usercreate.clickOnaddSkill();
	}

	@Test(priority = 370)
	public void selectDPValueFromAddSkillTest() throws InterruptedException {
		usercreate.selectDPValueFromAddSkill("HR");
	}

	@Test(priority = 371)
	public void displayStatusOfaddSkillProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfaddSkillProfeciancy(), true);
	}

	@Test(priority = 372)
	public void enableStatusOfaddSkillProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfaddSkillProfeciancy(), true);
	}

	@Test(priority = 373)
	public void clickOnaddSkillProfeciancyTest() throws InterruptedException {
		usercreate.clickOnaddSkillProfeciancy();
	}

	@Test(priority = 374)
	public void selectDPValueFromAddSkillProfeciancyTest() throws InterruptedException {
		usercreate.selectDPValueFromAddSkillProfeciancy("Basic");
	}

	@Test(priority = 375)
	public void displayStatusOfremoveSkillAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfremoveSkillAndProfeciancy(), true);
	}

	@Test(priority = 376)
	public void enableStatusOfremoveSkillAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfremoveSkillAndProfeciancy(), true);
	}

//	@Test(priority = 377)
//	public void clickOnremoveSkillAndProfeciancyTest() throws InterruptedException {
//		usercreate.clickOnremoveSkillAndProfeciancy();
//	}	
	@Test(priority = 378)
	public void displayStatusOfaddLanguageAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfaddLanguageAndProfeciancy(), true);
	}

	@Test(priority = 379)
	public void enableStatusOfaddLanguageAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfaddLanguageAndProfeciancy(), true);
	}

	@Test(priority = 380)
	public void clickOnaddLanguageAndProfeciancyTest() throws InterruptedException {
		usercreate.clickOnaddLanguageAndProfeciancy();
	}

	@Test(priority = 381)
	public void displayStatusOfaddLanguageTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfaddLanguage(), true);
	}

	@Test(priority = 382)
	public void enableStatusOfaddLanguageTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfaddLanguage(), true);
	}

	@Test(priority = 383)
	public void clickOnaddLanguageTest() throws InterruptedException {
		usercreate.clickOnaddLanguage();
	}

	@Test(priority = 384)
	public void selectDPValueFromAddLanguageTest() throws InterruptedException {
		usercreate.selectDPValueFromAddLanguage("Hindi");
	}

	@Test(priority = 385)
	public void displayStatusOfaddLanguageProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfaddLanguageProfeciancy(), true);
	}

	@Test(priority = 386)
	public void enableStatusOfaddLanguageProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfaddLanguageProfeciancy(), true);
	}

	@Test(priority = 387)
	public void clickOnaddLanguageProfeciancyTest() throws InterruptedException {
		usercreate.clickOnaddLanguageProfeciancy();
	}

	@Test(priority = 388)
	public void selectDPValueFromAddLanguageProfeciancyTest() throws InterruptedException {
		usercreate.selectDPValueFromAddLanguageProfeciancy("Basic");
	}

	@Test(priority = 389)
	public void displayStatusOfremoveLanguageAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfremoveLanguageAndProfeciancy(), true);
	}

	@Test(priority = 390)
	public void enableStatusOfremoveLanguageAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfremoveLanguageAndProfeciancy(), true);
	}

//	@Test(priority = 391)
//	public void clickOnremoveLanguageAndProfeciancyTest() throws InterruptedException {
//		usercreate.clickOnremoveLanguageAndProfeciancy();
//	}	
	@Test(priority = 392)
	public void displayStatusOfcreateUserTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfcreateUser(), true);
	}

	@Test(priority = 393)
	public void enableStatusOfcreateUserTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfcreateUser(), true);
	}

//	@Test(priority = 394)
//	public void clickOncreateUserTest() throws InterruptedException {
//		usercreate.clickOncreateUser();
//	}	
	@Test(priority = 395)
	public void displayStatusOfclearTest() throws InterruptedException {
		Assert.assertEquals(usercreate.displayStatusOfclear(), true);
	}

	@Test(priority = 396)
	public void enableStatusOfclearTest() throws InterruptedException {
		Assert.assertEquals(usercreate.enableStatusOfclear(), true);
	}

//	@Test(priority = 397)
//	public void clickOnclearTest() throws InterruptedException {
//		usercreate.clickOnclear();
//	}	
	@Test(priority = 397)
	public void clickOncreateUserTest() throws InterruptedException {
		usercreate.clickOncreateUser();
	}

}
