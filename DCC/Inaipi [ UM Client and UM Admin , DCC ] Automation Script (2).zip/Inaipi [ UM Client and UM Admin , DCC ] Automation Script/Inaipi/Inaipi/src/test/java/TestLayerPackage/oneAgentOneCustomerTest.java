package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import PageLayerPackage.oneAgentOneCustomer;

public class oneAgentOneCustomerTest extends BaseClass {

	private static Logger log = Logger.getLogger(oneAgentOneCustomerTest.class);
	public static oneAgentOneCustomer onetoone;

	@BeforeClass
	public void starting() {
		BaseClass.chatInterFace();
	}

	@Test(priority = 1)
	public void displayStatusOfUsernameTest() throws InterruptedException {
		onetoone = new oneAgentOneCustomer();
		Assert.assertEquals(onetoone.displayStatusOfUsername(), true);
	}

	@Test(priority = 2)
	public void enableStatusOfUsernameTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfUsername(), true);
	}

	@Test(priority = 3)
	public void displayStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfPassword(), true);
	}

	@Test(priority = 4)
	public void enableStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfPassword(), true);
	}

	@Test(priority = 5)
	public void displayStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfLogin(), true);
	}

	@Test(priority = 6)
	public void enableStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfLogin(), true);
	}

	@Test(priority = 7)
	public void enterLoginCredentialandLogin() throws InterruptedException {
		try {
			String username = excel.getDataFromExcelSheet(7, 2, 1);
			String password = excel.getDataFromExcelSheet(7, 3, 1);
			onetoone.enterLoginCredentialandLogin(username, password);
			log.info("enter username , password and login");
		} catch (InterruptedException e) {
			log.error("Please enter valid credential and login");
		}
	}

	@Test(priority = 8)
	public void displayStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfstatus(), true);
	}

	@Test(priority = 9)
	public void enableStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfstatus(), true);
	}

	@Test(priority = 10)
	public void clickOnstatusTest() {
		try {
			onetoone.clickOnstatus();
			log.info("click on status");
		} catch (Exception e) {
			log.error("Not able to click on status");
		}
	}

	@Test(priority = 11)
	public void displayStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfgoready(), true);
	}

	@Test(priority = 12)
	public void enableStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfgoready(), true);
	}

	@Test(priority = 13)
	public void clickOngoreadyTest() {
		try {
			onetoone.clickOngoready();
			log.info("change the status go ready to ready");
		} catch (Exception e) {
			log.error("NOt able to change the status go ready to ready");
		}
	}

	@Test(priority = 14)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfclose(), true);
	}

	@Test(priority = 15)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfclose(), true);
	}

	@Test(priority = 16)
	public void clickOncloseTest() {
		try {
			onetoone.clickOnclose();
			log.info("and close this");
		} catch (Exception e) {
			log.error("Not able to close");
		}
	}

	@Test(priority = 17)
	public void navigatetoCustomerPortalTest() {
		try {
			onetoone.navigatetoCustomerPortal();
			log.info("navigate to Customer portal");
		} catch (Exception e) {
			log.error("Not able to navigate to Customer portal");
		}
	}

	@Test(priority = 18)
	public void displayStatusOfchatTest() throws InterruptedException {
		onetoone.displayStatusOfchat();
	}

	@Test(priority = 19)
	public void enableStatusOfchatTest() throws InterruptedException {
		onetoone.enableStatusOfchat();
	}

	@Test(priority = 20)
	public void clickOnchatTest() throws InterruptedException {
		try {
			onetoone.clickOnchat();
			log.info("click on chat");
		} catch (Exception e) {
			log.error("Not able to click on chat");
		}
	
	}

	@Test(priority = 21)
	public void displayStatusOfCPusernameTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfCPusername(), true);
	}

	@Test(priority = 22)
	public void enableStatusOfCPusernameTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfCPusername(), true);
	}

	@Test(priority = 23)
	public void enterDataInCPusernameTest() throws InterruptedException {
		try {
			String user = excel.getDataFromExcelSheet(7, 7, 1);
			onetoone.enterDataInCPusername(user + UtilsLayerPackage.RandomIntData.randomInt());
			log.info("enter username");
		} catch (Exception e) {
			log.error("Not able to enter username");
		}
	}

	@Test(priority = 24)
	public void displayStatusOfCPemailTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfCPemail(), true);
	}

	@Test(priority = 25)
	public void enableStatusOfCPemailTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfCPemail(), true);
	}

	@Test(priority = 26)
	public void enterDataInCPemailTest() throws InterruptedException {
		try {
			String emailStart = excel.getDataFromExcelSheet(7, 8, 1);
			String emailEnd = excel.getDataFromExcelSheet(7, 8, 3);
			onetoone.enterDataInCPemail(emailStart + UtilsLayerPackage.RandomIntData.randomInt() + emailEnd);
			log.info("enter email");
		} catch (Exception e) {
			log.error("Not able to enter email");
		}
	}

	@Test(priority = 27)
	public void displayStatusOfCPphoneNumberTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfCPphoneNumber(), true);
	}

	@Test(priority = 28)
	public void enableStatusOfCPphoneNumberTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfCPphoneNumber(), true);
	}

	@Test(priority = 29)
	public void enterDataInCPphoneNumberTest() throws InterruptedException {
		try {
			String mobileNumber = excel.getDataFromExcelSheet(7, 9, 1);
			onetoone.enterDataInCPphoneNumber(mobileNumber + UtilsLayerPackage.RandomIntData.randomInt());
			log.info("enter phone number");
		} catch (Exception e) {
			log.error("Not able to enter phone number");
		}
	}

	@Test(priority = 30)
	public void displayStatusOfCPskillSetTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfCPskillSet(), true);
	}

	@Test(priority = 31)
	public void enableStatusOfCPskillSetTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfCPskillSet(), true);
	}

	@Test(priority = 32)
	public void selectSkillsetfromDPCPskillSetTest() throws InterruptedException {
		try {
			String skill = excel.getDataFromExcelSheet(7, 10, 1);
			onetoone.selectSkillsetfromDPCPskillSet("Product Owner");
			log.info("select skill set");
		} catch (Exception e) {
			log.error("Not able to select skill set");
		}
	}

	@Test(priority = 33)
	public void displayStatusOfCPselectLanguageTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfCPselectLanguage(), true);
	}

	@Test(priority = 34)
	public void enableStatusOfCPselectLanguageTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfCPselectLanguage(), true);
	}

	@Test(priority = 35)
	public void selectSkillsetfromDPCPselectLanguageTest() throws InterruptedException {
		try {
			String language = excel.getDataFromExcelSheet(7, 11, 1);
			onetoone.selectSkillsetfromDPCPselectLanguage(language);
			log.info("select language");
		} catch (Exception e) {
			log.error("Not able to select language");
		}
	}

	@Test(priority = 36)
	public void displayStatusOfCPcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfCPcomplaintType(), true);
	}

	@Test(priority = 37)
	public void enableStatusOfCPcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfCPcomplaintType(), true);
	}

	@Test(priority = 38)
	public void selectSkillsetfromDPCPcomplaintTypeTest() throws InterruptedException {
		try {
			String complaint = excel.getDataFromExcelSheet(7, 12, 1);
			onetoone.selectSkillsetfromDPCPcomplaintType(complaint);
			log.info("select complaint type");
		} catch (Exception e) {
			log.error("Not able to select complaint type");
		}
	}

	@Test(priority = 39)
	public void displayStatusOfCPchatButtonTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfCPchatButton(), true);
	}

	@Test(priority = 40)
	public void enableStatusOfCPchatButtonTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfCPchatButton(), true);
	}

	@Test(priority = 41)
	public void clickOnCPchatButtonTest() throws InterruptedException {
		try {
			onetoone.clickOnCPchatButton();
			log.info("tab on chat button");
		} catch (InterruptedException e) {
			log.error("Not able to tab on chat button");
		}
	}

	@Test(priority = 42)
	public void navigatebacktoAgentPortalTest() {
		try {
			onetoone.navigatebacktoAgentPortal();
			log.info("navigate back to Agent 1");
		} catch (Exception e) {
			log.error("Not able to navigate back to Agent 1");
		}
	}

	@Test(priority = 43)
	public void displayStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfmessage(), true);
	}

	@Test(priority = 44)
	public void enableStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfmessage(), true);
	}

	@Test(priority = 45)
	public void clickOnmessageTest() throws InterruptedException {
		try {
			onetoone.clickOnmessage();
			log.info("tab on message");
		} catch (InterruptedException e) {
			log.error("Not able to tab on message");
		}
	}

	@Test(priority = 46)
	public void displayStatusOfacceptCallTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfacceptCall(), true);
	}

	@Test(priority = 47)
	public void enableStatusOfacceptCallTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfacceptCall(), true);
	}

	@Test(priority = 48)
	public void clickOnacceptCallTest() throws InterruptedException {
		try {
			onetoone.clickOnacceptCall();
			log.info("accept the call");
		} catch (InterruptedException e) {
			log.error("Not able to accept the call");
		}
	}

	@Test(priority = 49)
	public void displayStatusOfstartChatTest() throws InterruptedException {
		Assert.assertEquals(onetoone.displayStatusOfstartChat(), true);
	}

	@Test(priority = 50)
	public void enableStatusOfstartChatTest() throws InterruptedException {
		Assert.assertEquals(onetoone.enableStatusOfstartChat(), true);
	}

	@Test(priority = 51)
	public void clickOnstartChatTest() throws InterruptedException {
		try {
			onetoone.clickOnstartChat();
			log.info("start to chat");
		} catch (InterruptedException e) {
			log.error("Not able to start to chat");
		}
	}

//	@Test(priority = 52)
//	public void displayStatusOfmessageBoxTest() throws InterruptedException {
//		Assert.assertEquals(onetoone.displayStatusOfmessageBox(), true);
//	}
//	@Test(priority = 53)
//	public void enableStatusOfmessageBoxTest() throws InterruptedException {
//		Assert.assertEquals(onetoone.enableStatusOfmessageBox(), true);
//	}
	@Test(priority = 54)
	public void clickOnmessageBoxTest() throws InterruptedException {
		try {
			onetoone.clickOnmessageBox();
			log.info("click on message box");
		} catch (InterruptedException e) {
			log.error("Not able to click on message box");
		}
	}

	@Test(priority = 55)
	public void sendDataInMessageBoxTest() {
		try {
			String Agent1Msg = excel.getDataFromExcelSheet(7, 16, 1);
			onetoone.sendDataInMessageBox(Agent1Msg);
			log.info("enter message");
		} catch (Exception e) {
			log.error("Not able to enter message");
		}

	}

//	@Test(priority = 56)
//	public void displayStatusOfsendMsgTest() throws InterruptedException {
//		Assert.assertEquals(onetoone.displayStatusOfsendMsg(), true);
//	}
//	@Test(priority = 57)
//	public void enableStatusOfsendMsgTest() throws InterruptedException {
//		Assert.assertEquals(onetoone.enableStatusOfsendMsg(), true);
//	}
	@Test(priority = 58)
	public void clickOnsendMsgTest() throws InterruptedException {
		try {
			onetoone.clickOnsendMsg();
			log.info("send messge");
		} catch (InterruptedException e) {
			log.error("Not able to send messge");
		}
	}

	@Test(priority = 59)
	public void navigateToCustomerPortalTest() {
		try {
			onetoone.navigateToCustomerPortal();
			log.info("Navigate to customer portal");
		} catch (Exception e) {
			log.error("Not able to Navigate to customer portal");
		}
	}

	@Test(priority = 60)
	public void clickOnChatTest() throws InterruptedException {
		try {
			onetoone.clickOnChat();
			log.info("tab on chat");
		} catch (InterruptedException e) {
			log.error("Not able to tab on chat");
		}
	}

	@Test(priority = 61)
	public void ClickandEnterMessageInCustomerMsgBoxandSendTest() throws InterruptedException {
		try {
			String Customer1Msg = excel.getDataFromExcelSheet(7, 17, 1);
			onetoone.ClickandEnterMessageInCustomerMsgBoxandSend(Customer1Msg);
			log.info("enter message and send");
		} catch (InterruptedException e) {
			log.error("Not able to enter message and send");
		}
	}

//	@Test(priority = 62)
	public void sendEmojiFromCustomerPortalTest() throws InterruptedException {
		try {
			onetoone.sendEmojiFromCustomerPortal();
			log.info("send emoji");
		} catch (InterruptedException e) {
			log.error("Not able to send emoji");
		}
	}

	@Test(priority = 63)
	public void sendFileFromCustomerPortalTest() throws InterruptedException {
		try {
			String Customer1File = excel.getDataFromExcelSheet(7, 18, 1);
			onetoone.sendFileFromCustomerPortal(Customer1File);
			log.info("send file");
		} catch (InterruptedException e) {
			log.error("Not able to send file");
		}
	}

	@Test(priority = 64)
	public void moveToAgent1ForVerifiedTest() throws InterruptedException {
		try {
			onetoone.moveToAgent1ForVerified();
			log.info("move to agent portal for and see the message is received or not and start the chatting");
		} catch (InterruptedException e) {
			log.error("Not able to move to agent portal for and see the message is received or not and start the chatting");
		}
	}

	@Test(priority = 65)
	public void sendEmojiFromAgent1PortalTest() throws InterruptedException {
		try {
			onetoone.sendEmojiFromAgent1Portal();
			log.info("send emoji");
		} catch (InterruptedException e) {
			log.error("Not able to send emoji");
		}
	}

	@Test(priority = 66)
	public void sendFileFromAgent1PortalTest() throws InterruptedException {
		try {
			String Agent1File = excel.getDataFromExcelSheet(7, 19, 1);
			onetoone.sendFileFromAgent1Portal(Agent1File);
			log.info("send file");
		} catch (InterruptedException e) {
			log.error("Not ale to send file");
		}
	}

	@Test(priority = 67)
	public void recodTheRecordingAndSendTest() throws InterruptedException {
		try {
			onetoone.recodTheRecordingAndSend();
			log.info("send recording");
		} catch (InterruptedException e) {
			log.error("Not able to send recording");
		}
	}

	@Test(priority = 68)
	public void navigateToCustomerPortaTest() throws InterruptedException {
		try {
			onetoone.navigateToCustomerPorta();
			log.info("navigate to customer portal");
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			log.error("Not able to navigate to customer portal");
		}
	}

	@Test(priority = 69)
	public void moveToAgent1ForVerified1Test() throws InterruptedException {
		try {
			onetoone.moveToAgent1ForVerified1();
			log.info("navigate to agent 1");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to agent 1");
		}
	}

	@Test(priority = 71)
	public void displayStatusOfcobrowserTest() throws InterruptedException {
		onetoone.displayStatusOfcobrowser();
		Thread.sleep(1000);
	}

	@Test(priority = 72)
	public void enableStatusOfcobrowserTest() throws InterruptedException {
		onetoone.enableStatusOfcobrowser();
		Thread.sleep(1000);
	}

	@Test(priority = 73)
	public void clickOncobrowserTest() throws InterruptedException {
		try {
			onetoone.clickOncobrowser();
			log.info("click on co browser");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			log.error("Not able to click on co browser");
		}
	}

	@Test(priority = 74)
	public void displayStatusOfcobrowserURLTest() throws InterruptedException {
		onetoone.displayStatusOfcobrowserURL();
		Thread.sleep(1000);
	}

	@Test(priority = 75)
	public void enableStatusOfcobrowserURLTest() throws InterruptedException {
		onetoone.enableStatusOfcobrowserURL();
		Thread.sleep(1000);
	}

	@Test(priority = 76)
	public void enterDataIncobrowserURLTest() throws InterruptedException {
		try {
			String cobrowserURL = excel.getDataFromExcelSheet(7, 21, 1);
			onetoone.enterDataIncobrowserURL(cobrowserURL);
			log.info("enter URL");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			log.error("Not able to enter URL");
		}
	}

	@Test(priority = 77)
	public void displayStatusOfcobrowserbtnTest() throws InterruptedException {
		onetoone.displayStatusOfcobrowserbtn();
		Thread.sleep(1000);
	}

	@Test(priority = 78)
	public void enableStatusOfcobrowserbtnTest() throws InterruptedException {
		onetoone.enableStatusOfcobrowserbtn();
		Thread.sleep(1000);
	}

	@Test(priority = 79)
	public void clickoncobrowserbtnTest() throws InterruptedException {
		try {
			onetoone.clickoncobrowserbtn();
			log.info("send co browser link with customer");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			log.error("Not able to send co browser link with customer");
			}
	}

	@Test(priority = 80)
	public void getCobrowserURLTest() throws InterruptedException {
		try {
			onetoone.getCobrowserURL();
			log.info("opening the cobrowser window");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			log.error("Not able to opening the cobrowser window");
		}
	}

	@Test(priority = 81)
	public void navigateToCustomerPortal1Test() throws InterruptedException {
		try {
			onetoone.navigateToCustomerPortal1();
			log.info("navigate to customer portal");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to customer portal");
		}
	}

	@Test(priority = 82)
	public void sendMsgFromCustomerPortal1Test() throws InterruptedException {
		try {
			onetoone.sendMsgFromCustomerPortal1("Hi");
			log.info("send message");
		} catch (InterruptedException e) {
			log.error("Not able to send message");
		}
	}

	@Test(priority = 83)
	public void openTheCoBrowserLinkTest() throws InterruptedException {
		try {
			onetoone.openTheCoBrowserLink();
			log.info("verified the cobrowser link and open");
		} catch (InterruptedException e) {
			log.error("Not able to verified the cobrowser link and open");
		}
	}

//	@Test(priority = 84)
	public void clickOnvideoCall_voiceCall_andJoin1Test() throws InterruptedException {
		try {
			onetoone.clickOnvideoCall_voiceCall_andJoin1();
			log.info("Mute video call");
			log.info("Mute audio call");
			log.info("tab on join");
		} catch (InterruptedException e) {
			log.error("Not able to Mute video , voice Call and tab on join");
		}
	}

	@Test(priority = 85)
	public void switchToAgentSideCoBrowserTest() throws InterruptedException {
		try {
			onetoone.switchToAgentSideCoBrowser();
			log.info("move to agent to co browser side for see customer connected or not");
		} catch (InterruptedException e) {
			log.error("Not able to move to agent to co browser side for see customer connected or not");
		}
	}

	@Test(priority = 86)
	public void switchToAgent1Test() throws InterruptedException {
		try {
			onetoone.switchToAgent1();
			log.info("move to customer co browser side to agent side and tab on start chat");
		} catch (InterruptedException e) {
			log.error("Not able to move to customer co browser side to agent side and tab on start chat");
		}
	}

	@Test(priority = 87)
	public void clickOnendChat1Test() throws InterruptedException {
		try {
			onetoone.clickOnendChat1();
			log.info("tab on End Chat");
		} catch (InterruptedException e) {
			log.error("Not able to tab on End Chat");
		}
	}

	@Test(priority = 88)
	public void selectReasonforDisconnect1Test() throws InterruptedException {
		try {
			String reason = excel.getDataFromExcelSheet(7, 25, 1);
			onetoone.selectReasonforDisconnect1(reason);
			log.info("Select the reason");
		} catch (InterruptedException e) {
			log.error("Not able to Select the reason");
		}
	}

	@Test(priority = 89)
	public void enterComment1Test() throws InterruptedException {
		try {
			String comment = excel.getDataFromExcelSheet(7, 26, 1);
			onetoone.enterComment1(comment);
			log.info("Enter the comment");
		} catch (InterruptedException e) {
			log.error("Not able to Enter the comment");
		}
	}

	@Test(priority = 90)
	public void clickOnSUbmit1Test() throws InterruptedException {
		try {
			onetoone.clickOnSUbmit1();
			log.info("tab on Submit");
		} catch (InterruptedException e) {
			log.error("Not able to tab on Submit");
		}
	}
	@Test(priority = 91)
	public void signouttheagentTest() throws InterruptedException {
		try {
			onetoone.signouttheagent();
			log.info("sign out agent");
		} catch (InterruptedException e) {
			log.error("Not able to sign out agent");
		}
	}

}
