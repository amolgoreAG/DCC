package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import PageLayerPackage.Supervisor;

public class SupervisorTest extends BaseClass {
	private static Logger log = Logger.getLogger(SupervisorTest.class);
	public static Supervisor Super;

	@BeforeClass
	public void starting() {
		BaseClass.chatInterFace();
	}

	@Test(priority = 1)
	public void displayStatusOfUsernameTest() throws InterruptedException {
		Super = new Supervisor();
		Assert.assertEquals(Super.displayStatusOfUsername(), true);
	}

	@Test(priority = 2)
	public void enableStatusOfUsernameTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfUsername(), true);
	}

	@Test(priority = 3)
	public void displayStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfPassword(), true);
	}

	@Test(priority = 4)
	public void enableStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfPassword(), true);
	}

	@Test(priority = 5)
	public void displayStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfLogin(), true);
	}

	@Test(priority = 6)
	public void enableStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfLogin(), true);
	}

	@Test(priority = 7)
	public void enterLoginCredentialandLogin() throws InterruptedException {
		try {
			String username = excel.getDataFromExcelSheet(8, 2, 1);
			String password = excel.getDataFromExcelSheet(8, 3, 1);
			Super.enterLoginCredentialandLogin(username, password);
			log.info("enter username , password and login");
		} catch (InterruptedException e) {
			log.error("Please enter correct creadential and login");
		}
	}

	@Test(priority = 8)
	public void displayStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfstatus(), true);
	}

	@Test(priority = 9)
	public void enableStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfstatus(), true);
	}

	@Test(priority = 10)
	public void clickOnstatusTest() {
		try {
			Super.clickOnstatus();
			log.info("click on status");
		} catch (Exception e) {
			log.error("Not able to click on status");
		}
	}

	@Test(priority = 11)
	public void displayStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfgoready(), true);
	}

	@Test(priority = 12)
	public void enableStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfgoready(), true);
	}

	@Test(priority = 13)
	public void clickOngoreadyTest() {
		try {
			Super.clickOngoready();
			log.info("change the status go ready to ready");
		} catch (Exception e) {
			log.error("Not able to change the status go ready to ready");
		}
	}

	@Test(priority = 14)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfclose(), true);
	}

	@Test(priority = 15)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfclose(), true);
	}

	@Test(priority = 16)
	public void clickOncloseTest() {
		try {
			Super.clickOnclose();
			log.info("and close this");
		} catch (Exception e) {
			log.error("Not able to tab on close");
		}
	}
	@Test(priority = 17)
	public void displayStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfmessage(), true);
	}
	@Test(priority = 18)
	public void enableStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfmessage(), true);
	}
	@Test(priority = 19)
	public void clickOnmessageTest() throws InterruptedException {
		try {
			Super.clickOnmessage();
			log.info("click on message");
		} catch (Exception e) {
			log.error("Not able to click on message");
		}
	}
	@Test(priority = 20)
	public void displayStatusOfcalenderTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfcalender(), true);
	}
	@Test(priority = 21)
	public void enableStatusOfcalenderTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfcalender(), true);
	}
	@Test(priority = 22)
	public void clickOncalenderTest() throws InterruptedException {
		try {
			Super.clickOncalender();
			log.info("click on calender");
		} catch (Exception e) {
			log.error("Not able to click on calender");
		}
	}
	@Test(priority = 23)
	public void displayStatusOfsessionReportTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfsessionReport(), true);
	}
	@Test(priority = 24)
	public void enableStatusOfsessionReportTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfsessionReport(), true);
	}
	@Test(priority = 25)
	public void clickOnsessionReportTest() throws InterruptedException {
		try {
			Super.clickOnsessionReport();
			log.info("click on session report");
		} catch (Exception e) {
			log.error("Not able to click on session report");
		}
	}
	@Test(priority = 26)
	public void displayStatusOffilterTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOffilter(), true);
	}
	@Test(priority = 27)
	public void enableStatusOffilterTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOffilter(), true);
	}
	@Test(priority = 28)
	public void clickOnfilterTest() throws InterruptedException {
		try {
			Super.clickOnfilter();
			log.info("click on filter");
		} catch (Exception e) {
			log.error("Not able to click on filter");
		}
	}
	@Test(priority = 29)
	public void displayStatusOffromCalenderTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOffromCalender(), true);
	}
	@Test(priority = 30)
	public void enableStatusOffromCalenderTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOffromCalender(), true);
	}
	@Test(priority = 31)
	public void clickOnfromCalenderTest() throws InterruptedException {
		try {
			Super.clickOnfromCalender();
			log.info("click on fromCalender");
		} catch (InterruptedException e) {
			log.error("Not able to click on fromCalender");
		}
	}
	@Test(priority = 32)
	public void displayStatusOftoCalenderTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOftoCalender(), true);
	}
	@Test(priority = 33)
	public void enableStatusOftoCalenderTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOftoCalender(), true);
	}
	@Test(priority = 34)
	public void clickOntoCalenderTest() throws InterruptedException {
		try {
			Super.clickOntoCalender();
			log.info("click on toCalender");
		} catch (InterruptedException e) {
			log.error("Not able to click on toCalender");
		}
	}
	@Test(priority = 35)
	public void displayStatusOffilterStatusTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOffilterStatus(), true);
	}
	@Test(priority = 36)
	public void enableStatusOffilterStatusTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOffilterStatus(), true);
	}
	@Test(priority = 37)
	public void selectfilterStatus() throws InterruptedException {
		try {
			Super.selectfilterStatus("Chat Ended");
			log.info("select  filter_Status");
		} catch (InterruptedException e) {
			log.error("Not able to select  filter_Status");
		}
	}
	@Test(priority = 38)
	public void displayStatusOfselectAgentTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfselectAgent(), true);
	}
	@Test(priority = 39)
	public void enableStatusOfselectAgentTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfselectAgent(), true);
	}
	@Test(priority = 40)
	public void clickOnselectAgentTest() throws InterruptedException {
		try {
			Super.clickOnselectAgent("Nandhini 03");
			log.info("select Agent");
		} catch (InterruptedException e) {
			log.error("Not able to select Agent");
		}
	}
	@Test(priority = 41)
	public void displayStatusOfsubmitTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfsubmit(), true);
	}
	@Test(priority = 42)
	public void enableStatusOfsubmitTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfsubmit(), true);
	}
	@Test(priority = 43)
	public void clickOnsubmitTest() throws InterruptedException {
		try {
			Super.clickOnsubmit();
			log.info("tab on submit");
		} catch (InterruptedException e) {
			log.error("Not able to tab on submit");
		}
	}
	@Test(priority = 44)
	public void displayStatusOfnextPageTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfnextPage(), true);
	}
	@Test(priority = 45)
	public void enableStatusOfnextPageTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfnextPage(), true);
	}
	@Test(priority = 46)
	public void clickOnnextPageTest() throws InterruptedException {
		try {
			Super.clickOnnextPage();
			log.info("tab on next page");
		} catch (InterruptedException e) {
			log.error("Not able to tab on next page");
		}
	}
	@Test(priority = 47)
	public void displayStatusOfagentReportTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfagentReport(), true);
	}
	@Test(priority = 48)
	public void enableStatusOfagentReportTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfagentReport(), true);
	}
	@Test(priority = 49)
	public void clickOnagentReportTest() throws InterruptedException {
		try {
			Super.clickOnagentReport();
			log.info("tab on agent report");
		} catch (InterruptedException e) {
			log.error("Not able to tab on agent report");
		}
	}
	@Test(priority = 50)
	public void displayStatusOffilterTest2() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOffilter2(), true);
	}
	@Test(priority = 51)
	public void enableStatusOffilterTest2() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOffilter2(), true);
	}
	@Test(priority = 52)
	public void clickOnfilterTest2() throws InterruptedException {
		try {
			Super.clickOnfilter2();
			log.info("click on filter");
		} catch (Exception e) {
			log.error("Not able to click on filter");
		}
	}
	@Test(priority = 53)
	public void displayStatusOffromCalenderTest2() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOffromCalender2(), true);
	}
	@Test(priority = 54)
	public void enableStatusOffromCalenderTest2() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOffromCalender2(), true);
	}
	@Test(priority = 55)
	public void clickOnfromCalenderTest2() throws InterruptedException {
		try {
			Super.clickOnfromCalender2();
			log.info("click on fromCalender");
		} catch (InterruptedException e) {
			log.error("Not able to click on fromCalender");
		}
	}
	@Test(priority = 56)
	public void displayStatusOftoCalenderTest2() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOftoCalender2(), true);
	}
	@Test(priority = 57)
	public void enableStatusOftoCalenderTest2() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOftoCalender2(), true);
	}
	@Test(priority = 58)
	public void clickOntoCalenderTest2() throws InterruptedException {
		try {
			Super.clickOntoCalender2();
			log.info("click on toCalender");
		} catch (InterruptedException e) {
			log.error("NOt able to click on toCalender");
		}
	}
	@Test(priority = 59)
	public void displayStatusOfsubmit2Test() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfsubmit2(), true);
	}
	@Test(priority = 60)
	public void enableStatusOfsubmit2Test() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfsubmit2(), true);
	}
	@Test(priority = 61)
	public void clickOnsubmit2Test() throws InterruptedException {
		try {
			Super.clickOnsubmit2();
			log.info("click on submit");
		} catch (InterruptedException e) {
			log.error("Not able to click on submit");
		}
	}
	@Test(priority = 62)
	public void displayStatusOfnextPage2Test() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfnextPage2(), true);
	}
	@Test(priority = 63)
	public void enableStatusOfnextPage2Test() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfnextPage2(), true);
	}
	@Test(priority = 64)
	public void clickOnnextPage2Test() throws InterruptedException {
		try {
			Super.clickOnnextPage2();
			log.info("click on next button");
		} catch (InterruptedException e) {
			log.error("Not able to click on next button");
		}
	}
	@Test(priority = 65)
	public void displayStatusOfstatus12Test() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfstatus12(), true);
	}
	@Test(priority = 66)
	public void enableStatusOfstatus12Test() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfstatus12(), true);
	}
	@Test(priority = 67)
	public void clickOnstatus12Test() throws InterruptedException {
		try {
			Super.clickOnstatus12();
			log.info("click on status");
		} catch (InterruptedException e) {
			log.error("Not able to click on status");
		}
	}
	@Test(priority = 68)
	public void displayStatusOffinishworkTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOffinishwork(), true);
	}
	@Test(priority = 69)
	public void enableStatusOffinishworkTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOffinishwork(), true);
	}
	@Test(priority = 70)
	public void clickOnfinishworkTest() throws InterruptedException {
		try {
			Super.clickOnfinishwork();
			log.info("click on finish work");
		} catch (InterruptedException e) {
			log.error("NOt able to click on finish work");
		}
	}
	@Test(priority = 71)
	public void displayStatusOfsignOutTest() throws InterruptedException {
		Assert.assertEquals(Super.displayStatusOfsignOut(), true);
	}
	@Test(priority = 72)
	public void enableStatusOfsignOutTest() throws InterruptedException {
		Assert.assertEquals(Super.enableStatusOfsignOut(), true);
	}
	@Test(priority = 73)
	public void clickOnsignOutTest() throws InterruptedException {
		try {
			Super.clickOnsignOut();
			log.info("click on signout");
		} catch (InterruptedException e) {
			log.error("Not able to click on signout");
		}
	}
}
