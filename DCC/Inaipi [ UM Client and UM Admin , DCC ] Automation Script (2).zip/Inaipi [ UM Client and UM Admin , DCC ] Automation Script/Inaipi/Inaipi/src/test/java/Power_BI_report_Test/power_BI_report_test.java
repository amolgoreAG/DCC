package Power_BI_report_Test;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import Power_BI_Report.power_BI_report;

public class power_BI_report_test extends BaseClass {
	private static Logger log = Logger.getLogger(power_BI_report_test.class);
	private power_BI_report bi;
	
	@BeforeClass
	public void start() {
		BaseLayerPackage.BaseClass.PowerBIReport();
		log.info("Open The URL");
	}
	@Test(priority = 1)
	public void loginInAgentPortalTest() throws InterruptedException {
		bi = new power_BI_report();
		bi.loginInAgentPortal();
	}
	@Test(priority = 2)
	public void tab_on_power_BITest() throws InterruptedException {
		bi.tab_on_power_BI();
	}
	@Test(priority = 3)
	public void interation_details_reportTest() {
		bi.interation_details_report();
	}
	@Test(priority = 4)
	public void fromcalender_IDRTest() {
		bi.fromcalender_IDR();
	}
	@Test(priority = 5)
	public void Tocalender_IDRTest() {
		bi.Tocalender_IDR();
	}
	@Test(priority = 6)
	public void select_AgentName_TextBox_In_IDR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_IDR_and_select_unselect_all_agent();
	}
	@Test(priority = 7)
	public void select_SkillSet_TextBox_In_IDR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_IDR_and_select_unselect_all_SkillSet();
	}
	@Test(priority = 8)
	public void select_Channel_TextBox_In_IDR_and_select_unselect_all_ChannelTest() throws InterruptedException {
		bi.select_Channel_TextBox_In_IDR_and_select_unselect_all_Channel();
	}
	@Test(priority = 9)
	public void select_Disposition_TextBox_In_IDR_and_select_unselect_all_DispositionTest() throws InterruptedException {
		bi.select_Disposition_TextBox_In_IDR_and_select_unselect_all_Disposition();
	}
	@Test(priority = 10)
	public void Open_Overall_Interaction_ReportTesttest() throws InterruptedException {
		bi.Open_Overall_Interaction_ReportTest();
	}
	@Test(priority = 11)
	public void fromcalender_OIRTest() throws InterruptedException {
		bi.fromcalender_OIR();
	}
	@Test(priority = 12)
	public void Tocalender_OIRTest() throws InterruptedException {
		bi.Tocalender_OIR();
	}
	@Test(priority = 13)
	public void select_AgentName_TextBox_In_OIR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_OIR_and_select_unselect_all_agent();
	}
	@Test(priority = 14)
	public void select_SkillSet_TextBox_In_OIR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_OIR_and_select_unselect_all_SkillSet();
	}
	@Test(priority = 15)
	public void select_Channel_TextBox_In_OIR_and_select_unselect_all_ChannelTest() throws InterruptedException {
		bi.select_Channel_TextBox_In_OIR_and_select_unselect_all_Channel();
	}
	@Test(priority = 16)
	public void select_Language_TextBox_In_OIR_and_select_unselect_all_ChannelTest() throws InterruptedException {
		bi.select_Language_TextBox_In_OIR_and_select_unselect_all_Channel();
	}
	
	@Test(priority = 17)
	public void Open_Interaction_Summary_ReportTest() throws InterruptedException {
		bi.Open_Interaction_Summary_Report();
	}
	
	@Test(priority = 18)
	public void fromcalender_ISRTest() throws InterruptedException {
		bi.fromcalender_ISR();
	}
	
	@Test(priority = 19)
	public void Tocalender_ISRTest() throws InterruptedException {
		bi.Tocalender_ISR();
	}
	
	@Test(priority = 20)
	public void select_AgentName_TextBox_In_ISR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_ISR_and_select_unselect_all_agent();
	}
	
	@Test(priority = 21)
	public void select_SkillSet_TextBox_In_ISR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_ISR_and_select_unselect_all_SkillSet();
	}
	
	@Test(priority = 22)
	public void Open_Agent_Skill_set_reportTest() throws InterruptedException {
		bi.Open_Agent_Skill_set_report();
	}
	
	@Test(priority = 23)
	public void fromcalender_ASSRTest() throws InterruptedException {
		bi.fromcalender_ASSR();
	}
	
	@Test(priority = 24)
	public void Tocalender_ASSRTest() throws InterruptedException {
		bi.Tocalender_ASSR();
	}
	
	@Test(priority = 25)
	public void select_AgentName_TextBox_In_ASSR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_ASSR_and_select_unselect_all_agent();
	}
	
	@Test(priority = 26)
	public void select_SkillSet_TextBox_In_ASSR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_ASSR_and_select_unselect_all_SkillSet();
	}
	
	@Test(priority = 27)
	public void Open_Month_wise_performance_reportTest() throws InterruptedException {
		bi.Open_Month_wise_performance_report();
	}
	
	@Test(priority = 28)
	public void open_MonthTest() throws InterruptedException {
		bi.open_Month();
	}
	
	@Test(priority = 29)
	public void SelectAllMonthTestTest() throws InterruptedException {
		bi.SelectAllMonthTest();
	}
	
	@Test(priority = 30)
	public void select_AgentName_TextBox_In_MWPR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_MWPR_and_select_unselect_all_agent();
	}
	
	@Test(priority = 31)
	public void select_SkillSet_TextBox_In_MWPR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_MWPR_and_select_unselect_all_SkillSet();
	}
	
	@Test(priority = 32)
	public void Open_Agent_Wise_Performance_ReportTest() throws InterruptedException {
		bi.Open_Agent_Wise_Performance_Report();
	}
	
	@Test(priority = 33)
	public void fromcalender_AWPRTest() throws InterruptedException {
		bi.fromcalender_AWPR();
	}
	
	@Test(priority = 34)
	public void Tocalender_AWPRTest() throws InterruptedException {
		bi.Tocalender_AWPR();
	}
	
	@Test(priority = 35)
	public void select_AgentName_TextBox_In_AWPR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_AWPR_and_select_unselect_all_agent();
	}
	
	@Test(priority = 36)
	public void select_SkillSet_TextBox_In_AWPR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_AWPR_and_select_unselect_all_SkillSet();
	}
	
	@Test(priority = 37)
	public void Open_Answer_ReportTestTest() throws InterruptedException {
		bi.Open_Answer_ReportTest();
	}
	
	@Test(priority = 38)
	public void fromcalender_ARTest() throws InterruptedException {
		bi.fromcalender_AR();
	}
	
	@Test(priority = 39)
	public void Tocalender_ARTest() throws InterruptedException {
		bi.Tocalender_AR();
	}
	
	@Test(priority = 40)
	public void select_AgentName_TextBox_In_AR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_AR_and_select_unselect_all_agent();
	}
	
	@Test(priority = 41)
	public void select_SkillSet_TextBox_In_AR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_AR_and_select_unselect_all_SkillSet();
	}
	
	@Test(priority = 42)
	public void Open_Interacton_Presentation_ReportTestTest() throws InterruptedException {
		bi.Open_Interacton_Presentation_ReportTest();
	}
	
	@Test(priority = 43)
	public void fromcalender_IPRTest() throws InterruptedException {
		bi.fromcalender_IPR();
	}
	
	@Test(priority = 44)
	public void Tocalender_IPRTest() throws InterruptedException {
		bi.Tocalender_IPR();
	}
	
	@Test(priority = 45)
	public void select_SkillSet_TextBox_In_IPR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_IPR_and_select_unselect_all_SkillSet();
	}
	@Test(priority = 46)
	public void movetonexttable() throws InterruptedException {
		bi.movetonexttable();
	}
	@Test(priority = 47)
	public void Open_Inbound_Interaction_SummaryTest() throws InterruptedException {
		bi.Open_Inbound_Interaction_Summary();
	}
	
	@Test(priority = 48)
	public void fromcalender_IIRTest() throws InterruptedException {
		bi.fromcalender_IIR();
	}
	
	@Test(priority = 49)
	public void Tocalender_IIRTest() throws InterruptedException {
		bi.Tocalender_IIR();
	}
	
	@Test(priority = 50)
	public void select_SkillSet_TextBox_In_IIR_and_select_unselect_all_SkillSetTest() throws InterruptedException {
		bi.select_SkillSet_TextBox_In_IIR_and_select_unselect_all_SkillSet();
	}
	
	@Test(priority = 51)
	public void select_AgentName_TextBox_In_IIR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_IIR_and_select_unselect_all_agent();
	}
	
	@Test(priority = 52)
	public void Open_Agent_Not_Ready_ReportsTest() throws InterruptedException {
		bi.Open_Agent_Not_Ready_Reports();
	}
	
	@Test(priority = 53)
	public void fromcalender_ANRRTest() throws InterruptedException {
		bi.fromcalender_ANRR();
	}
	
	@Test(priority = 54)
	public void Tocalender_ANRRTest() throws InterruptedException {
		bi.Tocalender_ANRR();
	}
	
	@Test(priority = 55)
	public void select_AgentName_TextBox_In_ANRR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_ANRR_and_select_unselect_all_agent();
	}
	
	@Test(priority = 56)
	public void Opene_Agent_Performance_And_StatisticsTest() throws InterruptedException {
		bi.Opene_Agent_Performance_And_Statistics();
	}
	
	@Test(priority = 57)
	public void select_AgentName_TextBox_In_APASR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_APASR_and_select_unselect_all_agent();
	}
	@Test(priority = 58)
	public void Open_Agent_Details_ReportsTest() throws InterruptedException {
		bi.Open_Agent_Details_Reports();
	}
	
	@Test(priority = 59)
	public void select_AgentName_TextBox_In_ADR_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_ADR_and_select_unselect_all_agent();
	}
	
	@Test(priority = 60)
	public void Open_Overall_DashboardTest() throws InterruptedException {
		bi.Open_Overall_Dashboard();
	}
	
	@Test(priority = 61)
	public void fromcalender_ODTest() throws InterruptedException {
		bi.fromcalender_OD();
	}
	
	@Test(priority = 62)
	public void Tocalender_ODTest() throws InterruptedException {
		bi.Tocalender_OD();
	}
	
	@Test(priority = 63)
	public void select_AgentName_TextBox_In_OD_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_OD_and_select_unselect_all_agent();
	}
	
	@Test(priority = 64)
	public void nextTest() throws InterruptedException {
		bi.next();
	}
	@Test(priority = 65)
	public void Open_Chat_DashboardTest() throws InterruptedException {
		bi.Open_Chat_Dashboard();
	}
	@Test(priority = 66)
	public void fromcalender_CDTest() throws InterruptedException {
		bi.fromcalender_CD();
	}
	@Test(priority = 67)
	public void Tocalender_CDTest() throws InterruptedException {
		bi.Tocalender_CD();
	}
	@Test(priority = 68)
	public void select_AgentName_TextBox_In_CD_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_CD_and_select_unselect_all_agent();
	}
	@Test(priority = 69)
	public void Open_Email_DashboardTest() throws InterruptedException {
		bi.Open_Email_Dashboard();
	}
	@Test(priority = 70)
	public void fromcalender_EDTest() throws InterruptedException {
		bi.fromcalender_ED();
	}
	@Test(priority = 71)
	public void Tocalender_EDTest() throws InterruptedException {
		bi.Tocalender_ED();
	}
	@Test(priority = 72)
	public void select_AgentName_TextBox_In_ED_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_ED_and_select_unselect_all_agent();
	}
	@Test(priority = 73)
	public void Open_Voice_DashboardTest() throws InterruptedException {
		bi.Open_Voice_Dashboard();
	}
	@Test(priority = 74)
	public void fromcalender_VDTest() throws InterruptedException {
		bi.fromcalender_VD();
	}
	@Test(priority = 75)
	public void Tocalender_VDTest() throws InterruptedException {
		bi.Tocalender_VD();
	}
	@Test(priority = 76)
	public void select_AgentName_TextBox_In_VD_and_select_unselect_all_agentTest() throws InterruptedException {
		bi.select_AgentName_TextBox_In_VD_and_select_unselect_all_agent();
	}
}
