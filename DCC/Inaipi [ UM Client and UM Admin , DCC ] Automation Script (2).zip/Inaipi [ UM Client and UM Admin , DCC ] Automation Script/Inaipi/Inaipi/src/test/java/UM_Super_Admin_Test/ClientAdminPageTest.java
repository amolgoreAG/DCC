package UM_Super_Admin_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Super_Admin.ClientAdminPage;

public class ClientAdminPageTest extends BaseClass {

	private static Logger log = Logger.getLogger(ClientAdminPageTest.class);
	private static ClientAdminPage clientAdmin;
	
	@Test(priority = 163)
	public void displayStatusOfclientAdmin1Test() throws InterruptedException {
		clientAdmin = new ClientAdminPage();
		Assert.assertEquals(clientAdmin.displayStatusOfclientAdmin1(), true);
	}

	@Test(priority = 164)
	public void enableStatusOfclientAdmin1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfclientAdmin1(), true);
	}

	@Test(priority = 165)
	public void clickOnclientAdmin1Test() throws InterruptedException {
		clientAdmin.clickOnclientAdmin1();
		log.info("click on client admin");
	}

	@Test(priority = 166)
	public void displayStatusOfselectClient1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfselectClient1(), true);
	}

	@Test(priority = 167)
	public void enableStatusOfselectClient1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfselectClient1(), true);
	}

	@Test(priority = 168)
	public void clickOnselectClient1andSelectAdminFromDPTest() throws InterruptedException {
		String clientFromDP = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 23, 1);
		clientAdmin.clickOnselectClient1andSelectAdminFromDP(clientFromDP);
		log.info("Select the client from drop down : " + clientFromDP);
	}

	@Test(priority = 169)
	public void displayStatusOfview1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfview1(), true);
	}

	@Test(priority = 170)
	public void enableStatusOfview1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfview1(), true);
	}

	@Test(priority = 171)
	public void clickOnview1Test() throws InterruptedException {
		clientAdmin.clickOnview1();
		log.info("Click on view");
	}

	@Test(priority = 172)
	public void displayStatusOfaddAdmin1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfaddAdmin1(), true);
	}

	@Test(priority = 173)
	public void enableStatusOfaddAdmin1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfaddAdmin1(), true);
	}

	@Test(priority = 174)
	public void clickOnaddAdmin1Test() throws InterruptedException {
		clientAdmin.clickOnaddAdmin1();
		log.info("click on add Admin here we fill the details of agent");
	}

	@Test(priority = 175)
	public void displayStatusOffirstName1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOffirstName1(), true);
	}

	@Test(priority = 176)
	public void enableStatusOffirstName1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOffirstName1(), true);
	}

	@Test(priority = 177)
	public void enterDataInfirstName1Test() throws InterruptedException {
		String firstName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 26, 1);
		clientAdmin.enterDataInfirstName1(firstName);
		log.info("Enter Agent First Name : " + firstName);
	}

	@Test(priority = 178)
	public void displayStatusOflastName1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOflastName1(), true);
	}

	@Test(priority = 179)
	public void enableStatusOflastName1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOflastName1(), true);
	}

	@Test(priority = 180)
	public void enterDataInlastName1Test() throws InterruptedException {
		String lastName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 27, 1);
		clientAdmin.enterDataInlastName1(lastName);
		log.info("Enter Agent Last Name : " + lastName);
	}

	@Test(priority = 181)
	public void displayStatusOfemail1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfemail1(), true);
	}

	@Test(priority = 182)
	public void enableStatusOfemail1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfemail1(), true);
	}

	@Test(priority = 183)
	public void enterDataInemail1Test() throws InterruptedException {
		String email = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 28, 1);
		clientAdmin.enterDataInemail1(email);
		log.info("Enter Agent Email Address : " + email);
	}

	@Test(priority = 184)
	public void displayStatusOfcontactNumber1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfcontactNumber1(), true);
	}

	@Test(priority = 185)
	public void enableStatusOfcontactNumber1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfcontactNumber1(), true);
	}

	@Test(priority = 186)
	public void enterDataIncontactNumber1Test() throws InterruptedException {
		String mobileNumber = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 29, 1);
		clientAdmin.enterDataIncontactNumber1(mobileNumber);
		log.info("Enter Agent Contact Number : " + mobileNumber);
	}

	@Test(priority = 187)
	public void displayStatusOfadminPassword1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfadminPassword1(), true);
	}

	@Test(priority = 188)
	public void enableStatusOfadminPassword1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfadminPassword1(), true);
	}

	@Test(priority = 189)
	public void enterDataInadminPassword1Test() throws InterruptedException {
		String password = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 30, 1);
		clientAdmin.enterDataInadminPassword1(password);
		log.info("Enter Password : " + password);
	}

	@Test(priority = 190)
	public void displayStatusOfadminPasswordShow1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfadminPasswordShow1(), true);
	}

	@Test(priority = 191)
	public void enableStatusOfadminPasswordShow1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfadminPasswordShow1(), true);
	}

	@Test(priority = 192)
	public void clickOnadminPasswordShow1Test() throws InterruptedException {
		clientAdmin.clickOnadminPasswordShow1();
		log.info("Click on eye button for see the enter password");
	}

	@Test(priority = 193)
	public void displayStatusOfadminConfirmPassword1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfadminConfirmPassword1(), true);
	}

	@Test(priority = 194)
	public void enableStatusOfadminConfirmPassword1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfadminConfirmPassword1(), true);
	}

	@Test(priority = 195)
	public void enterDataInadminConfirmPassword1Test() throws InterruptedException {
		String confirmpassword = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 31, 1);
		clientAdmin.enterDataInadminConfirmPassword1(confirmpassword);
		log.info("Enter Confirm Password : " + confirmpassword);
	}

	@Test(priority = 196)
	public void displayStatusOfadminConfirmPasswordShow1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfadminConfirmPasswordShow1(), true);
	}

	@Test(priority = 197)
	public void enableStatusOfadminConfirmPasswordShow1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfadminConfirmPasswordShow1(), true);
	}

	@Test(priority = 198)
	public void clickOnadminConfirmPasswordShow1Test() throws InterruptedException {
		clientAdmin.clickOnadminConfirmPasswordShow1();
		log.info("Click on eye button for see the enter password");
	}

	@Test(priority = 199)
	public void displayStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfclose2(), true);
	}

	@Test(priority = 200)
	public void enableStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfclose2(), true);
	}

//	@Test(priority = 201)
//	public void clickOnclose2Test() throws InterruptedException {
//		admin.clickOnclose2();
//	}
	@Test(priority = 202)
	public void displayStatusOfadminCancelTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfadminCancel(), true);
	}

	@Test(priority = 203)
	public void enableStatusOfadminCancelTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfadminCancel(), true);
	}

//	@Test(priority = 204)
//	public void clickOnadminCancelTest() throws InterruptedException {
//		clientAdmin.clickOnadminCancel();
//	}
	@Test(priority = 205)
	public void displayStatusOfadminAddAdminTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfadminAddAdmin(), true);
	}

	@Test(priority = 206)
	public void enableStatusOfadminAddAdminTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfadminAddAdmin(), true);
	}

//	@Test(priority = 207)
//	public void clickOnadminAddAdminTest() throws InterruptedException {
//		clientAdmin.clickOnadminAddAdmin();
//	}
	@Test(priority = 207)
	public void clickOnadminCancelTest() throws InterruptedException {
		clientAdmin.clickOnadminCancel();
		log.info("Click on cancel button");
	}

	@Test(priority = 208)
	public void displayStatusOfeditAdminTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfeditAdmin(), true);
	}

	@Test(priority = 209)
	public void enableStatusOfeditAdminTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfeditAdmin(), true);
	}

	@Test(priority = 210)
	public void clickOneditAdminTest() throws InterruptedException {
		clientAdmin.clickOneditAdmin();
		log.info("Click on edit Admin");
	}

	@Test(priority = 211)
	public void displayStatusOfedit_firstName1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfedit_firstName1(), true);
	}

	@Test(priority = 212)
	public void enableStatusOfedit_firstName1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfedit_firstName1(), true);
	}

	@Test(priority = 213)
	public void enterDataInedit_firstName1Test() throws InterruptedException {
		clientAdmin.enterDataInedit_firstName1();
		log.info("Enter First Name");
	}

	@Test(priority = 214)
	public void displayStatusOfedit_lastName1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfedit_lastName1(), true);
	}

	@Test(priority = 215)
	public void enableStatusOfedit_lastName1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfedit_lastName1(), true);
	}

	@Test(priority = 216)
	public void enterDataInedit_lastName1Test() throws InterruptedException {
		clientAdmin.enterDataInedit_lastName1();
		log.info("Enter Last Name");
	}

	@Test(priority = 217)
	public void displayStatusOfedit_email1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfedit_email1(), true);
	}

	@Test(priority = 218)
	public void enableStatusOfedit_email1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfedit_email1(), true);
	}

	@Test(priority = 219)
	public void enterDataInedit_email1Test() throws InterruptedException {
		clientAdmin.enterDataInedit_email1();
		log.info("Enter Email Id");
	}

	@Test(priority = 220)
	public void displayStatusOfedit_contactNumber1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfedit_contactNumber1(), true);
	}

	@Test(priority = 221)
	public void enableStatusOfedit_contactNumber1Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfedit_contactNumber1(), true);
	}

	@Test(priority = 222)
	public void enterDataInedit_contactNumber1Test() throws InterruptedException {
		clientAdmin.enterDataInedit_contactNumber1("5647893210");
		log.info("Enter Mobile Number");
	}

	@Test(priority = 223)
	public void displayStatusOfedit_close2Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfedit_close2(), true);
	}

	@Test(priority = 224)
	public void enableStatusOfedit_close2Test() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfedit_close2(), true);
	}

//	@Test(priority = 225)
//	public void clickOnedit_close2Test() throws InterruptedException {
//		admin.clickOnedit_close2();
//	}
	@Test(priority = 226)
	public void displayStatusOfedit_adminCancelTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfedit_adminCancel(), true);
	}

	@Test(priority = 227)
	public void enableStatusOfedit_adminCancelTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfedit_adminCancel(), true);
	}

//	@Test(priority = 228)
//	public void clickOnedit_adminCancelTest() throws InterruptedException {
//		clientAdmin.clickOnedit_adminCancel();
//	}
	@Test(priority = 229)
	public void displayStatusOfedit_updateAddAdminTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfedit_updateAddAdmin(), true);
	}

	@Test(priority = 230)
	public void enableStatusOfedit_updateAddAdminTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfedit_updateAddAdmin(), true);
	}

//	@Test(priority = 231)
//	public void clickOnedit_updateAddAdminTest() throws InterruptedException {
//		admin.clickOnedit_updateAddAdmin();
//	}
	@Test(priority = 231)
	public void clickOnedit_adminCancelTest() throws InterruptedException {
		clientAdmin.clickOnedit_adminCancel();
		log.info("Click on cancel button");
	}

	@Test(priority = 232)
	public void displayStatusOfadminAddAdminStatusTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.displayStatusOfadminAddAdminStatus(), true);
	}

	@Test(priority = 233)
	public void enableStatusOfadminAddAdminStatusTest() throws InterruptedException {
		Assert.assertEquals(clientAdmin.enableStatusOfadminAddAdminStatus(), true);
	}

	@Test(priority = 234)
	public void clickOnadminAddAdminStatusTest() throws InterruptedException {
		clientAdmin.clickOnadminAddAdminStatus();
		log.info("check admin active deactive status");
	}	
}
