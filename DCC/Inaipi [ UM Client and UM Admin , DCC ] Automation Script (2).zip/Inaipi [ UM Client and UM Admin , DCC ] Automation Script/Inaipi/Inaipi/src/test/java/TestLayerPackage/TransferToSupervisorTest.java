package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import PageLayerPackage.TransferToSupervisor;

public class TransferToSupervisorTest extends BaseClass {

	private static Logger log = Logger.getLogger(TransferToSupervisorTest.class);
	public static TransferToSupervisor transSupervisor;

	@BeforeClass
	public void starting() {
		BaseClass.chatInterFace();
	}

	@Test(priority = 1)
	public void displayStatusOfUsernameTest() throws InterruptedException {
		transSupervisor = new TransferToSupervisor();
		Assert.assertEquals(transSupervisor.displayStatusOfUsername(), true);
	}

	@Test(priority = 2)
	public void enableStatusOfUsernameTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfUsername(), true);
	}

	@Test(priority = 3)
	public void displayStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfPassword(), true);
	}

	@Test(priority = 4)
	public void enableStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfPassword(), true);
	}

	@Test(priority = 5)
	public void displayStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfLogin(), true);
	}

	@Test(priority = 6)
	public void enableStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfLogin(), true);
	}

	@Test(priority = 7)
	public void enterLoginCredentialandLogin() throws InterruptedException {
		try {
			String Username = excel.getDataFromExcelSheet(0, 20, 1);
			String Password = excel.getDataFromExcelSheet(0, 21, 1);
			transSupervisor.enterLoginCredentialandLogin(Username, Password);
			log.info("enter username , password and login");
		} catch (InterruptedException e) {
			log.error("Please enter valid data and login");
		}
	}

	@Test(priority = 8)
	public void displayStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfstatus(), true);
	}

	@Test(priority = 9)
	public void enableStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfstatus(), true);
	}

	@Test(priority = 10)
	public void clickOnstatusTest() {
		try {
			transSupervisor.clickOnstatus();
			log.info("click on status");
		} catch (Exception e) {
			log.error("Not able to click on status");
		}
	}

	@Test(priority = 11)
	public void displayStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfgoready(), true);
	}

	@Test(priority = 12)
	public void enableStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfgoready(), true);
	}

	@Test(priority = 13)
	public void clickOngoreadyTest() {
		try {
			transSupervisor.clickOngoready();
			log.info("change the status go ready to ready");
		} catch (Exception e) {
			log.error("Not able to change the status go ready to ready");
		}
	}

	@Test(priority = 14)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfclose(), true);
	}

	@Test(priority = 15)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfclose(), true);
	}

	@Test(priority = 16)
	public void clickOncloseTest() {
		try {
			transSupervisor.clickOnclose();
			log.info("and close this");
		} catch (Exception e) {
			log.error("Not able to Close");
		}
	}

	@Test(priority = 17)
	public void navigatetoCustomerPortalTest() {
		try {
			transSupervisor.navigatetoCustomerPortal();
			log.info("navigate to Customer portal");
		} catch (Exception e) {
			log.error("Not able to navigate to Customer portal");
		}
	}

	@Test(priority = 18)
	public void displayStatusOfchatTest() throws InterruptedException {
		transSupervisor.displayStatusOfchat();
	}

	@Test(priority = 19)
	public void enableStatusOfchatTest() throws InterruptedException {
		transSupervisor.enableStatusOfchat();
	}

	@Test(priority = 20)
	public void clickOnchatTest() throws InterruptedException {
		try {
			transSupervisor.clickOnchat();
			log.info("click on chat");
		} catch (Exception e) {
			log.error("Not able to click on chat");
		}
	}

	@Test(priority = 21)
	public void displayStatusOfCPusernameTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfCPusername(), true);
	}

	@Test(priority = 22)
	public void enableStatusOfCPusernameTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfCPusername(), true);
	}

	@Test(priority = 23)
	public void enterDataInCPusernameTest() throws InterruptedException {
		try {
			String User = excel.getDataFromExcelSheet(6, 4, 1);
			transSupervisor.enterDataInCPusername(User + UtilsLayerPackage.RandomIntData.randomInt());
			log.info("enter username");
		} catch (Exception e) {
			log.error("Not able to enter username");
		}
	}

	@Test(priority = 24)
	public void displayStatusOfCPemailTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfCPemail(), true);
	}

	@Test(priority = 25)
	public void enableStatusOfCPemailTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfCPemail(), true);
	}

	@Test(priority = 26)
	public void enterDataInCPemailTest() throws InterruptedException {
		try {
			String emailStart = excel.getDataFromExcelSheet(6, 5, 1);
			String emailEnd = excel.getDataFromExcelSheet(6, 5, 3);
			transSupervisor.enterDataInCPemail(emailStart + UtilsLayerPackage.RandomIntData.randomInt() + emailEnd);
			log.info("enter email");
		} catch (Exception e) {
			log.error("Not able to enter email");
		}
	}

	@Test(priority = 27)
	public void displayStatusOfCPphoneNumberTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfCPphoneNumber(), true);
	}

	@Test(priority = 28)
	public void enableStatusOfCPphoneNumberTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfCPphoneNumber(), true);
	}

	@Test(priority = 29)
	public void enterDataInCPphoneNumberTest() throws InterruptedException {
		try {
			String mobileNumber = excel.getDataFromExcelSheet(6, 6, 1);
			transSupervisor.enterDataInCPphoneNumber(mobileNumber + UtilsLayerPackage.RandomIntData.randomInt());
			log.info("enter phone number");
		} catch (Exception e) {
			log.error("Not able to enter phone number");
		}
	}

	@Test(priority = 30)
	public void displayStatusOfCPskillSetTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfCPskillSet(), true);
	}

	@Test(priority = 31)
	public void enableStatusOfCPskillSetTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfCPskillSet(), true);
	}

	@Test(priority = 32)
	public void selectSkillsetfromDPCPskillSetTest() throws InterruptedException {
		try {
			String skill = excel.getDataFromExcelSheet(0, 22, 1);
			transSupervisor.selectSkillsetfromDPCPskillSet(skill);
			log.info("select skill set");
		} catch (Exception e) {
			log.error("Not able to select skill set");
		}
	}

	@Test(priority = 33)
	public void displayStatusOfCPselectLanguageTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfCPselectLanguage(), true);
	}

	@Test(priority = 34)
	public void enableStatusOfCPselectLanguageTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfCPselectLanguage(), true);
	}

	@Test(priority = 35)
	public void selectSkillsetfromDPCPselectLanguageTest() throws InterruptedException {
		try {
			String language = excel.getDataFromExcelSheet(0, 23, 1);
			transSupervisor.selectSkillsetfromDPCPselectLanguage(language);
			log.info("select language");
		} catch (Exception e) {
			log.error("Not able to select language");
		}
	}

	@Test(priority = 36)
	public void displayStatusOfCPcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfCPcomplaintType(), true);
	}

	@Test(priority = 37)
	public void enableStatusOfCPcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfCPcomplaintType(), true);
	}

	@Test(priority = 38)
	public void selectSkillsetfromDPCPcomplaintTypeTest() throws InterruptedException {
		try {
			String complaintType = excel.getDataFromExcelSheet(0, 24, 1);
			transSupervisor.selectSkillsetfromDPCPcomplaintType(complaintType);
			log.info("select complaint type");
		} catch (Exception e) {
			log.error("Not able to select complaint type");
		}
	}

	@Test(priority = 39)
	public void displayStatusOfCPchatButtonTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfCPchatButton(), true);
	}

	@Test(priority = 40)
	public void enableStatusOfCPchatButtonTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfCPchatButton(), true);
	}

	@Test(priority = 41)
	public void clickOnCPchatButtonTest() throws InterruptedException {
		try {
			transSupervisor.clickOnCPchatButton();
			log.info("tab on chat button");
		} catch (InterruptedException e) {
			log.error("Not able to tab on chat button");
		}
	}
	@Test(priority = 42)
	public void navigatebacktoAgentPortalTest() {
		try {
			transSupervisor.navigatebacktoAgentPortal();
			log.info("navigate back to Agent 1");
		} catch (Exception e) {
			log.error("Not able to navigate back to Agent 1");
		}
	}
	@Test(priority = 43)
	public void displayStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfmessage(), true);
	}
	@Test(priority = 44)
	public void enableStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfmessage(), true);
	}
	@Test(priority = 45)
	public void clickOnmessageTest() throws InterruptedException {
		try {
			transSupervisor.clickOnmessage();
			log.info("tab on message");
		} catch (InterruptedException e) {
			log.error("Not able to tab on message");
		}
	}
	@Test(priority = 46)
	public void displayStatusOfacceptCallTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfacceptCall(), true);
	}
	@Test(priority = 47)
	public void enableStatusOfacceptCallTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfacceptCall(), true);
	}
	@Test(priority = 48)
	public void clickOnacceptCallTest() throws InterruptedException {
		try {
			transSupervisor.clickOnacceptCall();
			log.info("accept the call");
		} catch (InterruptedException e) {
			log.error("Not able to accept the call");
		}
	}
	@Test(priority = 49)
	public void displayStatusOfstartChatTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfstartChat(), true);
	}
	@Test(priority = 50)
	public void enableStatusOfstartChatTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfstartChat(), true);
	}
	@Test(priority = 51)
	public void clickOnstartChatTest() throws InterruptedException {
		try {
			transSupervisor.clickOnstartChat();
			log.info("start to chat");
		} catch (InterruptedException e) {
			log.error("Not able to start to chat");
		}
	}
//	@Test(priority = 52)
//	public void displayStatusOfmessageBoxTest() throws InterruptedException {
//		Assert.assertEquals(transSupervisor.displayStatusOfmessageBox(), true);
//	}
//	@Test(priority = 53)
//	public void enableStatusOfmessageBoxTest() throws InterruptedException {
//		Assert.assertEquals(transSupervisor.enableStatusOfmessageBox(), true);
//	}
	@Test(priority = 54)
	public void clickOnmessageBoxTest() throws InterruptedException {
		try {
			transSupervisor.clickOnmessageBox();
			log.info("click on message box");
		} catch (InterruptedException e) {
			log.error("Not able to click on message box");
		}
	}
	@Test(priority = 55)
	public void sendDataInMessageBoxTest() {
		try {
			String agent1Msg = excel.getDataFromExcelSheet(6, 13, 2);
			transSupervisor.sendDataInMessageBox(agent1Msg);
			log.info("enter message");
		} catch (Exception e) {
			log.error("Not able to enter message");
		}
	}
//	@Test(priority = 56)
//	public void displayStatusOfsendMsgTest() throws InterruptedException {
//		Assert.assertEquals(transSupervisor.displayStatusOfsendMsg(), true);
//	}
//	@Test(priority = 57)
//	public void enableStatusOfsendMsgTest() throws InterruptedException {
//		Assert.assertEquals(transSupervisor.enableStatusOfsendMsg(), true);
//	}
	@Test(priority = 58)
	public void clickOnsendMsgTest() throws InterruptedException {
		try {
			transSupervisor.clickOnsendMsg();
			log.info("send messge");
		} catch (InterruptedException e) {
			log.error("Not able to send messge");
		}
	}
	@Test(priority = 59)
	public void navigatetoCustomerportalTest() throws InterruptedException {
		try {
			transSupervisor.navigatetoCustomerportal1();
			log.info("navigate to customer portal and tab on chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to customer portal and tab on chat");
		}
	}
	@Test(priority = 60)
	public void enterDataInCPmessageBoxTest() throws InterruptedException {
		try {
			String cutomer1Msg = excel.getDataFromExcelSheet(6, 14, 2);
			transSupervisor.enterDataInCPmessageBox(cutomer1Msg);
			log.info("enter message");
		} catch (InterruptedException e) {
			log.error("Not able to enter message");
		}
	}
	@Test(priority = 61)
	public void enterDataInCPsendMsgTest() throws InterruptedException {
		try {
			transSupervisor.clickOnCPsendMsg();
			log.info("send message");
		} catch (InterruptedException e) {
			log.error("Not able to send message");
		}
	}
	@Test(priority = 62)
	public void navigatebacktoagent1Test() throws InterruptedException {
		try {
			transSupervisor.navigatebacktoagent1();
			log.info("navigate to Agent 1 and tab on start chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1 and tab on start chat");
		}
	}
	@Test(priority = 63)
	public void openChromeIncognitoTest() throws InterruptedException {
		try {
			transSupervisor.openChromeIncognito();
			log.info("open new incognito tab for supervisor");
		} catch (InterruptedException e) {
			log.error("Not able to open new incognito tab for supervisor");
		}
	}
	@Test(priority = 64)
	public void transSupervisorsLoginTest() throws InterruptedException {
		try {
			String Username2 = excel.getDataFromExcelSheet(0, 35, 1);
			String Password2 = excel.getDataFromExcelSheet(0, 36, 1);
			transSupervisor.transSupervisorsLogin(Username2 , Password2);
			log.info("enter username , password and click on login");
		} catch (InterruptedException e) {
			log.error("Not able to enter username , password and click on login");
		}
	}
	@Test(priority = 65)
	public void displayStatusOfstatus2Test() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfstatus2(), true);
	}
	@Test(priority = 66)
	public void enableStatusOfstatus2Test() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfstatus2(), true);
	}
	@Test(priority = 67)
	public void clickOnstatus2Test() throws InterruptedException {
		try {
			transSupervisor.clickOnstatus2();
			log.info("click on status");
		} catch (Exception e) {
			log.error("Not able to click on status");
		}
	}
	@Test(priority = 68)
	public void displayStatusOfgoready2Test() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfgoready2(), true);
	}
	@Test(priority = 69)
	public void enableStatusOfgoready2Test() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfgoready2(), true);
	}
	@Test(priority = 70)
	public void clickOngoready2Test() throws InterruptedException {
		try {
			transSupervisor.clickOngoready2();
			log.info("change status go ready to ready");
		} catch (Exception e) {
			log.error("Not able to change status go ready to ready");
		}
	}
	@Test(priority = 71)
	public void displayStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfclose2(), true);
	}
	@Test(priority = 72)
	public void enableStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfclose2(), true);
	}
	@Test(priority = 73)
	public void clickOnclose2Test() throws InterruptedException {
		try {
			transSupervisor.clickOnclose2();
			log.info("and close this one");
		} catch (Exception e) {
			log.error("Not able to close");
		}
	}
	@Test(priority = 74)
	public void gotoAgent1Test() throws InterruptedException {
		try {
			transSupervisor.gotoAgent1();
			log.info("navigate to Agent 1");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1");
		}
	}
	@Test(priority = 75)
	public void displayStatusOftransferToSupervisorTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOftransferToSupervisor(), true);
	}
	@Test(priority = 76)
	public void enableStatusOftransferToSupervisorTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOftransferToSupervisor(), true);
	}
	@Test(priority = 77)
	public void clickOntransferToSupervisorTest() throws InterruptedException {
		try {
			transSupervisor.clickOntransferToSupervisor();
			log.info("click on Transefer to supervisor");
		} catch (Exception e) {
			log.error("Not able to click on Transefer to supervisor");
		}
	}
	
	@Test(priority = 78)
	public void displayStatusOfavailableAgentTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOfavailableAgent(), true);
	}
	@Test(priority = 79)
	public void enableStatusOfavailableAgentTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOfavailableAgent(), true);
	}
	@Test(priority = 80)
	public void selectSkillSetFromavailableAgentTest() throws InterruptedException {
		try {
			String availableAgent = excel.getDataFromExcelSheet(6, 22, 1);
			transSupervisor.selectSkillSetFromavailableAgent(availableAgent);
			log.info("select available agent");
		} catch (Exception e) {
			log.error("Not able to select available agent");
		}
	}
	@Test(priority = 81)
	public void displayStatusOftransferTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.displayStatusOftransfer(), true);
	}
	@Test(priority = 82)
	public void enableStatusOftransferTest() throws InterruptedException {
		Assert.assertEquals(transSupervisor.enableStatusOftransfer(), true);
	}
	@Test(priority = 83)
	public void clickOntransferTest() throws InterruptedException {
		try {
			transSupervisor.clickOntransfer();
			log.info("click on transfer");
		} catch (InterruptedException e) {
			log.error("Not able to click on transfer");
		}
	}
	@Test(priority = 84)
	public void gotoAgent2andAcceptThaRequestTest() throws InterruptedException {
		try {
			transSupervisor.gotoAgent2andAcceptThaRequest();
			log.info("navigate to Supervisor , tab on message , accept call and start chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Supervisor , tab on message , accept call and start chat");
		}
	}
	@Test(priority = 85)
	public void enterMsginAgent2MessageBox() throws InterruptedException {
		try {
			String supervisor2Msg = excel.getDataFromExcelSheet(6, 15, 2);
			transSupervisor.enterMsginAgent2MessageBox(supervisor2Msg);
			log.info("Enter the message");
		} catch (InterruptedException e) {
			log.error("Not able to Enter the message");
		}
	}
	@Test(priority = 86)
	public void clickOnSendMessagefromAgentPortalTest() throws InterruptedException {
		try {
			transSupervisor.clickOnSendMessagefromAgentPortal();
			log.info("send message");
		} catch (InterruptedException e) {
			log.error("Not able to send message");
		}
	}
	@Test(priority = 87)
	public void gotoagent1ToCheckMsgCommingOrNotTest() throws InterruptedException {
		try {
			transSupervisor.gotoagent1ToCheckMsgCommingOrNot();
			log.info("navigate to Agent 1 and verified");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1 and verified");
		}
	}
	@Test(priority = 88)
	public void gotoCustomer1ToCheckMsgCommingOrNotTest() throws InterruptedException {
		try {
			transSupervisor.gotoCustomer1ToCheckMsgCommingOrNot();
			log.info("go to customer portal");
		} catch (InterruptedException e) {
			log.error("Not able to go to customer portal");
		}
	}
	@Test(priority = 89)
	public void ClickandEnterMessageInCustomerMsgBoxandSendTest() throws InterruptedException {
		try {
			String Customer1Msg = excel.getDataFromExcelSheet(6, 17, 2);
			transSupervisor.ClickandEnterMessageInCustomerMsgBoxandSend(Customer1Msg);
			log.info("enter message and send");
		} catch (InterruptedException e) {
			log.error("Not able to enter message and send");
		}
	}
	@Test(priority = 90)
	public void sendMsgFromCustomerPortalTest() throws InterruptedException {
		try {
			transSupervisor.sendMsgFromCustomerPortal();
			log.info("select msg and send");
		} catch (InterruptedException e) {
			log.error("Not able to select msg and send");
		}
	}
	@Test(priority = 91)
	public void sendFileFromCustomerPortalTest() throws InterruptedException {
		try {
			String Customer1File = excel.getDataFromExcelSheet(6, 18, 2);
			transSupervisor.sendFileFromCustomerPortal(Customer1File);
			log.info("select file and send");
		} catch (InterruptedException e) {
		log.error("Not able to select file and send");
		}
	}
//	@Test(priority = 92)
//	public void moveToAgent1ForVerifiedTest() throws InterruptedException {
//		transSupervisor.moveToAgent1ForVerified();
//	}
	@Test(priority = 93)
	public void sendEmojiFromSupervisorPortalTest() throws InterruptedException {
		try {
			transSupervisor.sendEmojiFromSupervisorPortal();
			log.info("navigate to supervisor and send emoji");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to supervisor and send emoji");
		}
	}
	@Test(priority = 94)
	public void sendFileFromAgent1PortalTest() throws InterruptedException {
		try {
			String Supervisor2File = excel.getDataFromExcelSheet(6, 19, 2);
			transSupervisor.sendFileFromAgent1Portal(Supervisor2File);
			log.info("select file and send ");
		} catch (InterruptedException e) {
			log.error("Not able to select file and send ");
		}
	}

	@Test(priority = 95)
	public void clickOnendChat2Test() throws InterruptedException {
		try {
			transSupervisor.clickOnendChat2();
			log.info("tab on end chat");
		} catch (InterruptedException e) {
			log.error("Not able to tab on end chat");
		}
	}
	@Test(priority = 96)
	public void selectReasonforDisconnect2Test() throws InterruptedException {
		try {
			String reason = excel.getDataFromExcelSheet(6, 27, 1);
			transSupervisor.selectReasonforDisconnect2(reason);
			log.info("select reason");
		} catch (InterruptedException e) {
			log.error("Not able to select reason");
		}
	}
	@Test(priority = 97)
	public void enterComment2Test() throws InterruptedException {
		try {
			String comment = excel.getDataFromExcelSheet(6, 28, 1);
			transSupervisor.enterComment2(comment);
			log.info("enter comment");
		} catch (InterruptedException e) {
			log.error("Not able to enter comment");
		}
	}
	@Test(priority = 98)
	public void clickOnSUbmitandSignOut2Test() throws InterruptedException {
		try {
			transSupervisor.clickOnSUbmitandSignOut2();
			log.info("tab on submit ang Sign Out");
		} catch (InterruptedException e) {
			log.error("Not able to tab on submit ang Sign Out");
		}
	}

	@Test(priority = 99)
	public void navigateToCustomerAndentTheCallTest() throws InterruptedException {
		try {
			transSupervisor.navigateToCustomerAndentTheCall();
			log.info("navigate to customer portal and tab on chat and end the call");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to customer portal and tab on chat and end the call");
		}
	}
}
