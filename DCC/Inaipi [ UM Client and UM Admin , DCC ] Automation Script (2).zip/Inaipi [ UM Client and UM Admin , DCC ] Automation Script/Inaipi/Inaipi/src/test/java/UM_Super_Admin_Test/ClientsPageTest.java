package UM_Super_Admin_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Super_Admin.ClientsPage;

public class ClientsPageTest extends BaseClass{

	private static Logger log = Logger.getLogger(ClientsPageTest.class);
	private static ClientsPage client;
	
	@Test(priority = 13)
	public void displayStatusOfclientsTest() throws InterruptedException {
		client = new ClientsPage();
		Assert.assertEquals(client.displayStatusOfclients(), true);
	}

	@Test(priority = 14)
	public void enableStatusOfclientsTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclients(), true);
	}

	@Test(priority = 15)
	public void clickOnclientsTest() throws InterruptedException {
		client.clickOnclients();
		log.info("click on client");
	}

	@Test(priority = 16)
	public void displayStatusOfcreateClientTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateClient(), true);
	}

	@Test(priority = 17)
	public void enableStatusOfcreateClientTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateClient(), true);
	}

	@Test(priority = 18)
	public void clickOncreateClientTest() throws InterruptedException {
		client.clickOncreateClient();
		log.info("click on create client");
	}

	@Test(priority = 19)
	public void displayStatusOfclientNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientName(), true);
	}

	@Test(priority = 20)
	public void enableStatusOfclientNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientName(), true);
	}

	@Test(priority = 21)
	public void enterDataInclientNameTest() throws InterruptedException {
		String clientName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 2, 1);
		client.enterDataInclientName(clientName);
		log.info("Enter Client Name : " + clientName);
	}

	@Test(priority = 22)
	public void displayStatusOfcompanyLogoTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcompanyLogo(), true);
	}

	@Test(priority = 23)
	public void enableStatusOfcompanyLogoTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcompanyLogo(), true);
	}

	@Test(priority = 24)
	public void attachedFileTocompanyLogoTest() throws InterruptedException {
		client.attachedFileTocompanyLogo("C:\\Users\\cognicx\\Downloads\\580b57fcd9996e24bc43c4a1.png");
		log.info("attached logo");
	}

	@Test(priority = 25)
	public void displayStatusOfmaxUserTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfmaxUser(), true);
	}

	@Test(priority = 26)
	public void enableStatusOfmaxUserTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfmaxUser(), true);
	}

	@Test(priority = 27)
	public void enterDataInmaxUserTest() throws InterruptedException {
		String maxUser = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 3, 1);
		client.enterDataInmaxUser(maxUser);
		log.info("Enter maximum user count : " + maxUser);
	}

	@Test(priority = 28)
	public void displayStatusOfprimaryColorTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfprimaryColor(), true);
	}

	@Test(priority = 29)
	public void enableStatusOfprimaryColorTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfprimaryColor(), true);
	}

	@Test(priority = 30)
	public void clickOnprimaryColorTest() throws InterruptedException {
		client.clickOnprimaryColor();
		log.info("select primary colur");
	}

	@Test(priority = 31)
	public void displayStatusOfheaderColorTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfheaderColor(), true);
	}

	@Test(priority = 32)
	public void enableStatusOfheaderColorTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfheaderColor(), true);
	}

	@Test(priority = 33)
	public void clickOnheaderColorTest() throws InterruptedException {
		client.clickOnheaderColor();
		log.info("select header colour");
	}

	@Test(priority = 34)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclose(), true);
	}

	@Test(priority = 35)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclose(), true);
	}

//	@Test(priority = 36)
//	public void clickOncloseTest() throws InterruptedException {
//		client.clickOnclose();
//	}
	@Test(priority = 37)
	public void displayStatusOfcancelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcancel(), true);
	}

	@Test(priority = 38)
	public void enableStatusOfcancelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcancel(), true);
	}

//	@Test(priority = 39)
//	public void clickOncancelTest() throws InterruptedException {
//		client.clickOncancel();
//	log.info("click on cancel");
//	}
	@Test(priority = 40)
	public void displayStatusOfcreate_ClientTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreate_Client(), true);
	}

	@Test(priority = 41)
	public void enableStatusOfcreate_ClientTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreate_Client(), true);
	}

//	@Test(priority = 42)
//	public void clickOncreate_ClientTest() throws InterruptedException {
//		client.clickOncreate_Client();
//	log.info("save the client");
//	}
	@Test(priority = 42)
	public void clickOncancelTest() throws InterruptedException {
		client.clickOncancel();
		log.info("click on cancel");
	}

}
