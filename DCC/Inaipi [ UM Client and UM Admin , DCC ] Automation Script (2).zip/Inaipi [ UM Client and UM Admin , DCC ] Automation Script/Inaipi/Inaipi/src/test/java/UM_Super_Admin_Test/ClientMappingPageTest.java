package UM_Super_Admin_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Super_Admin.ClientMappingPage;

public class ClientMappingPageTest extends BaseClass {

	private static Logger log = Logger.getLogger(ClientAdminPageTest.class);
	private static ClientMappingPage clientMapping;
	
	@Test(priority = 235)
	public void displayStatusOfclientMappingTest() throws InterruptedException {
		clientMapping = new ClientMappingPage();
		Assert.assertEquals(clientMapping.displayStatusOfclientMapping(), true);
	}

	@Test(priority = 236)
	public void enableStatusOfclientMappingTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfclientMapping(), true);
	}

	@Test(priority = 237)
	public void clickOnclientMappingTest() throws InterruptedException {
		clientMapping.clickOnclientMapping();
		log.info("click on client mapping");
	}

	@Test(priority = 238)
	public void displayStatusOfclientChannelMappingTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfclientChannelMapping(), true);
	}

	@Test(priority = 239)
	public void enableStatusOfclientChannelMappingTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfclientChannelMapping(), true);
	}

	@Test(priority = 240)
	public void clickOnclientChannelMappingTest() throws InterruptedException {
		clientMapping.clickOnclientChannelMapping();
		log.info("Click on client channel mapping");
	}

	@Test(priority = 241)
	public void displayStatusOfselectClientCMTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfselectClientCM(), true);
	}

	@Test(priority = 242)
	public void enableStatusOfselectClientCMTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfselectClientCM(), true);
	}

	@Test(priority = 243)
	public void clickOnselectClientCMandSelectDPValueTest() throws InterruptedException {
		clientMapping.clickOnselectClientCMandSelectDPValue("Demo");
		log.info("select client from drop down");
	}

	@Test(priority = 244)
	public void displayStatusOfviewClientTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfviewClient(), true);
	}

	@Test(priority = 245)
	public void enableStatusOfviewClientTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfviewClient(), true);
	}

	@Test(priority = 246)
	public void clickOnviewClientTest() throws InterruptedException {
		clientMapping.clickOnviewClient();
		log.info("click on view button");
	}

	@Test(priority = 247)
	public void displayStatusOfchatCheckBoxTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfchatCheckBox(), true);
	}

	@Test(priority = 248)
	public void enableStatusOfchatCheckBoxTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfchatCheckBox(), true);
	}

	@Test(priority = 249)
	public void clickOnchatCheckBoxTest() throws InterruptedException {
		clientMapping.clickOnchatCheckBox();
		log.info("select check box");
	}

	@Test(priority = 250)
	public void displayStatusOftwitterCheckBoxTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOftwitterCheckBox(), true);
	}

	@Test(priority = 251)
	public void enableStatusOftwitterCheckBoxTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOftwitterCheckBox(), true);
	}

	@Test(priority = 252)
	public void clickOntwitterCheckBoxTest() throws InterruptedException {
		clientMapping.clickOntwitterCheckBox();
		log.info("select twitter check box");
	}

	@Test(priority = 253)
	public void displayStatusOfsaveChaneelTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfsaveChaneel(), true);
	}

	@Test(priority = 254)
	public void enableStatusOfsaveChaneelTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfsaveChaneel(), true);
	}

	@Test(priority = 255)
	public void clickOnsaveChaneelTest() throws InterruptedException {
		clientMapping.clickOnsaveChaneel();
		log.info("click on save button");
	}

	@Test(priority = 256)
	public void displayStatusOfselectClientCM2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfselectClientCM2(), true);
	}

	@Test(priority = 257)
	public void enableStatusOfselectClientCM2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfselectClientCM2(), true);
	}

	@Test(priority = 258)
	public void clickOnselectClientCMandSelectDPValue2Test() throws InterruptedException {
		clientMapping.clickOnselectClientCMandSelectDPValue2("Superbank1", "Demo");
		log.info("select dp value again for verificaion");
	}

	@Test(priority = 259)
	public void displayStatusOfviewClient2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfviewClient2(), true);
	}

	@Test(priority = 260)
	public void enableStatusOfviewClient2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfviewClient2(), true);
	}

	@Test(priority = 261)
	public void clickOnviewClient2Test() throws InterruptedException {
		clientMapping.clickOnviewClient2();
		log.info("click on view button");
	}

	@Test(priority = 262)
	public void displayStatusOfchatCheckBox2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfchatCheckBox2(), true);
	}

	@Test(priority = 263)
	public void enableStatusOfchatCheckBox2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfchatCheckBox2(), true);
	}

	@Test(priority = 264)
	public void clickOnchatCheckBox2Test() throws InterruptedException {
		clientMapping.clickOnchatCheckBox2();
		log.info("open the chat (click on down arrow)");
	}

	@Test(priority = 265)
	public void displayStatusOftwitterCheckBox2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOftwitterCheckBox2(), true);
	}

	@Test(priority = 266)
	public void enableStatusOftwitterCheckBox2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOftwitterCheckBox2(), true);
	}

	@Test(priority = 267)
	public void clickOntwitterCheckBox2Test() throws InterruptedException {
		clientMapping.clickOntwitterCheckBox2();
		log.info("click on check box again");
	}

	@Test(priority = 268)
	public void displayStatusOfsaveChaneel2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfsaveChaneel2(), true);
	}

	@Test(priority = 269)
	public void enableStatusOfsaveChaneel2Test() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfsaveChaneel2(), true);
	}

	@Test(priority = 270)
	public void clickOnsaveChaneel2Test() throws InterruptedException {
		clientMapping.clickOnsaveChaneel2();
		log.info("save the data");
	}

	@Test(priority = 271)
	public void displayStatusOfroutingMappingTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfroutingMapping(), true);
	}

	@Test(priority = 272)
	public void enableStatusOfroutingMappingTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfroutingMapping(), true);
	}

	@Test(priority = 273)
	public void clickOnroutingMappingTest() throws InterruptedException {
		clientMapping.clickOnroutingMapping();
		log.info("click on routing mapping");
	}

	@Test(priority = 274)
	public void displayStatusOfselectClientRMTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfselectClientRM(), true);
	}

	@Test(priority = 275)
	public void enableStatusOfselectClientRMTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfselectClientRM(), true);
	}

	@Test(priority = 276)
	public void clickOnselectClientRMandSelectDPValueTest() throws InterruptedException {
		clientMapping.clickOnselectClientRMandSelectDPValue("Demo");
		log.info("select client name from drop down");
	}

	@Test(priority = 277)
	public void displayStatusOfviewRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfviewRouter(), true);
	}

	@Test(priority = 278)
	public void enableStatusOfviewRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfviewRouter(), true);
	}

	@Test(priority = 279)
	public void clickOnviewRouterTest() throws InterruptedException {
		clientMapping.clickOnviewRouter();
		log.info("click on view button");
	}

	@Test(priority = 280)
	public void displayStatusOfaddRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfaddRouter(), true);
	}

	@Test(priority = 281)
	public void enableStatusOfaddRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfaddRouter(), true);
	}

	@Test(priority = 282)
	public void clickOnaddRouterTest() throws InterruptedException {
		clientMapping.clickOnaddRouter();
		log.info("click on add router");
	}

	@Test(priority = 283)
	public void displayStatusOfselectRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfselectRouter(), true);
	}

	@Test(priority = 284)
	public void enableStatusOfselectRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfselectRouter(), true);
	}

	@Test(priority = 285)
	public void clickOnselectRouterandSelectDPValueTest() throws InterruptedException {
		clientMapping.clickOnselectRouterandSelectDPValue("test demo 4");
		log.info("select router ");
	}

	@Test(priority = 286)
	public void displayStatusOfsaveRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfsaveRouter(), true);
	}

	@Test(priority = 287)
	public void enableStatusOfsaveRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfsaveRouter(), true);
	}

//	@Test(priority = 288)
//	public void clickOnsaveRouterandSelectDPValueTest() throws InterruptedException {
//		clientMapping.clickOnsaveRouterandSelectDPValue();
//	}
	@Test(priority = 289)
	public void displayStatusOfcancelRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.displayStatusOfcancelRouter(), true);
	}

	@Test(priority = 290)
	public void enableStatusOfcancelRouterTest() throws InterruptedException {
		Assert.assertEquals(clientMapping.enableStatusOfcancelRouter(), true);
	}

	@Test(priority = 291)
	public void clickOncancelRouterandSelectDPValueTest() throws InterruptedException {
		clientMapping.clickOncancelRouterandSelectDPValue();
		log.info("click on cancel");
	}
}
