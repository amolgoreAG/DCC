package UM_Client_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Client.masterPage;

public class masterPageTest extends BaseClass {

	private static final Logger log = Logger.getLogger(masterPageTest.class);
	public static masterPage master;

	@Test(priority = 13)
	public void displayStatusOfmasterTest() throws InterruptedException {
		masterPage master = new masterPage();
		Assert.assertEquals(master.displayStatusOfmaster(), true);

	}

	@Test(priority = 14)
	public void enableStatusOfmasterTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfmaster(), true);
	}

	@Test(priority = 15)
	public void clickOnmasterTest() {
		master.clickOnmaster();
		log.info("click on master");
	}

	@Test(priority = 16)
	public void displayStatusOfroleTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfrole(), true);

	}

	@Test(priority = 17)
	public void enableStatusOfroleTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfrole(), true);

	}

	@Test(priority = 18)
	public void clickOnroleTest() {
		master.clickOnrole();
		log.info("click on role");
	}

	@Test(priority = 19)
	public void displayStatusOfcreateRoleTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreateRole(), true);

	}

	@Test(priority = 20)
	public void enableStatusOfcreateRoleTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreateRole(), true);

	}

	@Test(priority = 21)
	public void clickOncreateRoleTest() {
		master.clickOncreateRole();
		log.info("click on create role");
	}

	@Test(priority = 22)
	public void displayStatusOfroleNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfroleName(), true);

	}

	@Test(priority = 23)
	public void enableStatusOfroleNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfroleName(), true);

	}

	@Test(priority = 24)
	public void enterDataInroleNameTest() {
		master.enterDataInroleName("abc");
		log.info("enter role name");
	}

	@Test(priority = 25)
	public void displayStatusOfroleDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfroleDiscription(), true);

	}

	@Test(priority = 26)
	public void enableStatusOfroleDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfroleDiscription(), true);

	}

	@Test(priority = 27)
	public void enterDataInroleDiscriptionTest() {
		master.enterDataInroleDiscription("abc");
		log.info("enter role discription");
	}

	@Test(priority = 28)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfclose(), true);

	}

	@Test(priority = 29)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfclose(), true);

	}

	@Test(priority = 30)
	public void displayStatusOfcancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcancel(), true);

	}

	@Test(priority = 31)
	public void enableStatusOfcancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcancel(), true);

	}

	@Test(priority = 32)
	public void displayStatusOfsubmitTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfsubmit(), true);

	}

	@Test(priority = 33)
	public void enableStatusOfsubmitTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfsubmit(), true);

	}

	@Test(priority = 34)
	public void clickOnsubmitTest() {
		master.clickOnsubmit();
		log.info("click on submit");
	}

//	@Test(priority = 35)
//	public void clickOncancelTest() {
//		master.clickOncancel();
//	log.info("click on cancel");
//	}

	@Test(priority = 36)
	public void displayStatusOfeditTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit(), true);

	}

	@Test(priority = 37)
	public void enableStatusOfeditTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit(), true);

	}

	@Test(priority = 38)
	public void clickOneditTest() {
		master.clickOnedit();
		log.info("click on edit");
	}

	@Test(priority = 39)
	public void displayStatusOfedit_roleNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_roleName(), true);

	}

	@Test(priority = 40)
	public void enableStatusOfedit_roleNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_roleName(), true);

	}

	@Test(priority = 41)
	public void clearTheRoleNameTest() {
		master.clearTheRoleName();
		log.info("clear the role name");
	}

	@Test(priority = 42)
	public void enterDataInedit_roleNameTest() throws InterruptedException {
		master.enterDataInedit_roleName("PQR");
		log.info("Enter Role name ");
	}

	@Test(priority = 43)
	public void displayStatusOfedit_roleDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_roleDiscription(), true);

	}

	@Test(priority = 44)
	public void enableStatusOfroleedit_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfroleedit_Discription(), true);

	}

	@Test(priority = 45)
	public void enterDataInedit_roleDiscriptionTest() throws InterruptedException {
		master.enterDataInedit_roleDiscription("PQRST");
		log.info("clear the role discription and enter role rescription");
	}

	@Test(priority = 46)
	public void displayStatusOfedit_closeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_close(), true);

	}

	@Test(priority = 47)
	public void enableStatusOfedit_closeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_close(), true);

	}

	@Test(priority = 48)
	public void displayStatusOfedit_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_cancel(), true);

	}

	@Test(priority = 49)
	public void enableStatusOfedit_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_cancel(), true);

	}

//	@Test(priority = 50)
//	public void clickOnedit_cancelTest() throws InterruptedException {
//		master.clickOnedit_cancel();
//	log.info("click on cancel");
//	}
	@Test(priority = 51)
	public void displayStatusOfupdateRoleTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfupdateRole(), true);

	}

	@Test(priority = 52)
	public void enableStatusOfupdateRoleTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfupdateRole(), true);

	}

//	@Test(priority = 53)
//	public void clickOnupdateRoleTest() throws InterruptedException {
//		master.clickOnupdateRole();
//	log.info("click on update role");
//	}
	@Test(priority = 54)
	public void clickOnedit_cancelTest() throws InterruptedException {
		master.clickOnedit_cancel();
		log.info("click on cancel");
	}

	@Test(priority = 55)
	public void displayStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfstatus(), true);
	}

	@Test(priority = 56)
	public void enableStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfstatus(), true);
	}

	@Test(priority = 57)
	public void clickOnstatusTest() throws InterruptedException {
		master.clickOnstatus();
		log.info("change the active and deactive status ");
	}

	@Test(priority = 58)
	public void displayStatusOfgroupTets() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfgroup(), true);
	}

	@Test(priority = 59)
	public void enableStatusOfgroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfgroup(), true);
	}

	@Test(priority = 60)
	public void clickOngroupTest() throws InterruptedException {
		master.clickOngroup();
		log.info("click on group");
	}

	@Test(priority = 61)
	public void displayStatusOfcreateGroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreateGroup(), true);
	}

	@Test(priority = 62)
	public void enableStatusOfcreateGroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreateGroup(), true);
	}

	@Test(priority = 63)
	public void clickOncreateGroupTest() throws InterruptedException {
		master.clickOncreateGroup();
		log.info("click on create group");
	}

	@Test(priority = 64)
	public void displayStatusOfgroupNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfgroupName(), true);
	}

	@Test(priority = 65)
	public void enableStatusOfgroupNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfgroupName(), true);
	}

	@Test(priority = 66)
	public void enterDataIngroupNameTest() throws InterruptedException {
		master.enterDataIngroupName("IT");
		log.info("Enter Group Name");
	}

	@Test(priority = 67)
	public void displayStatusOfgroupNameDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfgroupNameDiscription(), true);
	}

	@Test(priority = 68)
	public void enableStatusOfgroupNameDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfgroupNameDiscription(), true);
	}

	@Test(priority = 69)
	public void enterDataIngroupNameDiscriptionTest() throws InterruptedException {
		master.enterDataIngroupNameDiscription("IT");
		log.info("enter group discription");
	}

	@Test(priority = 70)
	public void displayStatusOfclosegroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfclosegroup(), true);
	}

	@Test(priority = 71)
	public void enableStatusOfclosegroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfclosegroup(), true);
	}

	@Test(priority = 72)
	public void displayStatusOfcancelgroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcancelgroup(), true);
	}

	@Test(priority = 73)
	public void enableStatusOfcancelgroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcancelgroup(), true);
	}

//	@Test(priority = 74)
//	public void clickOncancelDiscriptionTest() throws InterruptedException {
//		master.clickOncancelDiscription();
//	log.info("click on cancel");
//	}	
	@Test(priority = 75)
	public void displayStatusOfsubmitgroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfsubmitgroup(), true);
	}

	@Test(priority = 76)
	public void enableStatusOfsubmitgroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfsubmitgroup(), true);
	}

	@Test(priority = 77)
	public void clickOnsubmitDiscriptionTest() throws InterruptedException {
		master.clickOnsubmitDiscription();
		log.info("click on submit");
	}
//	@Test(priority = 77)
//	public void clickOncancelDiscriptionTest() throws InterruptedException {
//		master.clickOncancelDiscription();
//	}

	@Test(priority = 78)
	public void displayStatusOfeditgroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditgroup(), true);
	}

	@Test(priority = 79)
	public void enableStatusOfeditgroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditgroup(), true);
	}

	@Test(priority = 80)
	public void clickOneditDiscriptionTest() throws InterruptedException {
		master.clickOneditDiscription();
		log.info("click on edit");
	}

	@Test(priority = 81)
	public void displayStatusOfedit_groupNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_groupName(), true);
	}

	@Test(priority = 82)
	public void enableStatusOfedit_groupNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_groupName(), true);
	}

	@Test(priority = 83)
	public void clearThegroupNameTest() throws InterruptedException {
		master.clearThegroupName();
		log.info("clear group name");
	}

	@Test(priority = 84)
	public void enterDataInedit_groupNameDiscriptionTest() throws InterruptedException {
		master.enterDataInedit_groupNameDiscription("PQR");
		log.info("click on edit");
	}

	@Test(priority = 85)
	public void displayStatusOfedit_groupNamegroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_groupNamegroup(), true);
	}

	@Test(priority = 86)
	public void enableStatusOfroleedit_groupNamegroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfroleedit_groupNamegroup(), true);
	}

	@Test(priority = 87)
	public void enterDataInedit_groupNamegroupTest() throws InterruptedException {
		master.enterDataInedit_groupNamegroup("PQRS");
	}

	@Test(priority = 88)
	public void displayStatusOfedit_closegroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_closegroup(), true);
	}

	@Test(priority = 89)
	public void enableStatusOfedit_closegroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_closegroup(), true);
	}

	@Test(priority = 90)
	public void displayStatusOfedit_cancelgroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_cancelgroup(), true);
	}

	@Test(priority = 91)
	public void enableStatusOfedit_cancelgroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_cancelgroup(), true);
	}

//	@Test(priority = 92)
//	public void clickOnedit_cancelgroupTest() throws InterruptedException {
//		master.clickOnedit_cancelgroup();
//	}	
	@Test(priority = 93)
	public void displayStatusOfupdateGroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfupdateGroup(), true);
	}

	@Test(priority = 94)
	public void enableStatusOfupdateGroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfupdateGroup(), true);
	}

//	@Test(priority = 95)
//	public void clickOnupdateGroupTest() throws InterruptedException {
//		master.clickOnupdateGroup();
//	}	
	@Test(priority = 95)
	public void clickOnedit_cancelgroupTest() throws InterruptedException {
		master.clickOnedit_cancelgroup();
	}

	@Test(priority = 96)
	public void displayStatusOfstatusgroupTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfstatusgroup(), true);
	}

	@Test(priority = 97)
	public void enableStatusOfstatusgroupTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfstatusgroup(), true);
	}

	@Test(priority = 98)
	public void clickOnstatusgroupTest() throws InterruptedException {
		master.clickOnstatusgroup();
	}

	@Test(priority = 99)
	public void displayStatusOfchannelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfchannel(), true);
	}

	@Test(priority = 100)
	public void enableStatusOfchannelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfchannel(), true);
	}

	@Test(priority = 101)
	public void clickOnchannelTets() throws InterruptedException {
		master.clickOnchannel();
	}

	@Test(priority = 102)
	public void displayStatusOfchannelStatus1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfchannelStatus1(), true);
	}

	@Test(priority = 103)
	public void enableStatusOfchannelStatus1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfchannelStatus1(), true);
	}

	@Test(priority = 104)
	public void clickOnchannelStatus1Test() throws InterruptedException {
		master.clickOnchannelStatus1();
	}

	@Test(priority = 105)
	public void displayStatusOfdownArrowTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfdownArrow(), true);
	}

	@Test(priority = 106)
	public void enableStatusOfdownArrowTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfdownArrow(), true);
	}

	@Test(priority = 107)
	public void clickOnchanneldownArrowTest() throws InterruptedException {
		master.clickOnchanneldownArrow();
	}

	@Test(priority = 108)
	public void displayStatusOfchannelSub1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfchannelSub1(), true);
	}

	@Test(priority = 109)
	public void enableStatusOfchannelSub1Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfchannelSub1(), true);
	}

	@Test(priority = 110)
	public void clickOnchannelSub1Test() throws InterruptedException {
		master.clickOnchannelSub1();
	}

	@Test(priority = 111)
	public void displayStatusOfchanne2Sub1Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfchannelSub2(), true);
	}

	@Test(priority = 112)
	public void enableStatusOfchannelSub2Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfchannelSub2(), true);
	}

	@Test(priority = 113)
	public void clickOnchannelSub2Test() throws InterruptedException {
		master.clickOnchannelSub2();
	}

	@Test(priority = 114)
	public void displayStatusOfchannelSub3Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfchannelSub3(), true);
	}

	@Test(priority = 115)
	public void enableStatusOfchannelSub3Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfchannelSub3(), true);
	}

	@Test(priority = 116)
	public void clickOnchannelSub3Test() throws InterruptedException {
		master.clickOnchannelSub3();
	}

	@Test(priority = 117)
	public void displayStatusOfdownArrow2Test() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfdownArrow2(), true);
	}

	@Test(priority = 118)
	public void enableStatusOfdownArrow2Test() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfdownArrow2(), true);
	}

	@Test(priority = 119)
	public void clickOndownArrow2Test() throws InterruptedException {
		master.clickOndownArrow2();
	}

	@Test(priority = 120)
	public void displayStatusOfStatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfStatus(), true);
	}

	@Test(priority = 121)
	public void enableStatusOfStatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfStatus(), true);
	}

	@Test(priority = 122)
	public void clickOnStatusTest() throws InterruptedException {
		master.clickOnStatus();
	}

	@Test(priority = 123)
	public void displayStatusOfcreate_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreate_Status(), true);
	}

	@Test(priority = 124)
	public void enableStatusOfcreate_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreate_Status(), true);
	}

	@Test(priority = 125)
	public void clickOncreate_StatusTest() throws InterruptedException {
		master.clickOncreate_Status();
	}

	@Test(priority = 126)
	public void displayStatusOfStatus_NameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfStatus_Name(), true);
	}

	@Test(priority = 127)
	public void enableStatusOfStatus_NameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfStatus_Name(), true);
	}

	@Test(priority = 128)
	public void eneterDataInStatus_NameTest() throws InterruptedException {
		master.eneterDataInStatus_Name("Break");
	}

	@Test(priority = 129)
	public void displayStatusOfStatus_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfStatus_Discription(), true);
	}

	@Test(priority = 130)
	public void enableStatusOfStatus_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfStatus_Discription(), true);
	}

	@Test(priority = 131)
	public void eneterDataInStatus_DiscriptionTest() throws InterruptedException {
		master.eneterDataInStatus_Discription("Break");
	}

	@Test(priority = 132)
	public void displayStatusOfStatus_closeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfStatus_close(), true);
	}

	@Test(priority = 133)
	public void enableStatusOfStatus_closeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfStatus_close(), true);
	}

	@Test(priority = 134)
	public void displayStatusOfStatus_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfStatus_cancel(), true);
	}

	@Test(priority = 135)
	public void enableStatusOfStatus_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfStatus_cancel(), true);
	}

//	@Test(priority = 136)
//	public void clickOnStatus_cancelTest() throws InterruptedException {
//		master.clickOnStatus_cancel();
//	}	
	@Test(priority = 137)
	public void displayStatusOfStatus_submitTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfStatus_submit(), true);
	}

	@Test(priority = 138)
	public void enableStatusOfStatus_submitTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfStatus_submit(), true);
	}

	@Test(priority = 139)
	public void clickOnStatus_submitTest() throws InterruptedException {
		master.clickOnStatus_submit();
	}
//	@Test(priority = 139)
//	public void clickOnStatus_cancelTest() throws InterruptedException {
//		master.clickOnStatus_cancel();
//	}

	@Test(priority = 140)
	public void displayStatusOfedit_statusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_status(), true);
	}

	@Test(priority = 141)
	public void enableStatusOfedit_statusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_status(), true);
	}

	@Test(priority = 142)
	public void clickOnedit_statusTest() throws InterruptedException {
		master.clickOnedit_status();
	}

	@Test(priority = 143)
	public void displayStatusOfedit_Status_NameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_Status_Name(), true);
	}

	@Test(priority = 144)
	public void enableStatusOfedit_Status_NameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_Status_Name(), true);
	}

	@Test(priority = 145)
	public void eneterDataInedit_Status_NameTest() throws InterruptedException {
		master.eneterDataInedit_Status_Name("PQR");
	}

	@Test(priority = 146)
	public void displayStatusOfedit_Status_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_Status_Discription(), true);
	}

	@Test(priority = 147)
	public void enableStatusOfedit_Status_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_Status_Discription(), true);
	}

	@Test(priority = 148)
	public void eneterDataInedit_Status_DiscriptionTest() throws InterruptedException {
		master.eneterDataInedit_Status_Discription("PQRS");
	}

	@Test(priority = 149)
	public void displayStatusOfedit_Status_closeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_Status_close(), true);
	}

	@Test(priority = 150)
	public void enableStatusOfedit_Status_closeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_Status_close(), true);
	}

	@Test(priority = 151)
	public void displayStatusOfedit_Status_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_Status_cancel(), true);
	}

	@Test(priority = 152)
	public void enableStatusOfedit_Status_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_Status_cancel(), true);
	}

//	@Test(priority = 153)
//	public void clickOnedit_Status_cancelTest() throws InterruptedException {
//		master.clickOnedit_Status_cancel();
//	}	
	@Test(priority = 154)
	public void displayStatusOfedit_Status_updateStatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_Status_updateStatus(), true);
	}

	@Test(priority = 155)
	public void enableStatusOfedit_Status_updateStatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_Status_updateStatus(), true);
	}

//	@Test(priority = 156)
//	public void clickOnedit_Status_updateStatusTest() throws InterruptedException {
//		master.clickOnedit_Status_updateStatus();
//	}	
	@Test(priority = 156)
	public void clickOnedit_Status_cancelTest() throws InterruptedException {
		master.clickOnedit_Status_cancel();
	}

	@Test(priority = 157)
	public void displayStatusOfStatus_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfStatus_Status(), true);
	}

	@Test(priority = 158)
	public void enableStatusOfStatus_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfStatus_Status(), true);
	}

	@Test(priority = 159)
	public void clickOnStatus_StatusTest() throws InterruptedException {
		master.clickOnStatus_Status();
	}

	@Test(priority = 160)
	public void displayStatusOfskillSetTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfskillSet(), true);
	}

	@Test(priority = 161)
	public void enableStatusOfskillSetTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfskillSet(), true);
	}

	@Test(priority = 162)
	public void clickOnskillSetTest() throws InterruptedException {
		master.clickOnskillSet();
	}

	@Test(priority = 163)
	public void displayStatusOfcreateSkillTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreateSkill(), true);
	}

	@Test(priority = 164)
	public void enableStatusOfcreateSkillTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreateSkill(), true);
	}

	@Test(priority = 165)
	public void clickOncreateSkillTest() throws InterruptedException {
		master.clickOncreateSkill();
	}

	@Test(priority = 166)
	public void displayStatusOfskillNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfskillName(), true);
	}

	@Test(priority = 167)
	public void enableStatusOfskillNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfskillName(), true);
	}

	@Test(priority = 168)
	public void clickOnskillNameTest() throws InterruptedException {
		master.enterDataInskillName("HR");
	}

	@Test(priority = 169)
	public void displayStatusOfskill_closeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfskill_close(), true);
	}

	@Test(priority = 170)
	public void enableStatusOfskill_closeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfskill_close(), true);
	}

	@Test(priority = 171)
	public void displayStatusOfskill_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfskill_cancel(), true);
	}

	@Test(priority = 172)
	public void enableStatusOfskill_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfskill_cancel(), true);
	}

//	@Test(priority = 173)
//	public void clickOnskill_cancelTest() throws InterruptedException {
//		master.clickOnskill_cancel();
//	}	
	@Test(priority = 174)
	public void displayStatusOfSkillsubmitTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfSkillsubmit(), true);
	}

	@Test(priority = 175)
	public void enableStatusOfSkillsubmitTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfSkillsubmit(), true);
	}

	@Test(priority = 176)
	public void clickOnskillsubmitTest() throws InterruptedException {
		master.clickOnskillsubmit();
	}
//	@Test(priority = 176)
//	public void clickOnskill_cancelTest() throws InterruptedException {
//		master.clickOnskill_cancel();
//	}

	@Test(priority = 177)
	public void displayStatusOfeditSkillTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditSkill(), true);
	}

	@Test(priority = 178)
	public void enableStatusOfeditSkillTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditSkill(), true);
	}

	@Test(priority = 179)
	public void clickOneditSkillTest() throws InterruptedException {
		master.clickOneditSkill();
	}

	@Test(priority = 180)
	public void displayStatusOfedit_skillNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_skillName(), true);
	}

	@Test(priority = 181)
	public void enableStatusOfedit_skillNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_skillName(), true);
	}

	@Test(priority = 182)
	public void enterDataInedit_skillNameTest() throws InterruptedException {
		master.enterDataInedit_skillName("PQR");
	}

	@Test(priority = 183)
	public void displayStatusOfedit_skill_closeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_skill_close(), true);
	}

	@Test(priority = 184)
	public void enableStatusOfedit_skill_closeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_skill_close(), true);
	}

	@Test(priority = 185)
	public void displayStatusOfedit_skill_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_skill_cancel(), true);
	}

	@Test(priority = 186)
	public void enableStatusOfedit_skill_cancelTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_skill_cancel(), true);
	}

//	@Test(priority = 187)
//	public void clickOnedit_skill_cancelTest() throws InterruptedException {
//		master.clickOnedit_skill_cancel();
//	}	
	@Test(priority = 188)
	public void displayStatusOfupdateSkillTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfupdateSkill(), true);
	}

	@Test(priority = 189)
	public void enableStatusOfupdateSkillTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfupdateSkill(), true);
	}

//	@Test(priority = 190)
//	public void clickOnupdateSkillTest() throws InterruptedException {
//		master.clickOnupdateSkill();
//	}	
	@Test(priority = 190)
	public void clickOnedit_skill_cancelTest() throws InterruptedException {
		master.clickOnedit_skill_cancel();
	}

	@Test(priority = 191)
	public void displayStatusOfskill_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfskill_Status(), true);
	}

	@Test(priority = 192)
	public void enableStatusOfskill_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfskill_Status(), true);
	}

	@Test(priority = 193)
	public void clickOnskill_StatusTest() throws InterruptedException {
		master.clickOnskill_Status();
	}

	@Test(priority = 194)
	public void displayStatusOfskillProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfskillProfeciancy(), true);
	}

	@Test(priority = 195)
	public void enableStatusOfskillProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfskillProfeciancy(), true);
	}

	@Test(priority = 196)
	public void clickOnskillProfeciancyTest() throws InterruptedException {
		master.clickOnskillProfeciancy();
	}

	@Test(priority = 197)
	public void displayStatusOfcreateProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreateProfeciancy(), true);
	}

	@Test(priority = 198)
	public void enableStatusOfcreateProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreateProfeciancy(), true);
	}

	@Test(priority = 199)
	public void clickOncreateProfeciancyTest() throws InterruptedException {
		master.clickOncreateProfeciancy();
	}

	@Test(priority = 200)
	public void displayStatusOfskillProfeciancyNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfskillProfeciancyName(), true);
	}

	@Test(priority = 201)
	public void enableStatusOfskillProfeciancyNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfskillProfeciancyName(), true);
	}

	@Test(priority = 202)
	public void entertDataInskillProfeciancyNameTest() throws InterruptedException {
		master.entertDataInskillProfeciancyName("Basic");
	}

	@Test(priority = 203)
	public void displayStatusOfcloseProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcloseProfeciancy(), true);
	}

	@Test(priority = 204)
	public void enableStatusOfcloseProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcloseProfeciancy(), true);
	}

//	@Test(priority = 205)
//	public void clickOncloseProfeciancyTest() throws InterruptedException {
//		master.clickOncloseProfeciancy();
//	}
	@Test(priority = 206)
	public void displayStatusOfsubmitProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfsubmitProfeciancy(), true);
	}

	@Test(priority = 207)
	public void enableStatusOfsubmitProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfsubmitProfeciancy(), true);
	}

//	@Test(priority = 208)
//	public void clickOnsubmitProfeciancyTest() throws InterruptedException {
//		master.clickOnsubmitProfeciancy();
//	}	
	@Test(priority = 209)
	public void displayStatusOfcancelProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcancelProfeciancy(), true);
	}

	@Test(priority = 210)
	public void enableStatusOfcancelProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcancelProfeciancy(), true);
	}

//	@Test(priority = 211)
//	public void clickOncancelProfeciancyTest() throws InterruptedException {
//		master.clickOncancelProfeciancy();
//	}
	@Test(priority = 211)
	public void clickOnsubmitProfeciancyTest() throws InterruptedException {
		master.clickOnsubmitProfeciancy();
	}

	@Test(priority = 212)
	public void displayStatusOfeditProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfeditProfeciancy(), true);
	}

	@Test(priority = 213)
	public void enableStatusOfeditProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfeditProfeciancy(), true);
	}

	@Test(priority = 214)
	public void clickOneditProfeciancyTest() throws InterruptedException {
		master.clickOneditProfeciancy();
	}

	@Test(priority = 215)
	public void displayStatusOfedit_skillProfeciancyNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_skillProfeciancyName(), true);
	}

	@Test(priority = 216)
	public void enableStatusOfedit_skillProfeciancyNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_skillProfeciancyName(), true);
	}

	@Test(priority = 217)
	public void entertDataInedit_skillProfeciancyNameTest() throws InterruptedException {
		master.entertDataInedit_skillProfeciancyName("PQR");
	}

	@Test(priority = 218)
	public void displayStatusOfedit_closeProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_closeProfeciancy(), true);
	}

	@Test(priority = 219)
	public void enableStatusOfedit_closeProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_closeProfeciancy(), true);
	}

//	@Test(priority = 220)
//	public void clickOnedit_closeProfeciancyTest() throws InterruptedException {
//		master.clickOnedit_closeProfeciancy();
//	}	
	@Test(priority = 221)
	public void displayStatusOfedit_updateProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_updateProfeciancy(), true);
	}

	@Test(priority = 222)
	public void enableStatusOfedit_updateProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_updateProfeciancy(), true);
	}

//	@Test(priority = 223)
//	public void clickOnedit_updateProfeciancyTest() throws InterruptedException {
//		master.clickOnedit_updateProfeciancy();
//	}	
	@Test(priority = 224)
	public void displayStatusOfedit_cancelProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_cancelProfeciancy(), true);
	}

	@Test(priority = 225)
	public void enableStatusOfedit_cancelProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_cancelProfeciancy(), true);
	}

	@Test(priority = 226)
	public void clickOnedit_cancelProfeciancyTest() throws InterruptedException {
		master.clickOnedit_cancelProfeciancy();
	}

	@Test(priority = 227)
	public void displayStatusOfprofeciancy_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfprofeciancy_Status(), true);
	}

	@Test(priority = 228)
	public void enableStatusOfprofeciancy_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfprofeciancy_Status(), true);
	}

	@Test(priority = 229)
	public void clickOnprofeciancy_StatusTest() throws InterruptedException {
		master.clickOnprofeciancy_Status();
	}

	@Test(priority = 230)
	public void displayStatusOflanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOflanguage(), true);
	}

	@Test(priority = 231)
	public void enableStatusOflanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOflanguage(), true);
	}

	@Test(priority = 232)
	public void clickOnlanguageTest() throws InterruptedException {
		master.clickOnlanguage();
	}

	@Test(priority = 233)
	public void displayStatusOfcreateLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreateLanguage(), true);
	}

	@Test(priority = 234)
	public void enableStatusOfcreateLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreateLanguage(), true);
	}

	@Test(priority = 235)
	public void clickOncreateLanguageTest() throws InterruptedException {
		master.clickOncreateLanguage();
	}

	@Test(priority = 236)
	public void displayStatusOflanguageNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOflanguageName(), true);
	}

	@Test(priority = 237)
	public void enableStatusOflanguageNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOflanguageName(), true);
	}

	@Test(priority = 238)
	public void enterDataInlanguageNameTest() throws InterruptedException {
		master.enterDataInlanguageName("Hindi");
	}

	@Test(priority = 239)
	public void displayStatusOflanguageCodeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOflanguageCode(), true);
	}

	@Test(priority = 240)
	public void enableStatusOflanguageCodeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOflanguageCode(), true);
	}

	@Test(priority = 241)
	public void enterDataInlanguageCodeTest() throws InterruptedException {
		master.enterDataInlanguageCode("Hindi");
	}

	@Test(priority = 242)
	public void displayStatusOfcloseLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcloseLanguage(), true);
	}

	@Test(priority = 243)
	public void enableStatusOfcloseLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcloseLanguage(), true);
	}

//	@Test(priority = 244)
//	public void clickOncloseLanguageTest() throws InterruptedException {
//		master.clickOncloseLanguage();
//	}	
	@Test(priority = 245)
	public void displayStatusOfsubmitLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfsubmitLanguage(), true);
	}

	@Test(priority = 246)
	public void enableStatusOfsubmitLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfsubmitLanguage(), true);
	}

//	@Test(priority = 247)
//	public void clickOnsubmitLanguageTest() throws InterruptedException {
//		master.clickOnsubmitLanguage();
//	}	
	@Test(priority = 248)
	public void displayStatusOfcancelLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcancelLanguage(), true);
	}

	@Test(priority = 249)
	public void enableStatusOfcancelLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcancelLanguage(), true);
	}

//	@Test(priority = 250)
//	public void clickOncancelLanguageTest() throws InterruptedException {
//		master.clickOncancelLanguage();
//	}
	@Test(priority = 250)
	public void clickOnsubmitLanguageTest() throws InterruptedException {
		master.clickOnsubmitLanguage();
	}

	@Test(priority = 251)
	public void displayStatusOfedit_LanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_Language(), true);
	}

	@Test(priority = 252)
	public void enableStatusOfedit_LanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_Language(), true);
	}

	@Test(priority = 253)
	public void clickOnedit_LanguageTest() throws InterruptedException {
		master.clickOnedit_Language();
	}

	@Test(priority = 254)
	public void displayStatusOfedit_languageNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_languageName(), true);
	}

	@Test(priority = 255)
	public void enableStatusOfedit_languageNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_languageName(), true);
	}

	@Test(priority = 256)
	public void enterDataInedit_languageNameTest() throws InterruptedException {
		master.enterDataInedit_languageName("PQR");
	}

	@Test(priority = 257)
	public void displayStatusOfedit_languageCodeTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_languageCode(), true);
	}

	@Test(priority = 258)
	public void enableStatusOfedit_languageCodeTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_languageCode(), true);
	}

	@Test(priority = 259)
	public void enterDataInedit_languageCodeTest() throws InterruptedException {
		master.enterDataInedit_languageCode("PQRS");
	}

	@Test(priority = 260)
	public void displayStatusOfedit_closeLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_closeLanguage(), true);
	}

	@Test(priority = 261)
	public void enableStatusOfedit_closeLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_closeLanguage(), true);
	}

//	@Test(priority = 262)
//	public void clickOnedit_closeLanguageTest() throws InterruptedException {
//		master.clickOnedit_closeLanguage();
//	}	
	@Test(priority = 263)
	public void displayStatusOfedit_updateLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_updateLanguage(), true);
	}

	@Test(priority = 264)
	public void enableStatusOfedit_updateLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_updateLanguage(), true);
	}

//	@Test(priority = 265)
//	public void clickOnedit_updateLanguageTest() throws InterruptedException {
//		master.clickOnedit_updateLanguage();
//	}	
	@Test(priority = 266)
	public void displayStatusOfedit_cancelLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_cancelLanguage(), true);
	}

	@Test(priority = 267)
	public void enableStatusOfedit_cancelLanguageTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_cancelLanguage(), true);
	}

	@Test(priority = 268)
	public void clickOnedit_cancelLanguageTest() throws InterruptedException {
		master.clickOnedit_cancelLanguage();
	}

	@Test(priority = 269)
	public void displayStatusOfedit_Language_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_Language_Status(), true);
	}

	@Test(priority = 270)
	public void enableStatusOfedit_Language_StatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_Language_Status(), true);
	}

	@Test(priority = 271)
	public void clickOnedit_Language_StatusTest() throws InterruptedException {
		master.clickOnedit_Language_Status();
	}

	@Test(priority = 272)
	public void displayStatusOflanguage_ProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOflanguage_Proficiency(), true);
	}

	@Test(priority = 273)
	public void enableStatusOflanguage_ProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOflanguage_Proficiency(), true);
	}

	@Test(priority = 274)
	public void clickOnlanguage_ProficiencyTest() throws InterruptedException {
		master.clickOnlanguage_Proficiency();
	}

	@Test(priority = 275)
	public void displayStatusOfcreateProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcreateProficiency(), true);
	}

	@Test(priority = 276)
	public void enableStatusOfcreateProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcreateProficiency(), true);
	}

	@Test(priority = 277)
	public void clickOncreateProficiencyTest() throws InterruptedException {
		master.clickOncreateProficiency();
	}

	@Test(priority = 278)
	public void displayStatusOflanguageProficiencyNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOflanguageProficiencyName(), true);
	}

	@Test(priority = 279)
	public void enableStatusOflanguageProficiencyNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOflanguageProficiencyName(), true);
	}

	@Test(priority = 280)
	public void enterDataInlanguageProficiencyNameTest() throws InterruptedException {
		master.enterDataInlanguageProficiencyName("Basic");
	}

	@Test(priority = 281)
	public void displayStatusOfcloseLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcloseLanguageProficiency(), true);
	}

	@Test(priority = 282)
	public void enableStatusOfcloseLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcloseLanguageProficiency(), true);
	}

//	@Test(priority = 283)
//	public void clickOncloseLanguageProficiencyTest() throws InterruptedException {
//		master.clickOncloseLanguageProficiency();
//	}	
	@Test(priority = 284)
	public void displayStatusOfsubmitLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfsubmitLanguageProficiency(), true);
	}

	@Test(priority = 285)
	public void enableStatusOfsubmitLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfsubmitLanguageProficiency(), true);
	}

//	@Test(priority = 286)
//	public void clickOnsubmitLanguageProficiencyTest() throws InterruptedException {
//		master.clickOnsubmitLanguageProficiency();
//	}	
	@Test(priority = 287)
	public void displayStatusOfcancelLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfcancelLanguageProficiency(), true);
	}

	@Test(priority = 288)
	public void enableStatusOfcancelLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfcancelLanguageProficiency(), true);
	}

//	@Test(priority = 289)
//	public void clickOncancelLanguageProficiencyTest() throws InterruptedException {
//		master.clickOncancelLanguageProficiency();
//	}
	@Test(priority = 289)
	public void clickOnsubmitLanguageProficiencyTest() throws InterruptedException {
		master.clickOnsubmitLanguageProficiency();
	}

	@Test(priority = 290)
	public void displayStatusOfedit_LanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_LanguageProficiency(), true);
	}

	@Test(priority = 291)
	public void enableStatusOfedit_LanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_LanguageProficiency(), true);
	}

	@Test(priority = 292)
	public void clickOnedit_LanguageProficiencyTest() throws InterruptedException {
		master.clickOnedit_LanguageProficiency();
	}

	@Test(priority = 293)
	public void displayStatusOfedit_languageProficiencyNameTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_languageProficiencyName(), true);
	}

	@Test(priority = 294)
	public void enableStatusOfedit_languageProficiencyNameTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_languageProficiencyName(), true);
	}

	@Test(priority = 295)
	public void enterDataInedit_languageProficiencyNameTest() throws InterruptedException {
		master.enterDataInedit_languageProficiencyName("PQR");
	}

	@Test(priority = 296)
	public void displayStatusOfedit_closeLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_closeLanguageProficiency(), true);
	}

	@Test(priority = 297)
	public void enableStatusOfedit_closeLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_closeLanguageProficiency(), true);
	}

//	@Test(priority = 298)
//	public void clickOnedit_closeLanguageProficiencyTest() throws InterruptedException {
//		master.clickOnedit_closeLanguageProficiency();
//	}	
	@Test(priority = 299)
	public void displayStatusOfedit_updateLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_updateLanguageProficiency(), true);
	}

	@Test(priority = 300)
	public void enableStatusOfedit_updateLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_updateLanguageProficiency(), true);
	}

//	@Test(priority = 301)
//	public void clickOnedit_updateLanguageProficiencyTest() throws InterruptedException {
//		master.clickOnedit_updateLanguageProficiency();
//	}	
	@Test(priority = 302)
	public void displayStatusOfedit_cancelLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_cancelLanguageProficiency(), true);
	}

	@Test(priority = 303)
	public void enableStatusOfedit_cancelLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_cancelLanguageProficiency(), true);
	}

	@Test(priority = 304)
	public void clickOnedit_cancelLanguageProficiencyTest() throws InterruptedException {
		master.clickOnedit_cancelLanguageProficiency();
	}

	@Test(priority = 305)
	public void displayStatusOfedit_languageProficiencyStatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_languageProficiencyStatus(), true);
	}

	@Test(priority = 306)
	public void enableStatusOfedit_languageProficiencyStatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_languageProficiencyStatus(), true);
	}

	@Test(priority = 307)
	public void clickOnedit_languageProficiencyStatusTest() throws InterruptedException {
		master.clickOnedit_languageProficiencyStatus();
	}

	@Test(priority = 308)
	public void displayStatusOfedit_routingAlgorithmTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_routingAlgorithm(), true);
	}

	@Test(priority = 309)
	public void enableStatusOfedit_routingAlgorithmTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_routingAlgorithm(), true);
	}

	@Test(priority = 310)
	public void clickOnedit_routingAlgorithmTest() throws InterruptedException {
		master.clickOnedit_routingAlgorithm();
	}

	@Test(priority = 311)
	public void displayStatusOfedit_routingAlgorithmStatusTest() throws InterruptedException {
		Assert.assertEquals(master.displayStatusOfedit_routingAlgorithmStatus(), true);
	}

	@Test(priority = 312)
	public void enableStatusOfedit_routingAlgorithmStatusTest() throws InterruptedException {
		Assert.assertEquals(master.enableStatusOfedit_routingAlgorithmStatus(), true);
	}

	@Test(priority = 313)
	public void clickOnedit_routingAlgorithmStatusTest() throws InterruptedException {
		master.clickOnedit_routingAlgorithmStatus();
	}

//	@Test(priority = 314)
//	public void displayStatusOfmoduleMasterTest() throws InterruptedException {
//		Assert.assertEquals(master.displayStatusOfmoduleMaster(), true);
//	}	
//	@Test(priority = 315)
//	public void enableStatusOfmoduleMasterTest() throws InterruptedException {
//		Assert.assertEquals(master.enableStatusOfmoduleMaster(), true);
//	}	
//	@Test(priority = 316)
//	public void clickOnmoduleMasterTest() throws InterruptedException {
//		master.clickOnmoduleMaster();
//	}	
//	@Test(priority = 317)
//	public void displayStatusOfselectAppNameTest() throws InterruptedException {
//		Assert.assertEquals(master.displayStatusOfselectAppName(), true);
//	}	
//	@Test(priority = 318)
//	public void enableStatusOfselectAppNameTest() throws InterruptedException {
//		Assert.assertEquals(master.enableStatusOfselectAppName(), true);
//	}	
//	@Test(priority = 319)
//	public void clickOnselectAppNameTest() throws InterruptedException {
//		master.clickOnselectAppName();
//	}	
//	@Test(priority = 320)
//	public void selectTheDpValueFromSelectAppNameTest() throws InterruptedException {
//		master.selectTheDpValueFromSelectAppName("Agent Desktop");
//	}
}
