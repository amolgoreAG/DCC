package NegativeTestCasesForChatInterfaceTest;

import java.io.File;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import UtilsLayerPackage.ExcelReader;
import io.github.bonigarcia.wdm.WebDriverManager;

public class one_agent_one_customer {
	private static Logger log = Logger.getLogger(one_agent_one_customer.class);
	
	
	private static WebDriver driver;
	private static ExcelReader excel;
	private static String Agent1 ;
	private static String customerPortal ;
	private static WebElement chatNow1;
	private static WebElement username1;
	private static WebElement email;
	private static WebElement phoneNumber;
	private static WebElement skillset;
	private static WebElement language;
	private static WebElement close;
	private static WebElement chat;
	private static WebElement complaint;
	private static WebElement message;
	private static WebElement acceptCall;
	private static WebElement startChat;
	private static WebElement messageBox;
	private static WebElement sendbtn;
	
	@Test(priority = 1, dataProvider = "login")
	public static void chatInterFace(String scenario, String Username, String Password) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("use-fake-ui-for-media-stream");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\DCC.xlsx");
//		String chatInterfaceURL = excel.getDataFromExcelSheet(0, 17, 1);
		driver.get("https://dcc.inaipi.ae/?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
		log.info("Open Chat Interface Url for login Agent");
		Thread.sleep(3000);
		WebElement username = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		Thread.sleep(2000); 
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green';", username);
		Thread.sleep(2000); 
		username.sendKeys(Username);
		log.info("Enter Username  : " + Username);
		Thread.sleep(3000);
		WebElement password = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		Thread.sleep(2000);
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green';", password);
		Thread.sleep(2000);
		password.sendKeys(Password);
		log.info("Enter Password  : "+ Password);
		Thread.sleep(3000);
		WebElement login = driver.findElement(By.xpath("//div[text()='Login']"));
		Thread.sleep(2000);
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green';", login);
		Thread.sleep(2000);
		login.click();
		log.info("Click on login");
		Thread.sleep(3000);

		if (scenario.equals("both_UserName_and_Password_InCorrect")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("you are able to login by enter both_UserName_and_Password_InCorrectt");
				log.info("you are able to login by enter both_UserName_and_Password_InCorrectt");
			} catch (Exception e) {
				System.out.println();
				System.out.println("you are not able to login by enter both_UserName_and_Password_InCorrect");
				log.info("you are not able to login by enter both_UserName_and_Password_InCorrect");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		} else if (scenario.equals("Correct_UserName_and_Incorrect_Password")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with correct username and incorrect password");
				log.info("You are able to login with correct username and incorrect password");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with correct username and incorrect password");
				log.info("You are not able to login with correct username and incorrect password");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		} else if (scenario.equals("Incorrect_UserName_and_Correct_Password")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with Incorrect_UserName_and_Correct_Password");
				log.info("You are able to login with Incorrect_UserName_and_Correct_Password");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with Incorrect_UserName_and_Correct_Password");
				log.info("You are not able to login with Incorrect_UserName_and_Correct_Password");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		} else if (scenario.equals("Incorrect_Username_and_blank_Password")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with Incorrect_Username_and_blank_Password");
				log.info("You are able to login with Incorrect_Username_and_blank_Password");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with Incorrect_Username_and_blank_Password");
				log.info("You are not able to login with Incorrect_Username_and_blank_Password");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		}else if(scenario.equals("Correct_Username_and_blank_Password")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with Correct_Username_and_blank_Password");
				log.info("You are able to login with Correct_Username_and_blank_Password");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with Correct_Username_and_blank_Password");
				log.info("You are not able to login with Correct_Username_and_blank_Password");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		}else if(scenario.equals("Blank_Username_and_Incorrect_Password")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with Blank_Username_and_Incorrect_Password");
				log.info("You are able to login with Blank_Username_and_Incorrect_Password");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with Blank_Username_and_Incorrect_Password");
				log.info("You are not able to login with Blank_Username_and_Incorrect_Password");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		}else if(scenario.equals("Blank_Username_and_Correct_Password")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with Blank_Username_and_Correct_Password");
				log.info("You are able to login with Blank_Username_and_Correct_Password");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with Blank_Username_and_Correct_Password");
				log.info("You are not able to login with Blank_Username_and_Correct_Password");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		}else if(scenario.equals("username_and_password_Both_are_Blank")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with username_and_password_Both_are_Blank");
				log.info("You are able to login with username_and_password_Both_are_Blank");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with username_and_password_Both_are_Blank");
				log.info("You are not able to login with username_and_password_Both_are_Blank");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		}else if(scenario.equals("username_and_password_both_r_upperCase")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with username_and_password_both_r_upperCase");
				log.info("You are able to login with username_and_password_both_r_upperCase");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with username_and_password_both_r_upperCase");
				log.info("You are not able to login with username_and_password_both_r_upperCase");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		}else if(scenario.equals("Uername_is_corrrect_but_upper_case_and_correct_password")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with Uername_is_corrrect_but_upper_case_and_correct_password");
				log.info("You are able to login with Uername_is_corrrect_but_upper_case_and_correct_password");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with Uername_is_corrrect_but_upper_case_and_correct_password");
				log.info("You are not able to login with Uername_is_corrrect_but_upper_case_and_correct_password");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		}else if(scenario.equals("Uername_is_corrrect_but_Lower_case_and_correct_password_Upper_case")) {
			try {
				WebElement logout = driver.findElement(By.xpath("//button[text()='Logout']"));
				Assert.assertEquals(logout.isDisplayed(), true);
				String title = driver.getTitle();
				System.out.println(title);
				boolean Title = title.equalsIgnoreCase("Inaipi-Digital");
				Assert.assertEquals(Title, true);
				System.out.println("You are able to login with Uername_is_corrrect_but_Lower_case_and_correct_password_Upper_case");
				log.info("You are able to login with Uername_is_corrrect_but_Lower_case_and_correct_password_Upper_case");
			} catch (Exception e) {
				System.out.println();
				System.out.println("You are not able to login with Uername_is_corrrect_but_Lower_case_and_correct_password_Upper_case");
				log.info("You are not able to login with Uername_is_corrrect_but_Lower_case_and_correct_password_Upper_case");
				System.out.println();
				driver.close();
				log.info("close the browser");
			}
		}
	}

	@DataProvider(name = "login")
	public Object[][] getData() {
		return new Object[][] {
				{ "both_UserName_and_Password_InCorrect", "ProductOwnerUrdu417gmail.com", "Welcome@1234" },
				{ "Correct_UserName_and_Incorrect_Password", "ProductOwnerUrdu417@gmail.com", "Welcome@1234" },
				{ "Incorrect_UserName_and_Correct_Password", "ProductOwnerUrdu417gmail.com", "Welcome@123" },
				{ "Incorrect_Username_and_blank_Password", "ProductOwnerUrdu417gmail.com", "" },
				{ "Correct_Username_and_blank_Password", "ProductOwnerUrdu417@gmail.com", "" },
				{ "Blank_Username_and_Incorrect_Password", "", "Welcome@1234" },
				{ "Blank_Username_and_Correct_Password", "", "Welcome@1234" },
				{ "username_and_password_Both_are_Blank", "", "" },
				{ "username_and_password_both_r_upperCase", "PRODUCTOWNERURDU417@GMAIL.COM", "WELCOME@123" },
				{"Uername_is_corrrect_but_upper_case_and_correct_password","PRODUCTOWNERURDU417@GMAIL.COM","Welcome@123"},
				{"Uername_is_corrrect_but_Lower_case_and_correct_password_Upper_case","ProductOwnerUrdu417@gmail.com","WELCOME@123"}};
	}
	
	@Test(priority = 2)
	public void loginWithAgentPortal() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("use-fake-ui-for-media-stream");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		excel = new ExcelReader("C:\\Users\\cognicx\\Desktop\\DCC.xlsx");
//		String chatInterfaceURL = excel.getDataFromExcelSheet(0, 17, 1);
		driver.get("https://dcc.inaipi.ae/?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
		log.info("Open Chat Interface Url for login Agent");
		Thread.sleep(2000);
		WebElement username = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		Thread.sleep(2000);
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green';", username);
		Thread.sleep(2000);
		username.sendKeys("ProductOwnerUrdu417@gmail.com");
		log.info("Enter Username");
		WebElement password = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		Thread.sleep(2000);
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green';", password);
		Thread.sleep(2000);
		password.sendKeys("Welcome@123");
		log.info("Enter Password");
		WebElement login = driver.findElement(By.xpath("//div[text()='Login']"));
		Thread.sleep(2000);
		((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid green';", login);
		Thread.sleep(2000);
		login.click();
		log.info("Click on login");
		Thread.sleep(3000);
		String homepage = driver.getCurrentUrl();
		System.out.println(homepage);
		if(homepage.equalsIgnoreCase("https://dcc.inaipi.ae/main/Dashboard")) {
			System.out.println("Welcome To Agent Home Page");
		}else {
			Thread.sleep(3000);
			WebElement logout1 = driver.findElement(By.xpath("//button[text()='Logout']"));
			logout1.click();
			log.info("tab on logout");
			Thread.sleep(3000);
			WebElement username1 = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
			username1.sendKeys("ProductOwnerUrdu417@gmail.com");
			log.info("Enter Username");
			WebElement password1 = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
			password1.sendKeys("Welcome@123");
			log.info("Enter Password");
			WebElement login1 = driver.findElement(By.xpath("//div[text()='Login']"));
			login1.click();
			log.info("Click on login");
		}
	}
	@Test(priority = 3)
	public void chngeTheStatusGoreadyToReady() throws Exception{
		Thread.sleep(3000);
		WebElement status = driver.findElement(By.xpath("//div[@class='neo-nav-status neo-nav-status--connected ']"));
		status.click();
		log.info("tab on status");
		WebElement goreayToReady = driver.findElement(By.xpath("//button[@class='btn btn-success work-start']"));
		goreayToReady.click();
		Thread.sleep(2000);
		log.info("tab on goready");
		WebElement close = driver.findElement(By.xpath("//span[@class='neo-icon-close user-close']"));
		close.click();
		log.info("tab on close");
		Agent1 = driver.getCurrentUrl();
		System.out.println("Agent1 : " + Agent1);
	}
	@Test(priority = 4)
	public void navigateToCustomerPortal() {
		driver.navigate().to("https://dcc.inaipi.ae/CustomerPortal?tenantID=a3dc14bd-fe70-4120-8572-461b0dc866b5");
		log.info("navigate to customer portal");
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		log.info("tab on chat");
	}
	@Test(priority = 5)
	public void tabOnChatNow1() throws Exception {
		Thread.sleep(2000);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Direct Tab On Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 6)
	public void enterUsernameAndClickOnChatNow() throws Exception{
		username1 = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		username1.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(3000);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		Thread.sleep(2000);
		log.info("Enter Username and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 7)
	public void enterEmailAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Email and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 8)
	public void enterPhoneNumberAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter PhoneNumber and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 9)
	public void selectSkillSetAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Select Skill Set and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 10)
	public void selectLanguageAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Select Language and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 11)
	public void selectComplaintTypeAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		complaint = driver.findElement(By.xpath("//select[@id='select_complain_type']"));
		new Select(complaint).selectByVisibleText("Help");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Select Cmplaint Type and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 12)
	public void enterUsernameAndEmailAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		username1 = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		username1.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(3000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Eneter Username and Email and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 13)
	public void enterEmailAndPhoneNumberAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Email and Phone Numeber and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 14)
	public void enterPhoneNumberAndSkillSetAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Phone Numeber and skillset and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 15)
	public void enterSkillSetAndLanguageAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter skill set and Language and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 16)
	public void enterLanguageAndComplaintTypeAndClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		complaint = driver.findElement(By.xpath("//select[@id='select_complain_type']"));
		new Select(complaint).selectByVisibleText("Help");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Language and complaint Type and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 17)
	public void enterUsername_Email_MobileNumber_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		username1 = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		username1.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(3000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Username , Email , Mobile Number and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 18)
	public void enterEmail_PhoneNumber_skillset_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Email , Phone Numeber , Skill Set and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 19)
	public void enterPhoneNumber_SkillSet_Language_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Phone Numeber , skillset , Language and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 20)
	public void enterSkillSet_Language_complaintType_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		complaint = driver.findElement(By.xpath("//select[@id='select_complain_type']"));
		new Select(complaint).selectByVisibleText("Help");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter skill set , Language , Complaint Type and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 21)
	public void enterUsername_Email_MobileNumber_Skillset_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		username1 = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		username1.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(3000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Username , Email , Mobile Number , skill set and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 22)
	public void enterEmail_PhoneNumber_skillset_Language_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Email , Phone Numeber , Skill Set , Language and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 23)
	public void enterPhoneNumber_SkillSet_Language_ComplaintType_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		complaint = driver.findElement(By.xpath("//select[@id='select_complain_type']"));
		new Select(complaint).selectByVisibleText("Help");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Phone Numeber , skillset , Language , Complaint Type and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 24)
	public void enterUsername_Email_MobileNumber_Skillset_Language_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		username1 = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		username1.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(3000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Username , Email , Mobile Number , skill set , Language and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 25)
	public void enterEmail_PhoneNumber_skillset_Language_ComplaintType_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		complaint = driver.findElement(By.xpath("//select[@id='select_complain_type']"));
		new Select(complaint).selectByVisibleText("Help");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Email , Phone Numeber , Skill Set , Language , Complaint Type and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
	}
	@Test(priority = 26)
	public void enterUsername_Email_MobileNumber_Skillset_Language_ComplaintType_and_ClickOnChatNow() throws InterruptedException {
		close = driver.findElement(By.xpath("//button[starts-with(@class,'btn btn-outline-primary1')]/i"));
		close.click();
		Thread.sleep(5000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
		Thread.sleep(2000);
		username1 = driver.findElement(By.xpath("//input[@id='exampleFormControlInput1']"));
		username1.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(3000);
		email = driver.findElement(By.xpath("//input[@id='exampleFormControlInput2']"));
		email.sendKeys("Anmol" + UtilsLayerPackage.RandomIntData.randomInt() + "@gmail.com");
		Thread.sleep(1500);
		phoneNumber = driver.findElement(By.xpath("//input[@id='exampleFormControlInput3']"));
		phoneNumber.sendKeys("951026" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		skillset = driver.findElement(By.xpath("//select[@id='select_skillset']"));
		new Select(skillset).selectByVisibleText("Product Owner");
		Thread.sleep(1500);
		language = driver.findElement(By.xpath("//select[@id='select_language']"));
		new Select(language).selectByVisibleText("Urdu");
		Thread.sleep(1500);
		complaint = driver.findElement(By.xpath("//select[@id='select_complain_type']"));
		new Select(complaint).selectByVisibleText("Help");
		Thread.sleep(1500);
		chatNow1 = driver.findElement(By.xpath("//button[text()='Chat Now']"));
		Thread.sleep(2000);
		new Actions(driver).moveToElement(chatNow1).build().perform();
		chatNow1.click();
		log.info("Enter Username , Email , Mobile Number , skill set , Language , Complaint Type and tab on Chat Now");
		Thread.sleep(3000);
		try {
			WebElement load = driver.findElement(By.xpath("//div[text()='load more']"));
			String xyz = load.getText();
			System.out.println("xyz : " + xyz);
			log.info("Now customer redy to chat with agent");
		} catch (Exception e) {
			log.error("Plese Enter Other Details also to connect to the agent");
		}
		customerPortal = driver.getCurrentUrl();
		
		System.out.println("customerPortal URL : " + customerPortal);
	}
	@Test(priority = 27)
	public void navigateToAgentPortal_and_Accept_The_Call()throws Exception{
		driver.navigate().to(Agent1);;
		log.info("navigate to agent portal for accept the call");
		Thread.sleep(3000);
		message = driver.findElement(By.xpath("//i[text()='sms']"));
		Thread.sleep(4000);
		message.click();
		log.info("tab on message");
		Thread.sleep(4000);
		acceptCall = driver.findElement(By.xpath("//button[@id='accept_client_chat']//p[text()='Accept']"));
		acceptCall.click();
		log.info("Accept the call");
		Thread.sleep(4000);
		startChat = driver.findElement(By.xpath("//div[@class='d-flex justify-content-between w-100']"));
		startChat.click();	
		log.info("start the chatting");
		Thread.sleep(3000);
	}
	@Test(priority = 28)
	public void tabOnSendButton() throws InterruptedException {
		sendbtn = driver.findElement(By.xpath("//span[text()='send']"));
		if(sendbtn.isDisplayed()) {
			log.info("display status of sendbtn : " + sendbtn.isDisplayed());
			sendbtn.click();
			log.info("without entering the message click on sendbtn");
		}else {
			log.info("please enter some message first then only you can send the message");
		}
	}
	@Test(priority = 29)
	public void enterMessageAndTabOnSendBtn() throws Exception {
		messageBox = driver.findElement(By.xpath("//textarea[@placeholder='Enter your message...']"));
		messageBox.click();
		Thread.sleep(3000);
		messageBox.sendKeys("Hi........");
		Thread.sleep(3000);
		sendbtn.click();
		log.info("Enter Message and tab on send button");
	}
	@Test(priority = 30)
	public void selectEmojiAndTabOnSendBtn() throws Exception {
		WebElement agentEmoji = driver.findElement(By.xpath("//div[@class='smiley btn-sm border-0 me-2 ']/i"));
		agentEmoji.click();
		Thread.sleep(3000);
		WebElement agentBestLuckEmohi =  driver.findElement(By.xpath("//div[@class='epr-body']//ul/li[2]/div[2]/button[7]"));
		agentBestLuckEmohi.click();
		Thread.sleep(2000);
		sendbtn.click();
		log.info("select emoji and tab on send button");
	}

	@Test(priority = 31)
	public void selectFileAndTabOnSendBtn() throws Exception {
		WebElement agentFile = driver.findElement(By.xpath("//input[@type='file']"));
		Thread.sleep(2000);
		agentFile.sendKeys("C:\\Users\\cognicx\\Downloads\\Postman-win64-Setup.exe");
		Thread.sleep(1000);
		File screenshotAs = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotAs, new File("C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\report\\abc.png"));
		Thread.sleep(3000);
//		driver.findElement(By.xpath("//button[text()='Send']")).click();
		log.info("Invalid file format");
		log.info("Screenshot");
	}
//	@Test(priority = 32)
	public void recordAndTabOnSendBtn() throws Exception {
		WebElement recording = driver.findElement(By.xpath("//div[@class='audio-recorder  ']"));
		recording.click();
		Thread.sleep(30000);
		driver.findElement(By.xpath("//div[@class='audio-recorder recording ']/img[1]")).click();
		Thread.sleep(3000);
		try {
			driver.findElement(By.xpath("//button[text()='Send']")).click();
		} catch (Exception e) {
			new Actions(driver).click(sendbtn).build().perform();
		}
		Thread.sleep(5000);
		log.info("record voice upto 30 second and tab on send button");
	}
	@Test(priority = 33)
	public void navigatesToCustomerPortal() throws Exception {
		driver.navigate().to(customerPortal);
		Thread.sleep(3000);
		chat = driver.findElement(By.xpath("//button[@class='chatbox-open call-animation']/i"));
		chat.click();
	}
	@Test(priority = 34)
	public void customer_tabOnSendButton() throws InterruptedException {
		Thread.sleep(3000);
		WebElement sendbtns = driver.findElement(By.xpath("//button[@class='btn btn-grad']/i"));
		if(sendbtns.isDisplayed()) {
			log.info("display status of sendbtn : " + sendbtns.isDisplayed());
			sendbtns.click();
			log.info("without entering the message click on sendbtn");
		}else {
			log.info("please enter some message first then only you can send the message");
		}
	}
	@Test(priority = 35)
	public void customer_selectFileAndTabOnSendBtn() throws Exception {
		WebElement agentFiles = driver.findElement(By.xpath("//input[@id='attach']"));
		Thread.sleep(2000);
		agentFiles.sendKeys("C:\\Users\\cognicx\\Downloads\\Postman-win64-Setup.exe");
		Thread.sleep(1000);
		File screenshotAs = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotAs, new File("C:\\Users\\cognicx\\eclipse-workspace\\Inaipi\\report\\pqr.png"));
		Thread.sleep(3000);
		try {
			driver.findElement(By.xpath("//button[text()='Send']")).click();
		} catch (Exception e) {
			System.out.println("send button not click");
		}
		Thread.sleep(2000);
		log.info("select file 159 MB and tab on send button");
		log.info("Screenshot");
	}
//	@Test(priority = 36)
	public void customer_selectEmojiAndTabOnSendBtn() throws Exception {
		WebElement Customer_Emoji = driver.findElement(By.xpath("//div[@class='smiley btn-sm border-0 me-2 ']/i"));
		Customer_Emoji.click();
		Thread.sleep(3000);
		WebElement Customer_BestLuckEmohi =  driver.findElement(By.xpath("//div[@class='epr-body']//ul/li[2]/div[2]/button[7]"));
		Customer_BestLuckEmohi.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='btn btn-grad']/i")).click();
		log.info("select emoji and tab on send button");
	}
	@Test(priority = 37)
	public void navigatetoagentportal() throws Exception {
		driver.navigate().to(Agent1);;
		Thread.sleep(3000);
		driver.findElement(By.xpath("//i[text()='sms']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='d-flex justify-content-between w-100']")).click();
	}
	@Test(priority = 38)
	public void disconnectTheCustomer() throws Exception{
		Thread.sleep(2000);
		WebElement three_dot = driver.findElement(By.xpath("(//button[@type='button'])[9]//*[@stroke='currentColor']"));
		three_dot.click();
		WebElement endchat = driver.findElement(By.xpath("(//button[@type='button'])[16]//*[@stroke='currentColor']"));
		new Actions(driver).click(endchat).build().perform();
		Thread.sleep(3000);
		new Select(driver.findElement(By.xpath("//select[@class='form-select']"))).selectByVisibleText("Technical Issue");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Leave a comment here']")).sendKeys("Network Problem" + UtilsLayerPackage.RandomIntData.randomInt());
		Thread.sleep(1500);
		driver.findElement(By.xpath("//button[text()='SUBMIT']")).click();
		Thread.sleep(3000);
	}
	@Test(priority = 39)
	public void signoutagent() throws Exception {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='neo-nav-status-info']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='Finish Work']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Sign Out']")).click();
	}
}
