package UM_Client_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Client.userPage;

public class userPageTest extends BaseClass {

	private static final Logger log = Logger.getLogger(userPageTest.class);
	public static userPage user;
	
	@Test(priority = 398)
	public void displayStatusOfusersTest() throws InterruptedException {
		user = new userPage();
		Assert.assertEquals(user.displayStatusOfusers(), true);
	}

	@Test(priority = 399)
	public void enableStatusOfusersTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfusers(), true);
	}

	@Test(priority = 400)
	public void clickOnusersTest() throws InterruptedException {
		user.clickOnusers();
	}

	@Test(priority = 401)
	public void displayStatusOfsearchUserTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfsearchUser(), true);
	}

	@Test(priority = 402)
	public void enableStatusOfsearchUserTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfsearchUser(), true);
	}

	@Test(priority = 403)
	public void clickOnsearchUserTest() throws InterruptedException {
		user.clickOnsearchUser();
	}

	@Test(priority = 404)
	public void enterDataInsearchUserTest() throws InterruptedException {
		user.enterDataInsearchUser("vanila");
	}

	@Test(priority = 405)
	public void displayStatusOfeditUsersTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfeditUsers(), true);
	}

	@Test(priority = 406)
	public void enableStatusOfeditUsersTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfeditUsers(), true);
	}

	@Test(priority = 407)
	public void clickOneditUsersTest() throws InterruptedException {
		user.clickOneditUsers();
	}

	@Test(priority = 408)
	public void displayStatusOfuserFirstNameTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfuserFirstName(), true);
	}

	@Test(priority = 409)
	public void enableStatusOfuserFirstNameTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfuserFirstName(), true);
	}

	@Test(priority = 410)
	public void enterDataInuserFirstNameTest() throws InterruptedException {
		user.enterDataInuserFirstName("vanila");
	}

	@Test(priority = 411)
	public void displayStatusOfuserLastNameTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfuserLastName(), true);
	}

	@Test(priority = 412)
	public void enableStatusOfuserLastNameTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfuserLastName(), true);
	}

	@Test(priority = 413)
	public void enterDataInuserLastNameTest() throws InterruptedException {
		user.enterDataInuserLastName("barath");
	}

	@Test(priority = 414)
	public void displayStatusOfuserEmailTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfuserEmail(), true);
	}

	@Test(priority = 415)
	public void enableStatusOfuserEmailTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfuserEmail(), true);
	}

	@Test(priority = 416)
	public void enterDataInuserEmailTest() throws InterruptedException {
		user.enterDataInuserEmail("vanila@gmail.com");
	}

	@Test(priority = 417)
	public void displayStatusOfuserContactNumberTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfuserContactNumber(), true);
	}

	@Test(priority = 418)
	public void enableStatusOfuserContactNumberTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfuserContactNumber(), true);
	}

	@Test(priority = 419)
	public void enterDataInuserContactNumberTest() throws InterruptedException {
		user.enterDataInuserContactNumber("9856741230");
	}

	@Test(priority = 420)
	public void displayStatusOfuserRoleTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfuserRole(), true);
	}

	@Test(priority = 421)
	public void enableStatusOfuserRoleTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfuserRole(), true);
	}

	@Test(priority = 422)
	public void enterDataInuserRoleTest() throws InterruptedException {
		user.enterDataInuserRole("Manager");
	}

	@Test(priority = 423)
	public void displayStatusOfuserGroupTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfuserGroup(), true);
	}

	@Test(priority = 424)
	public void enableStatusOfuserGroupTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfuserGroup(), true);
	}

	@Test(priority = 425)
	public void enterDataInuserGroupTest() throws InterruptedException {
		user.enterDataInuserGroup("Facebook");
	}

	@Test(priority = 426)
	public void displayStatusOfcloseUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfcloseUserWin(), true);
	}

	@Test(priority = 427)
	public void enableStatusOfcloseUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfcloseUserWin(), true);
	}

//	@Test(priority = 428)
//	public void clickOncloseUserWinTest() throws InterruptedException {
//		user.clickOncloseUserWin();
//	}	
	@Test(priority = 429)
	public void displayStatusOfuserUpdateUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfuserUpdateUserWin(), true);
	}

	@Test(priority = 430)
	public void enableStatusOfuserUpdateUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfuserUpdateUserWin(), true);
	}

//	@Test(priority = 431)
//	public void clickOnuserUpdateUserWinTest() throws InterruptedException {
//		user.clickOnuserUpdateUserWin();
//	}
	@Test(priority = 432)
	public void displayStatusOfuserCancelUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfuserCancelUserWin(), true);
	}

	@Test(priority = 433)
	public void enableStatusOfuserCancelUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfuserCancelUserWin(), true);
	}

	@Test(priority = 434)
	public void clickOnuserCancelUserWinTest() throws InterruptedException {
		user.clickOnuserCancelUserWin();
	}

	@Test(priority = 435)
	public void displayStatusOfUserStatusUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfUserStatusUserWin(), true);
	}

	@Test(priority = 436)
	public void enableStatusOfUserStatusUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfUserStatusUserWin(), true);
	}

	@Test(priority = 437)
	public void clickOnUserStatusTest() throws InterruptedException {
		user.clickOnUserStatus();
	}

	@Test(priority = 438)
	public void displayStatusOfView_viewUserUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfView_viewUserUserWin(), true);
	}

	@Test(priority = 439)
	public void enableStatusOfView_viewUserUserWinTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfView_viewUserUserWin(), true);
	}

	@Test(priority = 440)
	public void clickOnviewUserTest() throws InterruptedException {
		user.clickOnviewUser();
	}

	@Test(priority = 441)
	public void displayStatusOfView_userFirstNameTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfView_userFirstName(), true);
	}

	@Test(priority = 442)
	public void aenableStatusOfView_userFirstNameTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfView_userFirstName(), true);
	}

//	@Test(priority = 442)
//	public void benterDataInuserFirstNameTextTest() throws InterruptedException {
//		user.enterDataInuserFirstNameText("Amol");
//	}

	@Test(priority = 443)
	public void displayStatusOfView_userLastNameTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfView_userLastName(), true);
	}

	@Test(priority = 444)
	public void enableStatusOfView_userLastNameTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfView_userLastName(), true);
	}

	@Test(priority = 445)
	public void displayStatusOfView_userEmailTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfView_userEmail(), true);
	}

	@Test(priority = 446)
	public void enableStatusOfView_userEmailTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfView_userEmail(), true);
	}

	@Test(priority = 447)
	public void displayStatusOfView_userContactNumberTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfView_userContactNumber(), true);
	}

	@Test(priority = 448)
	public void enableStatusOfView_userContactNumberTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfView_userContactNumber(), true);
	}

	@Test(priority = 449)
	public void displayStatusOfView_userRoleTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfView_userRole(), true);
	}

	@Test(priority = 450)
	public void enableStatusOfView_userRoleTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfView_userRole(), true);
	}

	@Test(priority = 451)
	public void displayStatusOfView_userGroupTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfView_userGroup(), true);
	}

	@Test(priority = 452)
	public void enableStatusOfView_userGroupTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfView_userGroup(), true);
	}

	@Test(priority = 453)
	public void displayStatusOfView_viewCancelTest() throws InterruptedException {
		Assert.assertEquals(user.displayStatusOfView_viewCancel(), true);
	}

	@Test(priority = 454)
	public void enableStatusOfView_viewCancelTest() throws InterruptedException {
		Assert.assertEquals(user.enableStatusOfView_viewCancel(), true);
	}

	@Test(priority = 455)
	public void clickOnviewCancelTest() throws InterruptedException {
		user.clickOnviewCancel();
	}

}
