package UM_Super_Admin_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Super_Admin.LoginPage;

public class LoginPageTest extends BaseClass{

	private static Logger log = Logger.getLogger(LoginPageTest.class);
	private static LoginPage login ;
	
	@BeforeClass
	public void start() {
		BaseClass.StartingUM_SuperAdmin();
		login = new LoginPage();
	}

	@Test(priority = 1)
	public void displayStatusOfusername1Test() throws InterruptedException {
		Assert.assertEquals(login.displayStatusOfusername1(), true);
	}

	@Test(priority = 2)
	public void enableStatusOfusernameTest() throws InterruptedException {
		Assert.assertEquals(login.enableStatusOfusername(), true);

	}

	@Test(priority = 3)
	public void enterDataInusernameTest() throws InterruptedException {
		String username = UtilsLayerPackage.GetDataFromDCCExcel.excel(0, 11, 1);
		login.enterDataInusername(username);
		log.info("enter username : " + username);


	}

	@Test(priority = 4)
	public void displayStatusOfpasswordTest() throws InterruptedException {
		Assert.assertEquals(login.displayStatusOfpassword(), true);
//		log.info("display status of password test box : " + login.displayStatusOfpassword() );

	}

	@Test(priority = 5)
	public void enableStatusOfpasswordTest() throws InterruptedException {
		Assert.assertEquals(login.enableStatusOfpassword(), true);
//		log.info("enable status of password test box : " + login.displayStatusOfpassword() );
	}

	@Test(priority = 6)
	public void enterDataInpasswordTest() throws InterruptedException {
		String password = UtilsLayerPackage.GetDataFromDCCExcel.excel(0, 12, 1);
		login.enterDataInpassword(password);
		log.info("enter password : " + password);


	}

	@Test(priority = 7)
	public void displayStatusOfeyeTest() throws InterruptedException {
		Assert.assertEquals(login.displayStatusOfeye(), true);
//		log.info("display status of Eye button : " + admin.displayStatusOfeye());
	}

	@Test(priority = 8)
	public void enableStatusOfeyeTest() throws InterruptedException {
		Assert.assertEquals(login.enableStatusOfeye(), true);
//		log.info("enable status of Eye button : " + admin.enableStatusOfeye());
	}

	@Test(priority = 9)
	public void clickOneyeTest() throws InterruptedException {
		login.clickOneye();
		log.info("click on eye button");
	}

	@Test(priority = 10)
	public void displayStatusOfloginTest() throws InterruptedException {
		Assert.assertEquals(login.displayStatusOflogin(), true);
//		log.info("display status of login button : " + login.displayStatusOflogin());
	}

	@Test(priority = 11)
	public void enableStatusOfloginTest() throws InterruptedException {
		Assert.assertEquals(login.enableStatusOflogin(), true);
//		log.info("enable status of login button : " + login.enableStatusOflogin());
	}

	@Test(priority = 12)
	public void clickOnloginTest() throws InterruptedException {
		login.clickOnlogin();
		log.info("click on login button");
	}

}
