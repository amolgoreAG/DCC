package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import PageLayerPackage.ConferanceToSupervisor;

public class ConferanceToSupervisorTest extends BaseClass {
	private static Logger log = Logger.getLogger(ConferanceToSupervisorTest.class);
	public static ConferanceToSupervisor confsupervisor;

	@BeforeClass
	public void starting() {
		BaseClass.chatInterFace();
	}

	@Test(priority = 1)
	public void displayStatusOfUsernameTest() throws InterruptedException {
		confsupervisor = new ConferanceToSupervisor();
		Assert.assertEquals(confsupervisor.displayStatusOfUsername(), true);
	}

	@Test(priority = 2)
	public void enableStatusOfUsernameTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfUsername(), true);
	}

	@Test(priority = 3)
	public void displayStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfPassword(), true);
	}

	@Test(priority = 4)
	public void enableStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfPassword(), true);
	}

	@Test(priority = 5)
	public void displayStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfLogin(), true);
	}

	@Test(priority = 6)
	public void enableStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfLogin(), true);
	}

	@Test(priority = 7)
	public void enterLoginCredentialandLogin() throws InterruptedException {
		try {
			String Username = excel.getDataFromExcelSheet(0, 20, 1);
			String Password = excel.getDataFromExcelSheet(0, 21, 1);
			confsupervisor.enterLoginCredentialandLogin(Username, Password);
			log.info("Enter Username and Password and login");
		} catch (InterruptedException e) {
			log.error("Please enter valide creadential and tab on login");
		}
	}

	@Test(priority = 8)
	public void displayStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfstatus(), true);
	}

	@Test(priority = 9)
	public void enableStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfstatus(), true);
	}

	@Test(priority = 10)
	public void clickOnstatusTest() {
		try {
			confsupervisor.clickOnstatus();
			log.info("For change the status click on status");
		} catch (Exception e) {
		log.error("Not able to For change the status click on status");
		}
	}

	@Test(priority = 11)
	public void displayStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfgoready(), true);
	}

	@Test(priority = 12)
	public void enableStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfgoready(), true);
	}

	@Test(priority = 13)
	public void clickOngoreadyTest() {
		try {
			confsupervisor.clickOngoready();
			log.info("change the the status go ready to ready");
		} catch (Exception e) {
			log.error("Not able to change the the status go ready to ready");
		}
	}

	@Test(priority = 14)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfclose(), true);
	}

	@Test(priority = 15)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfclose(), true);
	}

	@Test(priority = 16)
	public void clickOncloseTest() {
		try {
			confsupervisor.clickOnclose();
			log.info("close this one");
		} catch (Exception e) {
			log.error("Not able to Close");
		}
	}

	@Test(priority = 17)
	public void navigatetoCustomerPortalTest() {
		try {
			confsupervisor.navigatetoCustomerPortal();
			log.info("navigate to customer portal");
		} catch (Exception e) {
			log.error("Not able to navigate to customer portal");
		}
	}

	@Test(priority = 18)
	public void displayStatusOfchatTest() throws InterruptedException {
		confsupervisor.displayStatusOfchat();
	}

	@Test(priority = 19)
	public void enableStatusOfchatTest() throws InterruptedException {
		confsupervisor.enableStatusOfchat();
	}

	@Test(priority = 20)
	public void clickOnchatTest() throws InterruptedException {
		try {
			confsupervisor.clickOnchat();
			log.info("click on chat");
		} catch (Exception e) {
			log.error("Not able to click on chat");
		}
	}

	@Test(priority = 21)
	public void displayStatusOfCPusernameTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfCPusername(), true);
	}

	@Test(priority = 22)
	public void enableStatusOfCPusernameTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfCPusername(), true);
	}

	@Test(priority = 23)
	public void enterDataInCPusernameTest() throws InterruptedException {
		try {
			String User = excel.getDataFromExcelSheet(5, 4, 1);
			confsupervisor.enterDataInCPusername(User + UtilsLayerPackage.RandomIntData.randomInt());
			log.info("Enter Username");
		} catch (Exception e) {
			log.error("Not able to Enter Username");
		}
	}

	@Test(priority = 24)
	public void displayStatusOfCPemailTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfCPemail(), true);
	}

	@Test(priority = 25)
	public void enableStatusOfCPemailTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfCPemail(), true);
	}

	@Test(priority = 26)
	public void enterDataInCPemailTest() throws InterruptedException {
		try {
			String EmailStart = excel.getDataFromExcelSheet(5, 5, 1);
			String EmailEnd = excel.getDataFromExcelSheet(5, 5, 3);
			confsupervisor.enterDataInCPemail(EmailStart + UtilsLayerPackage.RandomIntData.randomInt() + EmailEnd);
			log.info("Enter Gmail");
		} catch (Exception e) {
			log.error("Not able to Enter Gmail");
		}
	}

	@Test(priority = 27)
	public void displayStatusOfCPphoneNumberTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfCPphoneNumber(), true);
	}

	@Test(priority = 28)
	public void enableStatusOfCPphoneNumberTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfCPphoneNumber(), true);
	}

	@Test(priority = 29)
	public void enterDataInCPphoneNumberTest() throws InterruptedException {
		try {
			String MobileNumber = excel.getDataFromExcelSheet(5, 6, 1);
			confsupervisor.enterDataInCPphoneNumber(MobileNumber + UtilsLayerPackage.RandomIntData.randomInt());
			log.info("Enter Mobile Number");
		} catch (Exception e) {
			log.error("Not able to Enter Mobile Number");
		}
	}

	@Test(priority = 30)
	public void displayStatusOfCPskillSetTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfCPskillSet(), true);
	}

	@Test(priority = 31)
	public void enableStatusOfCPskillSetTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfCPskillSet(), true);
	}

	@Test(priority = 32)
	public void selectSkillsetfromDPCPskillSetTest() throws InterruptedException {
		try {
			String skill = excel.getDataFromExcelSheet(0, 22, 1);
			confsupervisor.selectSkillsetfromDPCPskillSet(skill);
			log.info("Select Skill");
		} catch (Exception e) {
			log.error("Not able to Select Skill");
		}
	}

	@Test(priority = 33)
	public void displayStatusOfCPselectLanguageTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfCPselectLanguage(), true);
		
	}

	@Test(priority = 34)
	public void enableStatusOfCPselectLanguageTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfCPselectLanguage(), true);
	}

	@Test(priority = 35)
	public void selectSkillsetfromDPCPselectLanguageTest() throws InterruptedException {
		try {
			String language = excel.getDataFromExcelSheet(0, 23, 1);
			confsupervisor.selectSkillsetfromDPCPselectLanguage(language);
			log.info("Select language");
		} catch (Exception e) {
			log.error("Not able to Select language");
		}
	}

	@Test(priority = 36)
	public void displayStatusOfCPcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfCPcomplaintType(), true);
	}

	@Test(priority = 37)
	public void enableStatusOfCPcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfCPcomplaintType(), true);
	}

	@Test(priority = 38)
	public void selectSkillsetfromDPCPcomplaintTypeTest() throws InterruptedException {
		try {
			String complaint = excel.getDataFromExcelSheet(0, 24, 1);
			confsupervisor.selectSkillsetfromDPCPcomplaintType(complaint);
			log.info("Select complaint type");
		} catch (Exception e) {
			log.error("Not able to Select complaint type");
		}
	}

	@Test(priority = 39)
	public void displayStatusOfCPchatButtonTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfCPchatButton(), true);
	}

	@Test(priority = 40)
	public void enableStatusOfCPchatButtonTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfCPchatButton(), true);
	}

	@Test(priority = 41)
	public void clickOnCPchatButtonTest() throws InterruptedException {
		try {
			confsupervisor.clickOnCPchatButton();
			log.info("click on chat button");
		} catch (InterruptedException e) {
			log.error("Not able to click on chat button");
		}
	}
	@Test(priority = 42)
	public void navigatebacktoAgentPortalTest() {
		try {
			confsupervisor.navigatebacktoAgentPortal();
			log.info("navigate back to Agent Portal for receiving call");
		} catch (Exception e) {
			log.error("Not able to navigate back to Agent Portal for receiving call");
		}
	}
	@Test(priority = 43)
	public void displayStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfmessage(), true);
	}
	@Test(priority = 44)
	public void enableStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfmessage(), true);
	}
	@Test(priority = 45)
	public void clickOnmessageTest() throws InterruptedException {
		try {
			confsupervisor.clickOnmessage();
			log.info("click on chat");
		} catch (InterruptedException e) {
			log.error("Not able to click on chat");
		}
	}
	@Test(priority = 46)
	public void displayStatusOfacceptCallTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfacceptCall(), true);
	}
	@Test(priority = 47)
	public void enableStatusOfacceptCallTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfacceptCall(), true);
	}
	@Test(priority = 48)
	public void clickOnacceptCallTest() throws InterruptedException {
		try {
			confsupervisor.clickOnacceptCall();
			log.info("click on Accept the call");
		} catch (InterruptedException e) {
			log.error("Not able to click on Accept the call");
		}
	}
	@Test(priority = 49)
	public void displayStatusOfstartChatTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfstartChat(), true);
	}
	@Test(priority = 50)
	public void enableStatusOfstartChatTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfstartChat(), true);
	}
	@Test(priority = 51)
	public void clickOnstartChatTest() throws InterruptedException {
		try {
			confsupervisor.clickOnstartChat();
			log.info("click on start chat");
		} catch (InterruptedException e) {
			log.error("Not able to click on start chat");
		}
	}
//	@Test(priority = 52)
//	public void displayStatusOfmessageBoxTest() throws InterruptedException {
//		Assert.assertEquals(confsupervisor.displayStatusOfmessageBox(), true);
//	}
//	@Test(priority = 53)
//	public void enableStatusOfmessageBoxTest() throws InterruptedException {
//		Assert.assertEquals(confsupervisor.enableStatusOfmessageBox(), true);
//	}
	@Test(priority = 54)
	public void clickOnmessageBoxTest() throws InterruptedException {
		try {
			confsupervisor.clickOnmessageBox();
			log.info("click on message box");
		} catch (InterruptedException e) {
			log.error("Not able to click on message box");
		}
	}
	@Test(priority = 55)
	public void sendDataInMessageBoxTest() {
		try {
			String agent1Msg = excel.getDataFromExcelSheet(5, 13, 2);
			confsupervisor.sendDataInMessageBox(agent1Msg);
			log.info("Send Msg to customer 1");
		} catch (Exception e) {
			log.error("Not able to Send Msg to customer 1");
		}
	}
//	@Test(priority = 56)
//	public void displayStatusOfsendMsgTest() throws InterruptedException {
//		Assert.assertEquals(confsupervisor.displayStatusOfsendMsg(), true);
//	}
//	@Test(priority = 57)
//	public void enableStatusOfsendMsgTest() throws InterruptedException {
//		Assert.assertEquals(confsupervisor.enableStatusOfsendMsg(), true);
//	}
	@Test(priority = 58)
	public void clickOnsendMsgTest() throws InterruptedException {
		try {
			confsupervisor.clickOnsendMsg();
			log.info("click on send message");
		} catch (InterruptedException e) {
			log.error("Not able to click on send message");
		}
	}
	@Test(priority = 59)
	public void navigatetoCustomerportalTest() throws InterruptedException {
		try {
			confsupervisor.navigatetoCustomerportal1();
			log.info("navigate to customer portal");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to customer portal");
		}
	}
	@Test(priority = 60)
	public void enterDataInCPmessageBoxTest() throws InterruptedException {
		try {
			String Customer1Msg = excel.getDataFromExcelSheet(5, 14, 2);
			confsupervisor.enterDataInCPmessageBox(Customer1Msg);
			log.info("click on message box and enter msg ");
		} catch (InterruptedException e) {
			log.error("Not able to click on message box and enter msg ");
		}
	}
	@Test(priority = 61)
	public void enterDataInCPsendMsgTest() throws InterruptedException {
		try {
			confsupervisor.clickOnCPsendMsg();
			log.info("click on send the message");
		} catch (InterruptedException e) {
			log.error("Not able to click on send the message");
		}
	}
	@Test(priority = 62)
	public void navigatebacktoagent1Test() throws InterruptedException {
		try {
			confsupervisor.navigatebacktoagent1();
			log.info("navigate back to Agent 1 ");
		} catch (InterruptedException e) {
			log.error("Not able to navigate back to Agent 1 ");
		}
	}
	@Test(priority = 63)
	public void openChromeIncognitoTest() throws InterruptedException {
		try {
			confsupervisor.openChromeIncognito();
			log.info("open new browser for Agent 2 Login");
		} catch (InterruptedException e) {
			log.error("Not able to open new browser for Agent 2 Login");
		}
	}
	@Test(priority = 64)
	public void ConfsupervisorLoginTest() throws InterruptedException {
		try {
			String Supervisor2UserName = excel.getDataFromExcelSheet(0, 35, 1);
			String Supervisor2Password = excel.getDataFromExcelSheet(0, 36, 1);
			confsupervisor.ConfsupervisorLogin(Supervisor2UserName , Supervisor2Password);
			log.info("Login Agent 2 ");
		} catch (InterruptedException e) {
			log.error("Not able to Login Agent 2 ");
		}
	}
	@Test(priority = 65)
	public void displayStatusOfstatus2Test() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfstatus2(), true);
	}
	@Test(priority = 66)
	public void enableStatusOfstatus2Test() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfstatus2(), true);
	}
	@Test(priority = 67)
	public void clickOnstatus2Test() throws InterruptedException {
		try {
			confsupervisor.clickOnstatus2();
			log.info("click on status");
		} catch (Exception e) {
			log.error("Not able to click on status");
		}
	}
	@Test(priority = 68)
	public void displayStatusOfgoready2Test() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfgoready2(), true);
	}
	@Test(priority = 69)
	public void enableStatusOfgoready2Test() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfgoready2(), true);
	}
	@Test(priority = 70)
	public void clickOngoready2Test() throws InterruptedException {
		try {
			confsupervisor.clickOngoready2();
			log.info("change status Go ready to ready");
		} catch (Exception e) {
			log.error("Not able to change status Go ready to ready");
		}
	}
	@Test(priority = 71)
	public void displayStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfclose2(), true);
	}
	@Test(priority = 72)
	public void enableStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfclose2(), true);
	}
	@Test(priority = 73)
	public void clickOnclose2Test() throws InterruptedException {
		try {
			confsupervisor.clickOnclose2();
			log.info("close this one");
		} catch (Exception e) {
			log.error("Not able to close this one");
		}
	}
	@Test(priority = 74)
	public void gotoAgent1Test() throws InterruptedException {
		try {
			confsupervisor.gotoAgent1();
			log.info("navigate to Agent 1");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1");
		}
	}
	@Test(priority = 75)
	public void displayStatusOfconferenceToSupervisorTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfconferenceToSupervisor(), true);
	}
	@Test(priority = 76)
	public void enableStatusOfconferenceToSupervisorTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfconferenceToSupervisor(), true);
	}
	@Test(priority = 77)
	public void clickOnConferanceToAgentTest() throws InterruptedException {
		try {
			confsupervisor.clickOnConferanceToSupervisor();
			log.info("click on conference to agent");
		} catch (Exception e) {
			log.error("Not able to click on conference to agent");
		}
	}

	@Test(priority = 78)
	public void displayStatusOfavailableSupervisorTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfavailableSupervisor(), true);
	}
	@Test(priority = 79)
	public void enableStatusOfavailableSupervisorTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfavailableSupervisor(), true);
	}
	@Test(priority = 80)
	public void selectSkillSetFromavailableSupervisorTest() throws InterruptedException {
		try {
			String availableSupervisor = excel.getDataFromExcelSheet(5, 22, 1);
			confsupervisor.selectSkillSetFromavailableSupervisor(availableSupervisor);
			log.info("Select The supervisor");
		} catch (Exception e) {
			log.error("Not able to Select The supervisor");
		}
	}
	@Test(priority = 81)
	public void displayStatusOfconferenceTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.displayStatusOfconference(), true);
	}
	@Test(priority = 81)
	public void enableStatusOfconferenceTest() throws InterruptedException {
		Assert.assertEquals(confsupervisor.enableStatusOfconference(), true);
	}
	@Test(priority = 82)
	public void clickOnconferenceTest() throws InterruptedException {
		try {
			confsupervisor.clickOnconference();
			log.info("Click on conference");
		} catch (InterruptedException e) {
			log.error("Not able to Click on conference");
		}
	}
	@Test(priority = 83)
	public void gotoConfsupervisorandAcceptThaRequestTest() throws InterruptedException {
		try {
			confsupervisor.gotoConfsupervisorandAcceptThaRequest();
			log.info("navigate to Supervisor 2 and start the chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Supervisor 2 and start the chat");
		}
	}
	@Test(priority = 84)
	public void enterMsginAgent2MessageBox() throws InterruptedException {
		try {
			String Supervisor2Msg = excel.getDataFromExcelSheet(5, 15, 2);
			confsupervisor.enterMsginAgent2MessageBox(Supervisor2Msg);
			log.info("enter message");
		} catch (InterruptedException e) {
			log.error("Not able to enter message");
		}
	}
	@Test(priority = 85)
	public void clickOnSendMessagefromAgentPortalTest() throws InterruptedException {
		try {
			confsupervisor.clickOnSendMessagefromAgentPortal();
			log.info("send message");
		} catch (InterruptedException e) {
			log.error("Not able to send message");
		}
	}
	@Test(priority = 86)
	public void gotoagent1ToCheckMsgCommingOrNotTest() throws InterruptedException {
		try {
			String Agent1Msg = excel.getDataFromExcelSheet(5, 16, 2);
			confsupervisor.gotoagent1ToCheckMsgCommingOrNot(Agent1Msg);
			log.info("navigate to Agent 1 tab on start chat , enter message and send ");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1 tab on start chat , enter message and send ");
		}
	}
	@Test(priority = 87)
	public void gotoCustomer1ToCheckMsgCommingOrNotTest() throws InterruptedException {
		try {
			confsupervisor.gotoCustomer1ToCheckMsgCommingOrNot();
			log.info("navigate to customer portal , tab on chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to customer portal , tab on chat");
		}
	}
	@Test(priority = 88)
	public void ClickandEnterMessageInCustomerMsgBoxandSendTest() throws InterruptedException {
		try {
			String Customer1Msg = excel.getDataFromExcelSheet(5, 17, 2);
			confsupervisor.ClickandEnterMessageInCustomerMsgBoxandSend(Customer1Msg);
			log.info("enter message and send");
		} catch (InterruptedException e) {
			log.error("Not able to enter message and send");
		}
	}
	@Test(priority = 89)
	public void sendMsgFromCustomerPortalTest() throws InterruptedException {
		try {
			confsupervisor.sendMsgFromCustomerPortal();
			log.info("Enter msg and send");
		} catch (InterruptedException e) {
			log.error("Not able to Enter msg and send");
		}
	}
	@Test(priority = 90)
	public void sendFileFromCustomerPortalTest() throws InterruptedException {
		try {
			String Customer1File = excel.getDataFromExcelSheet(5, 18, 2);
			confsupervisor.sendFileFromCustomerPortal(Customer1File);
			log.info("Select The file and send");
		} catch (InterruptedException e) {
			log.error("Not able to Select The file and send");
		}
	}
	@Test(priority = 91)
	public void moveToAgent1ForVerifiedTest() throws InterruptedException {
		try {
			confsupervisor.moveToAgent1ForVerified();
			log.info("navigate to Agent 1 and tab on start chat for verified message is reflected or not");
		} catch (InterruptedException e) {
		log.error("Not able to navigate to Agent 1 and tab on start chat for verified message is reflected or not");
		}
	}
	@Test(priority = 92)
	public void sendEmojiFromAgent1PortalTest() throws InterruptedException {
		try {
			confsupervisor.sendEmojiFromAgent1Portal();
			log.info("select emoji and send");
		} catch (InterruptedException e) {
			log.error("Not able to select emoji and send");
		}
	}
	@Test(priority = 93)
	public void sendFileFromAgent1PortalTest() throws InterruptedException {
		try {
			String Agent1File = excel.getDataFromExcelSheet(5, 19, 2);
			confsupervisor.sendFileFromAgent1Portal(Agent1File);
			log.info("Select The file and send");
		} catch (InterruptedException e) {
			log.error("Not able to Select The file and send");
		}
	}
	@Test(priority = 94)
	public void moveToConfsupervisorForVerifiedTest() throws InterruptedException {
		try {
			confsupervisor.moveToConfsupervisorForVerified();
			log.info("navigate to Supervisor for verified msg is comming or not");
		} catch (InterruptedException e) {
		log.error("Not able to navigate to Supervisor for verified msg is comming or not");
		}
	}
	@Test(priority = 95)
	public void clickOnendChat2Test() throws InterruptedException {
		try {
			confsupervisor.clickOnendChat2();
			log.info("tab on end chat");
		} catch (InterruptedException e) {
			log.error("Not able to tab on end chat");
		}
	}
	@Test(priority = 96)
	public void selectReasonforDisconnect2Test() throws InterruptedException {
		try {
			String reason = excel.getDataFromExcelSheet(5, 27, 1);
			confsupervisor.selectReasonforDisconnect2(reason);
			log.info("select reason");
		} catch (InterruptedException e) {
			log.error("Not able to select reason");
		}
	}
	@Test(priority = 97)
	public void enterComment2Test() throws InterruptedException {
		try {
			String comment = excel.getDataFromExcelSheet(5, 28, 1);
			confsupervisor.enterComment2(comment);
			log.info("enter comment");
		} catch (InterruptedException e) {
			log.error("Not able to enter comment");
		}
	}
	@Test(priority = 98)
	public void clickOnSUbmitandSignOut2Test() throws InterruptedException {
		try {
			confsupervisor.clickOnSUbmitandSignOut2();
			log.info("submit and sign out the agent");
		} catch (InterruptedException e) {
			log.error("Not able to submit and sign out the agent");
		}
	}
	@Test(priority = 99)
	public void moveToAgent1ForVerified1Test() throws InterruptedException {
		try {
			confsupervisor.moveToAgent1ForVerified1();
			log.info("navigate to Agent 1 and start chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1 and start chat");
		}
	}
	@Test(priority = 100)
	public void clickOnendChat1Test() throws InterruptedException {
		try {
			confsupervisor.clickOnendChat1();
			log.info("click on end chat");
		} catch (InterruptedException e) {
			log.error("Not able to click on end chat");
		}
	}
	@Test(priority = 101)
	public void selectReasonforDisconnect1Test() throws InterruptedException {
		try {
			String reason = excel.getDataFromExcelSheet(5, 27, 1);
			confsupervisor.selectReasonforDisconnect1(reason);
			log.info("Select The reason");
		} catch (InterruptedException e) {
			log.error("Not able to Select The reason");
		}
	}
	@Test(priority = 102)
	public void enterComment1Test() throws InterruptedException {
		try {
			String comment = excel.getDataFromExcelSheet(5, 28, 1);
			confsupervisor.enterComment1(comment);
			log.info("enter comment");
		} catch (InterruptedException e) {
		log.error("Not able to enter comment");
		}
	}
	@Test(priority = 103)
	public void clickOnSUbmitandSignOut1Test() throws InterruptedException {
		try {
			confsupervisor.clickOnSUbmit1();
			log.info("and submit");
		} catch (InterruptedException e) {
			log.error("Not able to submit");
		}
		try {
			confsupervisor.signouttheagent();
			log.info("sign out");
		} catch (InterruptedException e) {
			log.error("Not able to sign out");
		}
	}
	@Test(priority = 104)
	public void navigateToCustomerandcloseTest() throws InterruptedException {
		try {
			confsupervisor.navigateToCustomerandclose();
			log.info("navigate to customer portal and check both agent are disconnected or not and end the call from customer");
		} catch (InterruptedException e) {
		log.error("Not able to navigate to customer portal and check both agent are disconnected or not and end the call from customer");
		}
	}
}
