package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import PageLayerPackage.UserManagementClient;

public class UserManagementClientTest extends BaseClass {
	private static final Logger log = Logger.getLogger(UserManagementSuperAdminTest.class);
	public static UserManagementClient client;

	@BeforeClass
	public void start() {
		BaseClass.StartingUMClient();
	}

	@Test(priority = 1)
	public void displayStatusOfusernameTest() throws InterruptedException {
		client = new UserManagementClient();
		Assert.assertEquals(client.displayStatusOfusername(), true);
	}

	@Test(priority = 2)
	public void enableStatusOfusernameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfusername(), true);
	}

	@Test(priority = 3)
	public void enterDataInusernameTest() throws InterruptedException {
		try {
//			String username = UtilsLayerPackage.GetDataFromDCCExcel.excel(0, 4, 1);
			client.enterDataInusername("pragadeeswar.j@cognicx.com");
			log.info("Enter Username");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Username");
		}
	}

	@Test(priority = 4)
	public void displayStatusOfpasswordTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfpassword(), true);

	}

	@Test(priority = 5)
	public void enableStatusOfpasswordTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfpassword(), true);

	}

	@Test(priority = 6)
	public void enterDataInpasswordTest() {
		try {
			String password = UtilsLayerPackage.GetDataFromDCCExcel.excel(0, 5, 1);
			client.enterDataInpassword(password);
			log.info("Enter Password : " + password);
		} catch (Exception e) {
			log.error("Not able to Enter Password : ");
		}
	}

	@Test(priority = 7)
	public void displayStatusOfeyeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfeye(), true);

	}

	@Test(priority = 8)
	public void enableStatusOfeyeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfeye(), true);

	}

	@Test(priority = 9)
	public void clickOnEyeTest() {
		try {
			client.clickOnEye();
			log.info("click on eye button");
		} catch (Exception e) {
			log.error("Not able to click on eye button");
		}
	}

	@Test(priority = 10)
	public void displayStatusOfloginTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflogin(), true);

	}

	@Test(priority = 11)
	public void enableStatusOfloginTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflogin(), true);

	}

	@Test(priority = 12)
	public void clickOnloginTest() {
		try {
			client.clickOnlogin();
			log.info("click on login button");
		} catch (Exception e) {
			log.error("Not able to click on login button");
		}
	}

	@Test(priority = 13)
	public void displayStatusOfmasterTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfmaster(), true);

	}

	@Test(priority = 14)
	public void enableStatusOfmasterTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfmaster(), true);

	}

	@Test(priority = 15)
	public void clickOnmasterTest() {
		try {
			client.clickOnmaster();
			log.info("click on master");
		} catch (Exception e) {
			log.error("Not able to click on master");
		}
	}

	@Test(priority = 16)
	public void displayStatusOfroleTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfrole(), true);

	}

	@Test(priority = 17)
	public void enableStatusOfroleTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfrole(), true);

	}

	@Test(priority = 18)
	public void clickOnroleTest() {
		try {
			client.clickOnrole();
			log.info("click on role");
		} catch (Exception e) {
			log.error("Not able to click on role");
		}
	}

	@Test(priority = 19)
	public void displayStatusOfcreateRoleTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateRole(), true);

	}

	@Test(priority = 20)
	public void enableStatusOfcreateRoleTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateRole(), true);

	}

	@Test(priority = 21)
	public void clickOncreateRoleTest() {
		try {
			client.clickOncreateRole();
			log.info("click on create role");
		} catch (Exception e) {
			log.error("Not able to click on create role");
		}
	}

	@Test(priority = 22)
	public void displayStatusOfroleNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfroleName(), true);

	}

	@Test(priority = 23)
	public void enableStatusOfroleNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfroleName(), true);

	}

	@Test(priority = 24)
	public void enterDataInroleNameTest() {
		try {
			client.enterDataInroleName("abc");
			log.info("enter role name");
		} catch (Exception e) {
			log.error("Not able to enter role name");
		}
	}

	@Test(priority = 25)
	public void displayStatusOfroleDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfroleDiscription(), true);

	}

	@Test(priority = 26)
	public void enableStatusOfroleDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfroleDiscription(), true);

	}

	@Test(priority = 27)
	public void enterDataInroleDiscriptionTest() {
		try {
			client.enterDataInroleDiscription("abc");
			log.info("enter role discription");
		} catch (Exception e) {
			log.error("Not able to enter role discription");
		}
	}

	@Test(priority = 28)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclose(), true);

	}

	@Test(priority = 29)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclose(), true);

	}

	@Test(priority = 30)
	public void displayStatusOfcancelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcancel(), true);

	}

	@Test(priority = 31)
	public void enableStatusOfcancelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcancel(), true);

	}

	@Test(priority = 32)
	public void displayStatusOfsubmitTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsubmit(), true);

	}

	@Test(priority = 33)
	public void enableStatusOfsubmitTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsubmit(), true);

	}

	@Test(priority = 34)
	public void clickOnsubmitTest() {
		try {
			client.clickOnsubmit();
			log.info("click on submit");
		} catch (Exception e) {
			log.error("Not able to click on submit");
		}
	}

//	@Test(priority = 35)
//	public void clickOncancelTest() {
//		client.clickOncancel();
//	}

	@Test(priority = 36)
	public void displayStatusOfeditTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit(), true);

	}

	@Test(priority = 37)
	public void enableStatusOfeditTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit(), true);

	}

	@Test(priority = 38)
	public void clickOneditTest() {
		try {
			client.clickOnedit();
			log.info("click on edit");
		} catch (Exception e) {
			log.error("Not able to click on edit");
		}
	}

	@Test(priority = 39)
	public void displayStatusOfedit_roleNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_roleName(), true);

	}

	@Test(priority = 40)
	public void enableStatusOfedit_roleNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_roleName(), true);

	}

	@Test(priority = 41)
	public void clearTheRoleNameTest() {
		try {
			client.clearTheRoleName();
			log.info("click on Role NAme");
		} catch (Exception e) {
			log.error("Not able to click on Role NAme");
		}
	}

	@Test(priority = 42)
	public void enterDataInedit_roleNameTest() throws InterruptedException {
		client.enterDataInedit_roleName("PQR");
		log.info("Enter Role");
	}

	@Test(priority = 43)
	public void displayStatusOfedit_roleDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_roleDiscription(), true);

	}

	@Test(priority = 44)
	public void enableStatusOfroleedit_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfroleedit_Discription(), true);

	}

	@Test(priority = 45)
	public void enterDataInedit_roleDiscriptionTest() throws InterruptedException {
		try {
			client.enterDataInedit_roleDiscription("PQRST");
			log.info("Enter Role Discription");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Role Discription");
		}
	}

	@Test(priority = 46)
	public void displayStatusOfedit_closeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_close(), true);

	}

	@Test(priority = 47)
	public void enableStatusOfedit_closeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_close(), true);

	}

	@Test(priority = 48)
	public void displayStatusOfedit_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_cancel(), true);

	}

	@Test(priority = 49)
	public void enableStatusOfedit_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_cancel(), true);

	}

//	@Test(priority = 50)
//	public void clickOnedit_cancelTest() throws InterruptedException {
//		client.clickOnedit_cancel();
//	}
	@Test(priority = 51)
	public void displayStatusOfupdateRoleTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfupdateRole(), true);

	}

	@Test(priority = 52)
	public void enableStatusOfupdateRoleTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfupdateRole(), true);

	}

//	@Test(priority = 53)
//	public void clickOnupdateRoleTest() throws InterruptedException {
//		client.clickOnupdateRole();
//	}
	@Test(priority = 54)
	public void clickOnedit_cancelTest() throws InterruptedException {
		try {
			client.clickOnedit_cancel();
			log.info("click on Cancel");
		} catch (Exception e) {
			log.error("Not able to click on Cancel");
		}
	}

	@Test(priority = 55)
	public void displayStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfstatus(), true);
	}

	@Test(priority = 56)
	public void enableStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfstatus(), true);
	}

	@Test(priority = 57)
	public void clickOnstatusTest() throws InterruptedException {
		try {
			client.clickOnstatus();
			log.info("click on Status");
		} catch (InterruptedException e) {
			log.error("Not able to click on Status");
		}
	}

	@Test(priority = 58)
	public void displayStatusOfgroupTets() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfgroup(), true);
	}

	@Test(priority = 59)
	public void enableStatusOfgroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfgroup(), true);
	}

	@Test(priority = 60)
	public void clickOngroupTest() throws InterruptedException {
		try {
			client.clickOngroup();
			log.info("click on Group");
		} catch (InterruptedException e) {
			log.error("Not able to click on Group");
		}
	}

	@Test(priority = 61)
	public void displayStatusOfcreateGroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateGroup(), true);
	}

	@Test(priority = 62)
	public void enableStatusOfcreateGroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateGroup(), true);
	}

	@Test(priority = 63)
	public void clickOncreateGroupTest() throws InterruptedException {
		try {
			client.clickOncreateGroup();
			log.info("click on create Group");
		} catch (InterruptedException e) {
			log.error("Not able to click on create Group");
		}
	}

	@Test(priority = 64)
	public void displayStatusOfgroupNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfgroupName(), true);
	}

	@Test(priority = 65)
	public void enableStatusOfgroupNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfgroupName(), true);
	}

	@Test(priority = 66)
	public void enterDataIngroupNameTest() throws InterruptedException {
		try {
			client.enterDataIngroupName("IT");
			log.info("Enter Group NAme");
		} catch (Exception e) {
			log.error("Not able to Enter Group NAme");
		}
	}

	@Test(priority = 67)
	public void displayStatusOfgroupNameDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfgroupNameDiscription(), true);
	}

	@Test(priority = 68)
	public void enableStatusOfgroupNameDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfgroupNameDiscription(), true);
	}

	@Test(priority = 69)
	public void enterDataIngroupNameDiscriptionTest() throws InterruptedException {
		try {
			client.enterDataIngroupNameDiscription("IT");
			log.info("Enter Group Discription");
		} catch (Exception e) {
			log.error("Not able to Enter Group Discription");
		}
	}

	@Test(priority = 70)
	public void displayStatusOfclosegroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclosegroup(), true);
	}

	@Test(priority = 71)
	public void enableStatusOfclosegroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclosegroup(), true);
	}

	@Test(priority = 72)
	public void displayStatusOfcancelgroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcancelgroup(), true);
	}

	@Test(priority = 73)
	public void enableStatusOfcancelgroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcancelgroup(), true);
	}

//	@Test(priority = 74)
//	public void clickOncancelDiscriptionTest() throws InterruptedException {
//		client.clickOncancelDiscription();
//	}	
	@Test(priority = 75)
	public void displayStatusOfsubmitgroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsubmitgroup(), true);
	}

	@Test(priority = 76)
	public void enableStatusOfsubmitgroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsubmitgroup(), true);
	}

	@Test(priority = 77)
	public void clickOnsubmitDiscriptionTest() throws InterruptedException {
		try {
			client.clickOnsubmitDiscription();
			log.info("click on submit");
		} catch (Exception e) {
			log.error("Not able to click on submit");
		}
	}
//	@Test(priority = 77)
//	public void clickOncancelDiscriptionTest() throws InterruptedException {
//		client.clickOncancelDiscription();
//	}

	@Test(priority = 78)
	public void displayStatusOfeditgroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfeditgroup(), true);
	}

	@Test(priority = 79)
	public void enableStatusOfeditgroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfeditgroup(), true);
	}

	@Test(priority = 80)
	public void clickOneditDiscriptionTest() throws InterruptedException {
		try {
			client.clickOneditDiscription();
			log.info("click on Edit");
		} catch (Exception e) {
			log.error("Not able to click on Edit");
		}
	}

	@Test(priority = 81)
	public void displayStatusOfedit_groupNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_groupName(), true);
	}

	@Test(priority = 82)
	public void enableStatusOfedit_groupNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_groupName(), true);
	}

	@Test(priority = 83)
	public void clearThegroupNameTest() throws InterruptedException {
		try {
			client.clearThegroupName();
			log.info("Clear Group Name");
		} catch (Exception e) {
			log.error("Not able to Clear Group Name");
		}
	}

	@Test(priority = 84)
	public void enterDataInedit_groupNameDiscriptionTest() throws InterruptedException {
		try {
			client.enterDataInedit_groupNameDiscription("PQR");
			log.info("Enter Group Name");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Group Name");
		}
	}

	@Test(priority = 85)
	public void displayStatusOfedit_groupNamegroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_groupNamegroup(), true);
	}

	@Test(priority = 86)
	public void enableStatusOfroleedit_groupNamegroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfroleedit_groupNamegroup(), true);
	}

	@Test(priority = 87)
	public void enterDataInedit_groupNamegroupTest() throws InterruptedException {
		try {
			client.enterDataInedit_groupNamegroup("PQRS");
			log.info("Enter Group Discription");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Group Discription");
		}
	}

	@Test(priority = 88)
	public void displayStatusOfedit_closegroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_closegroup(), true);
	}

	@Test(priority = 89)
	public void enableStatusOfedit_closegroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_closegroup(), true);
	}

	@Test(priority = 90)
	public void displayStatusOfedit_cancelgroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_cancelgroup(), true);
	}

	@Test(priority = 91)
	public void enableStatusOfedit_cancelgroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_cancelgroup(), true);
	}

//	@Test(priority = 92)
//	public void clickOnedit_cancelgroupTest() throws InterruptedException {
//		client.clickOnedit_cancelgroup();
//	}	
	@Test(priority = 93)
	public void displayStatusOfupdateGroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfupdateGroup(), true);
	}

	@Test(priority = 94)
	public void enableStatusOfupdateGroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfupdateGroup(), true);
	}

//	@Test(priority = 95)
//	public void clickOnupdateGroupTest() throws InterruptedException {
//		client.clickOnupdateGroup();
//	}	
	@Test(priority = 95)
	public void clickOnedit_cancelgroupTest() throws InterruptedException {
		try {
			client.clickOnedit_cancelgroup();
			log.info("click on Cancel");
		} catch (Exception e) {
			log.error("Not able to click on Cancel");
		}
	}

	@Test(priority = 96)
	public void displayStatusOfstatusgroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfstatusgroup(), true);
	}

	@Test(priority = 97)
	public void enableStatusOfstatusgroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfstatusgroup(), true);
	}

	@Test(priority = 98)
	public void clickOnstatusgroupTest() throws InterruptedException {
		try {
			client.clickOnstatusgroup();
			log.info("active / deactive the group");
		} catch (InterruptedException e) {
			log.error("Not able to active / deactive the group");
		}
	}

	@Test(priority = 99)
	public void displayStatusOfchannelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannel(), true);
	}

	@Test(priority = 100)
	public void enableStatusOfchannelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannel(), true);
	}

	@Test(priority = 101)
	public void clickOnchannelTets() throws InterruptedException {
		try {
			client.clickOnchannel();
			log.info("click on channel");
		} catch (InterruptedException e) {
			log.error("Not able to click on channel");
		}
	}

	@Test(priority = 102)
	public void displayStatusOfchannelStatus1Test() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannelStatus1(), true);
	}

	@Test(priority = 103)
	public void enableStatusOfchannelStatus1Test() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannelStatus1(), true);
	}

	@Test(priority = 104)
	public void clickOnchannelStatus1Test() throws InterruptedException {
		try {
			client.clickOnchannelStatus1();
			log.info("check active / Deactive status of channel");
		} catch (InterruptedException e) {
			log.error("Not able to check active / Deactive status of channel");
		}
	}

	@Test(priority = 105)
	public void displayStatusOfdownArrowTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfdownArrow(), true);
	}

	@Test(priority = 106)
	public void enableStatusOfdownArrowTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfdownArrow(), true);
	}

	@Test(priority = 107)
	public void clickOnchanneldownArrowTest() throws InterruptedException {
		try {
			client.clickOnchanneldownArrow();
			log.info("click on down arrow");
		} catch (InterruptedException e) {
			log.error("Not able to click on down arrow");
		}
	}

	@Test(priority = 108)
	public void displayStatusOfchannelSub1Test() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannelSub1(), true);
	}

	@Test(priority = 109)
	public void enableStatusOfchannelSub1Test() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannelSub1(), true);
	}

	@Test(priority = 110)
	public void clickOnchannelSub1Test() throws InterruptedException {
		try {
			client.clickOnchannelSub1();
			log.info("check active /  deactive status of sub channel 1 ");
		} catch (InterruptedException e) {
			log.error("Not able to check active /  deactive status of sub channel 1 ");
		}

	}

	@Test(priority = 111)
	public void displayStatusOfchanne2Sub1Test() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannelSub2(), true);
	}

	@Test(priority = 112)
	public void enableStatusOfchannelSub2Test() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannelSub2(), true);
	}

	@Test(priority = 113)
	public void clickOnchannelSub2Test() throws InterruptedException {
		try {
			client.clickOnchannelSub2();
			log.info("check active / deactive status of sub channel 2");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status of sub channel 2");
		}
	}

	@Test(priority = 114)
	public void displayStatusOfchannelSub3Test() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannelSub3(), true);
	}

	@Test(priority = 115)
	public void enableStatusOfchannelSub3Test() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannelSub3(), true);
	}

	@Test(priority = 116)
	public void clickOnchannelSub3Test() throws InterruptedException {
		try {
			client.clickOnchannelSub3();
			log.info("check active / deactive status of sub channel 3");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status of sub channel 3");
		}
	}

	@Test(priority = 117)
	public void displayStatusOfdownArrow2Test() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfdownArrow2(), true);
	}

	@Test(priority = 118)
	public void enableStatusOfdownArrow2Test() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfdownArrow2(), true);
	}

	@Test(priority = 119)
	public void clickOndownArrow2Test() throws InterruptedException {
		try {
			client.clickOndownArrow2();
			log.info("click on arrow");
		} catch (InterruptedException e) {
			log.error("Not able to click on arrow");
		}
	}

	@Test(priority = 120)
	public void displayStatusOfStatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfStatus(), true);
	}

	@Test(priority = 121)
	public void enableStatusOfStatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfStatus(), true);
	}

	@Test(priority = 122)
	public void clickOnStatusTest() throws InterruptedException {
		try {
			client.clickOnStatus();
			log.info("click on channel");
		} catch (InterruptedException e) {
			log.error("Not able to click on channel");
		}
	}

	@Test(priority = 123)
	public void displayStatusOfcreate_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreate_Status(), true);
	}

	@Test(priority = 124)
	public void enableStatusOfcreate_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreate_Status(), true);
	}

	@Test(priority = 125)
	public void clickOncreate_StatusTest() throws InterruptedException {
		try {
			client.clickOncreate_Status();
			log.info("click on create status");
		} catch (InterruptedException e) {
			log.error("Not able to click on create status");
		}
	}

	@Test(priority = 126)
	public void displayStatusOfStatus_NameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfStatus_Name(), true);
	}

	@Test(priority = 127)
	public void enableStatusOfStatus_NameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfStatus_Name(), true);
	}

	@Test(priority = 128)
	public void eneterDataInStatus_NameTest() throws InterruptedException {
		try {
			client.eneterDataInStatus_Name("Break");
			log.info("enter status name");
		} catch (InterruptedException e) {
			log.error("Not able to enter status name");
		}
	}

	@Test(priority = 129)
	public void displayStatusOfStatus_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfStatus_Discription(), true);
	}

	@Test(priority = 130)
	public void enableStatusOfStatus_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfStatus_Discription(), true);
	}

	@Test(priority = 131)
	public void eneterDataInStatus_DiscriptionTest() throws InterruptedException {
		try {
			client.eneterDataInStatus_Discription("Break");
			log.info("enter discription ");
		} catch (InterruptedException e) {
			log.error("Not able to Not able to enter status name");
		}
	}

	@Test(priority = 132)
	public void displayStatusOfStatus_closeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfStatus_close(), true);
	}

	@Test(priority = 133)
	public void enableStatusOfStatus_closeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfStatus_close(), true);
	}

	@Test(priority = 134)
	public void displayStatusOfStatus_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfStatus_cancel(), true);
	}

	@Test(priority = 135)
	public void enableStatusOfStatus_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfStatus_cancel(), true);
	}

//	@Test(priority = 136)
//	public void clickOnStatus_cancelTest() throws InterruptedException {
//		client.clickOnStatus_cancel();
//	}	
	@Test(priority = 137)
	public void displayStatusOfStatus_submitTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfStatus_submit(), true);
	}

	@Test(priority = 138)
	public void enableStatusOfStatus_submitTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfStatus_submit(), true);
	}

	@Test(priority = 139)
	public void clickOnStatus_submitTest() throws InterruptedException {
		try {
			client.clickOnStatus_submit();
			log.info("click on submit");
		} catch (Exception e) {
			log.error("Not able to click on submit");
		}
	}
//	@Test(priority = 139)
//	public void clickOnStatus_cancelTest() throws InterruptedException {
//		client.clickOnStatus_cancel();
//	}

	@Test(priority = 140)
	public void displayStatusOfedit_statusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_status(), true);
	}

	@Test(priority = 141)
	public void enableStatusOfedit_statusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_status(), true);
	}

	@Test(priority = 142)
	public void clickOnedit_statusTest() throws InterruptedException {
		try {
			client.clickOnedit_status();
			log.info("click on edit status");
		} catch (Exception e) {
			log.error("Not able to click on edit status");
		}
	}

	@Test(priority = 143)
	public void displayStatusOfedit_Status_NameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_Status_Name(), true);
	}

	@Test(priority = 144)
	public void enableStatusOfedit_Status_NameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_Status_Name(), true);
	}

	@Test(priority = 145)
	public void eneterDataInedit_Status_NameTest() throws InterruptedException {
		try {
			client.eneterDataInedit_Status_Name("PQR");
			log.info("enter status name");
		} catch (InterruptedException e) {
			log.error("Not able to enter status name");
		}
	}

	@Test(priority = 146)
	public void displayStatusOfedit_Status_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_Status_Discription(), true);
	}

	@Test(priority = 147)
	public void enableStatusOfedit_Status_DiscriptionTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_Status_Discription(), true);
	}

	@Test(priority = 148)
	public void eneterDataInedit_Status_DiscriptionTest() throws InterruptedException {
		try {
			client.eneterDataInedit_Status_Discription("PQRS");
			log.info("Enter Discription");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Discription");
		}
	}

	@Test(priority = 149)
	public void displayStatusOfedit_Status_closeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_Status_close(), true);
	}

	@Test(priority = 150)
	public void enableStatusOfedit_Status_closeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_Status_close(), true);
	}

	@Test(priority = 151)
	public void displayStatusOfedit_Status_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_Status_cancel(), true);
	}

	@Test(priority = 152)
	public void enableStatusOfedit_Status_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_Status_cancel(), true);
	}

//	@Test(priority = 153)
//	public void clickOnedit_Status_cancelTest() throws InterruptedException {
//		client.clickOnedit_Status_cancel();
//	}	
	@Test(priority = 154)
	public void displayStatusOfedit_Status_updateStatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_Status_updateStatus(), true);
	}

	@Test(priority = 155)
	public void enableStatusOfedit_Status_updateStatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_Status_updateStatus(), true);
	}

//	@Test(priority = 156)
//	public void clickOnedit_Status_updateStatusTest() throws InterruptedException {
//		client.clickOnedit_Status_updateStatus();
//	}	
	@Test(priority = 156)
	public void clickOnedit_Status_cancelTest() throws InterruptedException {
		try {
			client.clickOnedit_Status_cancel();
			log.info("click on cancel");
		} catch (Exception e) {
			log.error("Not able to click on cancel");
		}
	}

	@Test(priority = 157)
	public void displayStatusOfStatus_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfStatus_Status(), true);
	}

	@Test(priority = 158)
	public void enableStatusOfStatus_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfStatus_Status(), true);
	}

	@Test(priority = 159)
	public void clickOnStatus_StatusTest() throws InterruptedException {
		try {
			client.clickOnStatus_Status();
			log.info("check active / deactive status of status");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status of status");
		}
	}

	@Test(priority = 160)
	public void displayStatusOfskillSetTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskillSet(), true);
	}

	@Test(priority = 161)
	public void enableStatusOfskillSetTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskillSet(), true);
	}

	@Test(priority = 162)
	public void clickOnskillSetTest() throws InterruptedException {
		try {
			client.clickOnskillSet();
			log.info("click on skill set");
		} catch (Exception e) {
			log.error("Not able to click on skill set");
		}
	}

	@Test(priority = 163)
	public void displayStatusOfcreateSkillTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateSkill(), true);
	}

	@Test(priority = 164)
	public void enableStatusOfcreateSkillTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateSkill(), true);
	}

	@Test(priority = 165)
	public void clickOncreateSkillTest() throws InterruptedException {
		try {
			client.clickOncreateSkill();
			log.info("click on create skill set");
		} catch (Exception e) {
			log.error("Not able to click on create skill set");
		}
	}

	@Test(priority = 166)
	public void displayStatusOfskillNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskillName(), true);
	}

	@Test(priority = 167)
	public void enableStatusOfskillNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskillName(), true);
	}

	@Test(priority = 168)
	public void clickOnskillNameTest() throws InterruptedException {
		try {
			client.enterDataInskillName("HR");
			log.info("enter skill set");
		} catch (Exception e) {
			log.error("Not able to enter skill set");
		}
	}

	@Test(priority = 169)
	public void displayStatusOfskill_closeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskill_close(), true);
	}

	@Test(priority = 170)
	public void enableStatusOfskill_closeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskill_close(), true);
	}

	@Test(priority = 171)
	public void displayStatusOfskill_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskill_cancel(), true);
	}

	@Test(priority = 172)
	public void enableStatusOfskill_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskill_cancel(), true);
	}

//	@Test(priority = 173)
//	public void clickOnskill_cancelTest() throws InterruptedException {
//		client.clickOnskill_cancel();
//	}	
	@Test(priority = 174)
	public void displayStatusOfSkillsubmitTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfSkillsubmit(), true);
	}

	@Test(priority = 175)
	public void enableStatusOfSkillsubmitTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfSkillsubmit(), true);
	}

	@Test(priority = 176)
	public void clickOnskillsubmitTest() throws InterruptedException {
		try {
			client.clickOnskillsubmit();
			log.info("click on submit");
		} catch (Exception e) {
			log.error("Not able to click on submit");
		}
	}
//	@Test(priority = 176)
//	public void clickOnskill_cancelTest() throws InterruptedException {
//		client.clickOnskill_cancel();
//	}

	@Test(priority = 177)
	public void displayStatusOfeditSkillTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfeditSkill(), true);
	}

	@Test(priority = 178)
	public void enableStatusOfeditSkillTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfeditSkill(), true);
	}

	@Test(priority = 179)
	public void clickOneditSkillTest() throws InterruptedException {
		try {
			client.clickOneditSkill();
			log.info("click on edit skill set");
		} catch (Exception e) {
			log.error("Not able to click on edit skill set");
		}
	}

	@Test(priority = 180)
	public void displayStatusOfedit_skillNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_skillName(), true);
	}

	@Test(priority = 181)
	public void enableStatusOfedit_skillNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_skillName(), true);
	}

	@Test(priority = 182)
	public void enterDataInedit_skillNameTest() throws InterruptedException {
		try {
			client.enterDataInedit_skillName("PQR");
			log.info("enter skill set");
		} catch (InterruptedException e) {
			log.error("Not able to enter skill set");
		}
	}

	@Test(priority = 183)
	public void displayStatusOfedit_skill_closeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_skill_close(), true);
	}

	@Test(priority = 184)
	public void enableStatusOfedit_skill_closeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_skill_close(), true);
	}

	@Test(priority = 185)
	public void displayStatusOfedit_skill_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_skill_cancel(), true);
	}

	@Test(priority = 186)
	public void enableStatusOfedit_skill_cancelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_skill_cancel(), true);
	}

//	@Test(priority = 187)
//	public void clickOnedit_skill_cancelTest() throws InterruptedException {
//		client.clickOnedit_skill_cancel();
//	}	
	@Test(priority = 188)
	public void displayStatusOfupdateSkillTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfupdateSkill(), true);
	}

	@Test(priority = 189)
	public void enableStatusOfupdateSkillTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfupdateSkill(), true);
	}

//	@Test(priority = 190)
//	public void clickOnupdateSkillTest() throws InterruptedException {
//		client.clickOnupdateSkill();
//	}	
	@Test(priority = 190)
	public void clickOnedit_skill_cancelTest() throws InterruptedException {
		try {
			client.clickOnedit_skill_cancel();
			log.info("click on cancel");
		} catch (Exception e) {
			log.error("Not able to click on cancel");
		}
	}

	@Test(priority = 191)
	public void displayStatusOfskill_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskill_Status(), true);
	}

	@Test(priority = 192)
	public void enableStatusOfskill_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskill_Status(), true);
	}

	@Test(priority = 193)
	public void clickOnskill_StatusTest() throws InterruptedException {
		try {
			client.clickOnskill_Status();
			log.info("check active / deactive status of skill set ");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status of skill set ");
		}
	}

	@Test(priority = 194)
	public void displayStatusOfskillProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskillProfeciancy(), true);
	}

	@Test(priority = 195)
	public void enableStatusOfskillProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskillProfeciancy(), true);
	}

	@Test(priority = 196)
	public void clickOnskillProfeciancyTest() throws InterruptedException {
		try {
			client.clickOnskillProfeciancy();
			log.info("click on skill profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to click on skill profeciancy");
		}
	}

	@Test(priority = 197)
	public void displayStatusOfcreateProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateProfeciancy(), true);
	}

	@Test(priority = 198)
	public void enableStatusOfcreateProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateProfeciancy(), true);
	}

	@Test(priority = 199)
	public void clickOncreateProfeciancyTest() throws InterruptedException {
		try {
			client.clickOncreateProfeciancy();
			log.info("click on create profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to click on create profeciancy");
		}
	}

	@Test(priority = 200)
	public void displayStatusOfskillProfeciancyNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskillProfeciancyName(), true);
	}

	@Test(priority = 201)
	public void enableStatusOfskillProfeciancyNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskillProfeciancyName(), true);
	}

	@Test(priority = 202)
	public void entertDataInskillProfeciancyNameTest() throws InterruptedException {
		try {
			client.entertDataInskillProfeciancyName("Basic");
			log.info("enter skill profeciancy ");
		} catch (InterruptedException e) {
			log.error("Not able to enter skill profeciancy ");
		}
	}

	@Test(priority = 203)
	public void displayStatusOfcloseProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcloseProfeciancy(), true);
	}

	@Test(priority = 204)
	public void enableStatusOfcloseProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcloseProfeciancy(), true);
	}

//	@Test(priority = 205)
//	public void clickOncloseProfeciancyTest() throws InterruptedException {
//		client.clickOncloseProfeciancy();
//	}
	@Test(priority = 206)
	public void displayStatusOfsubmitProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsubmitProfeciancy(), true);
	}

	@Test(priority = 207)
	public void enableStatusOfsubmitProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsubmitProfeciancy(), true);
	}

//	@Test(priority = 208)
//	public void clickOnsubmitProfeciancyTest() throws InterruptedException {
//		client.clickOnsubmitProfeciancy();
//	}	
	@Test(priority = 209)
	public void displayStatusOfcancelProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcancelProfeciancy(), true);
	}

	@Test(priority = 210)
	public void enableStatusOfcancelProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcancelProfeciancy(), true);
	}

//	@Test(priority = 211)
//	public void clickOncancelProfeciancyTest() throws InterruptedException {
//		client.clickOncancelProfeciancy();
//	}
	@Test(priority = 211)
	public void clickOnsubmitProfeciancyTest() throws InterruptedException {
		try {
			client.clickOnsubmitProfeciancy();
			log.info("click on submit");
		} catch (InterruptedException e) {
			log.error("Not able to click on submit");
		}
	}

	@Test(priority = 212)
	public void displayStatusOfeditProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfeditProfeciancy(), true);
	}

	@Test(priority = 213)
	public void enableStatusOfeditProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfeditProfeciancy(), true);
	}

	@Test(priority = 214)
	public void clickOneditProfeciancyTest() throws InterruptedException {
		try {
			client.clickOneditProfeciancy();
			log.info("click on edit profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to click on edit profeciancy");
		}
	}

	@Test(priority = 215)
	public void displayStatusOfedit_skillProfeciancyNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_skillProfeciancyName(), true);
	}

	@Test(priority = 216)
	public void enableStatusOfedit_skillProfeciancyNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_skillProfeciancyName(), true);
	}

	@Test(priority = 217)
	public void entertDataInedit_skillProfeciancyNameTest() throws InterruptedException {
		try {
			client.entertDataInedit_skillProfeciancyName("PQR");
			log.info("update profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to update profeciancy");
		}
	}

	@Test(priority = 218)
	public void displayStatusOfedit_closeProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_closeProfeciancy(), true);
	}

	@Test(priority = 219)
	public void enableStatusOfedit_closeProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_closeProfeciancy(), true);
	}

//	@Test(priority = 220)
//	public void clickOnedit_closeProfeciancyTest() throws InterruptedException {
//		client.clickOnedit_closeProfeciancy();
//	}	
	@Test(priority = 221)
	public void displayStatusOfedit_updateProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_updateProfeciancy(), true);
	}

	@Test(priority = 222)
	public void enableStatusOfedit_updateProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_updateProfeciancy(), true);
	}

//	@Test(priority = 223)
//	public void clickOnedit_updateProfeciancyTest() throws InterruptedException {
//		client.clickOnedit_updateProfeciancy();
//	}	
	@Test(priority = 224)
	public void displayStatusOfedit_cancelProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_cancelProfeciancy(), true);
	}

	@Test(priority = 225)
	public void enableStatusOfedit_cancelProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_cancelProfeciancy(), true);
	}

	@Test(priority = 226)
	public void clickOnedit_cancelProfeciancyTest() throws InterruptedException {
		try {
			client.clickOnedit_cancelProfeciancy();
			log.info("click on cancl");
		} catch (InterruptedException e) {
			log.error("Not able to click on cancl");
		}
	}

	@Test(priority = 227)
	public void displayStatusOfprofeciancy_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfprofeciancy_Status(), true);
	}

	@Test(priority = 228)
	public void enableStatusOfprofeciancy_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfprofeciancy_Status(), true);
	}

	@Test(priority = 229)
	public void clickOnprofeciancy_StatusTest() throws InterruptedException {
		try {
			client.clickOnprofeciancy_Status();
			log.info("check active / deactive status of profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status of profeciancy");
		}
	}

	@Test(priority = 230)
	public void displayStatusOflanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflanguage(), true);
	}

	@Test(priority = 231)
	public void enableStatusOflanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflanguage(), true);
	}

	@Test(priority = 232)
	public void clickOnlanguageTest() throws InterruptedException {
		try {
			client.clickOnlanguage();
			log.info("click on language");
		} catch (InterruptedException e) {
			log.error("Not able to click on language");
		}
	}

	@Test(priority = 233)
	public void displayStatusOfcreateLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateLanguage(), true);
	}

	@Test(priority = 234)
	public void enableStatusOfcreateLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateLanguage(), true);
	}

	@Test(priority = 235)
	public void clickOncreateLanguageTest() throws InterruptedException {
		try {
			client.clickOncreateLanguage();
			log.info("click on create language");
		} catch (InterruptedException e) {
			log.error("Not able to click on create language");
		}
	}

	@Test(priority = 236)
	public void displayStatusOflanguageNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflanguageName(), true);
	}

	@Test(priority = 237)
	public void enableStatusOflanguageNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflanguageName(), true);
	}

	@Test(priority = 238)
	public void enterDataInlanguageNameTest() throws InterruptedException {
		try {
			client.enterDataInlanguageName("Hindi");
			log.info("enter language");
		} catch (InterruptedException e) {
			log.error("Not able to enter language");
		}
	}

	@Test(priority = 239)
	public void displayStatusOflanguageCodeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflanguageCode(), true);
	}

	@Test(priority = 240)
	public void enableStatusOflanguageCodeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflanguageCode(), true);
	}

	@Test(priority = 241)
	public void enterDataInlanguageCodeTest() throws InterruptedException {
		try {
			client.enterDataInlanguageCode("Hindi");
			log.info("enter language code");
		} catch (InterruptedException e) {
			log.error("Not able to enter language code");
		}
	}

	@Test(priority = 242)
	public void displayStatusOfcloseLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcloseLanguage(), true);
	}

	@Test(priority = 243)
	public void enableStatusOfcloseLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcloseLanguage(), true);
	}

//	@Test(priority = 244)
//	public void clickOncloseLanguageTest() throws InterruptedException {
//		client.clickOncloseLanguage();
//	}	
	@Test(priority = 245)
	public void displayStatusOfsubmitLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsubmitLanguage(), true);
	}

	@Test(priority = 246)
	public void enableStatusOfsubmitLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsubmitLanguage(), true);
	}

//	@Test(priority = 247)
//	public void clickOnsubmitLanguageTest() throws InterruptedException {
//		client.clickOnsubmitLanguage();
//	}	
	@Test(priority = 248)
	public void displayStatusOfcancelLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcancelLanguage(), true);
	}

	@Test(priority = 249)
	public void enableStatusOfcancelLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcancelLanguage(), true);
	}

//	@Test(priority = 250)
//	public void clickOncancelLanguageTest() throws InterruptedException {
//		client.clickOncancelLanguage();
//	}
	@Test(priority = 250)
	public void clickOnsubmitLanguageTest() throws InterruptedException {
		try {
			client.clickOnsubmitLanguage();
			log.info("click on submit");
		} catch (InterruptedException e) {
			log.error("Not able to click on submit");
		}
	}

	@Test(priority = 251)
	public void displayStatusOfedit_LanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_Language(), true);
	}

	@Test(priority = 252)
	public void enableStatusOfedit_LanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_Language(), true);
	}

	@Test(priority = 253)
	public void clickOnedit_LanguageTest() throws InterruptedException {
		try {
			client.clickOnedit_Language();
			log.info("click on edit language");
		} catch (InterruptedException e) {
			log.error("Not able to click on edit language");
		}
	}

	@Test(priority = 254)
	public void displayStatusOfedit_languageNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_languageName(), true);
	}

	@Test(priority = 255)
	public void enableStatusOfedit_languageNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_languageName(), true);
	}

	@Test(priority = 256)
	public void enterDataInedit_languageNameTest() throws InterruptedException {
		try {
			client.enterDataInedit_languageName("PQR");
			log.info("enter ne language");
		} catch (InterruptedException e) {
			log.error("Not able to enter ne language");
		}
	}

	@Test(priority = 257)
	public void displayStatusOfedit_languageCodeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_languageCode(), true);
	}

	@Test(priority = 258)
	public void enableStatusOfedit_languageCodeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_languageCode(), true);
	}

	@Test(priority = 259)
	public void enterDataInedit_languageCodeTest() throws InterruptedException {
		try {
			client.enterDataInedit_languageCode("PQRS");
			log.info("enter new language code");
		} catch (InterruptedException e) {
			log.error("Not able to enter new language code");
		}
	}

	@Test(priority = 260)
	public void displayStatusOfedit_closeLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_closeLanguage(), true);
	}

	@Test(priority = 261)
	public void enableStatusOfedit_closeLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_closeLanguage(), true);
	}

//	@Test(priority = 262)
//	public void clickOnedit_closeLanguageTest() throws InterruptedException {
//		client.clickOnedit_closeLanguage();
//	}	
	@Test(priority = 263)
	public void displayStatusOfedit_updateLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_updateLanguage(), true);
	}

	@Test(priority = 264)
	public void enableStatusOfedit_updateLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_updateLanguage(), true);
	}

//	@Test(priority = 265)
//	public void clickOnedit_updateLanguageTest() throws InterruptedException {
//		client.clickOnedit_updateLanguage();
//	}	
	@Test(priority = 266)
	public void displayStatusOfedit_cancelLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_cancelLanguage(), true);
	}

	@Test(priority = 267)
	public void enableStatusOfedit_cancelLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_cancelLanguage(), true);
	}

	@Test(priority = 268)
	public void clickOnedit_cancelLanguageTest() throws InterruptedException {
		try {
			client.clickOnedit_cancelLanguage();
			log.info("click on cancel");
		} catch (InterruptedException e) {
			log.error("Not able to click on cancel");
		}
	}

	@Test(priority = 269)
	public void displayStatusOfedit_Language_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_Language_Status(), true);
	}

	@Test(priority = 270)
	public void enableStatusOfedit_Language_StatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_Language_Status(), true);
	}

	@Test(priority = 271)
	public void clickOnedit_Language_StatusTest() throws InterruptedException {
		try {
			client.clickOnedit_Language_Status();
			log.info("check active / deactive status of language");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status of language");
		}
	}

	@Test(priority = 272)
	public void displayStatusOflanguage_ProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflanguage_Proficiency(), true);
	}

	@Test(priority = 273)
	public void enableStatusOflanguage_ProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflanguage_Proficiency(), true);
	}

	@Test(priority = 274)
	public void clickOnlanguage_ProficiencyTest() throws InterruptedException {
		try {
			client.clickOnlanguage_Proficiency();
			log.info("click on language proficiancy");
		} catch (InterruptedException e) {
		log.error("Not able to click on language proficiancy");
		}
	}

	@Test(priority = 275)
	public void displayStatusOfcreateProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateProficiency(), true);
	}

	@Test(priority = 276)
	public void enableStatusOfcreateProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateProficiency(), true);
	}

	@Test(priority = 277)
	public void clickOncreateProficiencyTest() throws InterruptedException {
		try {
			client.clickOncreateProficiency();
			log.info("click on create language proficiancy");
		} catch (InterruptedException e) {
			log.error("Not able to click on create language proficiancy");
		}
	}

	@Test(priority = 278)
	public void displayStatusOflanguageProficiencyNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflanguageProficiencyName(), true);
	}

	@Test(priority = 279)
	public void enableStatusOflanguageProficiencyNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflanguageProficiencyName(), true);
	}

	@Test(priority = 280)
	public void enterDataInlanguageProficiencyNameTest() throws InterruptedException {
		try {
			client.enterDataInlanguageProficiencyName("Basic");
			log.info("enter language profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to enter language profeciancy");
		}
	}

	@Test(priority = 281)
	public void displayStatusOfcloseLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcloseLanguageProficiency(), true);
	}

	@Test(priority = 282)
	public void enableStatusOfcloseLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcloseLanguageProficiency(), true);
	}

//	@Test(priority = 283)
//	public void clickOncloseLanguageProficiencyTest() throws InterruptedException {
//		client.clickOncloseLanguageProficiency();
//	}	
	@Test(priority = 284)
	public void displayStatusOfsubmitLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsubmitLanguageProficiency(), true);
	}

	@Test(priority = 285)
	public void enableStatusOfsubmitLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsubmitLanguageProficiency(), true);
	}

//	@Test(priority = 286)
//	public void clickOnsubmitLanguageProficiencyTest() throws InterruptedException {
//		client.clickOnsubmitLanguageProficiency();
//	}	
	@Test(priority = 287)
	public void displayStatusOfcancelLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcancelLanguageProficiency(), true);
	}

	@Test(priority = 288)
	public void enableStatusOfcancelLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcancelLanguageProficiency(), true);
	}

//	@Test(priority = 289)
//	public void clickOncancelLanguageProficiencyTest() throws InterruptedException {
//		client.clickOncancelLanguageProficiency();
//	}
	@Test(priority = 289)
	public void clickOnsubmitLanguageProficiencyTest() throws InterruptedException {
		try {
			client.clickOnsubmitLanguageProficiency();
			log.info("click on submit");
		} catch (InterruptedException e) {
			log.error("Not able to click on submit");
		}
	}

	@Test(priority = 290)
	public void displayStatusOfedit_LanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_LanguageProficiency(), true);
	}

	@Test(priority = 291)
	public void enableStatusOfedit_LanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_LanguageProficiency(), true);
	}

	@Test(priority = 292)
	public void clickOnedit_LanguageProficiencyTest() throws InterruptedException {
		try {
			client.clickOnedit_LanguageProficiency();
			log.info("click on edit language profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to click on edit language profeciancy");
		}
	}

	@Test(priority = 293)
	public void displayStatusOfedit_languageProficiencyNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_languageProficiencyName(), true);
	}

	@Test(priority = 294)
	public void enableStatusOfedit_languageProficiencyNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_languageProficiencyName(), true);
	}

	@Test(priority = 295)
	public void enterDataInedit_languageProficiencyNameTest() throws InterruptedException {
		try {
			client.enterDataInedit_languageProficiencyName("PQR");
			log.info("update language profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to update language profeciancy");
		}
	}

	@Test(priority = 296)
	public void displayStatusOfedit_closeLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_closeLanguageProficiency(), true);
	}

	@Test(priority = 297)
	public void enableStatusOfedit_closeLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_closeLanguageProficiency(), true);
	}

//	@Test(priority = 298)
//	public void clickOnedit_closeLanguageProficiencyTest() throws InterruptedException {
//		client.clickOnedit_closeLanguageProficiency();
//	}	
	@Test(priority = 299)
	public void displayStatusOfedit_updateLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_updateLanguageProficiency(), true);
	}

	@Test(priority = 300)
	public void enableStatusOfedit_updateLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_updateLanguageProficiency(), true);
	}

//	@Test(priority = 301)
//	public void clickOnedit_updateLanguageProficiencyTest() throws InterruptedException {
//		client.clickOnedit_updateLanguageProficiency();
//	}	
	@Test(priority = 302)
	public void displayStatusOfedit_cancelLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_cancelLanguageProficiency(), true);
	}

	@Test(priority = 303)
	public void enableStatusOfedit_cancelLanguageProficiencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_cancelLanguageProficiency(), true);
	}

	@Test(priority = 304)
	public void clickOnedit_cancelLanguageProficiencyTest() throws InterruptedException {
		try {
			client.clickOnedit_cancelLanguageProficiency();
			log.info("click on cancel");
		} catch (InterruptedException e) {
			log.error("Not able to click on cancel");
		}
	}

	@Test(priority = 305)
	public void displayStatusOfedit_languageProficiencyStatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_languageProficiencyStatus(), true);
	}

	@Test(priority = 306)
	public void enableStatusOfedit_languageProficiencyStatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_languageProficiencyStatus(), true);
	}

	@Test(priority = 307)
	public void clickOnedit_languageProficiencyStatusTest() throws InterruptedException {
		try {
			client.clickOnedit_languageProficiencyStatus();
			log.info("check active / deactive status of language profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status of language profeciancy");
		}
	}

	@Test(priority = 308)
	public void displayStatusOfedit_routingAlgorithmTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_routingAlgorithm(), true);
	}

	@Test(priority = 309)
	public void enableStatusOfedit_routingAlgorithmTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_routingAlgorithm(), true);
	}

	@Test(priority = 310)
	public void clickOnedit_routingAlgorithmTest() throws InterruptedException {
		try {
			client.clickOnedit_routingAlgorithm();
			log.info("click on routing algorithm");
		} catch (InterruptedException e) {
			log.error("Not able to click on routing algorithm");
		}
	}

	@Test(priority = 311)
	public void displayStatusOfedit_routingAlgorithmStatusTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfedit_routingAlgorithmStatus(), true);
	}

	@Test(priority = 312)
	public void enableStatusOfedit_routingAlgorithmStatusTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfedit_routingAlgorithmStatus(), true);
	}

	@Test(priority = 313)
	public void clickOnedit_routingAlgorithmStatusTest() throws InterruptedException {
		try {
			client.clickOnedit_routingAlgorithmStatus();
			log.info("check active / deactive status of routing algorithms");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status of routing algorithms");
		}
	}

//	@Test(priority = 314)
//	public void displayStatusOfmoduleMasterTest() throws InterruptedException {
//		Assert.assertEquals(client.displayStatusOfmoduleMaster(), true);
//	}	
//	@Test(priority = 315)
//	public void enableStatusOfmoduleMasterTest() throws InterruptedException {
//		Assert.assertEquals(client.enableStatusOfmoduleMaster(), true);
//	}	
//	@Test(priority = 316)
//	public void clickOnmoduleMasterTest() throws InterruptedException {
//		client.clickOnmoduleMaster();
//	}	
//	@Test(priority = 317)
//	public void displayStatusOfselectAppNameTest() throws InterruptedException {
//		Assert.assertEquals(client.displayStatusOfselectAppName(), true);
//	}	
//	@Test(priority = 318)
//	public void enableStatusOfselectAppNameTest() throws InterruptedException {
//		Assert.assertEquals(client.enableStatusOfselectAppName(), true);
//	}	
//	@Test(priority = 319)
//	public void clickOnselectAppNameTest() throws InterruptedException {
//		client.clickOnselectAppName();
//	}	
//	@Test(priority = 320)
//	public void selectTheDpValueFromSelectAppNameTest() throws InterruptedException {
//		client.selectTheDpValueFromSelectAppName("Agent Desktop");
//	}
	@Test(priority = 321)
	public void displayStatusOfcreateClientTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateClient(), true);
	}

	@Test(priority = 322)
	public void enableStatusOfcreateClientTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateClient(), true);
	}

	@Test(priority = 323)
	public void clickOncreateClientTest() throws InterruptedException {
		try {
			client.clickOncreateClient();
			log.info("click on craete client");
		} catch (InterruptedException e) {
			log.error("Not able to click on craete client");
		}
	}

	@Test(priority = 324)
	public void displayStatusOffirstNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOffirstName(), true);
	}

	@Test(priority = 325)
	public void enableStatusOffirstNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOffirstName(), true);
	}

	@Test(priority = 326)
	public void enterDataInfirstNameTest() throws InterruptedException {
		try {
			client.enterDataInfirstName("Amol");
			log.info("enter client name");
		} catch (InterruptedException e) {
			log.error("Not able to enter client name");
		}
	}

	@Test(priority = 327)
	public void displayStatusOflastNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflastName(), true);
	}

	@Test(priority = 328)
	public void enableStatusOflastNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflastName(), true);
	}

	@Test(priority = 329)
	public void enterDataInlastNameTest() throws InterruptedException {
		try {
			client.enterDataInlastName("G");
			log.info("enter client last name");
		} catch (InterruptedException e) {
			log.error("Not able to enter client last name");
		}
	}

	@Test(priority = 330)
	public void displayStatusOfemailTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfemail(), true);
	}

	@Test(priority = 331)
	public void enableStatusOfemailTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfemail(), true);
	}

	@Test(priority = 332)
	public void enterDataInemailTest() throws InterruptedException {
		try {
			client.enterDataInemail("Abc123@gmail.com");
			log.info("enter client email");
		} catch (InterruptedException e) {
			log.error("Not able to enter client email");
		}
	}

	@Test(priority = 333)
	public void displayStatusOfcontactNumberTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcontactNumber(), true);
	}

	@Test(priority = 334)
	public void enableStatusOfcontactNumberTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcontactNumber(), true);
	}

	@Test(priority = 335)
	public void enterDataIncontactNumberTest() throws InterruptedException {
		try {
			client.enterDataIncontactNumber("9876581234");
			log.info("enter client mobile number");
		} catch (InterruptedException e) {
			log.error("Not able to enter client mobile number");
		}
	}

	@Test(priority = 336)
	public void displayStatusOfclientPasswordTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientPassword(), true);
	}

	@Test(priority = 337)
	public void enableStatusOfclientPasswordTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientPassword(), true);
	}

	@Test(priority = 338)
	public void enterDataInclientPasswordTest() throws InterruptedException {
		try {
			client.enterDataInclientPassword("Welcome@123");
			log.info("enter client password");
		} catch (InterruptedException e) {
			log.error("Not able to enter client password");
		}
	}

	@Test(priority = 339)
	public void displayStatusOfclientPasswordShowTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientPasswordShow(), true);
	}

	@Test(priority = 340)
	public void enableStatusOfclientPasswordShowTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientPasswordShow(), true);
	}

	@Test(priority = 341)
	public void clickclientPasswordShowTest() throws InterruptedException {
		try {
			client.clickclientPasswordShow();
			log.info("click on show password");
		} catch (InterruptedException e) {
			log.error("Not able to click on show password");
		}
	}

	@Test(priority = 342)
	public void displayStatusOfclientConfirmPasswordTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientConfirmPassword(), true);
	}

	@Test(priority = 343)
	public void enableStatusOfclientConfirmPasswordTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientConfirmPassword(), true);
	}

	@Test(priority = 344)
	public void enterDataInclientConfirmPasswordTest() throws InterruptedException {
		try {
			client.enterDataInclientConfirmPassword("Welcome@123");
			log.info("enter client confirm password");
		} catch (InterruptedException e) {
			log.error("Not able to enter client confirm password");
		}
	}

	@Test(priority = 345)
	public void displayStatusOfclientConfirmPasswordShowTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientConfirmPasswordShow(), true);
	}

	@Test(priority = 346)
	public void enableStatusOfclientConfirmPasswordShowTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientConfirmPasswordShow(), true);
	}

	@Test(priority = 347)
	public void clickConfirmPasswordShowTest() throws InterruptedException {
		try {
			client.clickConfirmPasswordShow();
			log.info("click on show password");
		} catch (InterruptedException e) {
			log.error("Not able to click on show password");
		}
	}

	@Test(priority = 348)
	public void displayStatusOfclientRoleTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientRole(), true);
	}

	@Test(priority = 349)
	public void enableStatusOfclientRoleTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientRole(), true);
	}

	@Test(priority = 350)
	public void clickOnclientRoleTest() throws InterruptedException {
		try {
			client.clickOnclientRole();
			log.info("tab on client role");
		} catch (InterruptedException e) {
			log.error("Not able to tab on client role");
		}
	}

	@Test(priority = 351)
	public void selectRoleFromDPTest() throws InterruptedException {
		try {
			client.selectRoleFromDP("Agent");
			log.info("select role from dp");
		} catch (Exception e) {
			log.error("Nota able to select role from dp");
		}
	}

	@Test(priority = 352)
	public void displayStatusOfclientGroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientGroup(), true);
	}

	@Test(priority = 353)
	public void enableStatusOfclientGroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientGroup(), true);
	}

	@Test(priority = 354)
	public void clickOnclientGroupTest() throws InterruptedException {
		try {
			client.clickOnclientGroup();
			log.info("tab on client group");
		} catch (InterruptedException e) {
			log.error("Not able to tab on client group");
		}
	}

	@Test(priority = 355)
	public void selectGroupFromDPTets() throws InterruptedException {
		try {
			client.selectGroupFromDP("IT");
			log.info("select group from dp");
		} catch (Exception e) {
			log.error("Nt able to select group from dp");
		}
	}

	@Test(priority = 356)
	public void displayStatusOfclientChannelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientChannel(), true);
	}

	@Test(priority = 357)
	public void enableStatusOfclientChannelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientChannel(), true);
	}

	@Test(priority = 358)
	public void clickOnclientChannelTest() throws InterruptedException {
		try {
			client.clickOnclientChannel();
			log.info("tab on channel ");
		} catch (InterruptedException e) {
			log.error("Not able to tab on channel ");
		}
	}

	@Test(priority = 359)
	public void selectChannelFromDPTest() throws InterruptedException {
		try {
			client.selectChannelFromDP("Chat");
			log.info("select channel name from dp");
		} catch (Exception e) {
			log.error("Not able to select channel name from dp");
		}
	}

	@Test(priority = 360)
	public void displayStatusOfclientSubChannelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclientSubChannel(), true);
	}

	@Test(priority = 361)
	public void enableStatusOfclientSubChannelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclientSubChannel(), true);
	}

	@Test(priority = 362)
	public void clickOnclientSubChannelTest() throws InterruptedException {
		try {
			client.clickOnclientSubChannel();
			log.info("tab on sub channel");
		} catch (InterruptedException e) {
			log.error("Not able to tab on sub channel");
		}
	}

	@Test(priority = 363)
	public void selectsubChannelFromDPTest() throws InterruptedException {
		try {
			client.selectsubChannelFromDP("whatsapp");
			log.info("select sub channel fom dp");
		} catch (Exception e) {
			log.error("Not able to select sub channel fom dp");
		}
	}

	@Test(priority = 364)
	public void displayStatusOfaddSkillAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfaddSkillAndProfeciancy(), true);
	}

	@Test(priority = 365)
	public void enableStatusOfaddSkillAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfaddSkillAndProfeciancy(), true);
	}

	@Test(priority = 366)
	public void clickOnaddSkillAndProfeciancyTest() throws InterruptedException {
		try {
			client.clickOnaddSkillAndProfeciancy();
			log.info("tab on add skill set and proficiency");
		} catch (InterruptedException e) {
			log.error("Not able to tab on add skill set and proficiency");
		}
	}

	@Test(priority = 367)
	public void displayStatusOfaddSkillTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfaddSkill(), true);
	}

	@Test(priority = 368)
	public void enableStatusOfaddSkillTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfaddSkill(), true);
	}

	@Test(priority = 369)
	public void clickOnaddSkillTest() throws InterruptedException {
		try {
			client.clickOnaddSkill();
			log.info("open skill set dp");
		} catch (InterruptedException e) {
			log.error("Not able to open skill set dp");
		}
	}

	@Test(priority = 370)
	public void selectDPValueFromAddSkillTest() throws InterruptedException {
		try {
			client.selectDPValueFromAddSkill("HR");
			log.info("select skill from dp");
		} catch (Exception e) {
			log.error("Not able to select skill from dp");
		}
	}

	@Test(priority = 371)
	public void displayStatusOfaddSkillProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfaddSkillProfeciancy(), true);
	}

	@Test(priority = 372)
	public void enableStatusOfaddSkillProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfaddSkillProfeciancy(), true);
	}

	@Test(priority = 373)
	public void clickOnaddSkillProfeciancyTest() throws InterruptedException {
		try {
			client.clickOnaddSkillProfeciancy();
			log.info("open add skill proficiancy");
		} catch (InterruptedException e) {
			log.error("Not able to open add skill proficiancy");
		}
	}

	@Test(priority = 374)
	public void selectDPValueFromAddSkillProfeciancyTest() throws InterruptedException {
		try {
			client.selectDPValueFromAddSkillProfeciancy();
			log.info("select skill proficiancy from dp");
		} catch (Exception e) {
			log.error("Not able to select skill proficiancy from dp");
		}
	}

	@Test(priority = 375)
	public void displayStatusOfremoveSkillAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfremoveSkillAndProfeciancy(), true);
	}

	@Test(priority = 376)
	public void enableStatusOfremoveSkillAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfremoveSkillAndProfeciancy(), true);
	}

//	@Test(priority = 377)
//	public void clickOnremoveSkillAndProfeciancyTest() throws InterruptedException {
//		client.clickOnremoveSkillAndProfeciancy();
//	}	
	@Test(priority = 378)
	public void displayStatusOfaddLanguageAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfaddLanguageAndProfeciancy(), true);
	}

	@Test(priority = 379)
	public void enableStatusOfaddLanguageAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfaddLanguageAndProfeciancy(), true);
	}

	@Test(priority = 380)
	public void clickOnaddLanguageAndProfeciancyTest() throws InterruptedException {
		try {
			client.clickOnaddLanguageAndProfeciancy();
			log.info("click On add Language And Profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to click On add Language And Profeciancy");
		}
	}

	@Test(priority = 381)
	public void displayStatusOfaddLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfaddLanguage(), true);
	}

	@Test(priority = 382)
	public void enableStatusOfaddLanguageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfaddLanguage(), true);
	}

	@Test(priority = 383)
	public void clickOnaddLanguageTest() throws InterruptedException {
		try {
			client.clickOnaddLanguage();
			log.info("click On add Language");
		} catch (InterruptedException e) {
			log.error("Not able to click On add Language");
		}
	}

	@Test(priority = 384)
	public void selectDPValueFromAddLanguageTest() throws InterruptedException {
		try {
			client.selectDPValueFromAddLanguage("Hindi");
			log.info("select DP Value From Add Language");
		} catch (Exception e) {
			log.error("Not able to select DP Value From Add Language");
		}
	}

	@Test(priority = 385)
	public void displayStatusOfaddLanguageProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfaddLanguageProfeciancy(), true);
	}

	@Test(priority = 386)
	public void enableStatusOfaddLanguageProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfaddLanguageProfeciancy(), true);
	}

	@Test(priority = 387)
	public void clickOnaddLanguageProfeciancyTest() throws InterruptedException {
		try {
			client.clickOnaddLanguageProfeciancy();
			log.info("click On add Language Profeciancy");
		} catch (InterruptedException e) {
			log.error("Not able to click On add Language Profeciancy");
		}
	}

	@Test(priority = 388)
	public void selectDPValueFromAddLanguageProfeciancyTest() throws InterruptedException {
		try {
			client.selectDPValueFromAddLanguageProfeciancy();
			log.info("select DP Value From Add Language Profeciancy");
		} catch (Exception e) {
			log.error("Not able to select DP Value From Add Language Profeciancy");
		}
	}

	@Test(priority = 389)
	public void displayStatusOfremoveLanguageAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfremoveLanguageAndProfeciancy(), true);
	}

	@Test(priority = 390)
	public void enableStatusOfremoveLanguageAndProfeciancyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfremoveLanguageAndProfeciancy(), true);
	}

//	@Test(priority = 391)
//	public void clickOnremoveLanguageAndProfeciancyTest() throws InterruptedException {
//		client.clickOnremoveLanguageAndProfeciancy();
//	}	
	@Test(priority = 392)
	public void displayStatusOfcreateUserTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcreateUser(), true);
	}

	@Test(priority = 393)
	public void enableStatusOfcreateUserTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcreateUser(), true);
	}

//	@Test(priority = 394)
//	public void clickOncreateUserTest() throws InterruptedException {
//		client.clickOncreateUser();
//	}	
	@Test(priority = 395)
	public void displayStatusOfclearTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclear(), true);
	}

	@Test(priority = 396)
	public void enableStatusOfclearTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclear(), true);
	}

//	@Test(priority = 397)
//	public void clickOnclearTest() throws InterruptedException {
//		client.clickOnclear();
//	}	
	@Test(priority = 397)
	public void clickOncreateUserTest() throws InterruptedException {
		try {
			client.clickOncreateUser();
			log.info("click on craete user");
		} catch (InterruptedException e) {
			log.error("Not able to click on craete user");
		}
	}

	@Test(priority = 398)
	public void displayStatusOfusersTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfusers(), true);
	}

	@Test(priority = 399)
	public void enableStatusOfusersTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfusers(), true);
	}

	@Test(priority = 400)
	public void clickOnusersTest() throws InterruptedException {
		try {
			client.clickOnusers();
			log.info("click on user");
		} catch (InterruptedException e) {
			log.error("Not able to click on user");
		}
	}

	@Test(priority = 401)
	public void displayStatusOfsearchUserTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsearchUser(), true);
	}

	@Test(priority = 402)
	public void enableStatusOfsearchUserTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsearchUser(), true);
	}

	@Test(priority = 403)
	public void clickOnsearchUserTest() throws InterruptedException {
		try {
			client.clickOnsearchUser();
			log.info("click on search user");
		} catch (InterruptedException e) {
			log.error("Not able to click on search user");
		}
	}

	@Test(priority = 404)
	public void enterDataInsearchUserTest() throws InterruptedException {
		try {
			client.enterDataInsearchUser("vanila");
			log.info("enter value for search");
		} catch (Exception e) {
			log.error("Nt able to enter value for search");
		}
	}

	@Test(priority = 405)
	public void displayStatusOfeditUsersTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfeditUsers(), true);
	}

	@Test(priority = 406)
	public void enableStatusOfeditUsersTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfeditUsers(), true);
	}

	@Test(priority = 407)
	public void clickOneditUsersTest() throws InterruptedException {
		try {
			client.clickOneditUsers();
			log.info("click on edit");
		} catch (InterruptedException e) {
			log.error("Not able to click on edit");
		}
	}

	@Test(priority = 408)
	public void displayStatusOfuserFirstNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserFirstName(), true);
	}

	@Test(priority = 409)
	public void enableStatusOfuserFirstNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserFirstName(), true);
	}

	@Test(priority = 410)
	public void enterDataInuserFirstNameTest() throws InterruptedException {
		try {
			client.enterDataInuserFirstName("vanila");
			log.info("enter first name");
		} catch (InterruptedException e) {
			log.error("Not able to enter first name");
		}
	}

	@Test(priority = 411)
	public void displayStatusOfuserLastNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserLastName(), true);
	}

	@Test(priority = 412)
	public void enableStatusOfuserLastNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserLastName(), true);
	}

	@Test(priority = 413)
	public void enterDataInuserLastNameTest() throws InterruptedException {
		try {
			client.enterDataInuserLastName("barath");
			log.info("enter last name");
		} catch (InterruptedException e) {
			log.error("Not able to enter last name");
		}
	}

	@Test(priority = 414)
	public void displayStatusOfuserEmailTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserEmail(), true);
	}

	@Test(priority = 415)
	public void enableStatusOfuserEmailTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserEmail(), true);
	}

	@Test(priority = 416)
	public void enterDataInuserEmailTest() throws InterruptedException {
		try {
			client.enterDataInuserEmail("vanila@gmail.com");
			log.info("enter email");
		} catch (InterruptedException e) {
			log.error("Not able to enter email");
		}
	}

	@Test(priority = 417)
	public void displayStatusOfuserContactNumberTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserContactNumber(), true);
	}

	@Test(priority = 418)
	public void enableStatusOfuserContactNumberTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserContactNumber(), true);
	}

	@Test(priority = 419)
	public void enterDataInuserContactNumberTest() throws InterruptedException {
		try {
			client.enterDataInuserContactNumber("9856741230");
			log.info("enter mobile number");
		} catch (InterruptedException e) {
			log.error("Not able to enter mobile number");
		}
	}

	@Test(priority = 420)
	public void displayStatusOfuserRoleTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserRole(), true);
	}

	@Test(priority = 421)
	public void enableStatusOfuserRoleTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserRole(), true);
	}

	@Test(priority = 422)
	public void enterDataInuserRoleTest() throws InterruptedException {
		try {
			client.enterDataInuserRole("Manager");
			log.info("enter user role");
		} catch (InterruptedException e) {
			log.error("Not able to enter user role");
		}
	}

	@Test(priority = 423)
	public void displayStatusOfuserGroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserGroup(), true);
	}

	@Test(priority = 424)
	public void enableStatusOfuserGroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserGroup(), true);
	}

	@Test(priority = 425)
	public void enterDataInuserGroupTest() throws InterruptedException {
		try {
			client.enterDataInuserGroup("Facebook");
			log.info("enter user group");
		} catch (InterruptedException e) {
			log.error("Not able to enter user group");
		}
	}

	@Test(priority = 426)
	public void displayStatusOfcloseUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcloseUserWin(), true);
	}

	@Test(priority = 427)
	public void enableStatusOfcloseUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcloseUserWin(), true);
	}

//	@Test(priority = 428)
//	public void clickOncloseUserWinTest() throws InterruptedException {
//		client.clickOncloseUserWin();
//	}	
	@Test(priority = 429)
	public void displayStatusOfuserUpdateUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserUpdateUserWin(), true);
	}

	@Test(priority = 430)
	public void enableStatusOfuserUpdateUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserUpdateUserWin(), true);
	}

//	@Test(priority = 431)
//	public void clickOnuserUpdateUserWinTest() throws InterruptedException {
//		client.clickOnuserUpdateUserWin();
//	}
	@Test(priority = 432)
	public void displayStatusOfuserCancelUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserCancelUserWin(), true);
	}

	@Test(priority = 433)
	public void enableStatusOfuserCancelUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserCancelUserWin(), true);
	}

	@Test(priority = 434)
	public void clickOnuserCancelUserWinTest() throws InterruptedException {
		try {
			client.clickOnuserCancelUserWin();
			log.info("tab on cancel");
		} catch (InterruptedException e) {
			log.error("Not able to tab on cancel");
		}
	}

	@Test(priority = 435)
	public void displayStatusOfUserStatusUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfUserStatusUserWin(), true);
	}

	@Test(priority = 436)
	public void enableStatusOfUserStatusUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfUserStatusUserWin(), true);
	}

	@Test(priority = 437)
	public void clickOnUserStatusTest() throws InterruptedException {
		try {
			client.clickOnUserStatus();
			log.info("check active / deactive status");
		} catch (InterruptedException e) {
			log.error("Not able to check active / deactive status");
		}
	}

	@Test(priority = 438)
	public void displayStatusOfView_viewUserUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfView_viewUserUserWin(), true);
	}

	@Test(priority = 439)
	public void enableStatusOfView_viewUserUserWinTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfView_viewUserUserWin(), true);
	}

	@Test(priority = 440)
	public void clickOnviewUserTest() throws InterruptedException {
		try {
			client.clickOnviewUser();
			log.info("click on view ");
		} catch (Exception e) {
			log.error("Not able to click on view ");
		}
	}

	@Test(priority = 441)
	public void displayStatusOfView_userFirstNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfView_userFirstName(), true);
	}

	@Test(priority = 442)
	public void aenableStatusOfView_userFirstNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfView_userFirstName(), true);
	}

//	@Test(priority = 442)
//	public void benterDataInuserFirstNameTextTest() throws InterruptedException {
//		client.enterDataInuserFirstNameText("Amol");
//	}

	@Test(priority = 443)
	public void displayStatusOfView_userLastNameTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfView_userLastName(), true);
	}

	@Test(priority = 444)
	public void enableStatusOfView_userLastNameTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfView_userLastName(), true);
	}

	@Test(priority = 445)
	public void displayStatusOfView_userEmailTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfView_userEmail(), true);
	}

	@Test(priority = 446)
	public void enableStatusOfView_userEmailTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfView_userEmail(), true);
	}

	@Test(priority = 447)
	public void displayStatusOfView_userContactNumberTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfView_userContactNumber(), true);
	}

	@Test(priority = 448)
	public void enableStatusOfView_userContactNumberTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfView_userContactNumber(), true);
	}

	@Test(priority = 449)
	public void displayStatusOfView_userRoleTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfView_userRole(), true);
	}

	@Test(priority = 450)
	public void enableStatusOfView_userRoleTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfView_userRole(), true);
	}

	@Test(priority = 451)
	public void displayStatusOfView_userGroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfView_userGroup(), true);
	}

	@Test(priority = 452)
	public void enableStatusOfView_userGroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfView_userGroup(), true);
	}

	@Test(priority = 453)
	public void displayStatusOfView_viewCancelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfView_viewCancel(), true);
	}

	@Test(priority = 454)
	public void enableStatusOfView_viewCancelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfView_viewCancel(), true);
	}

	@Test(priority = 455)
	public void clickOnviewCancelTest() throws InterruptedException {
		try {
			client.clickOnviewCancel();
			log.info("click on cancel");
		} catch (Exception e) {
			log.error("Not able to click on cancel");
		}
	}

	@Test(priority = 456)
	public void displayStatusOfuserMappingTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfuserMapping(), true);
	}

	@Test(priority = 457)
	public void enableStatusOfuserMappingTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfuserMapping(), true);
	}

	@Test(priority = 458)
	public void clickOnuserMappingTest() throws InterruptedException {
		try {
			client.clickOnuserMapping();
			log.info("click on user mapping");
		} catch (Exception e) {
			log.error("Not able to click on user mapping");
		}
	}

	@Test(priority = 459)
	public void displayStatusOfroleMappingTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfroleMapping(), true);
	}

	@Test(priority = 460)
	public void enableStatusOfroleMappingTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfroleMapping(), true);
	}

	@Test(priority = 461)
	public void clickOnroleMappingTest() throws InterruptedException {
		try {
			client.clickOnroleMapping();
			log.info("tab on role mapping");
		} catch (Exception e) {
			log.error("Not able to tab on role mapping");
		}
	}

	@Test(priority = 462)
	public void displayStatusOfselectRoleTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfselectRole(), true);
	}

	@Test(priority = 463)
	public void enableStatusOfselectRoleTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfselectRole(), true);
	}

	@Test(priority = 464)
	public void clickOnselectRoleTest() throws InterruptedException {
		try {
			client.clickOnselectRole("Agent");
			log.info("select the role from dp");
		} catch (InterruptedException e) {
			log.error("Not able to select the role from dp");
		}
	}

	@Test(priority = 465)
	public void displayStatusOfviewSelectRoleTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfviewSelectRole(), true);
	}

	@Test(priority = 466)
	public void enableStatusOfviewSelectRoleTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfviewSelectRole(), true);
	}

	@Test(priority = 467)
	public void clickOnSelectRoleTest() throws InterruptedException {
		try {
			client.clickOnSelectRole();
			log.info("tab on view");
		} catch (InterruptedException e) {
			log.error("Not able to tab on view");
		}
	}

	@Test(priority = 468)
	public void displayStatusOfaddUsersTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfaddUsers(), true);
	}

	@Test(priority = 469)
	public void enableStatusOfaddUsersTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfaddUsers(), true);
	}

	@Test(priority = 470)
	public void clickOnaddUsersTest() throws InterruptedException {
		try {
			client.clickOnaddUsers();
			log.info("tab on add user");
		} catch (InterruptedException e) {
			log.error("Not able to tab on add user");
		}
	}

	@Test(priority = 471)
	public void displayStatusOfselectUsersTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfselectUsers(), true);
	}

	@Test(priority = 472)
	public void enableStatusOfselectUsersTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfselectUsers(), true);
	}

	@Test(priority = 473)
	public void clickAndselectUsersTest() throws InterruptedException {
		try {
			client.clickAndselectUsers();
			log.info("tab and select user from dp");
		} catch (InterruptedException e) {
			log.error("Not able to tab and select user from dp");
		}
	}

	@Test(priority = 474)
	public void displayStatusOfsaveUserTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsaveUser(), true);
	}

	@Test(priority = 475)
	public void enableStatusOfsaveUserTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsaveUser(), true);
	}

	@Test(priority = 476)
	public void clickOnsaveUserTest() throws InterruptedException {
		try {
			client.clickOnsaveUser();
			log.info("tab on save");
		} catch (InterruptedException e) {
			log.error("Not able to tab on save");
		}
	}

	@Test(priority = 477)
	public void displayStatusOfnextPageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfnextPage(), true);
	}

	@Test(priority = 478)
	public void enableStatusOfnextPageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfnextPage(), true);
	}

//	@Test(priority = 479)
	public void clickOnnextPageTest() throws InterruptedException {
		client.clickOnnextPage();
	}

	@Test(priority = 480)
	public void displayStatusOfminimizeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfminimize(), true);
	}

	@Test(priority = 481)
	public void enableStatusOfminimizeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfminimize(), true);
	}

	@Test(priority = 482)
	public void clickOnminimizeTest() throws InterruptedException {
		try {
			client.clickOnminimize();
			log.info("tab on minus");
		} catch (InterruptedException e) {
			log.error("Not able to tab on minus");
		}
	}

	@Test(priority = 483)
	public void displayStatusOfremoveUserNoTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfremoveUserNo(), true);
	}

	@Test(priority = 484)
	public void enableStatusOfremoveUserNoTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfremoveUserNo(), true);
	}

//	@Test(priority = 485)
//	public void clickOnremoveUserNoTest() throws InterruptedException {
//		client.clickOnremoveUserNo();
//	}
	@Test(priority = 486)
	public void displayStatusOfremoveUserYesTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfremoveUserYes(), true);
	}

	@Test(priority = 487)
	public void enableStatusOfremoveUserYesTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfremoveUserYes(), true);
	}

//	@Test(priority = 488)
	public void clickOnremoveUserYesTest() throws InterruptedException {
		try {
			client.clickOnremoveUserYes();
			log.info("click on yes ");
		} catch (InterruptedException e) {
			log.error("Not able to click on yes ");
		}
	}

	@Test(priority = 488)
	public void clickOnremoveUserNOTest() throws InterruptedException {
		try {
			client.clickOnremoveUserNo();
			log.info("click on NO");
		} catch (InterruptedException e) {
			log.error("Not able to click on NO");
		}
	}

	@Test(priority = 489)
	public void displayStatusOfgroupMappingTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfgroupMapping(), true);
	}

	@Test(priority = 490)
	public void enableStatusOfgroupMappingTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfgroupMapping(), true);
	}

	@Test(priority = 491)
	public void clickOngroupMappingTest() throws InterruptedException {
		try {
			client.clickOngroupMapping();
			log.info("tab on role mapping");
		} catch (Exception e) {
			log.error("Not able to tab on role mapping");
		}
	}

	@Test(priority = 492)
	public void displayStatusOfselectGroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfselectGroup(), true);
	}

	@Test(priority = 493)
	public void enableStatusOfselectGroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfselectGroup(), true);
	}

	@Test(priority = 494)
	public void clickOnselectGroupTest() throws InterruptedException {
		try {
			client.clickOnselectGroup("Facebook");
			log.info("select group from dp");
		} catch (InterruptedException e) {
			log.error("Not able to select group from dp");
		}
	}

	@Test(priority = 495)
	public void displayStatusOfviewSelectGroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfviewSelectGroup(), true);
	}

	@Test(priority = 496)
	public void enableStatusOfviewSelectGroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfviewSelectGroup(), true);
	}

	@Test(priority = 497)
	public void clickOnviewSelectGroupTest() throws InterruptedException {
		try {
			client.clickOnviewSelectGroup();
			log.info("tab on view");
		} catch (InterruptedException e) {
			log.error("Not able to tab on view");
		}
	}

	@Test(priority = 498)
	public void displayStatusOfaddUsersGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfaddUsersGroupMap(), true);
	}

	@Test(priority = 499)
	public void enableStatusOfaddUsersGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfaddUsersGroupMap(), true);
	}

	@Test(priority = 500)
	public void clickOnaddUsersGroupMapTest() throws InterruptedException {
		try {
			client.clickOnaddUsersGroupMap();
			log.info("tab on add user");
		} catch (InterruptedException e) {
			log.error("Not able to tab on add user");
		}
	}

	@Test(priority = 501)
	public void displayStatusOfselectUsersGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfselectUsersGroupMap(), true);
	}

	@Test(priority = 502)
	public void enableStatusOfselectUsersGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfselectUsersGroupMap(), true);
	}

	@Test(priority = 503)
	public void clickAndselectUsersGroupMapTest() throws InterruptedException {
		try {
			client.clickAndselectUsersGroupMap();
			log.info("select user from dp");
		} catch (InterruptedException e) {
			log.error("Not able to select user from dp");
		}
	}

	@Test(priority = 504)
	public void displayStatusOfsaveUserGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsaveUserGroupMap(), true);
	}

	@Test(priority = 505)
	public void enableStatusOfsaveUserGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsaveUserGroupMap(), true);
	}

	@Test(priority = 506)
	public void clickOnsaveUserGroupMapTest() throws InterruptedException {
		try {
			client.clickOnsaveUserGroupMap();
			log.info("tab on save");
		} catch (InterruptedException e) {
			log.error("Not able to tab on save");
		}
	}

	@Test(priority = 507)
	public void displayStatusOfnextPageGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfnextPageGroupMap(), true);
	}

	@Test(priority = 508)
	public void enableStatusOfnextPageGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfnextPageGroupMap(), true);
	}

//	@Test(priority = 509)
	public void clickOnnextPageGroupMapTest() throws InterruptedException {
		client.clickOnnextPageGroupMap();
	}

	@Test(priority = 510)
	public void displayStatusOfminimize1GroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfminimize1GroupMap(), true);
	}

	@Test(priority = 511)
	public void enableStatusOfminimize1GroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfminimize1GroupMap(), true);
	}

	@Test(priority = 512)
	public void clickOnminimize1GroupMapTest() throws InterruptedException {
		try {
			client.clickOnminimize1GroupMap();
			log.info("tab on minus button");
		} catch (InterruptedException e) {
			log.error("Not able to tab on minus button");
		}
	}

	@Test(priority = 513)
	public void displayStatusOfremoveUserNoGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfremoveUserNoGroupMap(), true);
	}

	@Test(priority = 514)
	public void enableStatusOfremoveUserNoGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfremoveUserNoGroupMap(), true);
	}

//	@Test(priority = 515)
//	public void clickOnremoveUserNoGroupMapTest() throws InterruptedException {
//		client.clickOnremoveUserNoGroupMap();
//	}
	@Test(priority = 516)
	public void displayStatusOfremoveUserYesGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfremoveUserYesGroupMap(), true);
	}

	@Test(priority = 517)
	public void enableStatusOfremoveUserYesGroupMapTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfremoveUserYesGroupMap(), true);
	}

	@Test(priority = 518)
	public void clickOnremoveUserYesGroupMapTest() throws InterruptedException {
		try {
			client.clickOnremoveUserYesGroupMap();
			log.info("tab on yes");
		} catch (InterruptedException e) {
			log.error("Not able to tab on yes");
		}
		Thread.sleep(5000);
		try {
			client.clickOnuserMapping();
			log.info("tab on user mapping");
		} catch (Exception e) {
			log.error("Not able to tab on user mapping");
		}
	}

	@Test(priority = 519)
	public void displayStatusOfccMappingTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfccMapping(), true);
	}

	@Test(priority = 520)
	public void enableStatusOfccMappingTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfccMapping(), true);
	}

	@Test(priority = 521)
	public void clickOnccMappingTest() throws InterruptedException {
		try {
			client.clickOnccMapping();
			log.info("tab on cc mapping");
		} catch (InterruptedException e) {
			log.error("Not able to tab on cc mapping");
		}
	}

	@Test(priority = 522)
	public void displayStatusOfchannelMappingTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannelMapping(), true);
	}

	@Test(priority = 523)
	public void enableStatusOfchannelMappingTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannelMapping(), true);
	}

	@Test(priority = 524)
	public void clickOnchannelMappingTest() throws InterruptedException {
		try {
			client.clickOnchannelMapping();
			log.info("Tab on Channel Mapping");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Channel Mapping");
		}
	}

	@Test(priority = 525)
	public void displayStatusOfCCselectChannelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCselectChannel(), true);
	}

	@Test(priority = 526)
	public void enableStatusOfCCselectChannelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCselectChannel(), true);
	}

	@Test(priority = 527)
	public void clickOnCCselectChannelandSelectDPvalueTest() throws InterruptedException {
		try {
			client.clickOnCCselectChannelandSelectDPvalue("Chat");
			log.info("Select Channel From DP");
		} catch (InterruptedException e) {
			log.error("Not able to Select Channel From DP");
		}
	}

	@Test(priority = 528)
	public void displayStatusOfCCselectSubChannelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCselectSubChannel(), true);
	}

	@Test(priority = 529)
	public void enableStatusOfCCselectSubChannelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCselectSubChannel(), true);
	}

	@Test(priority = 530)
	public void clickOnCCselectSubChannelandSelectDPvalueTest() throws InterruptedException {
		try {
			client.clickOnCCselectSubChannelandSelectDPvalue("whatsapp");
			log.info("Select Sub Channel From DP");
		} catch (InterruptedException e) {
			log.error("Not able to Select Sub Channel From DP");
		}
	}

	@Test(priority = 531)
	public void displayStatusOfCCViewButtonTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCViewButton(), true);
	}

	@Test(priority = 532)
	public void enableStatusOfCCViewButtonTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCViewButton(), true);
	}

	@Test(priority = 533)
	public void clickOnCCViewButtonTest() throws InterruptedException {
		try {
			client.clickOnCCViewButton();
			log.info("Tab On View Button");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On View Button");
		}
	}

	@Test(priority = 534)
	public void displayStatusOfCCaddUserTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCaddUser(), true);
	}

	@Test(priority = 535)
	public void enableStatusOfCCaddUserTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCaddUser(), true);
	}

	@Test(priority = 536)
	public void clickOnCCaddUserTest() throws InterruptedException {
		try {
			client.clickOnCCaddUser();
			log.info("Tab On Add user");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Add user");
		}
	}

	@Test(priority = 537)
	public void displayStatusOfCCselectUserTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCselectUser(), true);
	}

	@Test(priority = 538)
	public void enableStatusOfCCselectUserTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCselectUser(), true);
	}

	@Test(priority = 539)
	public void clickOnCCselectUserandSelectDPvalueTest() throws InterruptedException {
		try {
			client.clickOnCCselectUserandSelectDPvalue();
			log.info("Select User From DP");
		} catch (InterruptedException e) {
			log.error("Not able to Select User From DP");
		}
	}

	@Test(priority = 540)
	public void displayStatusOfCCsaveUserTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCsaveUser(), true);
	}

	@Test(priority = 541)
	public void enableStatusOfCCsaveUserTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCsaveUser(), true);
	}

	@Test(priority = 542)
	public void clickOnCCsaveUserTest() throws InterruptedException {
		try {
			client.clickOnCCsaveUser();
			log.info("Tab On SAVE");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On SAVE");
		}
	}

	@Test(priority = 543)
	public void displayStatusOfCCnextPageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCnextPage(), true);
	}

	@Test(priority = 544)
	public void enableStatusOfCCnextPageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCnextPage(), true);
	}

//	@Test(priority = 545)
	public void clickOnCCnextPageTest() throws InterruptedException {
		client.clickOnCCnextPage();
	}

	@Test(priority = 546)
	public void displayStatusOfCCremoveUserTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUser(), true);
	}

	@Test(priority = 547)
	public void enableStatusOfCCremoveUserTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUser(), true);
	}

	@Test(priority = 548)
	public void clickOnCCremoveUserTest() throws InterruptedException {
		try {
			client.clickOnCCremoveUser();
			log.info("Tab On Remove USER");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Remove USER");
		}
	}

	@Test(priority = 549)
	public void displayStatusOfCCremoveUserNOTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUserNO(), true);
	}

	@Test(priority = 550)
	public void enableStatusOfCCremoveUserNOTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUserNO(), true);
	}

//	@Test(priority = 551)
//	public void clickOnCCremoveUserNOTest() throws InterruptedException {
//		client.clickOnCCremoveUserNO();
//	}
	@Test(priority = 552)
	public void displayStatusOfCCremoveUserYESTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUserYES(), true);
	}

	@Test(priority = 553)
	public void enableStatusOfCCremoveUserYESTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUserYES(), true);
	}

//	@Test(priority = 554)
	public void clickOnCCremoveUserYESTest() throws InterruptedException {
		try {
			client.clickOnCCremoveUserYES();
			log.info("Tab On Yes");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Yes");
		}
	}

	@Test(priority = 554)
	public void clickOnCCremoveUserNOTest() throws InterruptedException {
		try {
			client.clickOnCCremoveUserNO();
			log.info("Tab On No");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On No");
		}
	}

	@Test(priority = 555)
	public void displayStatusOfskillsetMappingTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskillsetMapping(), true);
	}

	@Test(priority = 556)
	public void enableStatusOfskillsetMappingTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskillsetMapping(), true);
	}

	@Test(priority = 557)
	public void clickOnskillsetMappingTest() throws InterruptedException {
		try {
			client.clickOnskillsetMapping();
			log.info("Tab On SKill set Mapping");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On SKill set Mapping");
		}
	}

	@Test(priority = 558)
	public void displayStatusOfCCskillSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCskillSM(), true);
	}

	@Test(priority = 559)
	public void enableStatusOfCCskillSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCskillSM(), true);
	}

	@Test(priority = 560)
	public void clickOnCCskillandSelectDPvalueSMTest() throws InterruptedException {
		try {
			client.clickOnCCskillandSelectDPvalueSM("HR");
			log.info("Select skill set from dp");
		} catch (InterruptedException e) {
			log.error("Not able to Select skill set from dp");
		}
	}

	@Test(priority = 561)
	public void displayStatusOfCCskillProficiencySMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCskillProficiencySM(), true);
	}

	@Test(priority = 562)
	public void enableStatusOfCCskillProficiencySMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCskillProficiencySM(), true);
	}

	@Test(priority = 563)
	public void clickOnCCskillProficiencyandSelectDPvalueSMTest() throws InterruptedException {
		try {
			client.clickOnCCskillProficiencyandSelectDPvalueSM("Proficient");
			log.info("select skill profeciancy from dp");
		} catch (InterruptedException e) {
			log.error("Not able to select skill profeciancy from dp");
		}
	}

	@Test(priority = 564)
	public void displayStatusOfCCViewButtonSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCViewButtonSM(), true);
	}

	@Test(priority = 565)
	public void enableStatusOfCCViewButtonSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCViewButtonSM(), true);
	}

	@Test(priority = 566)
	public void clickOnCCViewButtonSMTest() throws InterruptedException {
		try {
			client.clickOnCCViewButtonSM();
			log.info("Tab On View");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On View");
		}
	}

	@Test(priority = 567)
	public void displayStatusOfCCaddUserSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCaddUserSM(), true);
	}

	@Test(priority = 568)
	public void enableStatusOfCCaddUserSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCaddUserSM(), true);
	}

	@Test(priority = 569)
	public void clickOnCCaddUserSMTest() throws InterruptedException {
		try {
			client.clickOnCCaddUserSM();
			log.info("Tab on add user");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on add user");
		}
	}

	@Test(priority = 570)
	public void displayStatusOfCCselectUserSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCselectUserSM(), true);
	}

	@Test(priority = 571)
	public void enableStatusOfCCselectUserSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCselectUserSM(), true);
	}

	@Test(priority = 572)
	public void clickOnCCselectUserandSelectDPvalueSMTest() throws InterruptedException {
		try {
			client.clickOnCCselectUserandSelectDPvalueSM();
			log.info("Select User From DP");
		} catch (InterruptedException e) {
			log.error("Not able to Select User From DP");
		}
	}

	@Test(priority = 573)
	public void displayStatusOfCCsaveUserSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCsaveUserSM(), true);
	}

	@Test(priority = 574)
	public void enableStatusOfCCsaveUserSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCsaveUserSM(), true);
	}

	@Test(priority = 575)
	public void clickOnCCsaveUserSMTest() throws InterruptedException {
		try {
			client.clickOnCCsaveUserSM();
			log.info("Tab on save");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on save");
		}
	}

	@Test(priority = 576)
	public void displayStatusOfCCnextPageSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCnextPageSM(), true);
	}

	@Test(priority = 577)
	public void enableStatusOfCCnextPageSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCnextPageSM(), true);
	}

//	@Test(priority = 578)
	public void clickOnCCnextPageSMTest() throws InterruptedException {
		client.clickOnCCnextPageSM();
	}

	@Test(priority = 579)
	public void displayStatusOfCCremoveUserSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUserSM(), true);
	}

	@Test(priority = 580)
	public void enableStatusOfCCremoveUserSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUserSM(), true);
	}

	@Test(priority = 581)
	public void clickOnCCremoveUserSMTest() throws InterruptedException {
		try {
			client.clickOnCCremoveUserSM();
			log.info("Tab on remove user");
		} catch (InterruptedException e) {
			log.info("Not able to Tab on remove user");
		}
	}

	@Test(priority = 582)
	public void displayStatusOfCCremoveUserNOSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUserNOSM(), true);
	}

	@Test(priority = 583)
	public void enableStatusOfCCremoveUserNOSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUserNOSM(), true);
	}

//	@Test(priority = 584)
//	public void clickOnCCremoveUserNOSMTest() throws InterruptedException {
//		client.clickOnCCremoveUserNOSM();
//	}
	@Test(priority = 585)
	public void displayStatusOfCCremoveUserYESSMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUserYESSM(), true);
	}

	@Test(priority = 586)
	public void enableStatusOfCCremoveUserYESSMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUserYESSM(), true);
	}

//	@Test(priority = 587)
	public void clickOnCCremoveUserYESSMTest() throws InterruptedException {
		client.clickOnCCremoveUserYESSM();
	}

	@Test(priority = 587)
	public void clickOnCCremoveUserNOSMTest() throws InterruptedException {
		try {
			client.clickOnCCremoveUserNOSM();
			log.info("Tab on NO");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on NO");
		}
	}

	@Test(priority = 588)
	public void displayStatusOflanguageMappingTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflanguageMapping(), true);
	}

	@Test(priority = 589)
	public void enableStatusOflanguageMappingTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflanguageMapping(), true);
	}

	@Test(priority = 590)
	public void clickOnlanguageMappingTest() throws InterruptedException {
		try {
			client.clickOnlanguageMapping();
			log.info("Tab On Language Mapping");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Language Mapping");
		}
	}

	@Test(priority = 591)
	public void displayStatusOfCClanguageLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCClanguageLM(), true);
	}

	@Test(priority = 592)
	public void enableStatusOfCClanguageLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCClanguageLM(), true);
	}

	@Test(priority = 593)
	public void clickOnCClanguageandSelectDPvalueLMTest() throws InterruptedException {
		try {
			client.clickOnCClanguageandSelectDPvalueLM("Hindi");
			log.info("Select Language from DP");
		} catch (InterruptedException e) {
			log.error("Not able to Select Language from DP");
		}
	}

	@Test(priority = 594)
	public void displayStatusOfCClanguageProficiencyLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCClanguageProficiencyLM(), true);
	}

	@Test(priority = 595)
	public void enableStatusOfCClanguageProficiencyLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCClanguageProficiencyLM(), true);
	}

	@Test(priority = 596)
	public void clickOnCClanguageProficiencyandSelectDPvalueLMTest() throws InterruptedException {
		try {
			client.clickOnCClanguageProficiencyandSelectDPvalueLM("Proficient ");
			log.info("Select Language Proficiancy From DP");
		} catch (InterruptedException e) {
			log.error("Not able to Select Language Proficiancy From DP");
		}
	}

	@Test(priority = 597)
	public void displayStatusOfCCViewButtonLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCViewButtonLM(), true);
	}

	@Test(priority = 598)
	public void enableStatusOfCCViewButtonLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCViewButtonLM(), true);
	}

	@Test(priority = 599)
	public void clickOnCCViewButtonLMTest() throws InterruptedException {
		try {
			client.clickOnCCViewButtonLM();
			log.info("Tab on View");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on View");
		}
	}

	@Test(priority = 600)
	public void displayStatusOfCCaddUserLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCaddUserLM(), true);
	}

	@Test(priority = 601)
	public void enableStatusOfCCaddUserLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCaddUserLM(), true);
	}

	@Test(priority = 602)
	public void clickOnCCaddUserLMTest() throws InterruptedException {
		try {
			client.clickOnCCaddUserLM();
			log.info("Tab on Add user");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Add user");
		}
	}

	@Test(priority = 603)
	public void displayStatusOfCCselectUserLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCselectUserLM(), true);
	}

	@Test(priority = 604)
	public void enableStatusOfCCselectUserLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCselectUserLM(), true);
	}

	@Test(priority = 605)
	public void clickOnCCselectUserandSelectDPvalueLMTest() throws InterruptedException {
		try {
			client.clickOnCCselectUserandSelectDPvalueLM();
			log.info("Select User from DP");
		} catch (InterruptedException e) {
			log.error("Not able to Select User from DP");
		}
	}

	@Test(priority = 606)
	public void displayStatusOfCCsaveUserLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCsaveUserLM(), true);
	}

	@Test(priority = 607)
	public void enableStatusOfCCsaveUserLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCsaveUserLM(), true);
	}

	@Test(priority = 608)
	public void clickOnCCsaveUserLMTest() throws InterruptedException {
		try {
			client.clickOnCCsaveUserLM();
			log.info("Tab on save");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on save");
		}
	}

	@Test(priority = 609)
	public void displayStatusOfCCnextPageLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCnextPageLM(), true);
	}

	@Test(priority = 610)
	public void enableStatusOfCCnextPageLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCnextPageLM(), true);
	}

//	@Test(priority = 611)
	public void clickOnCCnextPageLMTest() throws InterruptedException {
		client.clickOnCCnextPageLM();
	}

	@Test(priority = 612)
	public void displayStatusOfCCremoveUserLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUserLM(), true);
	}

	@Test(priority = 613)
	public void enableStatusOfCCremoveUserLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUserLM(), true);
	}

	@Test(priority = 614)
	public void clickOnCCremoveUserLMTest() throws InterruptedException {
		try {
			client.clickOnCCremoveUserLM();
			log.info("Tab on Remove user");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Remove user");
		}
	}

	@Test(priority = 615)
	public void displayStatusOfCCremoveUserNOLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUserNOLM(), true);
	}

	@Test(priority = 616)
	public void enableStatusOfCCremoveUserNOLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUserNOLM(), true);
	}

//	@Test(priority = 617)
//	public void clickOnCCremoveUserNOLMTest() throws InterruptedException {
//		client.clickOnCCremoveUserNOLM();
//	}
	@Test(priority = 618)
	public void displayStatusOfCCremoveUserYESLMTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCCremoveUserYESLM(), true);
	}

	@Test(priority = 619)
	public void enableStatusOfCCremoveUserYESLMTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCCremoveUserYESLM(), true);
	}

	@Test(priority = 620)
	public void clickOnCCremoveUserYESLMTest() throws InterruptedException {
		try {
			client.clickOnCCremoveUserYESLM();
			log.info("TAb on Yes");
		} catch (InterruptedException e) {
			log.error("Not able to TAb on Yes");
		}
	}

	@Test(priority = 621)
	public void displayStatusOfchatConfigurationCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchatConfigurationCC(), true);
	}

	@Test(priority = 622)
	public void enableStatusOfchatConfigurationCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchatConfigurationCC(), true);
	}

	@Test(priority = 623)
	public void clickOnchatConfigurationCCTest() throws InterruptedException {
		try {
			client.clickOnchatConfigurationCC();
			log.info("Tab On Chat Configuration");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Chat Configuration");
		}
	}

	@Test(priority = 624)
	public void displayStatusOfautoRejectTimeCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfautoRejectTimeCC(), true);
	}

	@Test(priority = 625)
	public void enableStatusOfautoRejectTimeCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfautoRejectTimeCC(), true);
	}

	@Test(priority = 626)
	public void enterDataInautoRejectTimeCCTest() throws InterruptedException {
		try {
			client.enterDataInautoRejectTimeCC();
			log.info("Enter Reject Time");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Reject Time");
		}
	}

	@Test(priority = 627)
	public void displayStatusOfagentIdleChangeStatusTimeCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfagentIdleChangeStatusTimeCC(), true);
	}

	@Test(priority = 628)
	public void enableStatusOfagentIdleChangeStatusTimeCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfagentIdleChangeStatusTimeCC(), true);
	}

	@Test(priority = 629)
	public void enterDataInagentIdleChangeStatusTimeCCTest() throws InterruptedException {
		try {
			client.enterDataInagentIdleChangeStatusTimeCC();
			log.info("Enter Agent Idle Time");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Agent Idle Time");
		}
	}

	@Test(priority = 630)
	public void displayStatusOfmaxRequestInQueueCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfmaxRequestInQueueCC(), true);
	}

	@Test(priority = 631)
	public void enableStatusOfmaxRequestInQueueCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfmaxRequestInQueueCC(), true);
	}

	@Test(priority = 632)
	public void enterDataInmaxRequestInQueueCCTest() throws InterruptedException {
		try {
			client.enterDataInmaxRequestInQueueCC();
			log.info("Enter Maximum Request In Queue Count");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Maximum Request In Queue Count");
		}
	}

	@Test(priority = 633)
	public void displayStatusOfalertSupCheckBoxCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfalertSupCheckBoxCC(), true);
	}

	@Test(priority = 634)
	public void enableStatusOfalertSupCheckBoxCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfalertSupCheckBoxCC(), true);
	}

	@Test(priority = 635)
	public void clickOnalertSupCheckBoxCCTest() throws InterruptedException {
		try {
			client.clickOnalertSupCheckBoxCC();
			log.info("Tab On Alert Supervisor Tab ");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Alert Supervisor Tab ");
		}
	}

	@Test(priority = 636)
	public void displayStatusOfwelcomeMessageCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfwelcomeMessageCC(), true);
	}

	@Test(priority = 637)
	public void enableStatusOfwelcomeMessageCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfwelcomeMessageCC(), true);
	}

	@Test(priority = 638)
	public void enterDataInwelcomeMessageCCTest() throws InterruptedException {
		try {
			client.enterDataInwelcomeMessageCC();
			log.info("Enter Welcome Message");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Welcome Message");
		}
	}

	@Test(priority = 639)
	public void displayStatusOfqueueMessageCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfqueueMessageCC(), true);
	}

	@Test(priority = 640)
	public void enableStatusOfqueueMessageCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfqueueMessageCC(), true);
	}

	@Test(priority = 641)
	public void enterDataInqueueMessageCCTest() throws InterruptedException {
		try {
			client.enterDataInqueueMessageCC();
			log.info("Enter Queue Message");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Queue Message");
		}
	}

	@Test(priority = 642)
	public void displayStatusOfagentNAmsgCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfagentNAmsgCC(), true);
	}

	@Test(priority = 643)
	public void enableStatusOfagentNAmsgCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfagentNAmsgCC(), true);
	}

	@Test(priority = 644)
	public void enterDataInagentNAmsgCCTest() throws InterruptedException {
		try {
			client.enterDataInagentNAmsgCC();
			log.info("Enter message when agent Not Available");
		} catch (InterruptedException e) {
			log.error("Not able to Enter message when agent Not Available");
		}
	}

	@Test(priority = 645)
	public void displayStatusOfmaxQueueMessageCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfmaxQueueMessageCC(), true);
	}

	@Test(priority = 646)
	public void enableStatusOfmaxQueueMessageCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfmaxQueueMessageCC(), true);
	}

	@Test(priority = 647)
	public void enterDataInmaxQueueMessageCCTest() throws InterruptedException {
		try {
			client.enterDataInmaxQueueMessageCC();
			log.info("Enter Queue is already full message");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Queue is already full message");
		}
	}

	@Test(priority = 648)
	public void displayStatusOfclearCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfclearCC(), true);
	}

	@Test(priority = 649)
	public void enableStatusOfclearCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfclearCC(), true);
	}

//	@Test(priority = 650)
//	public void clickOnclearCCTest() throws InterruptedException {
//		client.clickOnclearCC();
//	}
	@Test(priority = 651)
	public void displayStatusOfsaveCCTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfsaveCC(), true);
	}

	@Test(priority = 652)
	public void enableStatusOfsaveCCTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfsaveCC(), true);
	}

	@Test(priority = 653)
	public void clickOnsaveCCTest() throws InterruptedException {
		try {
			client.clickOnsaveCC();
			log.info("Tab on save");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on save");
		}
	}

	@Test(priority = 654)
	public void displayStatusOfroutingConfigurationTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfroutingConfiguration(), true);
	}

	@Test(priority = 655)
	public void enableStatusOfroutingConfigurationTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfroutingConfiguration(), true);
	}

	@Test(priority = 656)
	public void clickOnroutingConfigurationTest() throws InterruptedException {
		try {
			client.clickOnroutingConfiguration();
			log.info("Tab on Routing Configuration");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Routing Configuration");
		}
	}

	@Test(priority = 657)
	public void displayStatusOfglobalConcurrencyTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfglobalConcurrency(), true);
	}

	@Test(priority = 658)
	public void enableStatusOfglobalConcurrencyTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfglobalConcurrency(), true);
	}

	@Test(priority = 659)
	public void enterDataInglobalConcurrencyTest() throws InterruptedException {
		try {
			client.enterDataInglobalConcurrency();
			log.info("Enter Global Concurancy Count");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Global Concurancy Count");
		}
	}

	@Test(priority = 660)
	public void displayStatusOfchannelWiseConcurrencyRateTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannelWiseConcurrencyRate(), true);
	}

	@Test(priority = 661)
	public void enableStatusOfchannelWiseConcurrencyRateTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannelWiseConcurrencyRate(), true);
	}

	@Test(priority = 662)
	public void clickOnchannelWiseConcurrencyRateTest() throws InterruptedException {
		try {
			client.clickOnchannelWiseConcurrencyRate();
			log.info("Tab on Channel wise concurancy rate check box");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Channel wise concurancy rate check box");
		}
	}

	@Test(priority = 663)
	public void displayStatusOfvoiceTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfvoice(), true);
	}

	@Test(priority = 664)
	public void enableStatusOfvoiceTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfvoice(), true);
	}

	@Test(priority = 665)
	public void enterDataInvoiceTest() throws InterruptedException {
		try {
			client.enterDataInvoice();
			log.info("Enter Voice Count");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Voice Count");
		}
	}

	@Test(priority = 666)
	public void displayStatusOfchatTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchat(), true);
	}

	@Test(priority = 667)
	public void enableStatusOfchatTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchat(), true);
	}

	@Test(priority = 668)
	public void enterDataInchatTest() throws InterruptedException {
		try {
			client.enableStatusOfchat();
			log.info("Enter Chat Count");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Chat Count");
		}
	}

	@Test(priority = 669)
	public void displayStatusOfACWTimeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfACWTime(), true);
	}

	@Test(priority = 670)
	public void enableStatusOfACWTimeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfACWTime(), true);
	}

	@Test(priority = 671)
	public void enterDataInACWTimeTest() throws InterruptedException {
		try {
			client.enterDataInACWTime();
			log.info("Enter ACW Time");
		} catch (InterruptedException e) {
			log.error("Not able to Enter ACW Time");
		}
	}

	@Test(priority = 672)
	public void displayStatusOfroutingAlgorithmDPTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfroutingAlgorithmDP(), true);
	}

	@Test(priority = 673)
	public void enableStatusOfroutingAlgorithmDPTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfroutingAlgorithmDP(), true);
	}

	@Test(priority = 674)
	public void clickOnroutingAlgorithmDPandSelectVAlueTest() throws InterruptedException {
		try {
			client.clickOnroutingAlgorithmDPandSelectVAlue("Round Robin");
			log.info("select Round Robin From DP");
		} catch (InterruptedException e) {
			log.error("Not able to select Round Robin From DP");
		}
		Thread.sleep(2000);
		try {
			client.clickOnroutingAlgorithmDPandSelectVAlue("Precision Routing");
			log.info("Select Precision Routng From DP");
		} catch (InterruptedException e) {
			log.error("Not able to Select Precision Routng From DP");
		}
	}

	@Test(priority = 675)
	public void displayStatusOfroutingAlgorithmDP_EyeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfroutingAlgorithmDP_Eye(), true);
	}

	@Test(priority = 676)
	public void enableStatusOfroutingAlgorithmDP_EyeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfroutingAlgorithmDP_Eye(), true);
	}

	@Test(priority = 677)
	public void clickOnroutingAlgorithmDP_EyeTest() throws InterruptedException {
		try {
			client.clickOnroutingAlgorithmDP_Eye();
			log.info("Tab on Eye Icon");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Eye Icon");
		}
	}

	@Test(priority = 678)
	public void displayStatusOfskillWeightageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskillWeightage(), true);
	}

	@Test(priority = 679)
	public void enableStatusOfskillWeightageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskillWeightage(), true);
	}

	@Test(priority = 680)
	public void enterDataInskillWeightageTest() throws InterruptedException {
		try {
			client.enterDataInskillWeightage();
			log.info("Enter Skill Weightage");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Skill Weightage");
		}
	}

	@Test(priority = 681)
	public void displayStatusOflanguageWeightageTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOflanguageWeightage(), true);
	}

	@Test(priority = 682)
	public void enableStatusOflanguageWeightageTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOflanguageWeightage(), true);
	}

	@Test(priority = 683)
	public void enterDataInlanguageWeightageTest() throws InterruptedException {
		try {
			client.enterDataInlanguageWeightage();
			log.info("Enter Language Weightage");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Language Weightage");
		}
	}

	@Test(priority = 684)
	public void displayStatusOfCANCELTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCANCEL(), true);
	}

	@Test(priority = 685)
	public void enableStatusOfCANCELTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCANCEL(), true);
	}

//	@Test(priority = 686)
//	public void clickOnCANCELTest() throws InterruptedException {
//		client.clickOnCANCEL();
//	}
	@Test(priority = 687)
	public void displayStatusOfSAVETest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfSAVE(), true);
	}

	@Test(priority = 688)
	public void enableStatusOfSAVETest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfSAVE(), true);
	}

	@Test(priority = 689)
	public void clickOnSAVETest() throws InterruptedException {
		try {
			client.clickOnSAVE();
			log.info("Tab On Save");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Save");
		}
	}

	@Test(priority = 690)
	public void displayStatusOfcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfcomplaintType(), true);
	}

	@Test(priority = 691)
	public void enableStatusOfcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfcomplaintType(), true);
	}

	@Test(priority = 692)
	public void IsSelectedStatusOfcomplaintTypeBeforeSelectingRadioBtnTest() throws InterruptedException {
		Assert.assertEquals(client.IsSelectedStatusOfcomplaintTypeBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 693)
	public void clickOncomplaintTypeandSelectVAlueTest() throws InterruptedException {
		try {
			client.clickOncomplaintTypeandSelectVAlue();
			log.info("Tab On Complait Type Radio Button");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Complait Type Radio Button");
		}
	}

//	@Test(priority = 694)
//	public void IsSelectedStatusOfcomplaintTypeAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(client.IsSelectedStatusOfcomplaintTypeAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 695)
	public void displayStatusOfskillGroupTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfskillGroup(), true);
	}

	@Test(priority = 696)
	public void enableStatusOfskillGroupTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfskillGroup(), true);
	}

	@Test(priority = 697)
	public void IsSelectedStatusOfskillGroupBeforeSelectingRadioBtnTest() throws InterruptedException {
		Assert.assertEquals(client.IsSelectedStatusOfskillGroupBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 698)
	public void clickOnskillGroupandSelectVAlueTest() throws InterruptedException {
		try {
			client.clickOnskillGroupandSelectVAlue();
			log.info("Tab On Skill Group Radio btn");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Skill Group Radio btn");
		}
	}

//	@Test(priority = 699)
//	public void IsSelectedStatusOfskillGroupAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(client.IsSelectedStatusOfskillGroupAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 700)
	public void displayStatusOfChannelTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfChannel(), true);
	}

	@Test(priority = 701)
	public void enableStatusOfChannelTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfChannel(), true);
	}

	@Test(priority = 702)
	public void IsSelectedStatusOfChannelBeforeSelectingRadioBtnTest() throws InterruptedException {
		Assert.assertEquals(client.IsSelectedStatusOfChannelBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 703)
	public void clickOnChannelTest() throws InterruptedException {
		try {
			client.clickOnChannel();
			log.info("Tab On Channel Radio btn");
		} catch (InterruptedException e) {
			log.error("Not able to Tab On Channel Radio btn");
		}
	}

//	@Test(priority = 704)
//	public void IsSelectedStatusOfChannelAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(client.IsSelectedStatusOfChannelAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 705)
	public void displayStatusOfchannelBasedRoutingAllTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannelBasedRoutingAll(), true);
	}

	@Test(priority = 706)
	public void enableStatusOfchannelBasedRoutingAllTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannelBasedRoutingAll(), true);
	}

	@Test(priority = 707)
	public void IsSelectedStatusOfchannelBasedRoutingAllBeforeSelectingRadioBtnTest() throws InterruptedException {
		Assert.assertEquals(client.IsSelectedStatusOfchannelBasedRoutingAllBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 708)
	public void clickOnchannelBasedRoutingAllTest() throws InterruptedException {
		try {
			client.clickOnchannelBasedRoutingAll();
			log.info("Tab on channel base Routing For ALL");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on channel base Routing For ALL");
		}
	}

//	@Test(priority = 709)
//	public void IsSelectedStatusOfchannelBasedRoutingAllAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(client.IsSelectedStatusOfchannelBasedRoutingAllAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 710)
	public void displayStatusOfchannelBasedRoutingIndividualTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfchannelBasedRoutingIndividual(), true);
	}

	@Test(priority = 711)
	public void enableStatusOfchannelBasedRoutingIndividualTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfchannelBasedRoutingIndividual(), true);
	}

	@Test(priority = 712)
	public void IsSelectedStatusOfchannelBasedRoutingIndividualBeforeSelectingRadioBtnTest()
			throws InterruptedException {
		Assert.assertEquals(client.IsSelectedStatusOfchannelBasedRoutingIndividualBeforeSelectingRadioBtn(), false);
	}

	@Test(priority = 713)
	public void clickOnchannelBasedRoutingIndividualTest() throws InterruptedException {
		try {
			client.clickOnchannelBasedRoutingIndividual();
			log.info("Tab on Channel base Routing Indivisual");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Channel base Routing Indivisual");
		}
	}

//	@Test(priority = 714)
//	public void IsSelectedStatusOfchannelBasedRoutingIndividualAfterSelectingRadioBtnTest() throws InterruptedException {
//		Assert.assertEquals(client.IsSelectedStatusOfchannelBasedRoutingIndividualAfterSelectingRadioBtn(), true);
//	}
	@Test(priority = 715)
	public void displayStatusOfCLEARTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfCLEAR(), true);
	}

	@Test(priority = 716)
	public void enableStatusOfCLEARTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfCLEAR(), true);
	}

//	@Test(priority = 717)
//	public void clickOnCLEARTest() throws InterruptedException {
//		client.clickOnCLEAR();
//	}
	@Test(priority = 718)
	public void displayStatusOfSUBMITTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfSUBMIT(), true);
	}

	@Test(priority = 719)
	public void enableStatusOfSUBMITTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfSUBMIT(), true);
	}

	@Test(priority = 720)
	public void clickOnSUBMITTest() throws InterruptedException {
		try {
			client.clickOnSUBMIT();
			log.info("Tab on Submit");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Submit");
		}
	}

	@Test(priority = 721)
	public void displayStatusOfModule_MappingTest() throws InterruptedException {
		Assert.assertEquals(client.displayStatusOfModule_Mapping(), true);
	}

	@Test(priority = 722)
	public void enableStatusOfModule_MappingTest() throws InterruptedException {
		Assert.assertEquals(client.enableStatusOfModule_Mapping(), true);
	}

	@Test(priority = 723)
	public void clickOnModule_MappingTest() throws InterruptedException {
		try {
			client.clickOnModule_Mapping();
			log.info("Tab on Module Mapping");
		} catch (InterruptedException e) {
			log.error("Not able to Tab on Module Mapping");
		}
	}

//	@Test(priority = 724)
//	public void displayStatusOfModule_Mapping_selectRoleTest() throws InterruptedException {
//		Assert.assertEquals(client.displayStatusOfModule_Mapping_selectRole(), true);
//	}
//
//	@Test(priority = 725)
//	public void enableStatusOfModule_Mapping_selectRoleTest() throws InterruptedException {
//		Assert.assertEquals(client.enableStatusOfModule_Mapping_selectRole(), true);
//	}
//
//	@Test(priority = 726)
//	public void clickOnModule_Mapping_selectRoleandSelectValueTest() throws InterruptedException {
//		client.clickOnModule_Mapping_selectRoleandSelectValue("Supervisor");
//	}
//
//	@Test(priority = 727)
//	public void displayStatusOfselectRole_viewTest() throws InterruptedException {
//		Assert.assertEquals(client.displayStatusOfselectRole_view(), true);
//	}
//
//	@Test(priority = 728)
//	public void enableStatusOfselectRole_viewTest() throws InterruptedException {
//		Assert.assertEquals(client.enableStatusOfselectRole_view(), true);
//	}
//
//	@Test(priority = 729)
//	public void clickOnselectRole_viewandSelectValueTest() throws InterruptedException {
//		client.clickOnselectRole_viewandSelectValue();
//	}
//
//	@Test(priority = 730)
//	public void displayStatusOfcheckBox1Test() throws InterruptedException {
//		Assert.assertEquals(client.displayStatusOfcheckBox1(), true);
//	}
//
//	@Test(priority = 731)
//	public void enableStatusOfcheckBox1Test() throws InterruptedException {
//		Assert.assertEquals(client.enableStatusOfcheckBox1(), true);
//	}
//
//	@Test(priority = 732)
//	public void clickOncheckBox1andSelectValueTest() throws InterruptedException {
//		client.clickOncheckBox1andSelectValue();
//	}
//
//	@Test(priority = 733)
//	public void displayStatusOfChatCondWritecheckBoxTest() throws InterruptedException {
//		Assert.assertEquals(client.displayStatusOfChatCondWritecheckBox(), true);
//	}
//
//	@Test(priority = 734)
//	public void enableStatusOfChatCondWritecheckBoxTest() throws InterruptedException {
//		Assert.assertEquals(client.enableStatusOfChatCondWritecheckBox(), true);
//	}
//
//	@Test(priority = 735)
//	public void clickOnChatCondWritecheckBoxandSelectValueTest() throws InterruptedException {
//		client.clickOnChatCondWritecheckBoxandSelectValue();
//	}
//
//	@Test(priority = 736)
//	public void displayStatusOfsaveModuleTest() throws InterruptedException {
//		Assert.assertEquals(client.displayStatusOfsaveModule(), true);
//	}
//
//	@Test(priority = 737)
//	public void enableStatusOfsaveModuleTest() throws InterruptedException {
//		Assert.assertEquals(client.enableStatusOfsaveModule(), true);
//	}
//
//	@Test(priority = 738)
//	public void clickOnsaveModuleandSelectValueTest() throws InterruptedException {
//		client.clickOnsaveModuleandSelectValue();
//	}
//
////	@Test(priority = 739)
//	public void againSameOpeForVerifiedTest() throws InterruptedException {
//		client.againSameOpeForVerified("abc", "Supervisor");
//	}
}
