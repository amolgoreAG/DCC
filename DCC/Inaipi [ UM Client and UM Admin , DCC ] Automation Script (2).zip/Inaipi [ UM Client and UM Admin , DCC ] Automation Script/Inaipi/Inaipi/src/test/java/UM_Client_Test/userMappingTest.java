package UM_Client_Test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import UM_Client.userMapping;

public class userMappingTest extends BaseClass{

	private static final Logger log = Logger.getLogger(userMappingTest.class);
	public static userMapping usermaping;
	
	@Test(priority = 456)
	public void displayStatusOfuserMappingTest() throws InterruptedException {
		usermaping = new userMapping();
		Assert.assertEquals(usermaping.displayStatusOfuserMapping(), true);
	}

	@Test(priority = 457)
	public void enableStatusOfuserMappingTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfuserMapping(), true);
	}

	@Test(priority = 458)
	public void clickOnuserMappingTest() throws InterruptedException {
		usermaping.clickOnuserMapping();
	}

	@Test(priority = 459)
	public void displayStatusOfroleMappingTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfroleMapping(), true);
	}

	@Test(priority = 460)
	public void enableStatusOfroleMappingTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfroleMapping(), true);
	}

	@Test(priority = 461)
	public void clickOnroleMappingTest() throws InterruptedException {
		usermaping.clickOnroleMapping();
	}

	@Test(priority = 462)
	public void displayStatusOfselectRoleTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfselectRole(), true);
	}

	@Test(priority = 463)
	public void enableStatusOfselectRoleTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfselectRole(), true);
	}

	@Test(priority = 464)
	public void clickOnselectRoleTest() throws InterruptedException {
		usermaping.clickOnselectRole("Agent");
	}

	@Test(priority = 465)
	public void displayStatusOfviewSelectRoleTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfviewSelectRole(), true);
	}

	@Test(priority = 466)
	public void enableStatusOfviewSelectRoleTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfviewSelectRole(), true);
	}

	@Test(priority = 467)
	public void clickOnSelectRoleTest() throws InterruptedException {
		usermaping.clickOnSelectRole();
	}

	@Test(priority = 468)
	public void displayStatusOfaddUsersTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfaddUsers(), true);
	}

	@Test(priority = 469)
	public void enableStatusOfaddUsersTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfaddUsers(), true);
	}

	@Test(priority = 470)
	public void clickOnaddUsersTest() throws InterruptedException {
		usermaping.clickOnaddUsers();
	}

	@Test(priority = 471)
	public void displayStatusOfselectUsersTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfselectUsers(), true);
	}

	@Test(priority = 472)
	public void enableStatusOfselectUsersTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfselectUsers(), true);
	}

	@Test(priority = 473)
	public void clickAndselectUsersTest() throws InterruptedException {
		usermaping.clickAndselectUsers();
	}

	@Test(priority = 474)
	public void displayStatusOfsaveUserTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfsaveUser(), true);
	}

	@Test(priority = 475)
	public void enableStatusOfsaveUserTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfsaveUser(), true);
	}

	@Test(priority = 476)
	public void clickOnsaveUserTest() throws InterruptedException {
		usermaping.clickOnsaveUser();
	}

	@Test(priority = 477)
	public void displayStatusOfnextPageTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfnextPage(), true);
	}

	@Test(priority = 478)
	public void enableStatusOfnextPageTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfnextPage(), true);
	}

	@Test(priority = 479)
	public void clickOnnextPageTest() throws InterruptedException {
		usermaping.clickOnnextPage();
	}

	@Test(priority = 480)
	public void displayStatusOfminimizeTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfminimize(), true);
	}

	@Test(priority = 481)
	public void enableStatusOfminimizeTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfminimize(), true);
	}

	@Test(priority = 482)
	public void clickOnminimizeTest() throws InterruptedException {
		usermaping.clickOnminimize();
	}

	@Test(priority = 483)
	public void displayStatusOfremoveUserNoTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfremoveUserNo(), true);
	}

	@Test(priority = 484)
	public void enableStatusOfremoveUserNoTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfremoveUserNo(), true);
	}

//	@Test(priority = 485)
//	public void clickOnremoveUserNoTest() throws InterruptedException {
//		usermaping.clickOnremoveUserNo();
//	}
	@Test(priority = 486)
	public void displayStatusOfremoveUserYesTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfremoveUserYes(), true);
	}

	@Test(priority = 487)
	public void enableStatusOfremoveUserYesTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfremoveUserYes(), true);
	}

	@Test(priority = 488)
	public void clickOnremoveUserYesTest() throws InterruptedException {
		usermaping.clickOnremoveUserYes();
	}

	@Test(priority = 489)
	public void displayStatusOfgroupMappingTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfgroupMapping(), true);
	}

	@Test(priority = 490)
	public void enableStatusOfgroupMappingTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfgroupMapping(), true);
	}

	@Test(priority = 491)
	public void clickOngroupMappingTest() throws InterruptedException {
		usermaping.clickOngroupMapping();
	}

	@Test(priority = 492)
	public void displayStatusOfselectGroupTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfselectGroup(), true);
	}

	@Test(priority = 493)
	public void enableStatusOfselectGroupTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfselectGroup(), true);
	}

	@Test(priority = 494)
	public void clickOnselectGroupTest() throws InterruptedException {
		usermaping.clickOnselectGroup();
	}

	@Test(priority = 495)
	public void displayStatusOfviewSelectGroupTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfviewSelectGroup(), true);
	}

	@Test(priority = 496)
	public void enableStatusOfviewSelectGroupTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfviewSelectGroup(), true);
	}

	@Test(priority = 497)
	public void clickOnviewSelectGroupTest() throws InterruptedException {
		usermaping.clickOnviewSelectGroup();
	}

	@Test(priority = 498)
	public void displayStatusOfaddUsersGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfaddUsersGroupMap(), true);
	}

	@Test(priority = 499)
	public void enableStatusOfaddUsersGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfaddUsersGroupMap(), true);
	}

	@Test(priority = 500)
	public void clickOnaddUsersGroupMapTest() throws InterruptedException {
		usermaping.clickOnaddUsersGroupMap();
	}

	@Test(priority = 501)
	public void displayStatusOfselectUsersGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfselectUsersGroupMap(), true);
	}

	@Test(priority = 502)
	public void enableStatusOfselectUsersGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfselectUsersGroupMap(), true);
	}

	@Test(priority = 503)
	public void clickAndselectUsersGroupMapTest() throws InterruptedException {
		usermaping.clickAndselectUsersGroupMap();
	}

	@Test(priority = 504)
	public void displayStatusOfsaveUserGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfsaveUserGroupMap(), true);
	}

	@Test(priority = 505)
	public void enableStatusOfsaveUserGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfsaveUserGroupMap(), true);
	}

	@Test(priority = 506)
	public void clickOnsaveUserGroupMapTest() throws InterruptedException {
		usermaping.clickOnsaveUserGroupMap();
	}

	@Test(priority = 507)
	public void displayStatusOfnextPageGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfnextPageGroupMap(), true);
	}

	@Test(priority = 508)
	public void enableStatusOfnextPageGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfnextPageGroupMap(), true);
	}

	@Test(priority = 509)
	public void clickOnnextPageGroupMapTest() throws InterruptedException {
		usermaping.clickOnnextPageGroupMap();
	}

	@Test(priority = 510)
	public void displayStatusOfminimize1GroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfminimize1GroupMap(), true);
	}

	@Test(priority = 511)
	public void enableStatusOfminimize1GroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfminimize1GroupMap(), true);
	}

	@Test(priority = 512)
	public void clickOnminimize1GroupMapTest() throws InterruptedException {
		usermaping.clickOnminimize1GroupMap();
	}

	@Test(priority = 513)
	public void displayStatusOfremoveUserNoGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfremoveUserNoGroupMap(), true);
	}

	@Test(priority = 514)
	public void enableStatusOfremoveUserNoGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfremoveUserNoGroupMap(), true);
	}

//	@Test(priority = 515)
//	public void clickOnremoveUserNoGroupMapTest() throws InterruptedException {
//		usermaping.clickOnremoveUserNoGroupMap();
//	}
	@Test(priority = 516)
	public void displayStatusOfremoveUserYesGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.displayStatusOfremoveUserYesGroupMap(), true);
	}

	@Test(priority = 517)
	public void enableStatusOfremoveUserYesGroupMapTest() throws InterruptedException {
		Assert.assertEquals(usermaping.enableStatusOfremoveUserYesGroupMap(), true);
	}

	@Test(priority = 518)
	public void clickOnremoveUserYesGroupMapTest() throws InterruptedException {
		usermaping.clickOnremoveUserYesGroupMap();
		Thread.sleep(5000);
		usermaping.clickOnuserMapping();
	}
}
