package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import PageLayerPackage.UserManagementSuperAdmin;

public class UserManagementSuperAdminTest extends BaseClass {

	private static final Logger log = Logger.getLogger(UserManagementSuperAdminTest.class);
	public static UserManagementSuperAdmin admin;

	@BeforeClass
	public void start() {
		BaseClass.StartingUM_SuperAdmin();
		admin = new UserManagementSuperAdmin();
	}

	@Test(priority = 1)
	public void displayStatusOfusernameTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfusername(), true);
//		log.info("display status of username test box : " + admin.displayStatusOfusername() );
	}

	@Test(priority = 2)
	public void enableStatusOfusernameTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfusername(), true);
//		log.info("Enable status of username test box : " + admin.enableStatusOfusername() );

	}

	@Test(priority = 3)
	public void enterDataInusernameTest() throws InterruptedException {
		try {
			String username = UtilsLayerPackage.GetDataFromDCCExcel.excel(0, 11, 1);
			admin.enterDataInusername(username);
			log.info("enter username : " + username);
		} catch (Exception e) {
			log.error("Not able to enter username ");
		}

	}

	@Test(priority = 4)
	public void displayStatusOfpasswordTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfpassword(), true);
//		log.info("display status of password test box : " + admin.displayStatusOfpassword() );

	}

	@Test(priority = 5)
	public void enableStatusOfpasswordTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfpassword(), true);
//		log.info("enable status of password test box : " + admin.displayStatusOfpassword() );
	}

	@Test(priority = 6)
	public void enterDataInpasswordTest() throws InterruptedException {
		try {
			String password = UtilsLayerPackage.GetDataFromDCCExcel.excel(0, 12, 1);
			admin.enterDataInpassword(password);
			log.info("enter password : " + password);
		} catch (Exception e) {
			log.error("Not able to enter password ");
		}

	}

	@Test(priority = 7)
	public void displayStatusOfeyeTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeye(), true);
//		log.info("display status of Eye button : " + admin.displayStatusOfeye());
	}

	@Test(priority = 8)
	public void enableStatusOfeyeTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeye(), true);
//		log.info("enable status of Eye button : " + admin.enableStatusOfeye());
	}

	@Test(priority = 9)
	public void clickOneyeTest() throws InterruptedException {
		try {
			admin.clickOneye();
			log.info("click on eye button");
		} catch (Exception e) {
			log.error("Not able to click on eye button");
		}
	}

	@Test(priority = 10)
	public void displayStatusOfloginTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOflogin(), true);
//		log.info("display status of login button : " + admin.displayStatusOflogin());
	}

	@Test(priority = 11)
	public void enableStatusOfloginTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOflogin(), true);
//		log.info("enable status of login button : " + admin.enableStatusOflogin());
	}

	@Test(priority = 12)
	public void clickOnloginTest() throws InterruptedException {
		try {
			admin.clickOnlogin();
			log.info("click on login button");
		} catch (Exception e) {
			log.error("Not able to click on login button");
		}
	}

	@Test(priority = 13)
	public void displayStatusOfclientsTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfclients(), true);
//		log.info("display status of client : " + admin.displayStatusOflogin());
	}

	@Test(priority = 14)
	public void enableStatusOfclientsTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfclients(), true);
	}

	@Test(priority = 15)
	public void clickOnclientsTest() throws InterruptedException {
		try {
			admin.clickOnclients();
			log.info("click on client");
		} catch (Exception e) {
			log.error("Not able to click on client");
		}
	}

	@Test(priority = 16)
	public void displayStatusOfcreateClientTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcreateClient(), true);
	}

	@Test(priority = 17)
	public void enableStatusOfcreateClientTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcreateClient(), true);
	}

	@Test(priority = 18)
	public void clickOncreateClientTest() throws InterruptedException {
		try {
			admin.clickOncreateClient();
			log.info("click on create client");
		} catch (Exception e) {
			log.error("Not able to click on create client");
		}
	}

	@Test(priority = 19)
	public void displayStatusOfclientNameTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfclientName(), true);
	}

	@Test(priority = 20)
	public void enableStatusOfclientNameTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfclientName(), true);
	}

	@Test(priority = 21)
	public void enterDataInclientNameTest() throws InterruptedException {
		try {
			String clientName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 2, 1);
			admin.enterDataInclientName(clientName);
			log.info("Enter Client Name : " + clientName);
		} catch (Exception e) {
			log.error("Not able to Enter Client Name");
		}
	}

	@Test(priority = 22)
	public void displayStatusOfcompanyLogoTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcompanyLogo(), true);
	}

	@Test(priority = 23)
	public void enableStatusOfcompanyLogoTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcompanyLogo(), true);
	}

	@Test(priority = 24)
	public void attachedFileTocompanyLogoTest() throws InterruptedException {
		try {
			admin.attachedFileTocompanyLogo("C:\\Users\\cognicx\\Downloads\\580b57fcd9996e24bc43c4a1.png");
			log.info("attached logo");
		} catch (InterruptedException e) {
			log.error("Not able to attached logo");
		}
	}

	@Test(priority = 25)
	public void displayStatusOfmaxUserTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfmaxUser(), true);
	}

	@Test(priority = 26)
	public void enableStatusOfmaxUserTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfmaxUser(), true);
	}

	@Test(priority = 27)
	public void enterDataInmaxUserTest() throws InterruptedException {
		try {
			String maxUser = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 3, 1);
			admin.enterDataInmaxUser(maxUser);
			log.info("Enter maximum user count : " + maxUser);
		} catch (InterruptedException e) {
			log.error("Not able to Enter maximum user count");
		}
	}

	@Test(priority = 28)
	public void displayStatusOfprimaryColorTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfprimaryColor(), true);
	}

	@Test(priority = 29)
	public void enableStatusOfprimaryColorTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfprimaryColor(), true);
	}

	@Test(priority = 30)
	public void clickOnprimaryColorTest() throws InterruptedException {
		try {
			admin.clickOnprimaryColor();
			log.info("select primary colur");
		} catch (InterruptedException e) {
			log.error("Not able to select primary colur");
		}
	}

	@Test(priority = 31)
	public void displayStatusOfheaderColorTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfheaderColor(), true);
	}

	@Test(priority = 32)
	public void enableStatusOfheaderColorTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfheaderColor(), true);
	}

	@Test(priority = 33)
	public void clickOnheaderColorTest() throws InterruptedException {
		try {
			admin.clickOnheaderColor();
			log.info("select header colour");
		} catch (InterruptedException e) {
			log.error("Not able to select header colour");
		}
	}

	@Test(priority = 34)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfclose(), true);
	}

	@Test(priority = 35)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfclose(), true);
	}

//	@Test(priority = 36)
//	public void clickOncloseTest() throws InterruptedException {
//		admin.clickOnclose();
//	}
	@Test(priority = 37)
	public void displayStatusOfcancelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcancel(), true);
	}

	@Test(priority = 38)
	public void enableStatusOfcancelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcancel(), true);
	}

//	@Test(priority = 39)
//	public void clickOncancelTest() throws InterruptedException {
//		admin.clickOncancel();
//	log.info("click on cancel");
//	}
	@Test(priority = 40)
	public void displayStatusOfcreate_ClientTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcreate_Client(), true);
	}

	@Test(priority = 41)
	public void enableStatusOfcreate_ClientTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcreate_Client(), true);
	}

//	@Test(priority = 42)
//	public void clickOncreate_ClientTest() throws InterruptedException {
//		admin.clickOncreate_Client();
//	log.info("save the client");
//	}
	@Test(priority = 42)
	public void clickOncancelTest() throws InterruptedException {
		try {
			admin.clickOncancel();
			log.info("click on cancel");
		} catch (InterruptedException e) {
			log.error("Not able to click on cancel");
		}
	}

	@Test(priority = 43)
	public void displayStatusOfmasterTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfmaster(), true);
	}

	@Test(priority = 44)
	public void enableStatusOfmasterTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfmaster(), true);
	}

	@Test(priority = 45)
	public void clickOnmasterTest() throws InterruptedException {
		try {
			admin.clickOnmaster();
			log.info("click on Master");
		} catch (InterruptedException e) {
			log.error("Not able to click on Master");
		}
	}

	@Test(priority = 46)
	public void displayStatusOfchannelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfchannel(), true);
	}

	@Test(priority = 47)
	public void enableStatusOfchannelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfchannel(), true);
	}

	@Test(priority = 48)
	public void clickOnchannelTest() throws InterruptedException {
		try {
			admin.clickOnchannel();
			log.info("click on channel");
		} catch (InterruptedException e) {
			log.error("Nt able to click on channel");
		}
	}

	@Test(priority = 49)
	public void displayStatusOfcreateChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcreateChannel(), true);
	}

	@Test(priority = 50)
	public void enableStatusOfcreateChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcreateChannel(), true);
	}

	@Test(priority = 51)
	public void clickOncreateChannelTest() throws InterruptedException {
		try {
			admin.clickOncreateChannel();
			log.info("click on create channel");
		} catch (InterruptedException e) {
			log.error("Not able to click on create channel");
		}
	}

	@Test(priority = 52)
	public void displayStatusOfchannelNameTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfchannelName(), true);
	}

	@Test(priority = 53)
	public void enableStatusOfchannelNameTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfchannelName(), true);
	}

	@Test(priority = 54)
	public void enterDataInchannelNameTest() throws InterruptedException {
		try {
			String channelName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 8, 1);
			admin.enterDataInchannelName(channelName);
			log.info("Enter channel name : " + channelName);
		} catch (InterruptedException e) {
			log.error("Not able to Enter channel name ");
		}
	}

	@Test(priority = 55)
	public void displayStatusOfchannelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfchannelDiscription(), true);
	}

	@Test(priority = 56)
	public void enableStatusOfchannelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfchannelDiscription(), true);
	}

	@Test(priority = 57)
	public void enterDataInchannelDiscriptionTest() throws InterruptedException {
		try {
			String channel_Discription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 9, 1);
			admin.enterDataInchannelDiscription(channel_Discription);
			log.info("Enter Discription of channel : " + channel_Discription);
		} catch (InterruptedException e) {
			log.error("Not able to Enter Discription of channel");
		}
	}

	@Test(priority = 58)
	public void displayStatusOfcloseCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcloseCreateChnnel(), true);
	}

	@Test(priority = 59)
	public void enableStatusOfcloseCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcloseCreateChnnel(), true);
	}

//	@Test(priority = 60)
//	public void clickOncloseCreateChnnelTest() throws InterruptedException {
//		admin.clickOncloseCreateChnnel();
//	log.info("click on close");
//	}
	@Test(priority = 61)
	public void displayStatusOfcancelCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcancelCreateChnnel(), true);
	}

	@Test(priority = 62)
	public void enableStatusOfcancelCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcancelCreateChnnel(), true);
	}

//	@Test(priority = 63)
//	public void clickOncancelCreateChnnelTest() throws InterruptedException {
//		admin.clickOncancelCreateChnnel();
//	}
	@Test(priority = 64)
	public void displayStatusOfsubmitCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfsubmitCreateChnnel(), true);
	}

	@Test(priority = 65)
	public void enableStatusOfsubmitCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfsubmitCreateChnnel(), true);
	}

	@Test(priority = 66)
	public void clickOnsubmitCreateChnnelTest() throws InterruptedException {
		try {
			admin.clickOnsubmitCreateChnnel();
			log.info("Click on submit the channel");
		} catch (InterruptedException e) {
			log.error("Not able to Click on submit the channel");
		}
	}

//	@Test(priority = 66)
//	public void clickOncancelCreateChnnelTest() throws InterruptedException {
//		admin.clickOncancelCreateChnnel();
//	}
	@Test(priority = 67)
	public void displayStatusOfeditChannelCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditChannelCreateChnnel(), true);
	}

	@Test(priority = 68)
	public void enableStatusOfeditChannelCreateChnnelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditChannelCreateChnnel(), true);
	}

	@Test(priority = 69)
	public void clickOneditChannelCreateChnnelTest() throws InterruptedException {
		try {
			admin.clickOneditChannelCreateChnnel();
			log.info("click on edit the channel");
		} catch (InterruptedException e) {
			log.error("Not able to click on edit the channel");
		}
	}

	@Test(priority = 70)
	public void displayStatusOfeditMain_channelNameTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditMain_channelName(), true);
	}

	@Test(priority = 71)
	public void enableStatusOfeditMain_channelNameTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditMain_channelName(), true);
	}

	@Test(priority = 72)
	public void enterDataIneditMain_channelNameTest() throws InterruptedException {
		try {
			String updatechannelName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 8, 4);
			admin.enterDataIneditMain_channelName(updatechannelName);
			log.info("Enter channel name : " + updatechannelName);
		} catch (InterruptedException e) {
			log.error("Not able to Enter channel name");
		}
	}

	@Test(priority = 73)
	public void displayStatusOfeditMain_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditMain_channelDiscription(), true);
	}

	@Test(priority = 74)
	public void enableStatusOfeditMain_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditMain_channelDiscription(), true);
	}

	@Test(priority = 75)
	public void enterDataIneditMain_channelDiscriptionTest() throws InterruptedException {
		try {
			String updatechannelDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 9, 4);
			admin.enterDataIneditMain_channelDiscription(updatechannelDiscription);
			log.info("Enter channel Discription : "  +updatechannelDiscription);
		} catch (InterruptedException e) {
			log.error("Not able to Enter channel Discription : ");
		}
	}

	@Test(priority = 76)
	public void displayStatusOfeditMain_closeTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditMain_close(), true);
	}

	@Test(priority = 77)
	public void enableStatusOfeditMain_closeTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditMain_close(), true);
	}

//	@Test(priority = 78)
//	public void clickOneditMain_closeTest() throws InterruptedException {
//		admin.clickOneditMain_close();
//	log.info("close the channel window");
//	}
	@Test(priority = 79)
	public void displayStatusOfeditMain_cancelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditMain_cancel(), true);
	}

	@Test(priority = 80)
	public void enableStatusOfeditMain_cancelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditMain_cancel(), true);
	}

//	@Test(priority = 81)
//	public void clickOneditMain_cancelTest() throws InterruptedException {
//		admin.clickOneditMain_cancel();
//	}
	@Test(priority = 82)
	public void displayStatusOfeditMain_updateChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditMain_updateChannel(), true);
	}

	@Test(priority = 83)
	public void enableStatusOfeditMain_updateChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditMain_updateChannel(), true);
	}

	@Test(priority = 84)
	public void clickOneditMain_updateChannelTest() throws InterruptedException {
		try {
			admin.clickOneditMain_updateChannel();
			log.info("click on update the channel (update the details)");
		} catch (InterruptedException e) {
			log.error("Not able to click on update the channel (update the details)");
		}
	}

	@Test(priority = 85)
	public void displayStatusOfedit_downArrowTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_downArrow(), true);
	}

	@Test(priority = 86)
	public void enableStatusOfedit_downArrowTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_downArrow(), true);
	}

	@Test(priority = 87)
	public void clickOnedit_downArrowTest() throws InterruptedException {
		try {
			admin.clickOnedit_downArrow();
			log.info("click on down Arrow");
		} catch (InterruptedException e) {
			log.error("Not able to click on down Arrow");
		}
	}

	@Test(priority = 88)
	public void displayStatusOfedit_addSubChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_addSubChannel(), true);
	}

	@Test(priority = 89)
	public void enableStatusOfedit_addSubChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_addSubChannel(), true);
	}

	@Test(priority = 90)
	public void clickOnedit_addSubChannelTest() throws InterruptedException {
		try {
			admin.clickOnedit_addSubChannel();
			log.info("click on add subchannel");
		} catch (InterruptedException e) {
			log.error("Not able to click on add subchannel");
		}
	}

	@Test(priority = 91)
	public void displayStatusOfaddsub_channelNameTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfaddsub_channelName(), true);
	}

	@Test(priority = 92)
	public void enableStatusOfaddsub_channelNameTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfaddsub_channelName(), true);
	}

	@Test(priority = 93)
	public void enterDataInaddsub_channelNameTest() throws InterruptedException {
	try {
		String subchannelName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 12, 1);
			admin.enterDataInaddsub_channelName(subchannelName);
			log.info("enter sub channel name : " + subchannelName);
	} catch (InterruptedException e) {
		log.error("Not able to enter sub channel name : ");
	}
	}

	@Test(priority = 94)
	public void displayStatusOfaddsub_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfaddsub_channelDiscription(), true);
	}

	@Test(priority = 95)
	public void enableStatusOfaddsub_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfaddsub_channelDiscription(), true);
	}

	@Test(priority = 96)
	public void enterDataInaddsub_channelDiscriptionTest() throws InterruptedException {
		try {
			String subchannelDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 13, 1);
			admin.enterDataInaddsub_channelDiscription(subchannelDiscription);
			log.info("enter suchannel Discription : " + subchannelDiscription);
		} catch (InterruptedException e) {
			log.error("Not able to enter suchannel Discription");
		}
	}

	@Test(priority = 97)
	public void displayStatusOfaddsub_closeTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfaddsub_close(), true);
	}

	@Test(priority = 98)
	public void enableStatusOfaddsub_closeTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfaddsub_close(), true);
	}

//	@Test(priority = 99)
//	public void clickOnaddsub_closeTest() throws InterruptedException {
//		admin.clickOnaddsub_close();
//	}
	@Test(priority = 100)
	public void displayStatusOfaddsub_cancelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfaddsub_cancel(), true);
	}

	@Test(priority = 101)
	public void enableStatusOfaddsub_cancelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfaddsub_cancel(), true);
	}

//	@Test(priority = 102)
//	public void clickOnaddsub_cancelTest() throws InterruptedException {
//		admin.clickOnaddsub_cancel();
//	}
	@Test(priority = 103)
	public void displayStatusOfaddsub_submitTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfaddsub_submit(), true);
	}

	@Test(priority = 104)
	public void enableStatusOfaddsub_submitTets() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfaddsub_submit(), true);
	}

	@Test(priority = 105)
	public void clickOnaddsub_submitTest() throws InterruptedException {
		try {
			admin.clickOnaddsub_submit();
			log.info("save the subchannel");
		} catch (InterruptedException e) {
			log.error("Not able to save the subchannel");
		}
	}

	@Test(priority = 106)
	public void displayStatusOfeditsub_editSubChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditsub_editSubChannel(), true);
	}

	@Test(priority = 107)
	public void enableStatusOfeditsub_editSubChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditsub_editSubChannel(), true);
	}

	@Test(priority = 108)
	public void clickOneditsub_editSubChannelTest() throws InterruptedException {
		try {
			admin.clickOneditsub_editSubChannel();
			log.info("click on Edit suchannel ");
		} catch (InterruptedException e) {
			log.error("Not able to click on Edit suchannel ");
		}
	}

	@Test(priority = 109)
	public void displayStatusOfeditsub_channelNameTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditsub_channelName(), true);
	}

	@Test(priority = 110)
	public void enableStatusOfeditsub_channelNameTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditsub_channelName(), true);
	}

	@Test(priority = 111)
	public void enterDataIneditsub_channelNameTest() throws InterruptedException {
		try {
			String updatesubchannelName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 12, 4);
			admin.enterDataIneditsub_channelName(updatesubchannelName);
			log.info("enter subchannel name : " + updatesubchannelName);
		} catch (InterruptedException e) {
			log.error("Not able to enter subchannel name");
		}
	}

	@Test(priority = 112)
	public void displayStatusOfeditsub_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditsub_channelDiscription(), true);
	}

	@Test(priority = 113)
	public void enableStatusOfeditsub_channelDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditsub_channelDiscription(), true);
	}

	@Test(priority = 114)
	public void enterDataIneditsub_channelDiscriptionTest() throws InterruptedException {
		try {
			String updatesubchannelDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 13, 4);
			admin.enterDataIneditsub_channelDiscription(updatesubchannelDiscription);
			log.info("enter suchannel Discription : " + updatesubchannelDiscription);
		} catch (InterruptedException e) {
			log.error("Not able to enter suchannel Discription ");
		}
	}

	@Test(priority = 115)
	public void displayStatusOfeditsub_closeTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditsub_close(), true);
	}

	@Test(priority = 116)
	public void enableStatusOfeditsub_closeTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditsub_close(), true);
	}

//	@Test(priority = 117)
//	public void clickOneditsub_closeTest() throws InterruptedException {
//		admin.clickOneditsub_close();
//	}
	@Test(priority = 118)
	public void displayStatusOfeditsub_cancelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditsub_cancel(), true);
	}

	@Test(priority = 119)
	public void enableStatusOfeditsub_cancelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditsub_cancel(), true);
	}

//	@Test(priority = 120)
//	public void clickOneditsub_cancelTest() throws InterruptedException {
//		admin.clickOneditsub_cancel();
//	}
	@Test(priority = 121)
	public void displayStatusOfeditsub_updateChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditsub_updateChannel(), true);
	}

	@Test(priority = 122)
	public void enableStatusOfeditsub_updateChannelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditsub_updateChannel(), true);
	}

	@Test(priority = 123)
	public void clickOneditsub_updateChannelTest() throws InterruptedException {
		try {
			admin.clickOneditsub_updateChannel();
			log.info("update the subchannel ");
		} catch (InterruptedException e) {
			log.error("Not able to update the subchannel ");
		}
	}

	@Test(priority = 124)
	public void displayStatusOfrouterTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfrouter(), true);
	}

	@Test(priority = 125)
	public void enableStatusOfrouterTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfrouter(), true);
	}

	@Test(priority = 126)
	public void clickOnrouterTest() throws InterruptedException {
		try {
			admin.clickOnrouter();
			log.info("Click on Router");
		} catch (InterruptedException e) {
			log.error("Not able to Click on Router");
		}
	}

	@Test(priority = 127)
	public void displayStatusOfcreateRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcreateRouter(), true);
	}

	@Test(priority = 128)
	public void enableStatusOfcreateRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcreateRouter(), true);
	}

	@Test(priority = 129)
	public void clickOncreateRouterTest() throws InterruptedException {
		try {
			admin.clickOncreateRouter();
			log.info("Click on create a router");
		} catch (InterruptedException e) {
			log.error("Not able to Click on create a router");
		}
	}

	@Test(priority = 130)
	public void displayStatusOfrouterNameTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfrouterName(), true);
	}

	@Test(priority = 131)
	public void enableStatusOfrouterNameTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfrouterName(), true);
	}

	@Test(priority = 132)
	public void enterDataInrouterNameTest() throws InterruptedException {
		try {
			String routerName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 17, 1);
			admin.enterDataInrouterName(routerName);
			log.info("enter router name : " + routerName);
		} catch (InterruptedException e) {
			log.error("Not able to enter router name ");
		}
	}

	@Test(priority = 133)
	public void displayStatusOfrouterDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfrouterDiscription(), true);
	}

	@Test(priority = 134)
	public void enableStatusOfrouterDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfrouterDiscription(), true);
	}

	@Test(priority = 135)
	public void enterDataInrouterDiscriptionTest() throws InterruptedException {
		try {
			String routerDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 18, 1);
			admin.enterDataInrouterDiscription(routerDiscription);
			log.info("enter router discription : " + routerDiscription);
		} catch (InterruptedException e) {
			log.error("Not able to enter router discription : ");
		}
	}

	@Test(priority = 136)
	public void displayStatusOfclose1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfclose1(), true);
	}

	@Test(priority = 137)
	public void enableStatusOfclose1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfclose1(), true);
	}

//	@Test(priority = 138)
//	public void clickOnclose1Test() throws InterruptedException {
//		admin.clickOnclose1();
//	}
	@Test(priority = 139)
	public void displayStatusOfcancel1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcancel1(), true);
	}

	@Test(priority = 140)
	public void enableStatusOfcancel1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcancel1(), true);
	}

//	@Test(priority = 141)
//	public void clickOncancel1Test() throws InterruptedException {
//		admin.clickOncancel1();
//	}
	@Test(priority = 142)
	public void displayStatusOfsubmit1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfsubmit1(), true);
	}

	@Test(priority = 143)
	public void enableStatusOfsubmit1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfsubmit1(), true);
	}

	@Test(priority = 144)
	public void clickOnsubmit1Test() throws InterruptedException {
		try {
			admin.clickOnsubmit1();
			log.info("click on submit the router");
		} catch (InterruptedException e) {
			log.error("Not able to click on submit the router");
		}
	}

	@Test(priority = 145)
	public void displayStatusOfeditRouter1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditRouter1(), true);
	}

	@Test(priority = 146)
	public void enableStatusOfeditRouter1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditRouter1(), true);
	}

	@Test(priority = 147)
	public void clickOneditRouter1Test() throws InterruptedException {
		try {
			admin.clickOneditRouter1();
			log.info("click on update router");
		} catch (InterruptedException e) {
			log.error("Not able to click on update router");
		}
	}

	@Test(priority = 148)
	public void displayStatusOfupdate_routerNameTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfupdate_routerName(), true);
	}

	@Test(priority = 149)
	public void enableStatusOfupdate_routerNameTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfupdate_routerName(), true);
	}

	@Test(priority = 150)
	public void enterDataInupdate_routerNameTest() throws InterruptedException {
		try {
			String updaterouterName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 17, 4);
			admin.enterDataInupdate_routerName(updaterouterName);
			log.info("enter router name : " + updaterouterName);
		} catch (InterruptedException e) {
			log.error("Not able to enter router name");
		}
	}

	@Test(priority = 151)
	public void displayStatusOfupdate_routerDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfupdate_routerDiscription(), true);
	}

	@Test(priority = 152)
	public void enableStatusOfupdate_routerDiscriptionTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfupdate_routerDiscription(), true);
	}

	@Test(priority = 153)
	public void enterDataInupdate_routerDiscriptionTest() throws InterruptedException {
		try {
			String updaterouterDiscription = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 18, 4);
			admin.enterDataInupdate_routerDiscription(updaterouterDiscription);
			log.info("enter router discription : " + updaterouterDiscription);
		} catch (InterruptedException e) {
			log.error("Not able to enter router discription");
		}
	}

	@Test(priority = 154)
	public void displayStatusOfupdate_close1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfupdate_close1(), true);
	}

	@Test(priority = 155)
	public void enableStatusOfupdate_close1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfupdate_close1(), true);
	}

//	@Test(priority = 156)
//	public void clickOnupdate_close1Test() throws InterruptedException {
//		admin.clickOnupdate_close1();
//	}
	@Test(priority = 157)
	public void displayStatusOfupdate_cancel1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfupdate_cancel1(), true);
	}

	@Test(priority = 158)
	public void enableStatusOfupdate_cancel1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfupdate_cancel1(), true);
	}

//	@Test(priority = 159)
//	public void clickOnupdate_cancel1Test() throws InterruptedException {
//		admin.clickOnupdate_cancel1();
//	}
	@Test(priority = 160)
	public void displayStatusOfupdate_updateRouter1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfupdate_updateRouter1(), true);
	}

	@Test(priority = 161)
	public void enableStatusOfupdate_updateRouter1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfupdate_updateRouter1(), true);
	}

	@Test(priority = 162)
	public void clickOnupdate_updateRouter1Test() throws InterruptedException {
		try {
			admin.clickOnupdate_updateRouter1();
			log.info("click on update router");
		} catch (InterruptedException e) {
			log.error("Not able to click on update router");
		}
	}

	@Test(priority = 163)
	public void displayStatusOfclientAdmin1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfclientAdmin1(), true);
	}

	@Test(priority = 164)
	public void enableStatusOfclientAdmin1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfclientAdmin1(), true);
	}

	@Test(priority = 165)
	public void clickOnclientAdmin1Test() throws InterruptedException {
		try {
			admin.clickOnclientAdmin1();
			log.info("click on client admin");
		} catch (InterruptedException e) {
			log.error("Not able to click on client admin");
		}
	}

	@Test(priority = 166)
	public void displayStatusOfselectClient1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfselectClient1(), true);
	}

	@Test(priority = 167)
	public void enableStatusOfselectClient1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfselectClient1(), true);
	}

	@Test(priority = 168)
	public void clickOnselectClient1andSelectAdminFromDPTest() throws InterruptedException {
		try {
			String clientFromDP = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 23, 1);
			admin.clickOnselectClient1andSelectAdminFromDP(clientFromDP);
			log.info("Select the client from drop down : " + clientFromDP);
		} catch (InterruptedException e) {
			log.error("Not able to Select the client from drop down ");
		}
	}

	@Test(priority = 169)
	public void displayStatusOfview1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfview1(), true);
	}

	@Test(priority = 170)
	public void enableStatusOfview1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfview1(), true);
	}

	@Test(priority = 171)
	public void clickOnview1Test() throws InterruptedException {
		try {
			admin.clickOnview1();
			log.info("Click on view");
		} catch (InterruptedException e) {
			log.error("Not able to Click on view");
		}
	}

	@Test(priority = 172)
	public void displayStatusOfaddAdmin1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfaddAdmin1(), true);
	}

	@Test(priority = 173)
	public void enableStatusOfaddAdmin1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfaddAdmin1(), true);
	}

	@Test(priority = 174)
	public void clickOnaddAdmin1Test() throws InterruptedException {
		try {
			admin.clickOnaddAdmin1();
			log.info("click on add Admin here we fill the details of agent");
		} catch (InterruptedException e) {
			log.error("Not able to click on add Admin here we fill the details of agent");
		}
	}

	@Test(priority = 175)
	public void displayStatusOffirstName1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOffirstName1(), true);
	}

	@Test(priority = 176)
	public void enableStatusOffirstName1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOffirstName1(), true);
	}

	@Test(priority = 177)
	public void enterDataInfirstName1Test() throws InterruptedException {
		try {
			String firstName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 26, 1);
			admin.enterDataInfirstName1(firstName);
			log.info("Enter Agent First Name : " + firstName);
		} catch (InterruptedException e) {
			log.error("Not able to Enter Agent First Name : ");
		}
	}

	@Test(priority = 178)
	public void displayStatusOflastName1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOflastName1(), true);
	}

	@Test(priority = 179)
	public void enableStatusOflastName1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOflastName1(), true);
	}

	@Test(priority = 180)
	public void enterDataInlastName1Test() throws InterruptedException {
		try {
			String lastName = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 27, 1);
			admin.enterDataInlastName1(lastName);
			log.info("Enter Agent Last Name : " + lastName);
		} catch (InterruptedException e) {
			log.error("Not able to Enter Agent Last Name ");
		}
	}

	@Test(priority = 181)
	public void displayStatusOfemail1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfemail1(), true);
	}

	@Test(priority = 182)
	public void enableStatusOfemail1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfemail1(), true);
	}

	@Test(priority = 183)
	public void enterDataInemail1Test() throws InterruptedException {
		try {
			String email = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 28, 1);
			admin.enterDataInemail1(email);
			log.info("Enter Agent Email Address : " + email);
		} catch (InterruptedException e) {
			log.error("Not able to Enter Agent Email Address");
		}
	}

	@Test(priority = 184)
	public void displayStatusOfcontactNumber1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcontactNumber1(), true);
	}

	@Test(priority = 185)
	public void enableStatusOfcontactNumber1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcontactNumber1(), true);
	}

	@Test(priority = 186)
	public void enterDataIncontactNumber1Test() throws InterruptedException {
		try {
			String mobileNumber = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 29, 1);
			admin.enterDataIncontactNumber1(mobileNumber);
			log.info("Enter Agent Contact Number : " + mobileNumber);
		} catch (InterruptedException e) {
			log.error("Not able to Enter Agent Contact Number");
		}
	}

	@Test(priority = 187)
	public void displayStatusOfadminPassword1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfadminPassword1(), true);
	}

	@Test(priority = 188)
	public void enableStatusOfadminPassword1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfadminPassword1(), true);
	}

	@Test(priority = 189)
	public void enterDataInadminPassword1Test() throws InterruptedException {
		try {
			String password = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 30, 1);
			admin.enterDataInadminPassword1(password);
			log.info("Enter Password : " + password);
		} catch (InterruptedException e) {
			log.error("Not able to Enter Password");
		}
	}

	@Test(priority = 190)
	public void displayStatusOfadminPasswordShow1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfadminPasswordShow1(), true);
	}

	@Test(priority = 191)
	public void enableStatusOfadminPasswordShow1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfadminPasswordShow1(), true);
	}

	@Test(priority = 192)
	public void clickOnadminPasswordShow1Test() throws InterruptedException {
		try {
			admin.clickOnadminPasswordShow1();
			log.info("Click on eye button for see the enter password");
		} catch (InterruptedException e) {
			log.error("Not able to Click on eye button for see the enter password");
		}
	}

	@Test(priority = 193)
	public void displayStatusOfadminConfirmPassword1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfadminConfirmPassword1(), true);
	}

	@Test(priority = 194)
	public void enableStatusOfadminConfirmPassword1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfadminConfirmPassword1(), true);
	}

	@Test(priority = 195)
	public void enterDataInadminConfirmPassword1Test() throws InterruptedException {
		try {
			String confirmpassword = UtilsLayerPackage.GetDataFromDCCExcel.excel(1, 31, 1);
			admin.enterDataInadminConfirmPassword1(confirmpassword);
			log.info("Enter Confirm Password : " + confirmpassword);
		} catch (InterruptedException e) {
			log.error("Not able to Enter Confirm Password ");
		}
	}

	@Test(priority = 196)
	public void displayStatusOfadminConfirmPasswordShow1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfadminConfirmPasswordShow1(), true);
	}

	@Test(priority = 197)
	public void enableStatusOfadminConfirmPasswordShow1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfadminConfirmPasswordShow1(), true);
	}

	@Test(priority = 198)
	public void clickOnadminConfirmPasswordShow1Test() throws InterruptedException {
		try {
			admin.clickOnadminConfirmPasswordShow1();
			log.info("Click on eye button for see the enter password");
		} catch (InterruptedException e) {
			log.error("Not able to Click on eye button for see the enter password");
		}
	}

	@Test(priority = 199)
	public void displayStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfclose2(), true);
	}

	@Test(priority = 200)
	public void enableStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfclose2(), true);
	}

//	@Test(priority = 201)
//	public void clickOnclose2Test() throws InterruptedException {
//		admin.clickOnclose2();
//	}
	@Test(priority = 202)
	public void displayStatusOfadminCancelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfadminCancel(), true);
	}

	@Test(priority = 203)
	public void enableStatusOfadminCancelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfadminCancel(), true);
	}

//	@Test(priority = 204)
//	public void clickOnadminCancelTest() throws InterruptedException {
//		admin.clickOnadminCancel();
//	}
	@Test(priority = 205)
	public void displayStatusOfadminAddAdminTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfadminAddAdmin(), true);
	}

	@Test(priority = 206)
	public void enableStatusOfadminAddAdminTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfadminAddAdmin(), true);
	}

//	@Test(priority = 207)
//	public void clickOnadminAddAdminTest() throws InterruptedException {
//		admin.clickOnadminAddAdmin();
//	}
	@Test(priority = 207)
	public void clickOnadminCancelTest() throws InterruptedException {
		try {
			admin.clickOnadminCancel();
			log.info("Click on cancel button");
		} catch (InterruptedException e) {
			log.error("Not able to Click on cancel button");
		}
	}

	@Test(priority = 208)
	public void displayStatusOfeditAdminTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfeditAdmin(), true);
	}

	@Test(priority = 209)
	public void enableStatusOfeditAdminTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfeditAdmin(), true);
	}

	@Test(priority = 210)
	public void clickOneditAdminTest() throws InterruptedException {
		try {
			admin.clickOneditAdmin();
			log.info("Click on edit Admin");
		} catch (InterruptedException e) {
			log.error("Not able to Click on edit Admin");
		}
	}

	@Test(priority = 211)
	public void displayStatusOfedit_firstName1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_firstName1(), true);
	}

	@Test(priority = 212)
	public void enableStatusOfedit_firstName1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_firstName1(), true);
	}

	@Test(priority = 213)
	public void enterDataInedit_firstName1Test() throws InterruptedException {
		try {
			admin.enterDataInedit_firstName1();
			log.info("Enter First Name");
		} catch (InterruptedException e) {
			log.error("Not able to Enter First Name");
		}
	}

	@Test(priority = 214)
	public void displayStatusOfedit_lastName1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_lastName1(), true);
	}

	@Test(priority = 215)
	public void enableStatusOfedit_lastName1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_lastName1(), true);
	}

	@Test(priority = 216)
	public void enterDataInedit_lastName1Test() throws InterruptedException {
		try {
			admin.enterDataInedit_lastName1();
			log.info("Enter Last Name");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Last Name");
		}
	}

	@Test(priority = 217)
	public void displayStatusOfedit_email1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_email1(), true);
	}

	@Test(priority = 218)
	public void enableStatusOfedit_email1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_email1(), true);
	}

	@Test(priority = 219)
	public void enterDataInedit_email1Test() throws InterruptedException {
		try {
			admin.enterDataInedit_email1();
			log.info("Enter Email Id");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Email Id");
		}
	}

	@Test(priority = 220)
	public void displayStatusOfedit_contactNumber1Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_contactNumber1(), true);
	}

	@Test(priority = 221)
	public void enableStatusOfedit_contactNumber1Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_contactNumber1(), true);
	}

	@Test(priority = 222)
	public void enterDataInedit_contactNumber1Test() throws InterruptedException {
		try {
			admin.enterDataInedit_contactNumber1("5647893210");
			log.info("Enter Mobile Number");
		} catch (InterruptedException e) {
			log.error("Not able to Enter Mobile Number");
		}
	}

	@Test(priority = 223)
	public void displayStatusOfedit_close2Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_close2(), true);
	}

	@Test(priority = 224)
	public void enableStatusOfedit_close2Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_close2(), true);
	}

//	@Test(priority = 225)
//	public void clickOnedit_close2Test() throws InterruptedException {
//		admin.clickOnedit_close2();
//	}
	@Test(priority = 226)
	public void displayStatusOfedit_adminCancelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_adminCancel(), true);
	}

	@Test(priority = 227)
	public void enableStatusOfedit_adminCancelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_adminCancel(), true);
	}

//	@Test(priority = 228)
//	public void clickOnedit_adminCancelTest() throws InterruptedException {
//		admin.clickOnedit_adminCancel();
//	}
	@Test(priority = 229)
	public void displayStatusOfedit_updateAddAdminTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfedit_updateAddAdmin(), true);
	}

	@Test(priority = 230)
	public void enableStatusOfedit_updateAddAdminTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfedit_updateAddAdmin(), true);
	}

//	@Test(priority = 231)
//	public void clickOnedit_updateAddAdminTest() throws InterruptedException {
//		admin.clickOnedit_updateAddAdmin();
//	}
	@Test(priority = 231)
	public void clickOnedit_adminCancelTest() throws InterruptedException {
		try {
			admin.clickOnedit_adminCancel();
			log.info("Click on cancel button");
		} catch (InterruptedException e) {
			log.error("Not able to Click on cancel button");
		}
	}

	@Test(priority = 232)
	public void displayStatusOfadminAddAdminStatusTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfadminAddAdminStatus(), true);
	}

	@Test(priority = 233)
	public void enableStatusOfadminAddAdminStatusTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfadminAddAdminStatus(), true);
	}

	@Test(priority = 234)
	public void clickOnadminAddAdminStatusTest() throws InterruptedException {
		try {
			admin.clickOnadminAddAdminStatus();
			log.info("check admin active deactive status");
		} catch (InterruptedException e) {
			log.error("Not able to check admin active deactive status");
		}
	}
	@Test(priority = 235)
	public void displayStatusOfclientMappingTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfclientMapping(), true);
	}

	@Test(priority = 236)
	public void enableStatusOfclientMappingTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfclientMapping(), true);
	}

	@Test(priority = 237)
	public void clickOnclientMappingTest() throws InterruptedException {
		try {
			admin.clickOnclientMapping();
			log.info("click on client mapping");
		} catch (InterruptedException e) {
			log.error("Not able to click on client mapping");
		}
	}

	@Test(priority = 238)
	public void displayStatusOfclientChannelMappingTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfclientChannelMapping(), true);
	}

	@Test(priority = 239)
	public void enableStatusOfclientChannelMappingTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfclientChannelMapping(), true);
	}

	@Test(priority = 240)
	public void clickOnclientChannelMappingTest() throws InterruptedException {
		try {
			admin.clickOnclientChannelMapping();
			log.info("Click on client channel mapping");
		} catch (InterruptedException e) {
			log.error("Not able to Click on client channel mapping");
		}
	}

	@Test(priority = 241)
	public void displayStatusOfselectClientCMTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfselectClientCM(), true);
	}

	@Test(priority = 242)
	public void enableStatusOfselectClientCMTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfselectClientCM(), true);
	}

	@Test(priority = 243)
	public void clickOnselectClientCMandSelectDPValueTest() throws InterruptedException {
		try {
			admin.clickOnselectClientCMandSelectDPValue("Demo");
			log.info("select client from drop down");
		} catch (InterruptedException e) {
			log.error("Not able to select client from drop down");
		}
	}

	@Test(priority = 244)
	public void displayStatusOfviewClientTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfviewClient(), true);
	}

	@Test(priority = 245)
	public void enableStatusOfviewClientTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfviewClient(), true);
	}

	@Test(priority = 246)
	public void clickOnviewClientTest() throws InterruptedException {
		try {
			admin.clickOnviewClient();
			log.info("click on view button");
		} catch (InterruptedException e) {
			log.error("Not able to click on view button");
		}
	}

	@Test(priority = 247)
	public void displayStatusOfchatCheckBoxTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfchatCheckBox(), true);
	}

	@Test(priority = 248)
	public void enableStatusOfchatCheckBoxTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfchatCheckBox(), true);
	}

	@Test(priority = 249)
	public void clickOnchatCheckBoxTest() throws InterruptedException {
		try {
			admin.clickOnchatCheckBox();
			log.info("select check box");
		} catch (InterruptedException e) {
			log.error("Not able to select check box");
		}
	}

	@Test(priority = 250)
	public void displayStatusOftwitterCheckBoxTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOftwitterCheckBox(), true);
	}

	@Test(priority = 251)
	public void enableStatusOftwitterCheckBoxTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOftwitterCheckBox(), true);
	}

	@Test(priority = 252)
	public void clickOntwitterCheckBoxTest() throws InterruptedException {
		try {
			admin.clickOntwitterCheckBox();
			log.info("select twitter check box");
		} catch (InterruptedException e) {
			log.error("Not able to select twitter check box");
		}
	}

	@Test(priority = 253)
	public void displayStatusOfsaveChaneelTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfsaveChaneel(), true);
	}

	@Test(priority = 254)
	public void enableStatusOfsaveChaneelTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfsaveChaneel(), true);
	}

	@Test(priority = 255)
	public void clickOnsaveChaneelTest() throws InterruptedException {
		try {
			admin.clickOnsaveChaneel();
			log.info("click on save button");
		} catch (InterruptedException e) {
			log.error("Not able to click on save button");
		}
	}

	@Test(priority = 256)
	public void displayStatusOfselectClientCM2Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfselectClientCM2(), true);
	}

	@Test(priority = 257)
	public void enableStatusOfselectClientCM2Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfselectClientCM2(), true);
	}

	@Test(priority = 258)
	public void clickOnselectClientCMandSelectDPValue2Test() throws InterruptedException {
		try {
			admin.clickOnselectClientCMandSelectDPValue2("Demo");
			log.info("select dp value again for verificaion");
		} catch (InterruptedException e) {
			log.error("Not able to select dp value again for verificaion");
		}
	}

	@Test(priority = 259)
	public void displayStatusOfviewClient2Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfviewClient2(), true);
	}

	@Test(priority = 260)
	public void enableStatusOfviewClient2Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfviewClient2(), true);
	}

	@Test(priority = 261)
	public void clickOnviewClient2Test() throws InterruptedException {
		try {
			admin.clickOnviewClient2();
			log.info("click on view button");
		} catch (InterruptedException e) {
			log.error("Not able to click on view button");
		}
	}

	@Test(priority = 262)
	public void displayStatusOfchatCheckBox2Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfchatCheckBox2(), true);
	}

	@Test(priority = 263)
	public void enableStatusOfchatCheckBox2Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfchatCheckBox2(), true);
	}

	@Test(priority = 264)
	public void clickOnchatCheckBox2Test() throws InterruptedException {
		try {
			admin.clickOnchatCheckBox2();
			log.info("open the chat (click on down arrow)");
		} catch (InterruptedException e) {
			log.error("Not able to open the chat (click on down arrow)");
		}
	}

	@Test(priority = 265)
	public void displayStatusOftwitterCheckBox2Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOftwitterCheckBox2(), true);
	}

	@Test(priority = 266)
	public void enableStatusOftwitterCheckBox2Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOftwitterCheckBox2(), true);
	}

	@Test(priority = 267)
	public void clickOntwitterCheckBox2Test() throws InterruptedException {
		try {
			admin.clickOntwitterCheckBox2();
			log.info("click on check box again");
		} catch (InterruptedException e) {
			log.error("Not able to click on check box again");
		}
	}

	@Test(priority = 268)
	public void displayStatusOfsaveChaneel2Test() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfsaveChaneel2(), true);
	}

	@Test(priority = 269)
	public void enableStatusOfsaveChaneel2Test() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfsaveChaneel2(), true);
	}

	@Test(priority = 270)
	public void clickOnsaveChaneel2Test() throws InterruptedException {
		try {
			admin.clickOnsaveChaneel2();
			log.info("save the data");
		} catch (InterruptedException e) {
			log.error("Not able to save the data");
		}
	}

	@Test(priority = 271)
	public void displayStatusOfroutingMappingTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfroutingMapping(), true);
	}

	@Test(priority = 272)
	public void enableStatusOfroutingMappingTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfroutingMapping(), true);
	}

	@Test(priority = 273)
	public void clickOnroutingMappingTest() throws InterruptedException {
		try {
			admin.clickOnroutingMapping();
			log.info("click on routing mapping");
		} catch (InterruptedException e) {
			log.error("Not able to click on routing mapping");
		}
	}

	@Test(priority = 274)
	public void displayStatusOfselectClientRMTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfselectClientRM(), true);
	}

	@Test(priority = 275)
	public void enableStatusOfselectClientRMTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfselectClientRM(), true);
	}

	@Test(priority = 276)
	public void clickOnselectClientRMandSelectDPValueTest() throws InterruptedException {
		try {
			admin.clickOnselectClientRMandSelectDPValue("Demo");
			log.info("select client name from drop down");
		} catch (InterruptedException e) {
			log.error("Not able to select client name from drop down");
		}
	}

	@Test(priority = 277)
	public void displayStatusOfviewRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfviewRouter(), true);
	}

	@Test(priority = 278)
	public void enableStatusOfviewRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfviewRouter(), true);
	}

	@Test(priority = 279)
	public void clickOnviewRouterTest() throws InterruptedException {
		try {
			admin.clickOnviewRouter();
			log.info("click on view button");
		} catch (InterruptedException e) {
			log.error("Not able to click on view button");
		}
	}

	@Test(priority = 280)
	public void displayStatusOfaddRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfaddRouter(), true);
	}

	@Test(priority = 281)
	public void enableStatusOfaddRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfaddRouter(), true);
	}

	@Test(priority = 282)
	public void clickOnaddRouterTest() throws InterruptedException {
		try {
			admin.clickOnaddRouter();
			log.info("click on add router");
		} catch (InterruptedException e) {
			log.error("Not able to click on add router");
		}
	}

	@Test(priority = 283)
	public void displayStatusOfselectRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfselectRouter(), true);
	}

	@Test(priority = 284)
	public void enableStatusOfselectRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfselectRouter(), true);
	}

	@Test(priority = 285)
	public void clickOnselectRouterandSelectDPValueTest() throws InterruptedException {
		try {
			admin.clickOnselectRouterandSelectDPValue();
			log.info("select router ");
		} catch (InterruptedException e) {
			log.error("Not able to select router ");
		}
	}

	@Test(priority = 286)
	public void displayStatusOfsaveRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfsaveRouter(), true);
	}

	@Test(priority = 287)
	public void enableStatusOfsaveRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfsaveRouter(), true);
	}

//	@Test(priority = 288)
//	public void clickOnsaveRouterandSelectDPValueTest() throws InterruptedException {
//		admin.clickOnsaveRouterandSelectDPValue();
//	}
	@Test(priority = 289)
	public void displayStatusOfcancelRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.displayStatusOfcancelRouter(), true);
	}

	@Test(priority = 290)
	public void enableStatusOfcancelRouterTest() throws InterruptedException {
		Assert.assertEquals(admin.enableStatusOfcancelRouter(), true);
	}

	@Test(priority = 291)
	public void clickOncancelRouterandSelectDPValueTest() throws InterruptedException {
		try {
			admin.clickOncancelRouterandSelectDPValue();
			log.info("click on cancel");
		} catch (InterruptedException e) {
			log.error("Not able to click on cancel");
		}
	}
}
