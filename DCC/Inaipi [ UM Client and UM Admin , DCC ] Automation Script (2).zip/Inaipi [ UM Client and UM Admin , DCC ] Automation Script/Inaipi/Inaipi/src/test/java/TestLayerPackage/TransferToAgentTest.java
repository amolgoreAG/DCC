package TestLayerPackage;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseLayerPackage.BaseClass;
import PageLayerPackage.TransferToAgent;

public class TransferToAgentTest extends BaseClass {
	private static Logger log = Logger.getLogger(TransferToAgentTest.class);
	public static TransferToAgent trans;

	@BeforeClass
	public void starting() {
		BaseClass.chatInterFace();
	}

	@Test(priority = 1)
	public void displayStatusOfUsernameTest() throws InterruptedException {
		trans = new TransferToAgent();
		Assert.assertEquals(trans.displayStatusOfUsername(), true);
	}

	@Test(priority = 2)
	public void enableStatusOfUsernameTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfUsername(), true);
	}

	@Test(priority = 3)
	public void displayStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfPassword(), true);
	}

	@Test(priority = 4)
	public void enableStatusOfPasswordTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfPassword(), true);
	}

	@Test(priority = 5)
	public void displayStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfLogin(), true);
	}

	@Test(priority = 6)
	public void enableStatusOfLoginTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfLogin(), true);
	}

	@Test(priority = 7)
	public void enterLoginCredentialandLogin() throws InterruptedException {
		try {
			String Username = excel.getDataFromExcelSheet(0, 20, 1);
			String Password = excel.getDataFromExcelSheet(0, 21, 1);
			trans.enterLoginCredentialandLogin(Username, Password);
			Thread.sleep(2000);
			log.info("enter username , password and login");
		} catch (InterruptedException e) {
			log.error("Please enter valid creadential and login");
		}
	}

	@Test(priority = 8)
	public void displayStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfstatus(), true);
	}

	@Test(priority = 9)
	public void enableStatusOfstatusTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfstatus(), true);
	}

	@Test(priority = 10)
	public void clickOnstatusTest() {
		try {
			trans.clickOnstatus();
			log.info("click on status");
		} catch (Exception e) {
			log.error("Not able to click on status");
		}
	}

	@Test(priority = 11)
	public void displayStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfgoready(), true);
	}

	@Test(priority = 12)
	public void enableStatusOfgoreadyTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfgoready(), true);
	}

	@Test(priority = 13)
	public void clickOngoreadyTest() {
		try {
			trans.clickOngoready();
			log.info("change the status go ready to ready");
		} catch (Exception e) {
			log.error("Not able to change the status go ready to ready");
		}
	}

	@Test(priority = 14)
	public void displayStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfclose(), true);
	}

	@Test(priority = 15)
	public void enableStatusOfcloseTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfclose(), true);
	}

	@Test(priority = 16)
	public void clickOncloseTest() {
		try {
			trans.clickOnclose();
			log.info("and close this");
		} catch (Exception e) {
			log.error("Not able to close");
		}
	}

	@Test(priority = 17)
	public void navigatetoCustomerPortalTest() {
		try {
			trans.navigatetoCustomerPortal();
			log.info("navigate to agent portal");
		} catch (Exception e) {
			log.error("Not able to navigate to agent portal");
		}
	}

	@Test(priority = 18)
	public void displayStatusOfchatTest() throws InterruptedException {
		trans.displayStatusOfchat();
	}

	@Test(priority = 19)
	public void enableStatusOfchatTest() throws InterruptedException {
		trans.enableStatusOfchat();
	}

	@Test(priority = 20)
	public void clickOnchatTest() throws InterruptedException {
		try {
			trans.clickOnchat();
			log.info("click on chat");
		} catch (Exception e) {
			log.error("Not able to click on chat");
		}
	}

	@Test(priority = 21)
	public void displayStatusOfCPusernameTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfCPusername(), true);
	}

	@Test(priority = 22)
	public void enableStatusOfCPusernameTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfCPusername(), true);
	}

	@Test(priority = 23)
	public void enterDataInCPusernameTest() throws InterruptedException {
		try {
			String User = excel.getDataFromExcelSheet(4, 4, 1);
			trans.enterDataInCPusername(User + UtilsLayerPackage.RandomIntData.randomInt());
			log.info("enter username");
		} catch (Exception e) {
			log.error("Not able to enter username");
		}
	}

	@Test(priority = 24)
	public void displayStatusOfCPemailTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfCPemail(), true);
	}

	@Test(priority = 25)
	public void enableStatusOfCPemailTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfCPemail(), true);
	}

	@Test(priority = 26)
	public void enterDataInCPemailTest() throws InterruptedException {
		try {
			String emailStart = excel.getDataFromExcelSheet(4, 5, 1);
			String emailEnd = excel.getDataFromExcelSheet(4, 5, 3);
			trans.enterDataInCPemail(emailStart + UtilsLayerPackage.RandomIntData.randomInt() + emailEnd);
			log.info("enter email");
		} catch (Exception e) {
			log.error("Not able to enter email");
		}
	}

	@Test(priority = 27)
	public void displayStatusOfCPphoneNumberTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfCPphoneNumber(), true);
	}

	@Test(priority = 28)
	public void enableStatusOfCPphoneNumberTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfCPphoneNumber(), true);
	}

	@Test(priority = 29)
	public void enterDataInCPphoneNumberTest() throws InterruptedException {
		try {
			String mobileNumber = excel.getDataFromExcelSheet(4, 6, 1);
			trans.enterDataInCPphoneNumber(mobileNumber + UtilsLayerPackage.RandomIntData.randomInt());
			log.info("enter phone number");
		} catch (Exception e) {
			log.error("Not able to enter phone number");
		}
	}

	@Test(priority = 30)
	public void displayStatusOfCPskillSetTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfCPskillSet(), true);
	}

	@Test(priority = 31)
	public void enableStatusOfCPskillSetTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfCPskillSet(), true);
	}

	@Test(priority = 32)
	public void selectSkillsetfromDPCPskillSetTest() throws InterruptedException {
		try {
			String skill = excel.getDataFromExcelSheet(0, 22, 1);
			trans.selectSkillsetfromDPCPskillSet(skill);
			log.info("select skill set");
		} catch (Exception e) {
			log.error("Not able to select skill set");
		}
	}

	@Test(priority = 33)
	public void displayStatusOfCPselectLanguageTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfCPselectLanguage(), true);
	}

	@Test(priority = 34)
	public void enableStatusOfCPselectLanguageTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfCPselectLanguage(), true);
	}

	@Test(priority = 35)
	public void selectSkillsetfromDPCPselectLanguageTest() throws InterruptedException {
		try {
			String language = excel.getDataFromExcelSheet(0, 23, 1);
			trans.selectSkillsetfromDPCPselectLanguage(language);
			log.info("select language");
		} catch (Exception e) {
			log.error("Not able to select language");
		}
	}

	@Test(priority = 36)
	public void displayStatusOfCPcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfCPcomplaintType(), true);
	}

	@Test(priority = 37)
	public void enableStatusOfCPcomplaintTypeTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfCPcomplaintType(), true);
	}

	@Test(priority = 38)
	public void selectSkillsetfromDPCPcomplaintTypeTest() throws InterruptedException {
		try {
			String complaintType = excel.getDataFromExcelSheet(0, 24, 1);
			trans.selectSkillsetfromDPCPcomplaintType(complaintType);
			log.info("select complaint type");
		} catch (Exception e) {
			log.error("Not able to select complaint type");
		}
	}

	@Test(priority = 39)
	public void displayStatusOfCPchatButtonTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfCPchatButton(), true);
	}

	@Test(priority = 40)
	public void enableStatusOfCPchatButtonTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfCPchatButton(), true);
	}

	@Test(priority = 41)
	public void clickOnCPchatButtonTest() throws InterruptedException {
		try {
			trans.clickOnCPchatButton();
			log.info("tab on chat button");
		} catch (InterruptedException e) {
			log.error("Not able to tab on chat button");
		}
	}
	@Test(priority = 42)
	public void navigatebacktoAgentPortalTest() {
		try {
			trans.navigatebacktoAgentPortal();
			log.info("navigate back to Agent 1");
		} catch (Exception e) {
			log.error("Not able to navigate back to Agent 1");
		}
	}
	@Test(priority = 43)
	public void displayStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfmessage(), true);
	}
	@Test(priority = 44)
	public void enableStatusOfmessageTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfmessage(), true);
	}
	@Test(priority = 45)
	public void clickOnmessageTest() throws InterruptedException {
		try {
			trans.clickOnmessage();
			log.info("tab on message");
		} catch (InterruptedException e) {
			log.error("Not able to tab on message");
		}
	}
	@Test(priority = 46)
	public void displayStatusOfacceptCallTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfacceptCall(), true);
	}
	@Test(priority = 47)
	public void enableStatusOfacceptCallTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfacceptCall(), true);
	}
	@Test(priority = 48)
	public void clickOnacceptCallTest() throws InterruptedException {
		try {
			trans.clickOnacceptCall();
			log.info("accept the call");
		} catch (InterruptedException e) {
			log.error("Not able to accept the call");
		}
	}
	@Test(priority = 49)
	public void displayStatusOfstartChatTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfstartChat(), true);
	}
	@Test(priority = 50)
	public void enableStatusOfstartChatTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfstartChat(), true);
	}
	@Test(priority = 51)
	public void clickOnstartChatTest() throws InterruptedException {
		try {
			trans.clickOnstartChat();
			log.info("start to chat");
		} catch (InterruptedException e) {
			log.error("Not able to start to chat");
		}
	}
//	@Test(priority = 52)
//	public void displayStatusOfmessageBoxTest() throws InterruptedException {
//		Assert.assertEquals(trans.displayStatusOfmessageBox(), true);
//	}
//	@Test(priority = 53)
//	public void enableStatusOfmessageBoxTest() throws InterruptedException {
//		Assert.assertEquals(trans.enableStatusOfmessageBox(), true);
//	}
	@Test(priority = 54)
	public void clickOnmessageBoxTest() throws InterruptedException {
		try {
			trans.clickOnmessageBox();
			log.info("click on message box");
		} catch (InterruptedException e) {
			log.error("Not able to click on message box");
		}
	}
	@Test(priority = 55)
	public void sendDataInMessageBoxTest() {
		try {
			String agent1Msg = excel.getDataFromExcelSheet(4, 13, 2);
			trans.sendDataInMessageBox(agent1Msg);
			log.info("enter message");
		} catch (Exception e) {
			log.error("Not able to enter message");
		}
	}
//	@Test(priority = 56)
//	public void displayStatusOfsendMsgTest() throws InterruptedException {
//		Assert.assertEquals(trans.displayStatusOfsendMsg(), true);
//	}
//	@Test(priority = 57)
//	public void enableStatusOfsendMsgTest() throws InterruptedException {
//		Assert.assertEquals(trans.enableStatusOfsendMsg(), true);
//	}
	@Test(priority = 58)
	public void clickOnsendMsgTest() throws InterruptedException {
		try {
			trans.clickOnsendMsg();
			log.info("send messge");
		} catch (InterruptedException e) {
			log.error("Not able to send messge");
		}
	}
	@Test(priority = 59)
	public void navigatetoCustomerportalTest() throws InterruptedException {
		try {
			trans.navigatetoCustomerportal1();
			log.info("navigate to customer portal and tab on chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to customer portal and tab on chat");
		}
	}
	@Test(priority = 60)
	public void enterDataInCPmessageBoxTest() throws InterruptedException {
		try {
			String cutomer1Msg = excel.getDataFromExcelSheet(4, 14, 2);
			trans.enterDataInCPmessageBox(cutomer1Msg);
			log.info("enter message");
		} catch (InterruptedException e) {
			log.error("Not able to enter message");
		}
	}
	@Test(priority = 61)
	public void enterDataInCPsendMsgTest() throws InterruptedException {
		try {
			trans.clickOnCPsendMsg();
			log.info("send message");
		} catch (InterruptedException e) {
			log.error("Not able to send message");
		}
	}
	@Test(priority = 62)
	public void navigatebacktoagent1Test() throws InterruptedException {
		try {
			trans.navigatebacktoagent1();
			log.info("navigate to Agent 1 and tab on start chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1 and tab on start chat");
		}
	}
	@Test(priority = 63)
	public void openChromeIncognitoTest() throws InterruptedException {
		try {
			trans.openChromeIncognito();
			log.info("open new incognito tab for agent 2");
		} catch (InterruptedException e) {
			log.error("Not able to open new incognito tab for agent 2");
		}
	}
	@Test(priority = 64)
	public void Agent2LoginTest() throws InterruptedException {
		try {
			String Username2 = excel.getDataFromExcelSheet(0, 28, 1);
			String Password2 = excel.getDataFromExcelSheet(0, 29, 1);
			trans.Agent2Login(Username2 , Password2);
			Thread.sleep(2000);
			log.info("enter username , password and click on login");
		} catch (InterruptedException e) {
			log.error("Not able to enter username , password and click on login");
		}
	}
	@Test(priority = 65)
	public void displayStatusOfstatus2Test() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfstatus2(), true);
	}
	@Test(priority = 66)
	public void enableStatusOfstatus2Test() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfstatus2(), true);
	}
	@Test(priority = 67)
	public void clickOnstatus2Test() throws InterruptedException {
		try {
			trans.clickOnstatus2();
			log.info("click on status");
		} catch (Exception e) {
			log.error("Not able to click on status");
		}
	}
	@Test(priority = 68)
	public void displayStatusOfgoready2Test() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfgoready2(), true);
	}
	@Test(priority = 69)
	public void enableStatusOfgoready2Test() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfgoready2(), true);
	}
	@Test(priority = 70)
	public void clickOngoready2Test() throws InterruptedException {
		try {
			trans.clickOngoready2();
			log.info("change status go ready to ready");
		} catch (Exception e) {
			log.error("Not able to change status go ready to ready");
		}
	}
	@Test(priority = 71)
	public void displayStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfclose2(), true);
	}
	@Test(priority = 72)
	public void enableStatusOfclose2Test() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfclose2(), true);
	}
	@Test(priority = 73)
	public void clickOnclose2Test() throws InterruptedException {
		try {
			trans.clickOnclose2();
			log.info("and close this one");
		} catch (Exception e) {
			log.error("Not able to close");
		}
	}
	@Test(priority = 74)
	public void gotoAgent1Test() throws InterruptedException {
		try {
			trans.gotoAgent1();
			log.info("navigate to Agent 1");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1");
		}
	}
	@Test(priority = 75)
	public void displayStatusOfconferenceToAgentTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfconferenceToAgent(), true);
	}
	@Test(priority = 76)
	public void enableStatusOfconferenceToAgentTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfconferenceToAgent(), true);
	}
	@Test(priority = 77)
	public void clickOnTransferToAgentTest() throws InterruptedException {
		try {
			trans.clickOnTransferToAgent();
			log.info("click on Transefer to Agent");
		} catch (Exception e) {
			log.error("Not able to click on Transefer to Agent");
		}
	}
	@Test(priority = 78)
	public void displayStatusOfchoseSkillSetTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfchoseSkillSet(), true);
	}
	@Test(priority = 79)
	public void enableStatusOfchoseSkillSetTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfchoseSkillSet(), true);
	}
	@Test(priority = 80)
	public void selectSkillSetFromchoseSkillSetTest() throws InterruptedException {
		try {
			String skill2 = excel.getDataFromExcelSheet(0, 30, 1);
			trans.selectSkillSetFromchoseSkillSet(skill2);
			log.info("select skill set to connect AGent 2");
		} catch (Exception e) {
			log.error("Not able to select skill set to connect AGent 2");
		}
	}
	@Test(priority = 81)
	public void displayStatusOfchoseLanguageTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfchoseLanguage(), true);
	}
	@Test(priority = 82)
	public void enableStatusOfchoseLanguageTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfchoseLanguage(), true);
	}
	@Test(priority = 83)
	public void selectSkillSetFromchoseLanguageTest() throws InterruptedException {
		try {
			String language2 = excel.getDataFromExcelSheet(0, 31, 1);
			trans.selectSkillSetFromchoseLanguage(language2);
			log.info("select language to connect Agent 2");
		} catch (Exception e) {
			log.error("Not able to select language to connect Agent 2");
		}
	}
	@Test(priority = 84)
	public void displayStatusOfavailableAgentTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOfavailableAgent(), true);
	}
	@Test(priority = 85)
	public void enableStatusOfavailableAgentTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOfavailableAgent(), true);
	}
	@Test(priority = 86)
	public void selectSkillSetFromavailableAgentTest() throws InterruptedException {
		try {
			String availableAgent = excel.getDataFromExcelSheet(4, 22, 1);
			trans.selectSkillSetFromavailableAgent(availableAgent);
			log.info("select available agent");
		} catch (Exception e) {
			log.error("Not able to select available agent");
		}
	}
	@Test(priority = 87)
	public void displayStatusOftransferTest() throws InterruptedException {
		Assert.assertEquals(trans.displayStatusOftransfer(), true);
	}
	@Test(priority = 88)
	public void enableStatusOftransferTest() throws InterruptedException {
		Assert.assertEquals(trans.enableStatusOftransfer(), true);
	}
	@Test(priority = 89)
	public void clickOntransferTest() throws InterruptedException {
		try {
			trans.clickOntransfer();
			log.info("click on transfer");
		} catch (InterruptedException e) {
			log.error("Not able to click on transfer");
		}
	}
	@Test(priority = 90)
	public void gotoAgent2andAcceptThaRequestTest() throws InterruptedException {
		try {
			trans.gotoAgent2andAcceptThaRequest();
			log.info("navigate to Agent 2 , tab on message , accept call and start chat");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 2 , tab on message , accept call and start chat");
		}
	}
	@Test(priority = 91)
	public void enterMsginAgent2MessageBox() throws InterruptedException {
		try {
			String Agent2Msg = excel.getDataFromExcelSheet(4, 15, 2);
			trans.enterMsginAgent2MessageBox(Agent2Msg);
			log.info("Enter the message");
		} catch (InterruptedException e) {
			log.error("Not able to Enter the message");
		}
	}
	@Test(priority = 92)
	public void clickOnSendMessagefromAgentPortalTest() throws InterruptedException {
		try {
			trans.clickOnSendMessagefromAgentPortal();
			log.info("send message");
		} catch (InterruptedException e) {
			log.error("Not able to send message");
		}
	}
	@Test(priority = 93)
	public void gotoagent1ToCheckMsgCommingOrNotandsignoutTest() throws InterruptedException {
		try {
			trans.gotoagent1ToCheckMsgCommingOrNotandsignout();
			log.info("navigate to Agent 1 for checking message is comming or not and then sign out");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 1 for checking message is comming or not and then sign out");
		}
	}
	@Test(priority = 94)
	public void gotoCustomer1ToCheckMsgCommingOrNotTest() throws InterruptedException {
		try {
			trans.gotoCustomer1ToCheckMsgCommingOrNot();
			log.info("go to customer portal");
		} catch (InterruptedException e) {
			log.error("Not able to go to customer portal");
		}
	}
	@Test(priority = 95)
	public void ClickandEnterMessageInCustomerMsgBoxandSendTest() throws InterruptedException {
		try {
			String Customer1Msg = excel.getDataFromExcelSheet(4, 17, 2);
			trans.ClickandEnterMessageInCustomerMsgBoxandSend(Customer1Msg);
			log.info("enter message and send");
		} catch (InterruptedException e) {
			log.error("Not able to enter message and send");
		}
	}
	@Test(priority = 96)
	public void sendMsgFromCustomerPortalTest() throws InterruptedException {
		try {
			trans.sendMsgFromCustomerPortal();
			log.info("enter message and send");
		} catch (InterruptedException e) {
			log.error("Not able to enter message and send");
		}
	}
	@Test(priority = 97)
	public void sendFileFromCustomerPortalTest() throws InterruptedException {
		try {
			String Customer1File = excel.getDataFromExcelSheet(4, 18, 2);
			trans.sendFileFromCustomerPortal(Customer1File);
			log.info("select file and send");
		} catch (InterruptedException e) {
			log.error("Not able to select file and send");
		}
	}
//	@Test(priority = 98)
//	public void moveToAgent1ForVerifiedTest() throws InterruptedException {
//		trans.moveToAgent1ForVerified();
//	}
	@Test(priority = 99)
	public void sendEmojiFromAgent1PortalTest() throws InterruptedException {
		try {
			trans.sendEmojiFromAgent1Portal();
			log.info("navigate to Agent 2 and send emoji");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to Agent 2 and send emoji");
		}
	}
	@Test(priority = 100)
	public void sendFileFromAgent1PortalTest() throws InterruptedException {
		try {
			String Agent1File = excel.getDataFromExcelSheet(4, 19, 2);
			trans.sendFileFromAgent1Portal(Agent1File);
			log.info("select file and send ");
		} catch (InterruptedException e) {
			log.error("Not able to select file and send ");
		}
	}

	@Test(priority = 101)
	public void clickOnendChat2Test() throws InterruptedException {
		try {
			trans.clickOnendChat2();
			log.info("tab on end chat");
		} catch (InterruptedException e) {
			log.error("Not able to tab on end chat");
		}
	}
	@Test(priority = 102)
	public void selectReasonforDisconnect2Test() throws InterruptedException {
		try {
			String reason2 = excel.getDataFromExcelSheet(4, 27, 1);
			trans.selectReasonforDisconnect2(reason2);
			log.info("select reason");
		} catch (InterruptedException e) {
			log.error("Not able to select reason");
		}
	}
	@Test(priority = 103)
	public void enterComment2Test() throws InterruptedException {
		try {
			String comment2 = excel.getDataFromExcelSheet(4, 28, 1);
			trans.enterComment2(comment2);
			log.info("enter comment");
		} catch (InterruptedException e) {
			log.error("Not able to enter comment");
		}
	}
	@Test(priority = 104)
	public void clickOnSUbmitandsignout2Test() throws InterruptedException {
		try {
			trans.clickOnSUbmitandsignout2();
			log.info("tab on submit and signout agent ");
		} catch (InterruptedException e) {
			log.error("Not able to tab on submit and signout agent");
		}
	}

	@Test(priority = 105)
	public void navigateToCustomerandendthecallTest() throws InterruptedException {
		try {
			trans.navigateToCustomerandendthecall();
			log.info("navigate to customer portal and tab on chat and end the call");
		} catch (InterruptedException e) {
			log.error("Not able to navigate to customer portal and tab on chat and end the call");
		}
	}
}
